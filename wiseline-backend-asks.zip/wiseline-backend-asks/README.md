# Wiseline — what the front end needs from the API

Sixteen asks, written from building the Trim board against the API as it stands today. Each one
says what is missing, why the board needs it, and what changes on our side once it lands.

## What is in here

| File | What it is |
| --- | --- |
| `asks.md` | The asks themselves, one section each. This is the document to work from. |
| `wiseline-spec.md` | The board's own requirements, as transcribed from the client's screens. Every ask cites it. |
| `screens/` | The four screenshots the asks point at by name. The rest live in the front-end repo under `docs/board-screens/`. |

## How the citations read

`p1 (507,291)` is a coordinate in the client's requirements board — page 1, that note. The quote
sits at that coordinate in `wiseline-spec.md`, so searching the file for `(507,291)` lands on it.
`screen (885,283)` is a screenshot, described in the same file and, for the four cited here, in
`screens/`.

## The asks, shortest first

**Query parameters that do not exist yet** — the client pulls a whole page and filters it in memory:

1. `role` on `GET /users/` — filter users by role.
2. `search` on `GET /warehouses/`.
3. `department` on `GET /priorities/` — priorities are created per department and never leave it,
   but the list endpoint returns every department's.

**Fields a record does not carry:**

4. `plate` on the truck.
5. `is_default` on the warehouse, exclusive across the table.
6. `color`, `gauge`, `width` on a coil lot — a cutlist is matched to a coil by colour.
7. `product_id` and `customer` on a Wrapping row.
8. `is_remanufacture` on a cutlist — a remake's own lists are marked on the board.
9. `trim_location` on a completed order, plus the PO, salesman and ship-via its footer carries.
10. The line item behind a cutlist row: `id_inven`, `description`, `quantity`, `pull_from_stock`,
    `status`, and the numeric `pm_item` id, which no cutlist response names.
11. A drawing per product — the sketch the bendlist's last column shows.

**Endpoints that do not exist yet:**

12. `PATCH`/`DELETE /coils/filters/{id}/` — a coil filter can be created and never changed.
13. `GET /wrapping/orders/{order}/packages/` — the packages of an order still being wrapped.
14. Stock Manufacturing: record pieces the floor made against no order and push them to EBMS.
15. An upload a Stock Card can point at: `image_id` is required to create one, and
    `POST /files/models/` accepts only `PackageItem`, `Package` and `Skid` — so no client can create
    a stock card at all.

**And one that is a data-shape bug rather than a missing feature:**

16. Line items of a fresh EBMS order are created with `department_id = NULL`, so every
    department-scoped endpoint answers `400 No line items of this order belong to that department`.
    This one blocks scheduling outright — it is the first thing to look at.

## Where the front end stands

The Trim board is built: Unscheduled, Scheduled, Production (Slinet, the machines and Wrapping),
Coils, Calendar and Completed, plus the Settings pages for priorities, machines, locations and
location types. Everything in this document is a place where a screen is built but a column, a
button or a whole window has nothing to read from or write to.
