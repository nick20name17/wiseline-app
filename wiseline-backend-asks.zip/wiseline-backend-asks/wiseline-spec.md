# Wiseline — product documentation from the workflow board

Source: `Copy of Overall Workflow.pdf` (Canva board by Wiselinetrimshop, exported 2026-08-17, 3 pages of
1440 × 810 pt). Every requirement below is quoted **verbatim** from the board and ends with the `(x, y)`
PDF-point coordinate of the text block it came from, so it can be found on the board again. Headings,
grouping, lead-ins and screenshot descriptions are editorial; requirement sentences are not paraphrased
and typos are left as written.

Every UI screenshot embedded on the board (640 of them) is transcribed under a **Screens** heading inside
the section it illustrates: window/tab titles, controls and their enabled state, table columns and the
visible rows, badges and colours, dialog text. `Screen (x,y)` is the screenshot's top-left corner on the
board; `File` is the extracted image name (`p<page>_<n>_x<x>_y<y>.png`), stored in [board-screens/](./board-screens/) at native resolution, with `index.json` mapping each file to its page and bbox. Screens whose section could not
be matched to a heading are listed under "Other screens on this page". Besides the screenshots the board
embeds only two other raster graphics: a green dot (the "note read" marker, 38 × 30 px, three copies) and a
red-orange gradient square (192 × 192 px) used as the background of the bare "?" markers on pages 2 and 3.
Arrows and connectors are vector shapes; the flow they express is reflected in the section order only.

Transcriptions were produced once, then re-verified entry by entry against the images in two further passes; entries carry `Verified: pass3`. Three random audits of 60–72 entries measured the residual error rate after each pass: ~32% major → ~7% → ~3%.

This is a structured transcript of the board, not an interpretation. Anything the board leaves
ambiguous is collected under "Unclear / open questions" at the end of each page section rather than
resolved here. The verification checklist that tracks which of these the port actually satisfies is
[canvas-requirements.md](./canvas-requirements.md).

Vocabulary used on the board: **EBMS** is the ERP the orders and notes come from. A **department** is
called a *category* in EBMS; the board writes "department (category)". Departments on the board: Trim,
Rollforming, Shipping, plus an Accessories flow attached to Shipping.

## Contents

- [Synthesis — consolidated model](#synthesis--consolidated-model)
- [Board-wide notes](#board-wide-notes-legend-priorities-warehouseslocations-machines)
- [Page 1 — Trim](#page-1--trim)
- [Page 2 — Rollforming](#page-2--rollforming)
- [Page 3 — Shipping](#page-3--shipping)

---

## Synthesis — consolidated model

This section consolidates facts scattered across the three-page board transcript below. Every statement
carries at least one page-qualified `(x, y)` coordinate back to the requirement or screen it is drawn
from. Contradictions and silences are listed in §12 rather than resolved.

### 1. Departments and roles

Departments (called "category" in EBMS): Trim, Rollforming (with an attached Slit Line), Shipping, and
Accessories (attached to the Shipping flow) p1 (1059,206) / p3 (1315,296). Each department is "completely separate
from the others" — one department can Release To Production without any other department scheduling
first p1 (1059,206), p2 (793,228), p3 (558,147).

| Role | Scope | Source |
|---|---|---|
| Admin | "Admin should be able to do everything in every Department (category)." | p1 (1045,211), p2 (774,232), p3 (548,150) |
| Manager (per department) | "Should be able to see and edit everything from here down. Including what the Worker can see and do." Only the Manager can set Priorities. | p1 (289,240) Trim; p2 (508,258) Rollforming; p3 (575,172) Shipping; "Only the Manager can set Priorities" p1 (241,403), p2 (498,394), p3 (1135,292 Accessories) |
| Worker (per department) | Sees "a list of the released uncompleted orders/line items," no day-of-week picker, sorted primarily by Production/Prep Date with a distinct line between days; "Workers can NOT change Priorities." | p1 (667,260) Trim, p2 (1034,272) Rollforming Worker, p2 (935,297) Rollforming Queue mirrors Manager but unsorted by Priority, p3 (1242,183) Accessories Worker; "Workers can NOT change Priorities" p1 (560,284), p2 (1100,299)/(1204,298), p3 (1264,197) |
| Driver (Shipping) | Checks packages loaded, checks off leaving warehouse (→ En Route), marks Delivered. | p3 (592,489)-(592,558) |

Salesmen "push orders into the app" from EBMS p1 (1051,207), p2 (786,228), p3 (552,147) — this is the
sole intake path ("All Unscheduled").

Sign-in / location defaulting: location pickers default to the department the signed-in Worker belongs
to, but the Worker can still pick a different department's locations — stated once per department (Trim
p1 (698,115), Rollforming p2/Wrapping (1143,331), Accessories p3 (1238,258)). No separate statement of
how a user's department assignment itself is set at sign-in (see Open points).

### 2. Navigation map

- **Trim** (p1 (81,286) et seq.)
  - Unscheduled / Scheduled / Production / Coils tabs, plus "Completed orders for the past 90 days" pill p1 (81,286)
  - Production tab sub-tabs: Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping p1 (660,522) — each with its own "Completed cutlists/bendlists for the past 90 days"
  - Wrapping tab has its own Completed Orders tab p1 (895,543)
- **Rollforming** (p2)
  - Unscheduled / Scheduled / Queue / Production / Wrapping tabs, machine sub-tabs: Tuff Rib & Diamond Rib, Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated, Slit Line p2 (549,461)
  - Scheduled tab is per-Machine ("Go to the Scheduled tab and choose the Machine you want to Manage" p2 (543,392))
  - Completed Orders tab p2 (1161,398)
- **Shipping** (p3)
  - Unscheduled / Scheduled tabs; Scheduled is per-Truck, each Truck has Load sub-tabs (Load 1, Load 2, …) p3 (594,308), (605,397)
  - Loading window (separate from Scheduled) p3 (598,468)
  - Route map per Load p3 (601,415)
- **Accessories** (attached to Shipping, p3 (1315,296))
  - Unscheduled / Scheduled / Packaging tabs; Completed Orders tab p3 (1252,374)
- **Admin tab bar** (repeated per department, p1 (504,59)): Users / Machines / Warehouses / Location Type /
  Locations (typo'd "Loactions" in the UI, p1 (807,64)) / Trucks / Priorities, each with department sub-tabs
  (Trim / Standing Seam / Rollforming / Board & Batten / Accessories[/ Shipping]) p1 (504,59)
  - Machines admin: per-department accordions with machine counts; Rollforming row additionally has a
    "Coil Suppliers" popup (add/remove suppliers) p1 (807,64)-(807,77)
  - Priorities admin: Colour | Names | Hierarchy | Actions table, department-scoped p1 (504,59)-(504,59)
  - Warehouses / Location Type / Locations admin: create flows detailed in §3

### 3. Entities and fields

**Order** — Entry Date, Ship Date (Prep Date for Accessories, Production Date once scheduled), Order #,
Priority, Customer Name, Order Notes, Reviewed, Status, Location(s). Stock Orders: no Ship Date, no Order
Note, Order# prefixed "S" in its own numbering series, Customer Name = "Stock", Location = "N/A" p1
(163,341)-(163,345), (149,402). EBMS-origin fields (PO, Salesman, Ship Via, Address, City, Gauge/Color) appear on
Shipping/Rollforming order rows p2 Screen (475,300), p3 Screen (595,185).

**Line item** — Qty Ordered, Vented (toggle, Trim/Slinet only), Machine, Stock (qty pulled from stock),
Status, Product ID, Description, Width, Length, Line Item Notes; Rollforming variant: # From Stock, Qty
To Produce, Supplier/Coil Number, Length only (no Width) p2 (650,492). Width and Description are editable
in the Scheduled tab and "DON'T need to push back to EBMS" p1 (326,422).

**Stock Card** — Product ID (must be valid/active EBMS ID), Description (auto-filled from EBMS, not
editable), Stock Minimum, Order Qty, Upload Image; all 5 fields required before Create enables p1
(71,307)-(72,321). Printed as QR-coded label with profile sketch p1 (197,323).

**Stock Order** — created from Qty + Product ID pairs, manually or by scanning a Stock Card's QR p1
(125,318); enters Unscheduled tab, then scheduled like a customer order p1 (138,337), (146,355).

**Cutlist / Bendlist** — auto-created on Release To Production, grouped by Production Date + Gauge/Colour
+ Priority (Trim, p1 (206,419)) or by matching multiple axes for Rollforming Queue (Production Date,
Color/Gauge, Profile, Priority, Supplier, Coil Number, cutlist-request-or-coil p2 (493,630)). "Never adds
to an existing cutlist" — a later Release creates a new one even if Gauge/Colour matches p1 (459,287), p2
(648,283). Sort: primarily width, then length, ascending p1 (461,327), p2 (650,330).

**Coil** — Product ID, Color, Width, Count (lots), Total Linear Feet, Total Weight p1 Screen (300,589); a Lot
has Coil Thickness, Material Thickness, Core OD, Linear Feet, Weight, and department checkboxes
(Rollforming / Trim / Slinet) p1 (342,648), and an optional coil Note p1 (300,607). Coil Filter admin window:
Thickness/Width/Grade ranges, "Apply All" checkbox for a limitless range p1 (287,612).

**Warehouse** — Name, Address, Description, Default flag (one default warehouse opens first) p1 (625,72),
(543,104), (611,98).
**Location Type** — Name, Warehouse, Description; created per department p1 (669,72), (653,98).
**Location** — Name, Warehouse, Location Type, Max Weight, Description, Multi Order (bool + Number of
Orders when true) p1 (710,72), (696,107). "All Location Names have to be unique within the entire app" p1 (691,88).
Multi Order: usable N times before becoming unavailable, resets to available as soon as it's removed from
1 of the N orders p1 (754,109).

**Package / Label** — 3-part code: department ID + order number + sequential package number for that
order p1 (876,427), p2 (1010,449), p3 (1238,294); department codes example Trim=01, Rollforming=02, Accessories=03
p1 (868,427).

**Truck / Load** — Truck: Weight Limit, Truck Notes. Load: sequence of orders, Status, total weight
p3 (586,378), Screen (598,305). Route: map + drag-to-reorder delivery sequence p3 (617,441).

**Priority** — Colour, Name, Hierarchy number (lower number = sorts first) p1 (495,64), (504,59); per-department,
created independently, assigning a Priority in one department doesn't affect the same line items in
another p1 (488,58).

**Note** — Order Note (from EBMS/Salesman, red=unread/green=read-and-dealt-with, X leaves it red) p1
(224,328)-(223,349); Line Item Note (app-only, doesn't sync to/from EBMS, same red/green semantics, re-flags red
if a second unread note is added) p1 (380,408)-(379,466).

**Machine** — Name (must exactly match the "Profile"→Machine mapping name used in EBMS "Roll Options")
p2 (541,284), (516,277); belongs to a department, has capacity totals (pieces, bends) shown in Machine
Capacities popup p1 (251,486).

### 4. Status state machines

**Trim — order Status**

| From | To | Trigger | Badge colour |
|---|---|---|---|
| (none) | Not Started | Order Released To Production | grey p1 (300,489) |
| Not Started | In Progress | ≥1 trim reaches Cut/Bent/Wrapped | yellow p1 (300,504) |
| In Progress | Wrapped | all trims reach Wrapped | green p1 (289,505), (300,504) |
| any | Bypassed | Manager clicks Bypass Production | purple p1 (261,537) |
| Bypassed | Wrapped | a Worker wraps the trim | — p1 (252,578) |

**Trim — line item Status**: Not Started → Cut (Slinet) → Bent (Machine) → Wrapped; or → Stock (Stock qty
== Qty Ordered) → Wrapped; or → Bypassed → Wrapped. "Bent needs to override Cut" if marked Bent before
Slinet marks Cut p1 (686,329). Colours seen: Cut=blue p1 (300,518), Bent=red p1 (300,518)/(660,522), Wrapped=green p1
(300,518), Stock=yellow p1 (300,518)/(300,436), Bypassed=purple p1 (300,541).

**Trim — Slinet/Machine cutlist Complete flow**: row Complete toggle No→Yes crosses the row out, no
confirm popup; Yes→No requires confirm p1 (499,334)-(499,338), p1 (686,329)-(653,358). All rows Complete ⇒ Done
button enables ⇒ Done removes the cutlist/bendlist to the Completed tab for 90 days, same formatting p1
(463,351)-(499,515), (688,378)-(687,411).

**Remanufacture/Recut column** (Slinet: "Recut"; Machine/Wrapping: "Remanufacture"): orange while
outstanding, turns green once the Slinet marks the material Cut (Complete) p1 (519,586)-(478,590), (686,514). A
Remanufacture entry in Wrapping spins off a brand-new cutlist+bendlist inheriting Production
Date/Gauge-Colour/Priority/Machine p1 (647,494), (848,634); the new bendlist shows only the remanufacture qty,
not the full order qty p1 (612,482), whereas a Remanufacture row *originating in* a Machine tab shows the
full Qty Ordered plus the remanufacture qty p1 (653,546).

**Rollforming — order/line item Status**: Not Started → In Progress (≥1 line item Rolled or Wrapped) →
Wrapped (all Wrapped) p2 (540,625); line item: Not Started → In Progress (Left To Package ≠ 0 and ≠ Qty
Ordered) → Rolled (Left To Package = 0) → Wrapped (once its package gets a Location) p2 (930,500)-(941,521),
(1144,366). Stock line items skip straight Stock → Wrapped, never shown as In Progress/Rolled p2 (941,521).

**Rollforming Slit Line icon**: material assigned "waiting..." (yellow scissors, Supplier/Coil Number
locked) → slit performed by Slit Line Worker → coil icon turns green scissors and Supplier/Coil Number
auto-fill p2 (1051,333), (1086,349), (1111,434), screen sequence p2 (1061,331)-(1061,350).

**Shipping — Load/order Status**: Not Started → Loading (first package on the Load marked Loaded) →
Loaded (order: all its packages Loaded; Load: all packages of all its orders Loaded) → En Route (Driver
checks "left the warehouse" — order checkboxes then lock) → Delivered (order) → Delivered/Completed
(Load, once all its orders are Delivered) p3 (592,489)-(605,580); screens show a further "Completed" green
badge on the Load p3 (598,538).

**Accessories — order/line item Status**: Not Started → In Progress (part packaged) → Packaged (all
packaged) p3 (1077,291), (1079,307), (1324,286). "If part of a line item is packaged... In Progress. Example: 2 out
of 4 bags of screws packaged shows In Progress" p3 (1079,307).

### 5. Scheduling, capacity and sorting rules

- Every day tab shows `(used / capacity)` e.g. "1000/5000" p1 (81,286), and the Machine Capacities popup
  breaks that down per machine as `Pieces` and `Total Bends / Daily Max` p1 (278,488), (251,486), including a
  separate Stock sub-total that is *part of*, not additional to, the shown total p1 (278,510).
- **Production Date** (Trim/Rollforming) is set when scheduling from Unscheduled; **Ship Date** comes
  from EBMS/order intake; Accessories uses **Prep Date** instead of Production Date, sorted "primarily by
  Prep Date and secondarily by Priority" p3 (1111,291), (1285,195).
- Scheduled-tab sort: primarily Production Date, secondarily Priority (by hierarchy) p1 (208,402); Worker
  cutlist/bendlist tabs: Production Date → Priority → Gauge/Colour (Trim) p1 (498,284) or → ID (Wrapping) p1
  (912,281); Rollforming Queue: Production Date only for the Worker (no Priority sort) p2 (935,297) but
  Manager's Queue additionally factors Color & Gauge, Profile, Priority, Supplier, Coil Number for
  combining rows into one p2 (493,630).
- Distinct lines are required between: days p1 (667,260), colours in Allocated Stock p1 (336,554), Product IDs
  in Rollforming line-item lists p2 (571,303), (681,413), Production Dates in the Rollforming Queue p2 (499,635).
- Overdue highlighting cascades: day tab red → calendar date red → rows/cutlists/bendlists/Loads red,
  restated near-verbatim for every department (Trim p1 (293,540)-(326,574); Rollforming Scheduled/Queue p2
  (495,675)-(574,704); Shipping p3 (593,591)-(605,628); Accessories p3 (1079,315)-(1079,325)).
- Rescheduling/unscheduling: only allowed pre-Release; unscheduling returns the order to Unscheduled "like
  a new order again" and resets any Manager edits p1 (343,526), p2 (589,646).
- Split/partial scheduling: selecting ≥1 line item enables Split Order (disables the order-level schedule
  checkbox); scheduled-away line items show greyed/uneditable in the Unscheduled and Scheduled tabs; a
  split icon marks both resulting sub-orders p1 (286,309)-(330,354), p2 (570,349)-(568,353).

### 6. Release to production / cutlist & bendlist generation

- Release To Production checkbox only available once Reviewed p1 (149,442); Release is a toggle — no popup
  turning On, confirm popup turning Off p1 (144,435); usable while order collapsed or expanded p1 (144,435).
- Selecting a Stock Order for Release locks out Customer Order checkboxes (and vice-versa); with multiple
  Stock Orders, selecting one leaves the other Stock Orders selectable but Customer Orders stay locked p1
  (127,467)-(127,491).
- Grouping key for generated cutlists/bendlists: **Production Date + Gauge/Colour + Priority** (Trim) p1
  (206,419); worked example: 7 same-Gauge/Colour orders with mixed priorities split into 5 lists — NOW, the 2
  ASAP orders combined, By 10:00, By 3:00, and the unprioritised rest p1 (206,419). Each Wrapping line item
  inherits the order's Priority p1 (206,419).
- Vented trims: Manager toggles Vented per line item (defaults off); for the Slinet cutlist only, Vented
  quantity is pulled out of the assigned Machine column into a separate "Vented" column, but the piece
  still shows in the assigned Machine's own tab too p1 (261,419)-(252,429).
- Bypass Production: skips Slinet/Machine tabs entirely, no cutlist/bendlist created, line items land
  directly in Wrapping with Status Bypassed; Production Date auto-set to the current date p1 (227,378)-(240,386).
- Rollforming coil assignment: "Select Supplier/Coil Number" or "Create Cutlist" — Manager can leave
  Supplier+Coil Number Undefined, assign Supplier only, or assign both; Coil Number is only selectable
  once a Supplier is chosen p2 (678,456)-(563,488). The coil-number lot list is built from any EBMS Product ID
  with the same Color+Gauge as the target Product ID and Production Type = Coil p2 (597,543)-(615,581). If left
  Undefined, "the Worker can use any Coil Number from any Supplier" p2 (709,408).
- Coil depletion/adjustment (Cutlist Coils / Coil Adjustment window): candidate coils are those checked
  into the Slinet matching the cutlist's Color (Gauge/Width irrelevant) p1 (426,341)-(463,379); entering Coil
  Thickness recalculates Linear Feet/Weight (Material Thickness + Core OD must be present first) p1
  (292,630), (351,681); entering "0" thickness triggers "Deplete & Delete Coil" which zeroes it in EBMS and
  deletes it from the App p1 (263,658), (521,424)-(512,450); otherwise "Make Adjustment" pushes the new Linear Feet
  back to EBMS p1 (294,658).
- Department coil checkboxes are mutually exclusive: Trim+Slinet can both be checked but Rollforming then
  locks out; checking Rollforming locks out Slinet; Slinet is only selectable once a Coil Thickness is
  present p1 (327,675)-(344,702).

### 7. Wrapping / packaging / locations

- Auto Fill fills the whole Left To Wrap/Package amount into the Wrapping/Packaging column and turns into
  a Delete button; Worker can instead type any number 1..Left To Wrap manually p1 (845,342)-(838,373), p2
  (963,404)-(961,428). Once Left To Wrap/Package hits zero the Status auto-flips to Wrapped/Rolled/Packaged and
  Auto Fill greys out p1 (877,459), p2 (1009,464).
- Select Location becomes available once any Wrapping/Packaging amount is entered p1 (878,358), p3 (1239,249);
  location picker defaults to the signed-in Worker's department but any department is selectable p1 (876,366).
- Over Weight package: box turns red, Create & Print prompts an override-confirm popup p1 (940,365)-(951,365).
- Over Weight on a Location (package + existing packages > location Max Weight): location name highlights
  red, Create & Print prompts a confirm popup; declining forces picking another location, accepting
  overrides and keeps the location name red p1 (846,414)-(797,464).
- Multiple locations: selecting a 2nd location adds it to the order; the first location then highlights
  orange ("do not put any more packages on that location") p1 (937,395)-(861,462).
- Removing a location requires confirmation; an order with existing packages must always have ≥1 location
  — removing the last one forces picking a new one p1 (937,437), (950,475), p3 (1291,329), screen confirming a hard
  block popup p3 (1272,331).
- Location reset: "removed from an order manually" OR "When the last trim package has been scanned onto
  the truck by shipping, then after 15 mins. the location becomes available again (reset)" p1 (972,396), p3
  (1305,283)-(1306,286) — phrased identically for Accessories.
- Deleting a package: confirm popup; returns its pieces to Left To Wrap/Package; the package number
  becomes permanently invalid ("scan... will need to get a message that this package has been deleted");
  if the line item's Status was already Wrapped/Rolled/Packaged it reverts to Bent/Rolled/Not Started (or
  to Stock if Qty Ordered == Stock qty) p1 (852,480)-(808,536), p2 (995,488)-(966,559), p3 (1199,368).
- Completing an order: Order Complete enables once Left To Wrap/Package is all zero; confirm popup;
  pushes a manufacturing batch to EBMS (Qty Ordered minus amount pulled from Stock); order disappears
  from Wrapping/Packaging and appears in Completed Orders (90-day view) p1 (879,506)-(903,543), (912,545), p3
  (1263,354)-(1258,373).
- Rollforming-specific: order only leaves Wrapping for Completed Orders once the *last* package gets a
  Location, which also stamps Completed Date & Time p2 (1144,383).

### 8. Shipping

- Scheduling (Unscheduled → Scheduled): pick Ship Date, select Delivery Orders and/or Pickups
  ("Pickups" = supplier pickups for the driver, not customer pickups) p3 (586,243)-(586,248); truck checkbox
  only available once a Ship Date is chosen p3 (562,244); Assigned Weight over a truck's Weight Limit
  highlights orange but does **not** block assignment — "the Manager will just have to divide up the
  orders into multiple loads for this truck" p3 (587,259); Apply moves the orders into Scheduled under the
  chosen Date/Truck p3 (566,273).
- Load assignment: select orders → Add To Load button enables; Add To Load assigns the Load number in
  place of the checkboxes, sets Status Unreleased, and spawns the next empty Load tab p3 (591,357)-(592,359).
- Route: opens a map, drag-and-drop reorders delivery sequence which also reorders the map route p3
  (601,415)-(617,441).
- Release To Loading: moves the Load into the Loading window, sets Load and order Statuses to Not Started
  p3 (598,468).
- Status progression is in §4; Driver actions are "left the warehouse" (→ En Route) and implicitly
  marking packages Loaded / orders Delivered p3 (592,540)-(605,580) (exact Driver-facing screen/controls for
  marking Delivered aren't transcribed on this board — see Open points).

### 9. Notes

- **Order Notes**: sourced from EBMS/Salesman only, never created in-app, never write back; red = unread,
  green = read/dealt-with (checkmark), clicking X leaves it red p1 (224,328)-(223,349); Stock Orders never have
  an Order Note p1 (163,345).
- **Line Item Notes**: app-only, both Manager and Workers can add/view at any point in production/
  packaging, never sync to/from EBMS p1 (380,408), p2 (526,410), p3 (1069,296), (1230,226); same red/green semantics; a
  second unread note re-flags the thread red even after the first was cleared p1 (379,466).
- Threads can hold multiple notes stacked in one popup, each with its own author avatar/initials, email,
  timestamp, and independent read state p1 (366,442).

### 10. Priorities

- Department-specific; each department creates its own; assigning a Priority in one department doesn't
  touch the same order's line items in another department p1 (488,58).
- Hierarchy: a numeric rank controls sort order, "if a Priority has the number 1 assigned to it, it will
  always appear on top of all the other priorities" p1 (495,64).
- Only the Manager sets Priorities; Workers cannot change them p1 (241,403), (560,284), p2 (1100,299).
- Colours observed: **NOW** = red, **ASAP** = orange, **By hh:mm** (8:00…5:00) = yellow p1 (504,59), (137,454).
- Priority always loses to Production/Ship/Prep Date in sorting — a prioritized row still sorts below an
  earlier-dated row p1 (526,316), p2 (943,305), p3 (1285,202).

### 11. EBMS integration points

- Orders and their Order Notes originate in EBMS via Salesman push; nothing else creates an Order Note
  p1 (1051,207), (224,328).
- Stock Card Product IDs "have to be valid, active IDs in EBMS"; Description auto-fills from EBMS and is
  not editable p1 (71,307).
- Manufacturing batches are pushed to EBMS on Order Complete / Create Manufacturing Batch, computed as
  Qty Ordered minus amount pulled from Stock p1 (763,485), (911,535), p2 (4027 implied via Wrapped status),
  p1 (697,492).
- Coil data: EBMS "Production tab" fields feeding the App — Production Type, Gauge, Thickness, Width,
  Grade, Color p1 (226,607)-(226,607); Linear Feet is the EBMS "main unit," pushed into the App, and the App
  computes Weight from Linear Feet and Gross Weight p1 (350,613)-(350,616); new EBMS coils appear automatically
  in the matching folder tab once they qualify per the Coil Filter thickness/width/grade ranges p1 (253,609),
  (253,624).
- Coil Adjustment "Apply" pushes the new Linear Feet amount back into EBMS; "Deplete & Delete Coil"
  zeroes the coil out in EBMS and deletes it from the App p1 (263,658), (294,658).
- Rollforming Machine assignment is driven by the "Profile" field, which is matched against the EBMS
  "Roll Options" tab; the Machine name in the App "has to exactly match" the Machine name given in EBMS
  p2 (541,284), (516,277), (541,284).
- Width/Description edits made in the Scheduled tab explicitly "DON'T need to push back to EBMS" p1
  (326,422) — an intentional one-way exception to the otherwise EBMS-sourced fields.
- Stock Orders are explicitly excluded from EBMS-origin fields: no Ship Date, no Order Note (both "come
  from EBMS" for real orders) p1 (163,341)-(163,345).

### 12. Open points and contradictions

- Two bare `?` / `?????????` placeholder markers with no explanatory text: p1 (814,473) in the
  Wrapping/packaging area, and p1 (613,109) in the Warehouses/Locations flow.
- p1 (1272,231): the "Rescheduing or Unscheduing an Order" and "Reviewing Order / Reviewing a Stock Order /
  Priorities" numbered callouts (1/2/3) appear to be diagram flow-sequence markers, not prose — exact
  intended order isn't stated.
- p2 (531,277)-(531,277): four more unexplained `?` / bare "Here" callouts near the default-Warehouse note, the
  Scheduled-tab line-item display note, and the cutlist section.
- p3 (1260,183)-(1305,283): a large cluster of ~26 unexplained `?` markers throughout the Accessories Packaging
  flow (weight overrides, multiple locations, deleting/reprinting packages, overdue, completing an
  order) — the board never resolves what each one is asking; many corresponding "Update Image"
  placeholders were also never filled in, so those UI states aren't documented anywhere on the board.
- p3 (1305,283): two near-duplicate location-reset rules joined by "or" — "removed from an order manually"
  vs. "15 mins. after the last package is scanned onto the truck" — unclear whether these are
  alternative triggers or must both eventually occur.
- p3 (1315,296): the Accessories sub-flow's structural relationship to Shipping is only a "See Shipping
  Department" cross-reference arrow p3 (1315,296); whether it is truly part of the Shipping department or
  a separate department misplaced on the same sheet is not stated.
- Mock typos worth knowing, transcribed verbatim: admin tab label "Loactions" (should be "Locations") p1
  (807,64), p2 admin screens; "J- Channel White White" (duplicated "White") on a Stock Manufacturing modal
  p1 (1011,322); "Reversed Diamind Rib" in the Rollforming Profile column p2 (943,296); "trimworker@gmail.caom"
  malformed email on a Line Item Note p1 (366,442); one screen's ID column literally repeats "OSC" where the
  adjacent row should read "ISC" p3 (1244,307), (1244,307) — flagged in the transcript itself as a probable mockup
  data artifact, not a design decision.
- Priority column contradiction: the text says Workers "can NOT change Priorities" p1 (560,284) and that
  Priority is Manager-only p1 (241,403), yet several **Worker**-facing Production/Wrapping screens render a
  fully populated, colour-coded Priority column inline in the row (e.g., p1 (916,283) Wrapping table, p2
  (1017,312) Rollforming Production) — consistent with *display* but never explicitly confirmed as
  read-only there; no screen shows a Worker attempting to edit it, so the contradiction is only about
  whether the column is rendered as interactive.
- No explicit rule is given for how a user's home department is assigned at sign-in (only that location
  pickers "default to the department the Worker is signed into" p1 (698,115), p2 (1143,331), p3
  (1238,258)) — sign-in flow itself (credentials screen, department switch UI) is not transcribed anywhere
  on the board.
- Driver role is only described through the effects of its actions on Load/order Status (§8); no Driver-
  specific screen (e.g. a mobile "mark delivered" UI) appears in the transcribed screenshots.
- The Rollforming Queue's Priority handling is stated twice slightly differently: "Priorities need to show
  here... but NOT be sorted by Priority" for the Worker p2 (935,297), while the Manager's Queue combining
  rule lists Priority as one of the match keys for merging rows p2 (493,630) — these describe different
  operations (display sort vs. row-combining key) but the two "Priority" mentions could be misread as
  contradictory without noting that distinction.

---

## Board-wide notes (Legend, Priorities, Warehouses/Locations, Machines)

The same header block sits at the top of all three pages. Coordinates below refer to page 1.

#### Legend

Color-coded key (green / blue / yellow swatches) for **Roles**, **Actions**, **Notes** (306,19)-(385,74):
- Roles (342,48)-(346,50)
- Actions (342,59)-(348,62)
- Notes (342,71)-(347,74)

#### Overall Notes

Top-of-page notes shared across departments, branching into Priorities, Warehouses/Locations, and Machines, Rollforming (536,4)-(638,25).

###### Priorities (497,41)-(536,52)

- "Priorities need to be department (category) specific. Each department (category) needs to be able to create their own Priorities. When a Priority is assigned to an order in a department (category), it should only assign that Priority to that order within that department (category). For example, if the Trim department (category) assigns a "By 10:00" Priority to an order, that should only affect the trims on that order. It should not assign that Priority to any of the other line items and departments (categories)." (488,58)
- "We need to be able to create a hierarchy on how Priorities will be sorted. So, if a Priority has the number 1 assigned to it, it will always appear on top of all the other priorities." (495,64)
- Only the Manager can set Priorities (241,403) — noted again under Trim Production.

###### Warehouses/Locations (576,41)-(671,52)

- First you would have to create a Warehouse (620,58)
- Second you would have to create a Location Type (663,59)
- Third you would have to create a Location (706,59)
- Select Warehouses (610,63) / Select Location Types (654,63) / Select Locations (699,63)
- "We need to be able to create these Location Types for each department (category) independently." (648,64)
- "We need to be able to create these Locations for each department (category) independently." (691,64)
- Select the department (category) you want to create a Location Type for. (660,68)
- Select the department (category) you want to create a Location for. (703,68)
- "Clicking this button would open this window where you would enter the Name, Address and Description of the Warehouse you want to create." (625,72)
- "Clicking this button would open this window where you would enter the Name and Description of the Location Type you want to create. You would also select a Warehouse from the dropdown of existing Warehouses." (669,72)
- "Clicking this button would open this window where you would enter the Name, Max Weight and Description of the Location you want to create. You would also select a Warehouse from the dropdown of existing Warehouses, a Location Type from the dropdown of existing Location Types within that Warehouse and you have to decide if this is a Multi Order location." (710,72)
- "All Location Names have to be unique within the entire app, can never be doubled up." (691,88)
- Yes A Multi Order Location (711,98) / Not A Multi Order Location (704,101)
- "If you want this to be a Multi Order Location than you would toggle "On" the Multi Order button. This would make the Number of Orders text box become available and you would have to enter how many orders can be in this location." (731,91)
- "A Multi Order Location would allow you to use the location multiple times (for multiple orders) before becoming unavailable, within the Max Weight limit. This example would be able to be used 12 times (for 12 different orders) before becoming unavailable, within 3500 lbs. If this location has been assigned to 12 different orders, then as soon as it has been removed from 1 of those orders it becomes available again." (754,109)
- "If we have multiply Warehouses then there needs to be a way to select the default Warehouse. This default Warehouse would be the one that opens first when selecting a location." (543,104)
- Fields shown on a location record: Name (Location) (695,113), Warehouse (702,126), Location Type (705,128). An unlabeled `?` block also appears here (613,109).
- "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into. Example: If a Worker in the Trim department (category) goes to select a location, the location window needs to default to Trim locations. That being said the Worker should still be able to choose a different department (category) to select a location there too." (698,115)
- "This is how locations would show up in production when Workers are selecting locations." (722,125)

###### Machines, Rollforming (772,47)-(866,58)

- "Clicking this button would open this window where you would be able to create a list of coil suppliers." (821,73)

#### Screens — admin setup (13)

Admin screens for Warehouses, Location Types, Locations and Machines, in board order.

##### Screen (504,59) — Admin Priorities tab
- File: `p1_120_x504_y59.png`
- Illustrates: "We need to be able to create a hierarchy on how Priorities will be sorted..." (495,64)-(502,67)
- Header/tabs: admin tab bar Users / Machines / Warehouses / Location Types / Loactions [sic] / Trucks / **Priorities** (active); department sub-tabs Trim (active) / Standing Seam / Rollforming / Board & Batten / Accessories / Shipping; Search... box
- Controls: none besides tabs/search
- Table: columns Colour | Names | Hierarchy | Actions ("..."). Rows: red swatch "Now" 1; orange swatch "ASAP" 2; yellow swatch "By 8:00" 3; yellow "By 9:00" 4; yellow "By 10:00" 5; yellow "By 11:00" 6; yellow "By 12:00" 7; yellow "By 1:00" 8; yellow "By 2:00" 9; yellow "By 3:00" 10; yellow "By 4:00" 11; yellow "By 5:00" 12. 12 rows visible (all shown, no scroll needed).
- Indicators: colour swatches red/orange/yellow denote priority urgency tiers
- Notes: this is the admin priorities configuration screen referenced by the Priorities/Warehouses/Locations overall-notes column
- Verified: pass3

##### Screen (579,98) — Admin Warehouses tab (three warehouses)
- File: `p1_121_x579_y98.png`
- Illustrates: "First you would have to create a Warehouse" (620,58)-(626,61)
- Header/tabs: admin tab bar Users / Machines / **Warehouses** (active) / Location Types / Loactions / Trucks / Priorities; Search... box
- Controls: green "+ Create Warehouse" button
- Table: columns Name | Address | Description | Default | Action. Rows: Warehouse #1 | 20 Clearview Dr. Tillsonburg | Wise Line's primary warehouse in the production plant | checkmark | "..."; Warehouse #2 | 52219 John Wise Line, Aylmer | Wise Line's secondary warehouse for large order packs | (no checkmark) | "..."; Warehouse #3 | 590 Barth Side Road, Langton | Wise Line's overflow warehouse | (no checkmark) | "...". 3 rows, not empty.
- Indicators: Warehouse #1 is marked Default (checkmark); Warehouse #2 and #3 are not
- Notes: corrects an earlier claim that this table was empty — it already lists all three warehouses, with Warehouse #1 marked Default
- Verified: pass3

##### Screen (611,64) — Admin Warehouses tab (empty list, wide header)
- File: `p1_143_x611_y64.png`
- Header/tabs: Users / Machines / **Warehouses**(active) / Location Types / Loactions / Trucks / Priorities; Search box
- Controls: green "+ Create Warehouse" button
- Table: Name | Address | Description | Default | Action — empty, no rows
- Notes: empty-state warehouse list (earlier/pristine state, before Screen (579,98) which already has 3 warehouses)
- Verified: pass3

##### Screen (611,81) — Create Warehouse modal
- File: `p1_146_x611_y81.png`
- Illustrates: "Clicking this button would open this window where you would enter the Name, Address and Description of the Warehouse you want to create." (625,72)-(631,75)
- Dialog/popup: title "Create Warehouse"; fields Name (placeholder "e.g. Warehouse #1"), Address (placeholder "e.g. 123 Main St"), Description (textarea placeholder "Enter Warehouse Description"); buttons "Create" (green), "Cancel" (red)
- Verified: pass3

##### Screen (611,98) — Warehouses tab with one row
- File: `p1_149_x611_y98.png`
- Table: Name | Address | Description | Default | Action. Row: Warehouse #1 | 20 Clearview Dr. Tillsonburg | Wise Line's primary warehouse in the production plant | ✓ (checkmark, default) | "..." action menu
- Indicators: checkmark in Default column marks the default warehouse
- Verified: pass3

##### Screen (653,64) — Admin Location Type tab (empty, Trim selected)
- File: `p1_144_x653_y64.png`
- Header/tabs: Users / Machines / Warehouses / **Location Type**(active) / Loactions / Trucks / Priorities; department sub-tabs Trim(active)/Standing Seam/Rollforming/Board & Batten/Accessories; green "+ Create Location Type" button
- Table: Name | Warehouse | Description | Action — empty
- Notes: empty-state location type list
- Verified: pass3

##### Screen (653,81) — Create Location Type modal
- File: `p1_147_x653_y81.png`
- Illustrates: "Clicking this button would open this window where you would enter the Name and Description of the Location Type you want to create. You would also select a Warehouse from the dropdown..." (669,72)-(675,76)
- Dialog/popup: department badge "Trim" at top of modal; title "Create Location Type"; fields Name (placeholder "e.g. Small"), Warehouse (dropdown placeholder "Warehouse"), Description (textarea placeholder "Enter Location Type Description"); buttons Create (green), Cancel (red)
- Verified: pass3

##### Screen (653,98) — Location Type tab with one row
- File: `p1_150_x653_y98.png`
- Header/tabs: department sub-tabs Trim(active)/Standing Seam/Rollforming/Board & Batten/Accessories
- Table: Name | Warehouse | Description | Action. Row: Small | Warehouse #1 | Small Trim Carts, 18" wide | "..."
- Verified: pass3

##### Screen (696,64) — Admin Locations tab (empty, Trim selected)
- File: `p1_145_x696_y64.png`
- Header/tabs: Users / Machines / Warehouses / Location Types / **Locations**(active) / Trucks / Priorities; department sub-tabs Trim(active)/Standing Seam/Rollforming/Board & Batten/Accessories; green "+ Create Location" button
- Table: Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action — empty
- Notes: empty-state locations list
- Verified: pass3

##### Screen (696,81) — Create Location modal
- File: `p1_148_x696_y81.png`
- Illustrates: "Clicking this button would open this window where you would enter the Name, Max Weight and Description of the Location..." (710,72)-(719,76)
- Dialog/popup: department badge "Trim"; title "Create Location"; fields Name (placeholder "e.g. 231"), Warehouse (dropdown placeholder), Location Type (dropdown placeholder), Max Weight (placeholder "0" lbs), Multi Order toggle "No" (checked/grey) with "Number of Orders" field (placeholder "0"), Description (textarea); buttons Create (green), Cancel (red)
- Verified: pass3

##### Screen (696,107) — Locations tab with one row
- File: `p1_151_x696_y107.png`
- Header/tabs: department sub-tabs Trim(active)/Standing Seam/Rollforming/Board & Batten/Accessories
- Table: Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action. Row: 301 | Warehouse #1 | Small | 1200 lbs | 1200 lbs, 18" Wide Small Trim Cart | 0 (checked/grey icon) | "..."
- Verified: pass3

##### Screen (807,64) — Admin: Machines (Rollforming, collapsed)
- File: `p1_193_x807_y64.png`
- Illustrates: (772,47)-(866,58) "Machines, Rollforming"
- Header/tabs: tab bar Users, Machines (active/white), Warehouses, Location Types, Loactions [sic], Trucks, Priorities; Search box top-right
- Controls: three collapsible section headers each with a chevron: "Trim" (green pill "6 Machine(s)"), "Rollforming" (green pill "5 Machine(s)", plus grey "Coil Suppliers" button), "Accessories" (no count shown)
- Table: none (sections collapsed)
- Indicators: green pill badges for machine counts
- Dialog/popup: none
- Notes: "Loactions" tab label is a typo (visible as shown)
- Verified: pass3

##### Screen (807,77) — Admin: Machines – Coil Suppliers popup
- File: `p1_194_x807_y77.png`
- Illustrates: (821,73)-(827,75) "Clicking this button would open this window where you would be able to create a list of coil suppliers."
- Header/tabs: same tab bar as above (Machines active)
- Controls: "Coil Suppliers" popup lists suppliers each with a red circular "X" remove button; green "Add" button at bottom
- Table: none
- Dialog/popup: title "Coil Suppliers"; body rows "- Taylor", "- Color Steel", "- Cascadia" each with red X delete icon; button "Add"
- Notes: popup anchored below the "Coil Suppliers" button in the Rollforming row
- Verified: pass3


---

## Page 1 — Trim

_Legend and Overall Notes are repeated at the top of this page; see [Board-wide notes](#board-wide-notes-legend-priorities-warehouseslocations-machines)._

### Trim department overview

Section header **Trim** (295,231)-(329,252), with roles branching below it.

#### Screens (1)

##### Screen (81,286) — Trim / Unscheduled
- File: `p1_000_x81_y286.png`
- Illustrates: no adjacent annotation (this is the base Unscheduled tab view referenced generally by (249,286)-(256,291) "Once you have selected at least one order, then the Schedule button and Bypass Production button should become available...")
- Header/tabs: "Trim" department pill top-left; top-right grey pill "Completed orders for the past 90 days"; tab bar: Unscheduled (active/white), Scheduled, Production, Coils; search box top-right "Search..."
- Controls: date strip: Wednesday May 08/2024 (calendar icon, current day selector) then day pills Mon. May 06/2024 (1000/5000), Tue. May 07/2024 (1000/5000), Wed. May 08/2024 (1000/5000), Thu. May 09/2024 (1000/5000), Fri. May 10/2024 (1000/5000); action buttons Schedule (greyed/disabled) and Bypass Production (greyed/disabled); right-side buttons Stock Cards (enabled, green) and Create Stock Order (enabled, green)
- Table: columns: [checkbox] | [expand chevron] | Entry Date | Ship Date | Order # | Priority | Customer Name | Order Notes. Rows (11 visible, all shown): 330605 Mon May06/Thu May09 H F H Inc, Select Priority, Notes(red dot); 330608 Mon May06/Thu May09 Jireh Tools, Notes; 330609 Mon May06/Thu May09 Arnold Contracting, Notes; 330615 Mon May06/Thu May09 DAP Roofing Inc., Notes; 330616 Mon May06/Thu May09 Arnold Contracting, Notes(green dot); 330617 Mon May06/Fri May10 Ontario Metal Products Ltd., Notes; 330618 Mon May06/Thu May09 A.W.C., Notes(green dot); 330622 Mon May06/Fri May10 Ontario Metal Products Ltd., Notes; 330629 Mon May06/Fri May10 Ontario Metal Products Ltd., Notes; 330631 Mon May06/Thu May09 Jireh Tools, Notes; 330632 Mon May06/Thu May09 Upright Construction, Notes
- Indicators: checkboxes are green-outlined squares (all unchecked); Order Notes button on order 330605 has a red dot; order 330616 and 330618 have a green dot; other rows' Notes buttons have no dot
- Dialog/popup: none
- Notes: each row has an expand caret (˅) to the left; Order # values shown in orange/red text, Customer Name in blue text (link style)
- Verified: pass3


#### Trim Manager (289,240)-(292,243)

"Trim Managers should be able to see and edit everything from here down. Including what the Worker can see and do." (281,240)

### Stock

Two entry actions: **Creating Stock Cards for Inventory** (106,282) and **Creating a Stock Order for Inventory** (127,282), under section label "Stock" (121,280).

#### Creating Stock Cards

- Clicking this button opens the Stock Cards window. (95,301)
- "Here the Manager can create Stock Cards. He would enter the Product ID, Stock Minimum, Order Qty and Upload an Image. The Product IDs would have to be valid, active IDs in EBMS. The Description would NOT be editable and would auto fill from EBMS." (71,307)
- Once ALL 5 of these fields are filled in, then the Create button becomes available. (72,321)
- Clicking Create would add the Stock Card to the list. (86,341)
- We need to be able to edit and delete the Stock Cards. (76,356)
- To print the Stock Cards you would check off all the cards you want to print and then click the Print Selected button. (75,383)
- Once you have selected at least one Stock Card to print, then the Print Selected button would become available. (108,383)

##### Screens (8)

###### Screen (136,303) — Create Stock Card (filled)
- File: `p1_001_x81_y303.png`
- Illustrates: (72,321)-(77,323) "Once ALL 5 of these fields are filled in, then the Create button becomes available."
- Header/tabs: same modal as above
- Controls: Product ID = "TSG8306"; Description = "Snow Guard  Charcoal"; Stock Minimum = "60"; Upload Image shows a hand-drawn trim profile sketch; Order Qty = "100"; Create button now enabled (solid green); Print Selected still disabled; Cancel red/enabled
- Table: none
- Indicators: none
- Dialog/popup: same Create Stock Card modal, now fully filled
- Notes: Upload Image box contains a simple line drawing of the trim profile shape
- Verified: pass3

###### Screen (136,321) — Create Stock Card (filled, Create enabled)
- File: `p1_002_x81_y323.png`
- Illustrates: (72,321)-(77,323) "Once ALL 5 of these fields are filled in, then the Create button becomes available."
- Header/tabs: same Create Stock Card modal
- Controls: Product ID "TSG8306", Description "Snow Guard  Charcoal", Stock Minimum "60", Order Qty "100", Upload Image shows the same hand-drawn trim profile sketch; Create enabled (solid green); Print Selected disabled (light green); Cancel red/enabled
- Table: none
- Indicators: none
- Dialog/popup: Create Stock Card modal
- Notes: identical field content and button states to Screen (136,303) (`p1_001_x81_y303.png`) — corrected from a prior mislabel as an empty form with Print Selected enabled, which does not match this image.
- Verified: pass3

###### Screen (197,323) — Create Stock Card (empty)
- File: `p1_003_x81_y343.png`
- Illustrates: (71,307)-(77,312) "Here the Manager can create Stock Cards..."
- Header/tabs: same Create Stock Card modal
- Controls: Product ID/Description/Stock Minimum/Order Qty all placeholders, Upload Image empty box; Create disabled (light green); Print Selected disabled (light green); Cancel red/enabled
- Table: none
- Indicators: none
- Dialog/popup: Create Stock Card modal
- Notes: identical to Screen (136,286) (`p1_007_x136_y286.png`) — corrected from a prior mislabel as the Stock Cards grid list, which this image is not.
- Verified: pass3

###### Screen (136,339) — Stock Cards list (none checked)
- File: `p1_004_x81_y357.png`
- Illustrates: (76,356)-(80,358) "We need to be able to edit and delete the Stock Cards." / (75,383)-(78,387) "To print the Stock Cards you would check off all the cards you want to print..."
- Header/tabs: panel titled "Stock Cards"
- Controls: none at top; each card has "Print Select" checkbox, edit (pencil, orange) and delete (trash, red) icons
- Table: 5 stock cards in a grid: TED8262 Width:6" "EAVE DRIP 2" BLACK" Stock Minimum 100 / Order Qty 150; TGS8306 Width:11" "GABLE STARTER F CHARCOAL" Stock Minimum 36 / Order Qty 42; TRC8306 Width:14" "RIDGE CAP CHARCOAL" Stock Minimum 80 / Order Qty 120; TSG8262 Width:8" "SNOW GUARD BLACK" Stock Minimum 60 / Order Qty 100; TSG8306 Width:8" "SNOW GUARD CHARCOAL" Stock Minimum 60 / Order Qty 100
- Indicators: each card shows a QR code and a line-drawing profile sketch; all Print Select checkboxes are unchecked in this view (corrected — no card is checked here)
- Dialog/popup: none (this is the Stock Cards list panel)
- Notes: none
- Verified: pass3

###### Screen (81,373) — Create Stock Card
- File: `p1_005_x81_y373.png`
- Illustrates: (71,307)-(77,312) "Here the Manager can create Stock Cards. He would enter the Product ID, Stock Minimum, Order Qty and Upload an Image. The Product IDs would have to be valid, active IDs in EBMS. The Description would NOT be editable and would auto fill from EBMS."
- Header/tabs: none (standalone modal)
- Controls: Product ID text field (placeholder "e.g. TRC8306"), Description text field (placeholder "Description...", greyed/disabled look), Stock Minimum field (placeholder "e.g. 30"), Order Qty field (placeholder "e.g. 50"), Upload Image box (placeholder "Browse..."), Create button (greyed/disabled), Print Selected button (green, enabled), Cancel button (red, enabled)
- Table: none
- Indicators: Create button appears greyed (disabled, fields empty); Print Selected green; Cancel red
- Dialog/popup: title "Create Stock Card"; fields Product ID, Description, Stock Minimum, Upload Image, Order Qty; buttons Create (disabled), Print Selected, Cancel
- Notes: all fields empty/placeholder text, consistent with "Once ALL 5 of these fields are filled in, then the Create button becomes available."
- Verified: pass3

###### Screen (81,388) — Stock Cards
- File: `p1_006_x81_y388.png`
- Illustrates: (75,383)-(78,387) "To print the Stock Cards you would check off all the cards you want to print and then click the Print Selected button."
- Header/tabs: heading "Stock Cards" at top
- Controls: each card has a "Print Select" checkbox (some checked/green, some unchecked), a yellow edit (pencil) icon button and a red delete (trash) icon button
- Table: card grid, 5 cards shown: TED8262 (Width 6") "EAVE DRIP 2" BLACK", Stock Minimum 100 / Order Qty 150, Print Select checked; TGS8306 (Width 11") "GABLE STARTER F CHARCOAL", Stock Minimum 36 / Order Qty 42, Print Select unchecked; TRC8306 (Width 14") "RIDGE CAP CHARCOAL", Stock Minimum 80 / Order Qty 120, Print Select unchecked; TSG8262 (Width 8") "SNOW GUARD BLACK", Stock Minimum 60 / Order Qty 100, Print Select unchecked; TSG8306 (Width 8") "SNOW GUARD CHARCOAL", Stock Minimum 60 / Order Qty 100, Print Select checked
- Indicators: Print Select checkbox green/checked on TED8262 and TSG8306 cards, unchecked (white) on the other three; each card has a line-drawing profile icon and a QR code
- Dialog/popup: none
- Notes: each card shows Product ID, Width, profile sketch, QR code, description in caps, Stock Minimum and Order Qty boxes
- Verified: pass3

###### Screen (122,324) — Stock Card TSG8306 (single card detail)
- File: `p1_011_x122_y324.png`
- Illustrates: no adjacent annotation (single-card close-up)
- Header/tabs: none (isolated card graphic)
- Table: none
- Indicators: card shows QR code top-right, line-drawing profile sketch left, "TSG8306 / Width: 8"" label, "SNOW GUARD CHARCOAL" bold caption, Stock Minimum 60 / Order Qty 100 boxes
- Dialog/popup: none — a cropped single Stock Card, likely the printable label output
- Notes: identical to Screen (238,369) (`p1_012_x136_y339.png` was previously mislabeled with this content — that file actually shows a different screen, see below). Corrected from a prior mislabel as a "Create Stock Card, Print Selected enabled" form.
- Verified: pass3

###### Screen (136,286) — Create Stock Card (empty)
- File: `p1_007_x136_y286.png`
- Illustrates: (71,307)-(77,312) "Here the Manager can create Stock Cards. He would enter the Product ID, Stock Minimum, Order Qty and Upload an Image..."
- Header/tabs: modal titled "Create Stock Card" overlaid on the Unscheduled tab behind it
- Controls: fields Product ID (placeholder "e.g. TRC8306"), Description (placeholder "Description...", greyed/non-editable style), Stock Minimum (placeholder "e.g. 30"), Upload Image ("Browse..." box), Order Qty (placeholder "e.g. 50"); buttons Create (disabled/light green), Print Selected (disabled/light green), Cancel (red, enabled)
- Table: none (form only); "Stock Cards" panel header visible below modal
- Indicators: none
- Dialog/popup: this entire screen is the Create Stock Card modal
- Notes: all fields empty/placeholder state
- Verified: pass3


#### Creating a Stock Order

- Clicking this button opens the Create Stock Order window. (151,301)
- "We need to be able to either manually enter the Qty and Product ID, or scan the QR code on a Stock Card which would then auto fill the Order Qty and Product ID that is on that card." (125,318)
- Enter the Qty and Product ID of the stock items you want made. (137,319)
- Clicking Create would enter the Stock Order into the Unscheduled tab. (138,337)
- "Stock Orders would NOT have a Ship Date. The Order# would have a prefix of "S" and be it's own series of numbers. The Customer Name would say Stock." (163,341)
- Stock Orders would NOT have an Order Note because Order Notes come from EBMS. (163,345)
- Entry Date would be the date that the Stock Order was created. (131,346)
- From here the Manager would Schedule the Stock Order just like a customer's order from EBMS. (146,355)

##### Screens (5)

###### Screen (197,341) — Create Stock Order (empty)
- File: `p1_008_x136_y303.png`
- Illustrates: (125,318)-(131,321) "We need to be able to either manually enter the Qty and Product ID, or scan the QR code on a Stock Card which would then auto fill the Order Qty and Product ID..."
- Header/tabs: modal titled "Create Stock Order" over the Unscheduled tab (visible table rows and Order Notes column behind the modal, dimmed)
- Controls: table with columns Qty / Product ID / Description, 9 empty rows; buttons Cancel (red, enabled) and Create (green)
- Table: empty entry grid, 9 blank rows
- Indicators: none
- Dialog/popup: "Create Stock Order" modal
- Notes: none
- Verified: pass3

###### Screen (212,345) — Create Stock Order (filled)
- File: `p1_009_x136_y321.png`
- Illustrates: (137,319)-(143,320) "Enter the Qty and Product ID of the stock items you want made."
- Header/tabs: same "Create Stock Order" modal
- Controls: same Cancel/Create buttons, both enabled (red/green)
- Table: 6 filled rows: Qty 100 / TEW8262 / "End Wall  Black"; Qty 150 / TDE8262 / "Drip Edge  Black"; Qty 150 / TBT8262 / "Base Trim  Black"; Qty 80 / TEW8306 / "End Wall  Charcoal"; Qty 120 / TSW8306 / "Side Wall  Charcoal"; Qty 120 / TSG8306 / "Snow Guard  Charcoal"; 3 further rows blank
- Indicators: none
- Dialog/popup: "Create Stock Order" modal
- Notes: none
- Verified: pass3

###### Screen (722,92) — Create Location (Multi Order = Yes, Number blank)
- File: `p1_195_x722_y92.png`
- Illustrates: (710,72)-(719,76) "Clicking this button would open this window where you would enter the Name, Max Weight and Description of the Location you want to create. You would also select a Warehouse from the dropdown of existing Warehouses, a Location Type from the dropdown of existing Location Types within that Warehouse and you have to decide if this is a Multi Order location." / (714,98)-(714,99) "Yes A Multi Order Location"
- Header/tabs: grey pill "Trim" at top of modal
- Controls: Name field (placeholder "e.g. 231"), Warehouse dropdown (placeholder "Warehouse"), Location Type dropdown (placeholder "Location Type"), Max Weight field (placeholder "0", suffix "lbs"), Multi Order toggle set to "Yes" (green, checked), Number of Orders field (placeholder "0", empty), Description textarea (placeholder "Enter Location Description"), Create button (green), Cancel button (red)
- Table: none
- Indicators: Multi Order toggle shown green/checked "Yes"
- Dialog/popup: title "Create Location"; fields as above; buttons Create, Cancel
- Notes: Number of Orders field is enabled (white background) but empty since Multi Order is toggled Yes
- Verified: pass3

###### Screen (728,107) — Admin: Locations tab (Trim)
- File: `p1_197_x728_y107.png`
- Illustrates: (722,125)-(726,128) "This is how locations would show up in production when Workers are selecting locations." / (691,88)-(696,90) "All Location Names have to be unique within the entire app, can never be doubled up."
- Header/tabs: tab bar Users, Machines, Warehouses, Location Types, Locations (active/white), Trucks, Priorities; sub-tabs Trim (active/white), Standing Seam, Rollforming, Board & Batten, Accessories; top-right green "+ Create Location" button; Search box
- Table: columns Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action. Row: "301" | "Warehouse #1" | "Small" | "3500 lbs" | "1200 lbs, 18" Wide Small Trim Cart" | Multi Order green checkmark with "12" | Action "..." menu
- Indicators: Multi Order column shows green checkmark badge with number 12
- Dialog/popup: none
- Notes: only one location row visible; rest of table empty
- Verified: pass3

###### Screen (736,92) — Create Location (Multi Order = Yes, Number = 12)
- File: `p1_196_x736_y92.png`
- Illustrates: (754,109)-(761,118) "A Multi Order Location would allow you to use the location multiple times (for multiple orders) before becoming unavailable, within the Max Weight limit. This example would be able to be used 12 times (for 12 different orders) before becoming unavailable, within 3500 lbs..."
- Same as Screen (722,92) except: Number of Orders field now filled with "12"
- Table: none
- Notes: this is the filled-in example referenced by the "12 times... 3500 lbs" annotation
- Verified: pass3


#### Order Notes (253,321)

- "These Order Notes would be imported from the Salesman (EBMS). There would be a red indicator showing that you haven't dealt with this note yet." (224,328)
- Clicking this button opens the note. (216,338)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (223,349)

##### Screens (3)

###### Screen (157,399) — Line Item Note popup (unread)
- File: `p1_014_x212_y345.png`
- Illustrates: (224,328)-(232,330) "These Order Notes would be imported from the Salesman (EBMS). There would be a red indicator showing that you haven't dealt with this note yet."
- Header/tabs: none (standalone note card)
- Dialog/popup: card header "HW" avatar, "Henry Wall / henrywall@wiseline.ca", timestamp "Tue. May 07/2024  10:42"; body text "Would like this order by 4:30 tomorrow"; two round buttons bottom-left: red X and green checkmark, both small circular icons
- Indicators: red X (dismiss/leave unread) and green check (mark read) icons both present
- Notes: corrected — this file was previously mislabeled as a duplicate Unscheduled base table; it is actually the unread Order Notes popup, matching what was previously (mis)claimed for File `p1_015_x238_y351.png`.
- Verified: pass3

###### Screen (157,435) — Line Item Note popup (checked/read state)
- File: `p1_017_x212_y362.png`
- Illustrates: (223,349)-(232,352) "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green."
- Header/tabs: none (standalone note card)
- Dialog/popup: same "HW" / Henry Wall header and body text ("Would like this order by 4:30 tomorrow") as Screen (157,399); the checkmark is now a full-width green pill/bar beneath the note text (pressed/selected state); the red X remains a small circular icon on the left
- Notes: corrected — this file was previously mislabeled as the Unscheduled table with row 330640; it is actually the read/checked-state note popup, matching what was previously (mis)claimed for File `p1_016_x197_y358.png`.
- Verified: pass3

###### Screen (1011,304) — Trim / Press Brake — Stock Manufacturing modal, empty
- File: `p1_278_x1011_y304.png`
- Illustrates: (1009,302)-(1016,303) "Clicking the Stock Manufacturing button opens this window."; (1013,320)-(1018,321) "Enter the new stock items"
- Header/tabs: background Press Brake bendlist table (production dates Wed May08–Thurs May09) visible behind modal.
- Dialog/popup: Title "Stock Manufacturing". Table columns: Qty | ID | Description — one empty input row. Buttons: "Cancel" (red), "Create Manufacturing Batch" (green).
- Notes: Empty-state version of the Stock Manufacturing entry window.
- Verified: pass3


#### Bypassing Production (259,348)

- Clicking the Bypass Production button would give you this pop up (239,367)
- "Clicking Yes, Bypass Production would make the selected order or orders bypass the Slinet and Machine tabs and go straight to the Wrapping tab. Nothing would get assigned to this order and no cutlist or bendlist would be created for it, all the line items would just appear in the Wrapping tab like line items that went throught production but have a Status of Bypassed." (227,378)
- Bypassing an order would automatically assign the current date as it's Production Date. (240,386)

##### Screens (1)

###### Screen (177,454) — Bypass Production confirmation popup
- File: `p1_018_x238_y369.png`
- Illustrates: (239,367)-(246,368) "Clicking the Bypass Production button would give you this pop up"
- Header/tabs: Unscheduled tab visible behind modal; Schedule/Bypass Production buttons are enabled (green) behind the popup and row 330640 (checked) is visible at the bottom of the table
- Dialog/popup: text "Are you sure you want this order(s) to bypass all the production tabs and go straight to the wrapping stage?"; buttons "Yes, Bypass Production" (green) and "No" (red)
- Notes: row 330615 (DAP Roofing Inc.) is partially obscured behind the modal
- Verified: pass3


### Trim Unscheduled (310,255)

Tabs/columns shown include Stock Orders (463,281) with icon note: "Stock Orders would have an icon in the Production Date column showing that it's a Stock Order." (417,288)

#### Screens (8)

##### Screen (238,351) — Trim Unscheduled tab (base, duplicate)
- File: `p1_010_x197_y323.png`
- Illustrates: no adjacent annotation
- Same as Screen (81,286) except: no differences noted — identical table/state (11 rows, same data, same disabled Schedule/Bypass Production buttons). Confirmed identical after opening both images.
- Verified: pass3

##### Screen (215,399) — Trim Unscheduled tab (base, no Stock row)
- File: `p1_013_x197_y341.png`
- Illustrates: no adjacent annotation
- Same as Screen (81,286) — no differences noted: identical 11-row table (330605...330632), disabled Schedule/Bypass Production buttons, no Stock order row present. Corrected — this file was previously mislabeled as having a Stock order row added; it does not.
- Verified: pass3

##### Screen (215,421) — Trim Unscheduled tab (base, duplicate)
- File: `p1_016_x197_y358.png`
- Illustrates: no adjacent annotation
- Same as Screen (81,286) — no differences noted: identical 11-row table, disabled Schedule/Bypass Production buttons, no Stock row, no row 330640. Corrected — this file was previously mislabeled as the "checked/read" note popup; it is actually a plain base-table duplicate.
- Verified: pass3

##### Screen (259,284) — Trim Unscheduled, Schedule/Bypass enabled, all rows checked
- File: `p1_034_x259_y284.png`
- Same as Screen (300,259) except: rows 330605, 330608, 330609, 330615, 330616, 330618, 330631, 330632 checked (green check), rows 330617, 330622, 330629 remain unchecked; Schedule / Bypass Production buttons are enabled (solid green); Priority column header reads "Priority" (not "Priorities")
- Verified: pass3

##### Screen (294,303) — Trim Unscheduled, most rows checked (duplicate)
- File: `p1_036_x294_y303.png`
- Same as Screen (259,284) — identical: rows 330605, 330608, 330609, 330615, 330616, 330618, 330631, 330632 checked (green); rows 330617, 330622, 330629 remain unchecked; Schedule/Bypass Production buttons enabled (solid green); Priority column header reads "Priorities"
- Verified: pass3

##### Screen (300,259) — Trim Unscheduled tab, base table (all rows unchecked)
- File: `p1_032_x300_y259.png`
- Header/tabs: "Trim" pill; "Completed orders for the past 90 days"; sub-tabs Unscheduled (active), Scheduled, Production, Coils; search box; date pills Wed May08/2024 (selected) through Fri May10/2024, each "(1000 / 5000)"
- Controls: Schedule and Bypass Production buttons both disabled (pale green); Stock Cards and Create Stock Order buttons enabled (solid green)
- Table: columns Entry Date | Ship Date | Order # | Priority | Customer Name | Order Notes; rows 330605 (H F H Inc, red Notes dot), 330608 (Jireh Tools), 330609 (Arnold Contracting), 330615 (DAP Roofing Inc.), 330616 (Arnold Contracting, green Notes dot), 330617 (Ontario Metal Products Ltd.), 330618 (A.W.C., green Notes dot), 330622 (Ontario Metal Products Ltd.), 330629 (Ontario Metal Products Ltd.), 330631 (Jireh Tools), 330632 (Upright Construction); all row checkboxes unchecked; Priority column shows "Select Priority" links for every row
- Notes: none
- Verified: pass3

##### Screen (338,282) — Trim Unscheduled, order 330609 expanded (Split Order view)
- File: `p1_033_x338_y282.png`
- Illustrates: no adjacent annotation
- Header/tabs: Unscheduled tab; column header for the Priority column reads "Priority" (not "Priorities") in this expanded state
- Controls: Split Order button, top-left of the expansion — pale/light green, styled disabled, since no line items are checked
- Table: order 330609 (Arnold Contracting) expanded showing columns Qty Ordered | Product ID | Description | Line Item Notes: 8/TRC8250/"Ridge Cap Dark Red"/Notes(green dot); 16/TED8250/"Eave Drip Dark Red"/Notes; 12/TGS8250/"Gable Stater F 3" Dark Red"/Notes(green dot); 14/TSG8250/"Snow Guard Dark Red"/Notes; checkboxes present next to each line item, all unchecked
- Indicators: green dots on 2 of 4 Notes buttons
- Notes: rest of Unscheduled table (330605...330632) shown above/below the expanded order; corrected — the Split Order button IS pale/disabled-styled in this image (confirmed by pixel comparison against the enabled solid-green version in Screen (338,303)), and the Priority column header reads "Priority", not "Priorities".
- Verified: pass3

##### Screen (338,303) — Order 330609 expanded, 2 line items checked, Split Order enabled
- File: `p1_035_x338_y303.png`
- Illustrates: (332,313)-(336,314) "Select the line items you are wanting to schedule." / (332,315)-(337,319) "As soon as you select at least 1 line item, then the Split Order button becomes available..."
- Same as Screen (338,282) except: Split Order button shown solid green (enabled); line items "8/TRC8250/Ridge Cap Dark Red" and "14/TSG8250/Snow Guard Dark Red" checked (green check); "16/TED8250" and "12/TGS8250" unchecked
- Verified: pass3


#### Set the Production Date (310,277)

- Scheduling Entire Order (306,279) Or (312,280) Scheduling Partial Order (314,279)
- "Once you have selected at least one order, then the Schedule button and Bypass Production button should become available. We need to be able to expand & collapse orders, check & deal with notes and set Priorities without losing the orders we've selected." (249,286)
- Each day needs to show the Max. Capacity for the day and also how much has been assigned to the day. (286,287)
- Select all the orders you want to Schedule. (252,296)
- Clicking the Schedule button will open a Calendar (263,301)
- "If you expand an order when at least 1 order has been check off to be scheduled, then the line item check boxes to split an order need to be unavailable." (286,309)
- "Select the Production Date and click Set Date, this will make the order disappear out of the Unscheduled tab and appear in the Scheduled tab." (250,314)
- Open the dropdown on the order that you want to partially schedule. (333,287)
- Select the line items you are wanting to schedule. (332,313)
- "As soon as you select at least 1 line item, then the Split Order button becomes available and the scheduling check boxes become unavailable." (332,315)
- Clicking the Split Order button opens the calendar. (341,322)
- "Select the Production Date for the selected line items. This will schedule those line items and reset the Split Order function." (332,334)
- "When part of an order has been scheduled, there needs be an indication in the Order # column showing that this order has been split, on both sub-orders." (365,349)
- "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be grayed out and completely uneditable in the Unscheduled tab. Once all the trims are Scheduled, the order will disappear in the Unscheduled tab within the Trim department (category)." (330,354)
- For Stock orders, there would be NO Stock column. (150,423)

##### Screens (1)

###### Screen (259,303) — Split Order calendar popup, over base/unchecked background
- File: `p1_037_x259_y303.png`
- Illustrates: (341,322)-(345,324) "Clicking the Split Order button opens the calendar."
- Dialog/popup: "May 2024" calendar, "8" highlighted green/selected, red "X" close button, Cancel and "Set Date" buttons — overlays the Unscheduled table; visible background rows (330605, 330608, and partly 330615) show unchecked checkboxes and Schedule/Bypass Production buttons disabled (pale green); order 330609's expanded line items are hidden behind the popup
- Notes: corrected — the visible background state here is the disabled/unchecked base table, not a checked state; the popup over the checked/expanded-330609 background is shown separately in File `p1_038_x338_y325.png`.
- Verified: pass3


### Trim Scheduled (310,369)

- "If orders have Priorities assigned to them then they are sorted primarily by Production Date and secondarily by Priority. The Priorities are sorted by the hierarchy assigned to them." (208,402)
- "Here in the Scheduled tab, Stock Orders would NOT have a Ship Date or Order Note. The Order# would have a prefix of "S" and be it's own series of numbers. The Customer Name would say Stock. The Location would say N/A." (149,402)

#### Screens (9)

##### Screen (137,469) — Trim Scheduled, Stock row selected (no additional Stock rows)
- File: `p1_026_x137_y469.png`
- Illustrates: (127,491)-(135,494) "If there are multiple Stock Orders, then if the Manager selects a Stock Order to Release To Production, the rest of the Stock Orders' check boxes need to stay available but NOT the Customer Orders."
- Table: same single-Stock-row layout as Screen (157,435 dup) — S10125 then 330605...330632, all rows with Reviewed clipboard icons
- Controls: Release To Production is ENABLED (solid green); Allocated Stock enabled
- Indicators: S10125's checkbox is checked (green filled check); all other rows (330605...330632) unchecked
- Notes: corrected — this image does not show additional Stock rows S10126/S10127. Release To Production is enabled here (not disabled) because S10125 is checked — differs from Screen (157,435 dup) (`p1_020_x157_y399.png`) in that respect.
- Verified: pass3

##### Screen (157,435 dup) — Trim Scheduled tab with Stock order row
- File: `p1_020_x157_y399.png`
- Illustrates: (149,402)-(155,407) "Here in the Scheduled tab, Stock Orders would NOT have a Ship Date or Order Note. The Order# would have a prefix of "S"... The Location would say N/A."
- Same as Screen (137,454) except: first row replaced with S10125, Ship Date N/A, Production Date Wed May08/2024, Customer Name "Stock", Select Priority, Trim Location "N/A", no Order Notes button; other rows (330605...330632) follow below without the NOW/ASAP priority rows shown
- Verified: pass3

##### Screen (177,469) — Trim Scheduled, one Customer order selected
- File: `p1_027_x177_y469.png`
- Illustrates: (168,468)-(175,471) "If the Manager selects a Customer Order to Release To Production, then any Stock Order check boxes need to become unavailable even if they have been Reviewed."
- Table: same layout as Screen (137,469) (S10125, 330605...330632, all with Reviewed icons); Release To Production enabled (green); only row 330608 (Jireh Tools) is checked
- Indicators: S10125's checkbox appears unchecked in this view
- Notes: corrected — no S10126/S10127 rows are present and only one customer row (330608) is checked, not the seven previously claimed.
- Verified: pass3

##### Screen (137,454) — Trim Scheduled tab, base list
- File: `p1_019_x215_y399.png`
- Illustrates: (208,402)-(214,405) "If orders have Priorities assigned to them then they are sorted primarily by Production Date and secondarily by Priority..."
- Header/tabs: Scheduled tab active; secondary sub-tabs "All Scheduled Orders" and date pill "Wednesday May 08/2024" plus day-of-week pills (Mon-Fri, each with gear icon and 1000/5000 capacity)
- Controls: Release To Production button (disabled/greyed), Allocated Stock button (enabled, green)
- Table: columns Ship Date | Production Date | Order # | Customer Name | Priority | Reviewed | Status | Trim Location | Order Notes. Rows: 330652 WJ Roofing NOW(red); 330653 Haines Roofing ASAP(orange); 330657 Arnold Contracting ASAP(orange); 330659 Upright Construction By 10:00(yellow); 330660 DAP Roofing Inc. By 3:00(yellow); 330605 H F H Inc Select Priority, Notes(red dot); 330608 Jireh Tools Select Priority; 330609 Arnold Contracting Select Priority (has split-order icon); 330615 DAP Roofing Inc. Select Priority; 330616 Arnold Contracting Select Priority, Notes(green dot); 330618 A.W.C. Select Priority; 330631 Jireh Tools Select Priority, Notes(green dot); 330632 Upright Construction Select Priority
- Indicators: Priority pills color-coded: NOW=red, ASAP=orange, By 10:00/By 3:00=yellow; small split-order icon next to order 330609
- Notes: no rows checked/reviewed yet
- Verified: pass3

##### Screen (300,399) — Trim Scheduled base table (duplicate)
- File: `p1_041_x300_y399.png`
- Same as Screen (137,454) — standard row list 330605-330632, no priority rows shown, Release To Production disabled
- Verified: pass3

##### Screen (300,518) — Trim Scheduled tab, expanded order row
- File: `p1_059_x300_y518.png`
- Illustrates: "When you expand an order, you should be able to see the Status of each individual trim." (293,525)
- Header/tabs: Same as above: Trim pill, Scheduled tab active, day strip Wed. May 08/2024 selected, Release To Production disabled, Allocated Stock enabled.
- Controls: Same day strip/buttons as Screen (342,512).
- Table: Columns: Ship Date, Production Date, Order #, Customer Name, Priority, Reviewed, Status, Trim Location, Order Notes. Rows: 330605 H F H Inc, Wrapped, Loc 258,310; 330608 Jireh Tools, In Progress, Loc 218; 330609 Arnold Contracting (split-order icon), Wrapped, Loc 108; 330615 DAP Roofing Inc. (expanded, In Progress, Loc 231) — expanded sub-table columns: Qty Ordered, Vented, Machine, Stock, Status, Product ID, Description, Width, Length, Line Item Notes: row1 5, X(vented off), Rollformer, -, Bent(red), TRC8262, Ridge Cap Black 6/12 Pitch, 14, 120; row2 10, X, Press Brake, -, Wrapped(green), TED8262, Eave Drip Black 6/12 Pitch, 6, 120; row3 8, X, V1, 3, Cut(blue), TGS8262, Gable Stater F 3" Black, 11, 120; row4 7, X, Rollformer, 7, Stock(yellow), TSG8262, Snow Guard Black, 8, 120. Below: 330616 Arnold Contracting (unreviewed, blank status); 330618 A.W.C. Not Started; 330631 Jireh Tools (unreviewed); 330632 Upright Construction In Progress, Loc 302.
- Indicators: Status colors: red=Bent, green=Wrapped, blue=Cut, yellow=Stock. Green checkbox rows (330616, 330631) indicate selected/checked.
- Dialog/popup: none.
- Notes: Split-order icon (scissors-like) next to Order # 330609.
- Verified: pass3

##### Screen (353,419) — Order 330631 expanded (duplicate)
- File: `p1_045_x353_y419.png`
- Same as Screen (353,399) — identical (Press Brake machines, same 4 line items and Notes dot colors)
- Verified: pass3

##### Screen (353,438) — Order 330631 expanded (duplicate)
- File: `p1_048_x353_y438.png`
- Same as Screen (353,399)/(353,419) — identical
- Verified: pass3

##### Screen (353,456) — Order 330631 expanded (duplicate)
- File: `p1_050_x353_y456.png`
- Same as Screen (353,399) and related duplicates — identical
- Verified: pass3


#### Viewing Partial Order (318,369)

"When viewing a partially scheduled order in the Scheduled tab, the trims that are still unscheduled or scheduled to a different day should appear but be grayed out and completely uneditable." (316,381)

##### Screens (1)

###### Screen (338,346) — Order 330609 partially scheduled (split indicator icon)
- File: `p1_039_x338_y346.png`
- Illustrates: (365,349)-(370,353) "When part of an order has been scheduled, there needs be an indication in the Order # column showing that this order has been split, on both sub-orders."
- Header/tabs: Unscheduled tab
- Table: order 330609 row now shows a small split icon next to the order number; expanded rows show "8/TRC8250/Ridge Cap Dark Red" and "14/TSG8250/Snow Guard Dark Red" greyed out/italic and unselectable (no checkbox, values shown in grey italic text), while "16/TED8250/Eave Drip Dark Red" (unchecked) and "12/TGS8250/Gable Stater F 3" Dark Red" (checked, green) remain active/checkable
- Indicators: split icon next to Order # 330609; scheduled line items shown italic/grey
- Notes: this is the Unscheduled-tab partial-order/split-icon state; Schedule/Bypass Production buttons disabled (pale green) in the background table.
- Verified: pass3


#### Reviewing Order (311,390) / Reviewing a Stock Order (289,392) / Priorities (292,395)

- Choose the day you want to work on, this day tab should show your maximum capacity for the day and how much is already assigned to that day. (326,402)
- Only the Manager can set Priorities (241,403)
- Click the dropdown for the order you are wanting to review. (293,406)
- Select the machines you want the trims to be assigned to. (303,433)
- When an order has not been Released To Production, the Status should remain empty. (326,419)
- The Width and Description columns need to be editable. These edits DON'T need to push back to EBMS. (326,422)

##### Screens (3)

###### Screen (137,454 dup) — Trim Scheduled, Stock row with Reviewed icon
- File: `p1_023_x157_y435.png`
- Same as Screen (157,435 dup) except: Stock row S10125 now shows the Reviewed clipboard icon and its checkbox is checked (green filled check); Release To Production button remains disabled
- Verified: pass3

###### Screen (177,454) — Trim Scheduled, Reviewed icons on all rows
- File: `p1_024_x177_y454.png`
- Same as Screen (157,435) except: every visible row (including S10125, 330605...330632) now has the Reviewed clipboard icon; Release To Production still disabled (no checkboxes checked)
- Verified: pass3

###### Screen (157,435) — Trim Scheduled tab, Reviewed icons added, Release To Production enabled
- File: `p1_022_x215_y421.png`
- Illustrates: (293,406)-(298,408) "Click the dropdown for the order you are wanting to review."
- Same as Screen (137,454) except: all order rows now show a "Reviewed" column icon (clipboard/checkmark icon) in place of blank; row checkboxes checked (green) for 330652, 330653, 330657, 330659, 330660 (the priority rows) as well as 330605 and 330608; the rest (330609, 330615, 330616, 330618, 330631, 330632) remain unchecked; Release To Production button is enabled (green)
- Verified: pass3


##### Vented Trims (289,413)

- Clicking this button opens the Line Item Note. (370,416)
- "If a trim needs to be Vented, then the Manager would toggle "on" the Vented column for that line item." (261,419)
- The Vented column needs to default to being toggled "off". (294,423)
- "When a line item has been marked as Vented, then for the Slinet ONLY it needs to over ride the Machine and put that Qty in the Vented column within the cutlist. This line item would still show up in the assigned Machine tab (in this case V2)." (252,423)
- "This way the Slinet Worker would put these pieces on a separate table to be Vented first before going to the assgined Machine (V2) to be bent." (253,426)
- "In this example you can see that the middle 2 line items are both assgined to V2, but the 1 is marked as Vented. Within the cutlist in the Slinet tab you can see that the 8 pieces that are NOT marked as Vented are in the V2 column and the 18 pieces that are marked as Vented are in the Vented column. Again, this ONLY effects the Slinet tab. All 26 of these pieces would still show up in the V2 tab." (252,429)

###### Screens (3)

###### Screen (267,416) — Order 330608 expanded, machines pre-assigned with Vented toggle ON
- File: `p1_044_x267_y416.png`
- Illustrates: (252,423)-(265,426) "When a line item has been marked as Vented, then for the Slinet ONLY it needs to over ride the Machine and put that Qty in the Vented column within the cutlist..." and worked example
- Table: order 330608 (Jireh Tools) expanded: 9/X/Rollformer/—/—/TRC8326/"Ridge Cap Coffee Brown"/14/120/Notes; 18/✓(green check, Vented ON)/V2/—/—/TSFWJV8326/"Eave Soffit/Fascia with J Vented  Coffee Brown  8" Fascia, 10" Soffit, 4/12 Pitch"/24/120/Notes; 8/X/V2/—/—/TGSFWJ8326/"Gable Soffit/Fascia with J  Coffee Brown  6" Fascia, 10" Soffit"/22/120/Notes; 2/X/Caps/—/—/TSFPC8326/"Soffit/Fascia Peak Cap Coffee Brown 6" Fascia, 10" Soffit, 4/12 Pitch"/11.75/28/Notes
- Indicators: second row's Vented column shows a green checkmark (toggled ON)
- Notes: matches the described example of vented vs non-vented pieces on V2
- Verified: pass3

###### Screen (300,416) — Order 330615 expanded, Vented toggle example
- File: `p1_043_x300_y416.png`
- Illustrates: (261,419)-(265,422) "If a trim needs to be Vented, then the Manager would toggle "on" the Vented column for that line item."
- Table: order 330615 (DAP Roofing Inc.) expanded: 5/X/[Machine... dropdown]/—/—/TRC8262/"Ridge Cap Black  6/12 Pitch"/14/120/Notes(green); 10/X/[Machine...]/—/—/TED8262/"Eave Drip Black  6/12 Pitch"/6/120/Notes; 8/X/[Machine...]/—/—/TGS8262/"Gable Stater F 3" Black"/11/120/Notes(green); 7/X/[Machine...]/—/—/TSG8262/"Snow Guard Black"/8/120/Notes(green)
- Indicators: all Vented cells show grey X (off) in this instance, machines not yet assigned; 3 of 4 Notes buttons show a green dot (all but Eave Drip)
- Notes: corrected — the fourth row's (Snow Guard) Notes button also has a green dot, not blank as previously stated.
- Verified: pass3

###### Screen (507,350) — Expanded cutlist row (Vented Trims example)
- File: `p1_128_x507_y350.png`
- Illustrates: "In this example you can see that the middle 2 line items are both assigned to V2, but the 1 is marked as Vented..." (252,429)-(265,432)
- Table: expanded cutlist for Wed 05/08/2024, 28Ga.-Bright White. Sub-columns: Width | Length | Total | P.B. | V1 | V2 | Rollformer | Vented | Caps | Flat Stock | Operator Notes | Complete. Rows: 4/120/61/16/-/45/-/-/-/-/32/No; 8/120/53/16/5/32/-/-/-/-/-/No; 10/120/18/6/-/12/-/-/-/4/-/No; 10/144(red-highlighted length)/26/-/26/-/-/-/-/-/-/No; 12/120/29/11/18/-/- (strikethrough row, Complete = "Yes" green)/-/-/-/-; 14/120/25/8/-/17/-/-/-/-/-/No; 16.25/164.75(red)/8/-/-/8/-/-/-/-/-/No; 18/32/4/-/-/-/-/4/-/-/-/No; 20.75/120/21/-/-/8/13/-/-/-/-(strikethrough, Complete Yes); 48/120/0/-/-/-/-/-/-/1,3/-/No
- Indicators: red-highlighted Length cells (144, 164.75) flag lengths that are not 120" per annotation (465,337); yellow "Operator Notes" column background; strikethrough rows with green "Yes" Complete checkbox for completed line items
- Notes: this is the cutlist expansion referenced for Vented Trims / Line Item Notes sections; verified distinct from Screen (546,324), which shows the same row before either line item was completed
- Verified: pass3


##### Line Item Notes (327,413)

- "The Manager and Workers should be able to add and view Line Item Notes at any point in production. These notes are just within the app, they do not come from or push back to EBMS." (380,408)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (379,426)
- If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again. (379,466)

##### Stock column (326,443)

- The Stock column needs to be editable. (326,443)
- "If the number entered to come from stock is less than the Qty Ordered, then the Status needs to remain blank because the remaining amount still needs to be manufactured." (292,445)
- "If the number entered to come from stock is equal to the Qty Ordered, then the Status needs to automatically update to Stock." (292,449)

###### Screens (5)

###### Screen (215,421 dup) — Trim Scheduled, Stock order row expanded (line items)
- File: `p1_021_x157_y414.png`
- Illustrates: (326,443)-(330,445) "The Stock column needs to be editable." (context: expanded stock order line items)
- Table: expanded sub-table under S10125 row with columns Qty Ordered | Vented | Machine | Status | Product ID | Description | Width | Length | Line Item Notes. Rows: 100/X/Press Brake/—/TEW8262/End Wall Black/10/120; 150/X/Press Brake/—/TDE8262/Drip Edge Black/4/120; 150/X/Press Brake/—/TBT8262/Base Trim Black/4/120; 80/X/V1/—/TEW8306/End Wall Charcoal/10/120; 120/X/Press Brake/—/TSW8306/Side Wall Charcoal/10/120; 120/X/Rollformer/—/TSG8306/Snow Guard Charcoal/8/120
- Indicators: Vented column shows grey "X" circle icon (toggled off) for all rows; Machine column pre-populated with machine dropdown buttons already assigned
- Notes: below the expansion, ordinary scheduled rows (330605 etc.) continue
- Verified: pass3

###### Screen (251,470) — Trim Scheduled, order 330615 Reviewed icon shown (collapsed, duplicate)
- File: `p1_051_x251_y470.png`
- Same as Screen (300,454) — pixel-identical: row 330615's checkbox is an empty (unfilled) green-outline square, Reviewed clipboard/checkmark icon present, all other rows unchanged
- Notes: corrected — confirmed pixel-identical to Screen (300,454) (`p1_049_x300_y454.png`), not merely similar; row is not expanded in either image.
- Verified: pass3

###### Screen (300,436) — Order 330615 expanded, machines assigned to specific stations
- File: `p1_046_x300_y436.png`
- Illustrates: (292,445)-(298,448) "If the number entered to come from stock is less than the Qty Ordered, then the Status needs to remain blank..." / (292,449)-(292,451) "...equal to the Qty Ordered, then the Status needs to automatically update to Stock."
- Table: order 330615 (DAP Roofing Inc.) expanded: 5/X/Rollformer/—/—/TRC8262/Ridge Cap Black 6/12 Pitch/14/120/Notes(green); 10/X/Press Brake/—/—/TED8262/Eave Drip Black 6/12 Pitch/6/120/Notes; 8/X/V1/3/—/TGS8262/Gable Stater F 3" Black/11/120/Notes(green); 7/X/Rollformer/7/Stock (yellow badge)/TSG8262/Snow Guard Black/8/120/Notes
- Indicators: last row Status column shows a yellow "Stock" badge because Stock qty (7) equals Qty Ordered (7); third row has Stock=3 (less than 8 ordered) with blank Status, matching the described rule
- Notes: matches annotation rule precisely
- Verified: pass3

###### Screen (300,454) — Trim Scheduled, order 330615 Reviewed icon shown (collapsed)
- File: `p1_049_x300_y454.png`
- Same as Screen (300,399) base table except: row 330615's Reviewed column now shows the clipboard/checkmark icon (previously blank); its checkbox is a plain unfilled green square
- Notes: corrected — the row is NOT expanded in this image (no line-item detail is shown), contrary to a prior claim; the expanded line-item data for order 330615 belongs to Screen (300,436) (`p1_046_x300_y436.png`).
- Verified: pass3

###### Screen (1011,322) — Trim / Press Brake — Stock Manufacturing modal, filled
- File: `p1_279_x1011_y322.png`
- Illustrates: same as (1011,304); (1025,338)-(1031,340) "When the Worker clicks the Create Manufacturing Batch button, then a manufacturing batch needs to be created in EBMS."
- Dialog/popup: Title "Stock Manufacturing". Table rows: 5/TJC8262/J-Channel Black; 2/TJC8317/J-Channel White White; 2/TJC8250/J-Channel Dark Red; 1/TSG8306/Snow Guard Charcoal; 4/TSG8326/Snow Guard Coffee Brown; 3/TSG8262/Snow Guard Black; 1/TRC8262/Ridge Cap Black; 2/TRC8307/Ridge Cap Melcher's Green. Buttons: "Cancel" (red), "Create Manufacturing Batch" (green, enabled).
- Notes: Literal typo carried over: "J- Channel White White" (double "White") in row 2 — transcribed verbatim.
- Verified: pass3


### Releasing To Production (167,450) / (310,470)

- "The check boxes to select orders to Release To Production should only become available if the order is checked as reviewed." (149,442) — repeated at (291,464)
- "This should be a toggleable button that can only be used once all the trims within the order have a machine assigned to them. When toggling it "On" there should NOT be a pop-up but when toggling it from "On" to "Off" then there should be a pop-up asking you to confirm that you want to do that. Also, you should be able it toggle it when the order is collapsed as well as when the order is expanded." (144,435) — repeated at (287,458)
- "If the Manager selects a Stock Order to Release To Production, then all the Customer Order check boxes need to become unavailable even if they have been Reviewed." (127,467)
- "If the Manager selects a Customer Order to Release To Production, then any Stock Order check boxes need to become unavailable even if they have been Reviewed." (168,468)
- "If there are multiple Stock Orders, then if the Manager selects a Stock Order to Release To Production, the rest of the Stock Orders' check boxes need to stay available but NOT the Customer Orders." (127,491)
- The Release To Production button should only become available when you have selected at least one order. (291,478)
- Select all the orders you want to Release To Production and then click the Release To Production button. (299,486)
- "When an order or group of orders is Released To Production a cutlist and bendlist needs to be created from those orders and be added to the workers windows." (307,486)
- "Once an order(s) has been Released To Production, the check box needs to change to a released icon and the Status should change to Not Started." (293,492)

#### Screens (5)

##### Screen (137,454) — Trim Scheduled tab with a Stock order row, nothing selected
- File: `p1_025_x137_y454.png`
- Illustrates: (149,402)-(155,407) "Here in the Scheduled tab, Stock Orders would NOT have a Ship Date or Order Note. The Order# would have a prefix of "S" …"; (291,478) "The Release To Production button should only become available when you have selected at least one order."
- Header/tabs: "Trim" pill; tabs Unscheduled / Scheduled (active) / Production / Coils; "Completed orders for the past 90 days"; Search box.
- Controls: "All Scheduled Orders" button; calendar chip "Wednesday May 08/2024"; day pills Mon. May 06/2024 (1000 / 5000), Tue. May 07/2024 (1000 / 5000), Wed. May 08/2024 (1000 / 5000, active/white), Thu. May 09/2024 (1000 / 5000), Fri. May 10/2024 (1000 / 5000), each with a blue gear icon (Machine Capacities); "Release To Production" button greyed/disabled (pale green, italic text); "Allocated Stock" button (green, enabled, top right).
- Table: Columns: [checkbox] | [expand] | Ship Date | Production Date | Order # | Customer Name | Priority | Reviewed | Status | Trim Location | Order Notes. Rows: S10125 — Ship Date "N/A", Production Date Wed. May 08/2024, Customer "Stock", Select Priority, Reviewed icon, Trim Location "N/A", no Order Notes button; then 330605 H F H Inc (Notes red dot); 330608 Jireh Tools; 330609 Arnold Contracting; 330615 DAP Roofing Inc.; 330616 Arnold Contracting (Notes green dot); 330618 A.W.C.; 330631 Jireh Tools (Notes green dot); 330632 Upright Construction — all with Ship Date Thursday, May 09/2024, Production Date field "Wed. May 08/2024", "Select Priority", Reviewed icon, empty Status and Trim Location.
- Indicators: every checkbox unchecked; Release To Production disabled.
- Dialog/popup: none.
- Verified: pass3

##### Screen (137,485) — Trim Scheduled, additional Stock rows S10126/S10127, S10126 selected
- File: `p1_028_x137_y485.png`
- Illustrates: (127,491)-(135,494) "If there are multiple Stock Orders, then if the Manager selects a Stock Order to Release To Production, the rest of the Stock Orders' check boxes need to stay available but NOT the Customer Orders."
- Header/tabs: Scheduled tab, Reviewed column shows clipboard icon for every row (Stock rows and customer rows alike)
- Controls: Release To Production enabled (solid green); Allocated Stock enabled
- Table: rows S10125 (unchecked, available), S10126 (checked, green), S10127 (unchecked, available), then 330605 H F H Inc, 330608 Jireh Tools, 330609 Arnold Contracting, 330615 DAP Roofing Inc., 330616 Arnold Contracting, 330618 A.W.C., 330631 Jireh Tools, 330632 Upright Construction — none of the customer rows are checked, but all have Reviewed icons like the Stock rows
- Notes: corrected — this file does not show a "Set Production Date" calendar popup as previously claimed; it is the Scheduled table with the three Stock rows (S10125/S10126/S10127), matching the scenario previously (mis)described for File `p1_026_x137_y469.png`. Also corrected the prior claim that customer rows lack Reviewed icons — they do have them here.
- Verified: pass3

##### Screen (300,472) — Trim Scheduled, most rows checked, Release To Production enabled
- File: `p1_052_x300_y472.png`
- Illustrates: (299,486)-(305,488) "Select all the orders you want to Release To Production and then click the Release To Production button."
- Table: rows 330605, 330608, 330609, 330615, 330618, 330632 checked (green check); rows 330616 and 330631 remain unchecked (both still show their green Notes dot); all rows show the Reviewed icon; Release To Production button enabled (solid green)
- Notes: corrected — 330616 and 330631 are NOT checked in this image, contrary to a prior claim that all rows were checked. Order 330609 still shows the split icon.
- Verified: pass3

##### Screen (300,489) — Trim Scheduled, orders released, Status="Not Started"
- File: `p1_054_x300_y489.png`
- Illustrates: (293,492)-(298,496) "Once an order(s) has been Released To Production, the check box needs to change to a released icon and the Status should change to Not Started."
- Table: rows 330605, 330608, 330609, 330615, 330618, 330632 show the released box/crate icon in place of a checkbox, with Status "Not Started" (grey badge); rows 330616 and 330631 still show a plain unchecked green-outline checkbox (no Status), each with a green Notes dot
- Indicators: released icon resembles a small open box/crate; Status "Not Started" shown as light grey pill; Release To Production button disabled/greyed
- Notes: corrected — order 330631 is NOT released in this image (contrary to a prior claim); only 330605, 330608, 330609, 330615, 330618 and 330632 are released.
- Verified: pass3

##### Screen (342,497) — Trim Scheduled, orders released (duplicate)
- File: `p1_055_x342_y497.png`
- Same as Screen (300,489) — identical: rows 330605, 330608, 330609, 330615, 330618, 330632 show the released icon and "Not Started" status; 330616 and 330631 remain unreleased plain checkboxes; Release To Production button remains disabled/greyed
- Notes: corrected — the Release To Production button is NOT enabled in this image, contrary to a prior claim; it is styled the same pale/disabled green as in Screen (300,489).
- Verified: pass3


#### Releasing To Production with Priorities (225,418)

- Select the machine you want the trim to be assigned to. (151,418)
- "When releasing orders with different Priorities and some without Priorities, the cutlists and bendlists need to be created by looking at and combining the: Production Date, Gauge/Colour, Priority. For example, if the 7 orders being released are all 28Ga. - Bright White then 5 cutlists and bendlist need to be created. 1st list is the "NOW" order, 2nd list is the 2 "ASAP" orders, 3rd list is the "By 10:00" order, 4th list is the "By 3:00" order, 5th list is the rest of the orders without a priority. In the Wrapping tab each line item would be assigned the same Priority as the order was." (206,419)

### Machine Capacities (290,467)

- This top row would show the totals that are Scheduled for the day. (278,486)
- "> Total # of Pieces > Total Bends / Daily Max." (278,488) — repeated at (278,494)
- This would show the totals that have been assigned to each Machine. (278,491)
- Clicking on this button within the day tab will open this window. (265,483)

#### Screens (3)

##### Screen (251,486) — Machine Capacities popup
- File: `p1_053_x251_y486.png`
- Illustrates: (286,287)-(293,289) "Each day needs to show the Max. Capacity for the day and also how much has been assigned to the day." / (265,483)-(270,485) "Clicking on this button within the day tab will open this window."
- Dialog/popup: title "Machine Capacities", red X close button; header row "Wed. May 08/2024" with Pieces "542 (70 - Stock)" and Bends "2710 / 5000 (180 - Stock)"; machine rows: Press Brake 10 (0-Stock) pieces / 40/1000 (0-Stock) bends; V1 5 (0-Stock) / 50/1000 (0-Stock); V2 0 (0-Stock) / 0/1000 (0-Stock); Rollformer 12 (0-Stock) / 24/1000 (0-Stock); Caps 0 (0-Stock) / 0/1000 (0-Stock); bottom button "Print" (green)
- Notes: none
- Verified: pass3

##### Screen (251,504) — Machine Capacities
- File: `p1_057_x251_y504.png`
- Illustrates: "Clicking on this button within the day tab will open this window." (265,483)
- Header/tabs: Modal (X close, red, top-right). No department pill/tabs visible in this crop.
- Controls: Print button (green, enabled) at bottom.
- Table: Rows: header row "Wed. May 08/2024" with columns Pieces / Bends: 542 (70 - Stock) / 2710 / 5000 (180 - Stock); Press Brake: 187 (20 - Stock) / 983/1000 (80 - Stock); V1: 172 (0 - Stock) / 882/1000 (0 - Stock); V2: 80 (0 - Stock) / 507/1000 (0 - Stock); Rollformer: 99 (50 - Stock) / 198/1000 (100 - Stock); Caps: 4 (0 - Stock) / 140/1000 (0 - Stock).
- Indicators: Stock qty figures shown in blue in parentheses next to each black total.
- Dialog/popup: Title "Machine Capacities". Body: table of Pieces/Bends per day and per machine as above. Buttons: red X (close, top-right), Print (bottom).
- Notes: none.
- Verified: pass3

##### Screen (325,372) — Trim Scheduled, order 330609 expanded (Machine Capacities view)
- File: `p1_040_x325_y372.png`
- Illustrates: no directly adjacent annotation; general Scheduled-tab expansion behavior
- Header/tabs: Scheduled tab, "All Scheduled Orders" + date pills as in Screen (137,454)
- Controls: Release To Production disabled; Allocated Stock enabled
- Table: order 330609 (Arnold Contracting) expanded with columns Qty Ordered | Vented | Machine | Stock | Status | Product ID | Description | Width | Length | Line Item Notes: 8/X/[Machine... dropdown]/—/Select Status/TRC8250/Ridge Cap Dark Red/14/120/Notes(green); 16 (greyed/italic)/—/—/—/—/TED8250/Eave Drip Dark Red/6/120; 12 (greyed/italic)/—/—/—/—/TGS8250/Gable Stater F 3" Dark Red/11/120; 14/X/[Machine... dropdown]/—/Select Status/TSG8250/Snow Guard Dark Red/8/120
- Indicators: two middle rows (TED8250, TGS8250) appear greyed/italic (already scheduled elsewhere), matching the "partial order" grey-out rule; split icon next to Order # 330609
- Notes: corrected — this file was previously mislabeled as order 330631 with Press Brake machines assigned; it actually shows order 330609 in the Scheduled tab. The 330631/Press Brake content is on File `p1_042_x353_y399.png` (see below).
- Verified: pass3


### Rescheduing or Unscheduing an Order (325,502)

- "If an order has NOT been Release To Production yet, we need to be able to reschedule it to another day or unschedule that order." (335,505)
- As soon as a Trim Location has been added to an order it should display it here. (326,507)
- Clicking this button opens the calendar. (350,510) — repeated at (295,572)
- "Here you would be able to reschedule the order to another day or unschedule that order. If you unschedule the order then it disappears from the scheduled tab and reappears in the unscheduled tab like a new order again. Rescheduling and Unscheduling an order also resets any edits that the Manager had already made to the order." (343,526)
- "The order Status should remain Not Started until at least one trim on that order has the Status of Cut, Bent or Wrapped. Then, the Status should change to In Progress and remain In Progress until all trims on that order have the Status of Wrapped. This means that if a trim has Stock as its Status, the order Status will remain Not Started until that trim's Status is changed to Wrapped or another trim on that order is marked as Cut, Bent or Wrapped." (289,505)
- We need to be able to print this report. (262,522)
- When you expand an order, you should be able to see the Status of each individual trim. (293,525)

#### Screens (2)

##### Screen (300,504) — Trim Scheduled, Status progressing (In Progress/Wrapped) with Trim Location values
- File: `p1_056_x300_y504.png`
- Illustrates: (289,505)-(299,511) "The order Status should remain Not Started until at least one trim on that order has the Status of Cut, Bent or Wrapped. Then, the Status should change to In Progress and remain In Progress until all trims on that order have the Status of Wrapped."
- Table: rows now show varied Status/Trim Location values: 330605 Status "Wrapped" (green badge) Trim Location "258, 310"; 330608 Status "In Progress" (yellow badge) Trim Location "218"; 330609 Status "Wrapped" (green) Trim Location "108" (still has split icon); 330615 Status "In Progress" (yellow) Trim Location "231"; 330616 no status yet (unchecked plain checkbox, green Notes dot); 330618 Status "Not Started" (grey); 330631 unchecked, green Notes dot, no status; 330632 Status "In Progress" (yellow) Trim Location "302"
- Indicators: Status badges color-coded: green=Wrapped, yellow=In Progress, grey=Not Started; all released rows show the box/package icon instead of a checkbox
- Notes: demonstrates the Status lifecycle and multiple Trim Location numbers per order (comma-separated)
- Verified: pass3

##### Screen (342,512) — Trim / Scheduled tab, calendar popup
- File: `p1_058_x342_y512.png`
- Illustrates: "Clicking this button opens the calendar." (350,510)
- Header/tabs: Department pill "Trim". Top-right "Completed orders for the past 90 days". Tab bar: Unscheduled / Scheduled (active, underlined) / Production / Coils. Search box top-right.
- Controls: "All Scheduled Orders" button; day strip: Mon. May 06/2024 (1000/5000), Tue. May 07/2024 (1000/5000), Wed. May 08/2024 (1000/5000, selected/white), Thu. May 09/2024 (1000/5000), Fri. May 10/2024 (1000/5000), each with gear icon. "Release To Production" button greyed/disabled. "Allocated Stock" button green/enabled.
- Table: Columns: (icon) | (expand) | Ship Date | Production Date | Order # | Customer Name | Priority | Reviewed | Status | Trim Location | Order Notes. 8 rows visible, dates Thu. May 09/2024, Production Date "Wed. May 08/2024" buttons, Order#s partially hidden behind popup (330605, 330608, 330609 (split-order icon), 330615, 330616, 330618, 330631, 330632). Priority column shows "iority" (Select Priority, obscured). Reviewed icons present each row. Status column obscured by popup. Order Notes buttons: two shown green (checked, rows 330616 and 330631), rest white.
- Indicators: Green checkbox outlines on 2 rows (left edge) indicating selected; green "Notes" buttons = read/dealt-with notes.
- Dialog/popup: Calendar "May 2024" with prev/next arrows, days Su-Sa, day 8 highlighted green (selected), day 1 lightly circled. Buttons: Cancel, Set Date (green), Unschedule (green, below).
- Notes: none.
- Verified: pass3


### Overdue Orders (311,537)

- "Whenever there is an order that is overdue, the day tab that has that order should be highlighted in red. Also, the calendar should be highlighted in red." (293,540)
- "It is Thursday and there are orders that were scheduled for Wednesday that are not completed yet (overdue). The Wednesday tab should then be highlighted in red" (326,541)
- When you click on the day that has overdue orders within it, then you would see the orders that are overdue highlighted in red. (293,555)
- If there are overdue orders for a day that is not displayed in the week tabs then you should still see the highlighted calendar. (326,569)
- The date that has the overdue order should be highlighted in red within the calendar. (326,574)

#### Screens (4)

##### Screen (261,567) — Overdue row highlighted with In Progress status
- File: `p1_066_x261_y567.png`
- Header/tabs: Trim pill, Scheduled tab active, "Wed. May 08/2024" selected (normal, not highlighted).
- Controls: Release To Production disabled; Allocated Stock enabled.
- Table: Base rows 330605–330632 collapsed, plus row 330640 H F H Inc expanded: sub-table Qty Ordered 4, Vented N/A, Machine N/A, Stock (blank), Status "Wrapped" (green, not Bypassed), Product ID TJC8262, Description J-Channel Black, Width 4, Length 120. Trim Location on the collapsed 330640 row reads "103".
- Indicators: Green "Wrapped" badge (this is the same order 330640 that appears "Bypassed" in Screen 063, now shown Wrapped/completed).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (300,541) — Overdue day tab highlighted red, full order list
- File: `p1_062_x300_y541.png`
- Illustrates: "Whenever there is an order that is overdue, the day tab that has that order should be highlighted in red. Also, the calendar should be highlighted in red." (293,540)
- Header/tabs: Trim pill, Scheduled tab active. Day strip: "Thursday May 08/2024" tab shown fully red (selected), Mon 06/Tue 07 normal, "Wed. May 08/2024 (1000/5000)" tile highlighted red, Thu 09/Fri 10 normal.
- Controls: Release To Production disabled; Allocated Stock enabled.
- Table: Columns: Ship Date, Production Date, Order #, Customer Name, Priority, Reviewed (blank), Status (blank), Trim Location (blank), Order Notes. Rows (all Ship Date "Friday, May 10/2024", Production Date "Thu. May 09/2024", Priority "Select Priority"): 330710 Arnold Contracting (Notes green); 330708 Jireh Tools (Notes white); 330685 H F H Inc (Notes white); 330692 DAP Roofing Inc. (Notes white); 330683 Arnold Contracting (Notes green); 330684 DAP Roofing Inc. (Notes white); 330701 Arnold Contracting (Notes green); 330702 Upright Construction (Notes white).
- Indicators: All 8 row checkboxes shown as empty green-outlined squares (unchecked) on left. Red highlight on the day-tab "Thursday May 08/2024" and on the "Wed. May 08/2024" capacity tile.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (300,555) — Overdue rows highlighted, mixed statuses
- File: `p1_065_x300_y555.png`
- Illustrates: overdue row/day highlighting.
- Header/tabs: Trim pill, Scheduled tab active. Day strip: "Wednesday May 08/2024" tab and "Wed. May 08/2024 (1000/5000)" tile both highlighted salmon/red.
- Controls: Release To Production disabled; Allocated Stock enabled.
- Table: Rows 330605 H F H Inc, Wrapped, 258,310 (normal); 330608 Jireh Tools, In Progress, 218 (red row highlight); 330609 Arnold Contracting (split icon), Wrapped, 108 (normal); 330615 DAP Roofing Inc., Wrapped, 231 (normal); 330616 Arnold Contracting, Wrapped, 308 (normal); 330618 A.W.C., Not Started (red row highlight, no location); 330631 Jireh Tools, In Progress, 215 (red row highlight); 330632 Upright Construction, Wrapped, 302 (normal).
- Indicators: Red row-highlight bars on rows 330608, 330618, 330631 only; red day tab and red capacity tile.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (342,537) — Trim Scheduled list, Wed 08 day (no overdue highlight)
- File: `p1_061_x342_y537.png`
- Illustrates: nearby overdue-highlighting annotation; this particular crop shows no red state.
- Header/tabs: Trim pill, Scheduled tab active. Day strip Mon 06 – Fri 10 May 2024, "Wed. May 08/2024 (1000/5000)" selected (normal white, not highlighted).
- Controls: Release To Production disabled (pale/greyed); Allocated Stock enabled (green).
- Table: Columns Ship Date/Production Date/Order #/Customer Name/Priority/Reviewed/Status/Trim Location/Order Notes. Rows: 330605 H F H Inc, Wrapped, 258,310; 330608 Jireh Tools, In Progress, 218; 330609 Arnold Contracting (split icon), Wrapped, 108; 330615 DAP Roofing Inc., In Progress, 231; 330616 Arnold Contracting, blank status (row checkbox selected); 330618 A.W.C., Not Started; 330631 Jireh Tools, blank status (row checkbox selected); 330632 Upright Construction, In Progress, 302. No row 330640.
- Indicators: Green outline checkboxes on 330616 and 330631 rows. No red highlighting anywhere in this crop.
- Dialog/popup: none.
- Notes: Unlike neighbouring entries, this crop shows no overdue red highlighting on the day tab or any row.
- Verified: pass3


### Orders that bypassed production (291,535)

- "When the Manager makes an order Bypass Production, then that order would automatically be assigned the current date as it's Production Date and appear in the day tab as a released order. The Reviewed column would say N/A and the Status would be Bypassed." (251,546)
- When you expand the order, the Vented and Machine columns would say N/A and the line item Status would be Bypassed. (253,563)
- The Status would stay Bypassed until a Worker wraps the trim, then it would change to Wrapped. (252,578)

#### Screens (2)

##### Screen (261,537) — Trim Scheduled tab, full order list incl. Bypassed order
- File: `p1_060_x261_y537.png`
- Illustrates: "When the Manager makes an order Bypass Production, then that order would automatically be assigned the current date as it's Production Date and appear in the day tab as a released order. The Reviewed column would say N/A and the Status would be Bypassed." (251,546)
- Header/tabs: Same Trim/Scheduled tab, Wed. May 08/2024 selected day.
- Controls: Same day strip/buttons.
- Table: Rows 330605–330632 same as Screen 059 (collapsed), plus new row 330640 H F H Inc, Priority "Select Priority", Reviewed column "N/A", Status "Bypassed" (purple).
- Indicators: Purple "Bypassed" status badge on order 330640.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (261,551) — Bypassed order row expanded (line item)
- File: `p1_063_x261_y551.png`
- Illustrates: "the Status would be Bypassed" (251,546)
- Header/tabs: Trim pill, Scheduled tab active, "Wed. May 08/2024" selected (normal, not highlighted).
- Controls: Release To Production disabled; Allocated Stock enabled.
- Table: Base rows 330605–330632 collapsed (unchanged from Screen 059/060), plus row 330640 H F H Inc expanded: sub-table Qty Ordered 4, Vented N/A, Machine N/A, Stock (blank), Status "Bypassed" (purple), Product ID TJC8262, Description J-Channel Black, Width 4, Length 120, Line Item Notes "Notes" button.
- Indicators: Purple "Bypassed" badge on order 330640 and its expanded sub-row.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3


### Allocated Stock (325,535)

- Clicking the Allocated Stock button opens this window (360,550)
- "This list would show all the trims that are assigned to come from Stock that have NOT been Wrapped yet. As soon as an order has been marked as Reviewed, then any number that is in the Stock column and NOT Wrapped yet what show up here in this list. It would show a combined total for the Product ID that has been assigned to be pulled from Stock across all orders that have the Reviewed column toggled "on"." (371,554)
- This list needs to be sorted by Color first and then Product ID. We need a distinct line between the colors. (336,554)
- "This needs to be a live report, as more orders are marked as Reviewed and have trims assigned as coming from stock then the numbers need to update. Like wise as trims are being Wrapped, then numbers also need to update. It would only update from the Wrapping tab when a line item gets the Status of Wrapped." (371,560)
- "The Stock numbers ONLY come from Stock Orders, when the Manager creates an order to manufacture Stock." (245,508)
- "The Stock numbers are part of the totals, NOT in addition to the totals. Example: 20 of the 187 pieces are Stock, 80 of the 983 bends are Stock." (278,510)

#### Screens (1)

##### Screen (342,553) — Allocated Stock modal
- File: `p1_064_x342_y553.png`
- Illustrates: "Clicking the Allocated Stock button opens this window" (360,550)
- Header/tabs: Modal over Trim/Scheduled screen; red X close top-right. Title "Allocated Stock".
- Controls: Search box.
- Table: Columns: Color, Product ID, Description, Qty. Rows: Black/TGS8262/Gable Starter F Black/3; Black/TRC8262/Ridge Cap Black/10; Black/TSG8262/Snow Guard Black/7; Bright White/TJC8783/J-Channel Bright White/2; Charcoal/TED8306/Eave Drip Charcoal/27; Charcoal/TGD8306/Gable Divider Charcoal/31; Charcoal/TGS8306/Gable Starter F Charcoal/15; Coffee Brown/TBT8326/Base Trim Coffee Brown/3; White White/TBT8317/Base Trim White White/18; White White/TJC8317/J-Channel White White/34. 10 rows total, all shown.
- Indicators: Orange divider lines between different Color groups.
- Dialog/popup: Title "Allocated Stock". No action buttons besides close X.
- Notes: none.
- Verified: pass3


#### Remanufacture Request from the Wrapping tab (460,545) / (627,442)

"This is the new Remanufacture cutlist from Wrapping. Opening it shows just what needs to be Remanufactured." (445,561)

##### Screens (2)

###### Screen (660,522) — Trim Stock Manufacturing – Press Brake
- File: `p1_191_x660_y522.png`
- Illustrates: (686,514)-(691,518) "It should be highlighted in orange until it has been marked as Cut (Complete) by the Slinet. After is has been marked as Cut, then it should be highlighted in green." / (612,501)-(617,504) "Marking it as Complete will change the Remanufacture column to green in the Wrapping tab."
- Header/tabs: department pill "Trim"; green "Stock Manufacturing" button below it; top-right "Completed bendlists for the past 90 days" button; Search box; tab bar: Slinet, Press Brake (active/white), V1, V2, Rollformer, Caps, Wrapping; right-aligned "Coils" tab
- Controls: each row has a "Done" button (green, appears disabled/greyed "Done" label italic) and a row-expand chevron
- Table: columns Production Date | Gauge/Colour | Priority | Remanufacture | (Done button). Rows: Wed. May 08/2024 – 28Ga.-Black; Wed. May 08/2024 – 28Ga.-Bright Red; Wed. May 08/2024 – 28Ga.-Bright White (Remanufacture cell shows green "1"); Wed. May 08/2024 – 28Ga.-Bright White; Wed. May 08/2024 – 28Ga.-Coffee Brown; Wed. May 08/2024 – 28Ga.-Colorbond Bronze; Wed. May 08/2024 – 28Ga.-Dark Red; Wed. May 08/2024 – 28Ga.-Melcher's Green; Wed. May 08/2024 – 26Ga.-Black; Wed. May 08/2024 – 26Ga.-Dark Red; (orange horizontal divider line); Thu. May 09/2024 – 28Ga.-Black; Thu. May 09/2024 – 28Ga.-Stone Grey (12 rows visible, more rows likely below)
- Indicators: Remanufacture cell on the "28Ga.-Bright White" row is highlighted solid green with number "1"; an orange horizontal rule separates Wed. May 08 rows from Thu. May 09 rows; row shading alternates light grey/white
- Dialog/popup: none
- Notes: rows alternate shading by date grouping; date labels appear as blue links
- Verified: pass3

###### Screen (660,539) — Trim Stock Manufacturing – Press Brake (row expanded)
- File: `p1_192_x660_y539.png`
- Illustrates: (668,495)-(672,497)/(711,495)-(715,497) "Enter the amount that needs to be Remanufactured"; (699,482)-(705,485) "Even if there is already a number in the Stock column, we still need to be able to change the number to anything from zero up to the Qty Ordered."
- Same as Screen (660,522) except: the "28Ga.-Bright White" row (Remanufacture = green "1") is expanded, outlined in black, revealing a detail sub-row with columns Width 6 | Length 120 | Qty Ordered 19 | Stock (blank) | Qty to Manufacture 19 | ID TED8783 | Description "Eave Drip Bright White 8/12 Pitch" | Remanufacture (blank) | Machine "Press Brake" (button) | Status "Cut" (blue dot) | Complete checkbox "No" (disabled/greyed) | Drawing (image icon) | Line Item Notes "Notes" button (green)
- Indicators: Status dot blue next to "Cut"; Complete checkbox shows "No" greyed/disabled; Line Item Notes button green
- Dialog/popup: none
- Notes: expand chevron rotated/highlighted on the active row
- Verified: pass3


### The Coils Tab (310,583)

Referenced also as "New Coils coming into the App" (336,586).

#### Screens (11)

##### Screen (226,607) — EBMS Product window, Production tab (Trim/coil, unset)
- File: `p1_029_x226_y607.png`
- Illustrates: (220,610)-(224,613) "We will need all these fields under the Production tab in EBMS."
- Header/tabs: EBMS desktop app window titled "Products\Coil Folder\Flat Stock Coils\28 Ga. Flat Stock Coils\28ga x 48" FS Coil  Bright White"; Product field "CS488783"; Category field "28 Ga. Flat Stock Coils"; tab bar: Pricing, Count, Components, Component of, Accessories, Advanced, Parts Calculate, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production (active), Elevate E-Commerce, Custom Prices, Roll Options, 2026, more (»)
- Controls: fields Production Type (empty dropdown), Gauge "28", Thickness "0.015", Width "48", Grade "33", Color "Bright White"; bottom buttons OK, Cancel, New, Delete, Print (dropdown)
- Table: none
- Indicators: none
- Dialog/popup: this is the EBMS native product editor window (non-Wiseline UI)
- Notes: this is a reference screenshot of the underlying ERP (EBMS) product record, not the Wiseline app
- Verified: pass3

##### Screen (226,627) — EBMS product tree/search with Production tab (Trim category, empty)
- File: `p1_030_x226_y627.png`
- Illustrates: no directly adjacent annotation; general EBMS coil category browsing reference
- Header/tabs: left panel "Search For Description:" = "28GA X 48" FS COIL  BRIGHT WHITE" with product tree (Products > Metal, Metal Trims, Screws, Underlayment, Agricultural Man Doors, Caulking Sealants, Closures & Sealers/Vented Closure, Closures Not On Web, Coil Folder > Tuff Rib & Diamond Rib Coils, Standing Seam Coils, 24 ga 44.72" AZ50 Coil, 24 Ga. 43" Coils, 26 ga 44.72" AZ50 Coil, Agra Panel Coils, Bare/Paintable Coils, Board and Batten Coils, Econo Coil Stock, Flat Stock Coils > 24 Ga./26 Ga./28 Ga. Flat Stock Coils (selected, highlighted blue) /28 Ga. Flat Stock Coils Colorbond, Colour Chart, Inactive, Lumber, Master Flash, Misc, Nails, Non-Tracked Items, Over Stock @ Reduced Price, Plastics, Poly Rebar, Reline Liner, Rivets Stainless Steel, Roof Vents And Louver Vents, Sliding Door Hardware, Snow Guards, Styrofoams, Tools, Touch Up Paint, Trough & Accessories, Versa Tube Building System)
- Controls: right panel same product editor, tab bar: General, Purchasing, Pricing, Count, Components, Component of, Accessories, Advanced, Parts Calculate, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production (active), Elevate E-Commerce, Custom Prices; fields Production Type (empty), Color (empty), Gauge "28"; OK/Cancel/New/Delete/Print buttons
- Table: category tree list (described above)
- Notes: this is the EBMS category browser + product editor combined; not a Wiseline app screen
- Verified: pass3

##### Screen (231,628) — EBMS Product window, Production tab, zoomed (no tree panel)
- File: `p1_031_x231_y628.png`
- Header/tabs: title "Products\Coil Folder\Flat Stock Coils\28 Ga. Flat Stock Coils\28ga x 48" FS Coil  Bright White"; Product "CS488783", Category "28 Ga. Flat Stock Coils"; tab bar: Pricing, Count, Components, Component of, Accessories, Advanced, Parts Calculate, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production (active), Elevate E-Commerce, Custom Prices, Roll Options, 2026
- Controls: fields Production Type (empty), Gauge "28", Thickness "0.015", Width "48", Grade "33", Color "Bright White"; OK/Cancel/New/Delete/Print buttons
- Notes: corrected — not identical to Screen (226,627): this view is cropped/zoomed with no left product-tree panel, shows extra Thickness/Width/Grade fields not visible there, and has additional Roll Options/2026 tabs not present in that screen.
- Verified: pass3

##### Screen (300,569) — Overdue day tab red, calendar popup open
- File: `p1_067_x300_y569.png`
- Header/tabs: Trim pill, Scheduled tab active. Day strip "Wednesday May 08/2024" tab highlighted solid red.
- Controls: Release To Production disabled; Allocated Stock enabled. Rows behind popup: Ship Date "Friday, May 10/2024", Production Date buttons "Thu. May 09/2024", Order #s 330710/330708/330685/330692/330683/330684/330701/330702, Priority column obscured by popup, Notes buttons (some green: 330710, 330683, 330701).
- Table: Order list as above, partly obscured by the calendar popup.
- Indicators: All row checkboxes shown as empty green-outlined squares (unchecked) on left.
- Dialog/popup: "May 2024" calendar. Day 3 highlighted solid red (prev/next arrows either side). Day 9 highlighted green (selected). Buttons: Cancel, "Set Date" (green).
- Notes: This is not a Coils-tab screenshot — it is a calendar popup over the Overdue Orders scheduled list.
- Verified: pass3

##### Screen (300,589) — Coils tab, folder list
- File: `p1_068_x300_y589.png`
- Illustrates: "When any one or more coils within a folder in EBMS qualify to show up in this Coils tab, then a folder tab needs to appear with the same title as the folder that the coil is in within EBMS." (253,624)
- Header/tabs: Trim pill; top-right "Completed order history for the past 90 days". Tabs: Unscheduled / Scheduled / Production / Coils (active). Folder tabs: 24 Ga. B&B Coils, 24 Ga. Flat Stock Coils, 24 Ga. SS Coils, 26 Ga. B&B Coils, 26 Ga. Flat Stock Coils, 26 Ga. SS Coils, 28 Ga. Flat Stock Coils (active/white), 28 Ga. Flat Stock Coils Colorbond. "Coil Filter" button (green).
- Table: Columns: Product ID, Color, Width (in.), Count, Total Linear Feet, Total Weight (lbs.). 12 rows, alternating blue/white shading: CS488262 Black 48 3 4,281 10,950; CS488273 Bone White 48 2 5,399 13,811; CS488783 Bright White 48 2 1,691 4,325; CS488055 Buckskin 48 0 0 0; CS488378 Burnished Slate 48 3 6,797 17,387; CS488306 Charcoal 48 1 240 614; CS488326 Coffee Brown 48 1 2,341 5,988; CS483234 Copper Penny 48 1 2,280 5,832; CS488229 Dark Brown 48 0 0 0; CS369822 Ebony Textured 36 1 771 1,972; CS489822 Ebony Textured 48 1 1,375 3,517; CS488730 Regent Grey 48 1 724 1,852.
- Indicators: Alternating light-blue/white row shading; zero-count rows (Buckskin, Dark Brown) shown with 0 values in orange/red text.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (361,608) — Trim / Coils tab
- File: `p1_114_x361_y608.png`
- Illustrates: no adjacent annotation directly touching this thumbnail region; nearest is "Choose a coil folder" (327,590) and folder-tab notes (253,624)-(258,629)
- Header/tabs: department pill "Trim" (top-left); top-right button "Completed order history for the past 90 days"; tab bar Unscheduled / Scheduled / Production / **Coils** (active); Search... box
- Controls: coil-grade folder tabs "24 Ga. B&B Coils", "24 Ga. Flat Stock Coils", "24 Ga. SS Coils", "26 Ga. B&B Coils", "26 Ga. Flat Stock Coils", "26 Ga. SS Coils", "28 Ga. Flat Stock Coils" (active/white), "28 Ga. Flat Stock Coils Colorbond"; green "Coil Filter" button
- Table: columns Product ID | Color | Width (in.) | Count | Total Linear Feet | Total Weight (lbs.). Rows (blue shading alternating): CS488262 Black 48 3 4,281 10,950; CS488273 Bone White 48 2 5,399 13,811; CS488783 Bright White 48 3 5,422 13,868 (expanded, black-bordered — shows nested Coil # sub-table); CS488055 Buckskin 48 0 0 0; CS488378 Burnished Slate 48 3 6,797 17,387; CS488306 Charcoal 48 1 240 614; CS488326 Coffee Brown 48 1 2,341 5,988; CS483234 Copper Penny 48 1 2,280 5,832; CS488229 Dark Brown 48 0 0 0; CS369822 Ebony Textured 36 1 771 1,972; CS489822 Ebony Textured 48 1 1,375 3,517; CS488730 Regent Grey 48 1 724 1,852. Total visible rows: 12 (plus nested sub-rows). Nested sub-table under CS488783 (Bright White): Coil # | Coil Thickness | Linear Feet | Weight (lbs.) | Location (Rollforming / Trim checkboxes) | Slinet In/Out | Note — rows: 37067677 | 4.125 | 1,533 | 3,986 | Rollforming unchecked, Trim checked | Slinet unchecked; 37067678 | 0.5 | 158 | 411 | Rollforming unchecked(greyed) Trim checked | Slinet checked; 37067692 | (blank) | 3,731 | 9,701 | Rollforming unchecked, Trim unchecked | Slinet unchecked(greyed)
- Indicators: light-blue row banding alternates per product row; the expanded Bright White row/coil block is outlined in black; checked checkboxes shown filled
- Dialog/popup: none
- Notes: this is the Manager's Coils tab default (folder) view
- Verified: pass3

##### Screen (361,628) — Trim / Coils tab
- File: `p1_115_x361_y628.png`
- Illustrates: same region as previous, no distinct adjacent annotation
- Same as Screen (361,608) — identical screenshot (duplicate capture, no visible differences)
- Verified: pass3

##### Screen (441,367) — Coils tab list, filter/location header row
- File: `p1_095_x441_y367.png`
- Same top portion of the Coils tab table (Slinet/Press Brake/... sub-tab bar + Coils button, then Product ID/Color/Width/Count/Total Linear Feet/Total Weight header, rows Black/Bone White/Bright White + expanded coil sub-rows 37067677/37067678/37067692 with Location Rollforming/Trim and Slinet In/Out checkboxes) — matches Screen 073/077 content.
- Verified: pass3

##### Screen (978,376) — Trim / Location picker — all available
- File: `p1_280_x978_y376.png`
- Header/tabs: Warehouse #1 (active)/Warehouse #2/Warehouse #3; Trim (active)/Rollforming/Accessories.
- Controls: Location-type pill headers: "1 of 1", Wooden, Small, Medium, Large, Long. All location number buttons 101–616 shown in bold/black (fully available), no greyed-out entries.
- Table: n/a (button grid).
- Notes: Red "X" close button top-right. This is the "all locations free" baseline state, contrasted with Screen (978,396) below.
- Verified: pass3

##### Screen (978,396) — Trim / Location picker — some locations greyed (occupied)
- File: `p1_281_x978_y396.png`
- Illustrates: (982,392)-(988,394) "As locations are assigned to orders they grey out and become unavailable."
- Same grid as Screen (978,376) except: several numbers now greyed/disabled: 102,104,105 ("1 of 1" col); 204,205,207,209,210 (Wooden); 303,304,305,306,307,308,311,313,314,315,318 (Small); 402,404,406,408,409 (Medium); 502,504,505,506 (Large); 602,604,605,609,612,613,614 (Long) — remaining numbers in each column are bold black/available.
- Notes: Confirms visual convention: bold black text = available location; light grey text = occupied/unavailable location.
- Verified: pass3

##### Screen (1047,288) — Trim / Coils tab — coil inventory table
- File: `p1_277_x1047_y288.png`
- Illustrates: nearest heading (1057,283)-(1063,285) "Coil tab in the Worker window"
- Header/tabs: same top bar; Tabs: Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping, Coils (active, outlined).
- Table: Columns: Product ID | Color | Width (in.) | Count | Total Linear Feet | Total Weight (lbs.). Rows (alternating light-blue/white banding): CS488262/Black/48/3/4,281/10,950; CS488273/Bone White/48/2/5,399/13,811; CS488783/Bright White/48/2/1,691/4,325; CS488055/Buckskin/48/0/0/0; CS488378/Burnished Slate/48/3/6,797/17,387; CS488306/Charcoal/48/1/240/614; CS488326/Coffee Brown/48/1/2,341/5,988; CS483234/Copper Penny/48/1/2,280/5,832; CS488229/Dark Brown/48/0/0/0; CS369822/Ebony Textured/36/1/771/1,972; CS489822/Ebony Textured/48/1/1,375/3,517; CS488730/Regent Grey/48/1/724/1,852. 12 rows visible, likely more below (not captured in crop).
- Indicators: Alternating blue/white row banding by colour group.
- Notes: Zero-count rows (Buckskin, Dark Brown) still listed with 0/0/0 — folder/colour always shown even if no matching coils currently in stock.
- Verified: pass3


#### Coil Filtering (293,587)

- Choose a coil folder (327,590)
- The Count column shows the number of lots for that coil, the Total Linear Feet & Total Weight columns show the totals of those lots. (326,595)
- Clicking on a coil row will open a drop down showing the coil lots (304,604)
- Clicking the Coil Filter button will open this window. (281,604)
- Within the drop down you would see all the lots that are in EBMS. (326,609)
- "When the Thickness, Width and Grade ALL fall within the ranges set in the filter, then that coil will show up in the Coils tab within the folder it's in, within EBMS." (253,609)
- "Here you would enter the range of Thickness, Width and Grade of coils that you want to be able to see in this Coil tab. You can also click the Apply All check box which would make the range limitless." (287,612)
- The Weight is calculated off of the Gross Weight in EBMS and the Linear Feet. (350,613)
- "When a new coil is entered into EBMS, then that coil needs to appear in the App. The Linear Feet (main unit in EBMS) for that coil would be pushed into the App from Ebms. The Weight would be calculated off of the Linear Feet. The Coil Thickness would be blank until someone inputs and applies all the needed parameters. The Location and Slinet check boxes would also be blank (unchecked)." (350,616)
- "When any one or more coils within a folder in EBMS qualify to show up in this Coils tab, then a folder tab needs to appear with the same title as the folder that the coil is in within EBMS." (253,624)
- Clicking in any of these 3 columns would open this window (307,624) — repeated (368,648)
- "We need to be able to enter either the Coil Thickness or Linear Feet or Weight and the others would auto adjust but only if the Material Thickness and Core OD are filled in." (292,630) — repeated (351,693)
- The Color and Width entered in the Production tab in EBMS would be what would appear in the Color and Width columns. (253,631)
- This row just show the coil that you are currently adjusting (294,636)
- Clicking the Apply button would give you one of these 2 pop ups (305,644)
- If the coil has been completely used up (294,645)
- If there's still an amount left on the coil (310,647)
- "We need to be able to check a coil into a location before entering a Coil Thickness, but even if a coil is checked into the Trim department the Slinet check box needs to remain unavailable until a Coil Thickness is present as well. The Slinet check box should only be available if both a Coil thickness is present and the coil is checked as being in the Trim department." (342,648)
- By clicking Yes, Deplete & Delete Coil the coil would be zeroed out in EBMS and deleted out of the App. (263,658) — repeated (502,461)
- "When you open the Coil Adjustment window for the first time, then the Coil Thickness, Material Thickness & Core OD fields would be blank." (351,658)
- By clicking Yes, Make Adjustment the new Linear Feet amount would get pushed back into EBMS. (294,658) — repeated (466,461), (356,719)
- The Apply button would only become available once the Material Thickness and Core OD fields have been filled in. (351,681)

##### Screens (1)

###### Screen (260,607) — Coil Filter dialog open
- File: `p1_072_x260_y607.png`
- Illustrates: "Here you would enter the range of Thickness, Width and Grade of coils that you want to be able to see in this Coil tab. You can also click the Apply All check box which would make the range limitless." (287,612)
- Header/tabs: Same Coils tab background.
- Controls: Modal fields: Thickness Between [0.015] & [0.026], "Apply All" checkbox (unchecked); Width Between [21] & [48], Apply All checkbox (unchecked); Grade Between [33] & [50], Apply All checkbox (unchecked). Buttons: Apply (green), Cancel (red).
- Table: background table (Coils list) visible around the modal, same columns as Screen 068.
- Dialog/popup: Title "Coil Filter". Buttons Apply/Cancel.
- Notes: none.
- Verified: pass3


##### Coil Notes (294,668)

"We need to be able to add a Note to any coil. This Note is only within the App and does NOT need to push back to EBMS. The Note needs to show up everywhere that the coil shows up and all Managers and Workers need to be able to add or edit the note." (278,674)

###### Screens (8)

###### Screen (260,624) — Coils tab list (unchanged, no expansion)
- File: `p1_075_x260_y624.png`
- Illustrates: "We need to be able to add a Note to any coil..." (278,674) — this crop does not show a note; see p1_073/p1_081 for expanded/note states.
- Header/tabs: Same Coils tab as Screen 068.
- Table: Same 12-row base list as Screen 068 (Black...Regent Grey), no row expanded, no Note text visible.
- Dialog/popup: none.
- Notes: Unlike the original caption, this crop shows the plain collapsed list — no note text is present here.
- Verified: pass3

###### Screen (300,607) — Coil row expanded showing lots/location/Slinet checkboxes
- File: `p1_073_x300_y607.png`
- Illustrates: "Clicking on a coil row will open a drop down showing the coil lots" (304,604)
- Header/tabs: Same Coils tab.
- Controls: Same folder tabs/Coil Filter button.
- Table: Row CS488783 Bright White expanded to sub-table: Coil # | Coil Thickness | Linear Feet | Weight (lbs.) | Location (Rollforming/Trim checkboxes) | Slinet In/Out checkbox | Note. Row 37067677: 4.125, 1,533, 3,986, Rollforming unchecked, Trim checked, Slinet unchecked. Row 37067678: 0.5, 158, 411, Rollforming unchecked(greyed), Trim checked, Slinet checked. Only these 2 coil rows present (no 37067692 yet). Base table rows below (Buckskin...Regent Grey) unchanged.
- Indicators: Checkboxes shown checked (black check) vs unchecked (empty) vs greyed/disabled (light grey, e.g. Rollforming on row 37067678 since Trim+Slinet checked).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (300,671) — Coils tab, 28 Ga. Flat Stock Coils, Bright White row expanded
- File: `p1_080_x300_y671.png`
- Illustrates: (307,624)-(312,626) "Clicking in any of these 3 columns would open this window" (Count / Total Linear Feet / Total Weight expand the product row); Department checkboxes (342,648).
- Header/tabs: "Trim" pill; tabs Unscheduled / Scheduled / Production / Coils (active); "Completed order history for the past 90 days"; Search box; sub-tabs 24 Ga. B&B Coils / 24 Ga. Flat Stock Coils / 24 Ga. SS Coils / 26 Ga. B&B Coils / 26 Ga. Flat Stock Coils / 26 Ga. SS Coils / 28 Ga. Flat Stock Coils (active, white) / 28 Ga. Flat Stock Coils Colorbond; "Coil Filter" button (green).
- Table: Columns: Product ID | Color | Width (in.) | Count | Total Linear Feet | Total Weight (lbs.). Rows: CS488262 Black 48 3 4,281 10,950; CS488273 Bone White 48 2 5,399 13,811; CS488783 Bright White 48 3 5,422 13,868 (expanded, black border); CS488055 Buckskin 48 0 0 0; CS488378 Burnished Slate 48 3 6,797 17,387; CS488306 Charcoal 48 1 240 614; CS488326 Coffee Brown 48 1 2,341 5,988; CS483234 Copper Penny 48 1 2,280 5,832; CS488229 Dark Brown 48 0 0 0; CS369822 Ebony Textured 36 1 771 1,972; CS489822 Ebony Textured 48 1 1,375 3,517; CS488730 Regent Grey 48 1 724 1,852. Expanded sub-table for Bright White: Coil # | Coil Thickness | Linear Feet | Weight (lbs.) | Location: Rollforming / Trim | Slinet In / Out | Note. Sub-rows: 37067677 4.125 1,533 3,986 — Rollforming unchecked, Trim checked, Slinet unchecked; 37067678 0.25 78 203 — Rollforming greyed, Trim checked, Slinet checked; 37067692 8.5 3,731 9,701 — Rollforming checked, Trim unchecked, Slinet greyed. Note column empty.
- Indicators: alternating light-blue row shading; Rollforming/Slinet checkboxes greyed on rows where the other department holds the coil.
- Dialog/popup: none.
- Notes: The Coil Adjustment confirm popup ("Are you sure you want to make this adjustment and push the new linear feet amount back to EBMS?") is not on this image — it is on p1_079.
- Verified: pass3

###### Screen (331,614) — EBMS coil product General tab
- File: `p1_074_x331_y614.png`
- Header/tabs: EBMS window title bar "Products\Coil Folder\Flat Stock Coils\28 Ga. Flat Stock Coils\28ga x 48" FS Coil Bright White". Tabs: General (active), Purchasing, Pricing, Count, Components, Component of, Accessories, Advanced, Parts Calculate, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production, Elevate E-Commerce, Custom.
- Controls: Description "28ga x 48" FS Coil Bright White"; Entry Date 06/03/2019 Mon; Gross Weight 2.60; checkboxes Purc/Sale under "Show on:"; UPC fields blank; Manufacturer ID/Part No./Web blank; Classification "Track Count" with Change button; Tax Group "Taxable" dropdown; Image box empty; Note/Internal Note tabs with empty text area; grids "Substitute Product/Include with Sales History/Description" and "Pick/Location/Note" empty. OK/Cancel/New/Delete/Print at bottom.
- Table: none.
- Dialog/popup: none (EBMS native window).
- Notes: EBMS source screen, not the Wiseline app.
- Verified: pass3

###### Screen (361,650) — Coil Adjustment dialog (empty)
- File: `p1_116_x361_y650.png`
- Illustrates: "Clicking in any of these 3 columns would open this window" (307,624,626)
- Header/tabs: same Coils tab background as above, dimmed behind modal
- Controls: fields Coil Thickness (blank) inches, Linear Feet 3731 feet, Weight 9701 lbs, Material Thickness (blank) inches, Core OD (blank) inches; Product ID CS488783, Color Bright White, Width (in.) 48, Coil #: 37067692; buttons "Apply" (disabled/greyed) and "Cancel" (red, enabled)
- Table: background table unchanged from Screen (361,608)
- Indicators: modal outlined in blue; Apply button greyed to show disabled state
- Dialog/popup: title "Coil Adjustment"; body has the 5 numeric fields plus Product ID/Color/Width/Coil # readout; buttons Apply (disabled), Cancel
- Notes: matches annotation (486,399)-(490,400) "Clicking in the Coil Thickness column opens a key pad" context — this is the pre-fill state of the modal
- Verified: pass3

###### Screen (361,670) — Coil Adjustment dialog (filled in)
- File: `p1_117_x361_y670.png`
- Illustrates: "We need to be able to enter either the Coil Thickness or Linear Feet or Weight and the others would auto adjust but only if the Material Thickness and Core OD are filled in." (292,630)-(297,634)
- Same as Screen (361,650) except: Coil Thickness now 8.5 inches, Material Thickness 0.017 inches, Core OD 20 inches; Apply button now enabled (bright green)
- Verified: pass3

###### Screen (361,690) — Coil Adjustment dialog (filled in, duplicate)
- File: `p1_118_x361_y690.png`
- Same as Screen (361,670) — identical (duplicate capture)
- Verified: pass3

###### Screen (361,710) — Coil Adjustment confirmation popup
- File: `p1_119_x361_y710.png`
- Illustrates: "By clicking Yes, Make Adjustment the new Linear Feet amount would get pushed back into EBMS." (294,658)-(299,661)
- Header/tabs: same background, Coil Adjustment modal still visible behind confirmation
- Controls: confirmation buttons "Yes, Make Adjustment" (green), "No" (red)
- Table: n/a
- Indicators: none new
- Dialog/popup: title "Are you sure you want to make this adjustment and push the new linear feet amount back to EBMS?"; buttons Yes, Make Adjustment / No
- Notes: nested popup over the Coil Adjustment dialog, which is itself over the Coils tab
- Verified: pass3


##### Department checkboxes (Rollforming / Trim / Slinet)

- If a coil is checked off as being in the Trim department but not in the Slinet, then the Rollforming and Slinet check boxes need to both be available. (327,675)
- If a coil is checked off as being in the Trim department and in the Slinet, then the Rollforming check box needs to become unavailable. (327,678)
- "If a coil is checked off as being in the Rollforming department, then the Slinet check box needs to become unavailable. The Slinet check box is only available if the coil is checked off as being in the Trim department and a Coil Thickness is present." (327,681)
- Clicking this check box to move the coil to the Rollforming department would give you this pop up (300,689)
- Clicking this check box to move the coil to the Trim department would give you this pop up (320,689)
- "By clicking Yes, the location for this coil will change to the Rollforming department. This will uncheck the Trim departament, both locations can NOT be checked at the same time." (276,702)
- "By clicking Yes, the location for this coil will change to the Trim department. This will uncheck the Rollforming departament, both locations can NOT be checked at the same time." (344,702)
- Clicking the Apply button would give this pop up (367,708)

###### Screens (6)

###### Screen (260,589) — Trim department checkboxes on Coils tab
- File: `p1_069_x260_y589.png`
- Illustrates: nearby annotation "Clicking on a coil row will open a drop down showing the coil lots" (304,604) — same as p1_073.
- Header/tabs: Same Coils tab as Screen 068.
- Controls: Same folder tabs, Coil Filter button.
- Table: Same as Screen (300,589)/p1_068 (identical, no expansion).
- Indicators: none additional.
- Dialog/popup: none.
- Notes: Duplicate of Screen (300,589) list, included for a different nearby annotation.
- Verified: pass3

###### Screen (300,627) — Coil Adjustment modal (coil 37067678)
- File: `p1_076_x300_y627.png`
- Header/tabs: Coils tab background (partly visible) behind modal.
- Controls: Apply (green, enabled), Cancel (red). No confirm popup is shown in this crop.
- Table: none (form modal).
- Dialog/popup: Title "Coil Adjustment". Fields: Coil Thickness 0.5 inches, Linear Feet 158 feet, Weight 411 lbs, Material Thickness 0.017 inches, Core OD 20 inches. Product ID CS488783, Color Bright White, Width (in.) 48, Coil # 37067678.
- Notes: Not a "Have you checked with Rollforming" confirmation — that dialog is on p1_082.
- Verified: pass3

###### Screen (300,649) — Coil Adjustment, push-to-EBMS confirm popup
- File: `p1_079_x300_y649.png`
- Header/tabs: Coils tab background (partly visible) behind modal.
- Controls: Apply (green), Cancel (red), both partly covered by the confirm popup.
- Table: none.
- Dialog/popup: "Coil Adjustment" modal with fields Coil Thickness 0.25 inches, Linear Feet 78 feet, Weight 203 lbs, Material Thickness 0.017 inches, Core OD (hidden by popup). Product ID CS488783, Color (hidden), Coil # 37067678. Confirm sub-popup: "Are you sure you want to make this adjustment and push the new linear feet amount back to EBMS?" Buttons: "Yes, Make Adjustment" (green), "No" (red).
- Notes: Not the Slinet Production-tab cutlist list — that list is on p1_084/p1_085. This entry previously misdescribed the neighbouring file's content.
- Verified: pass3

###### Screen (332,592) — EBMS coil Production tab (Gauge/Thickness/Width/Grade/Color)
- File: `p1_070_x332_y592.png`
- Illustrates: "We will need all these fields under the Production tab in EBMS." (220,610)
- Header/tabs: EBMS window titled "Products\Coil Folder\Flat Stock Coils\28 Ga. Flat Stock Coils\28ga x 48" FS Coil Bright White". Product: CS488783; Category: 28 Ga. Flat Stock Coils. EBMS tab bar: Pricing, Count, Components, Component of, Accessories, Advanced, Parts Calculate, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production (active), Elevate E-Commerce, Custom Prices, Roll Options, 2026.
- Controls: Production Type dropdown (blank); fields Gauge 28, Thickness 0.015, Width 48, Grade 33, Color "Bright White". OK/Cancel/New/Delete/Print buttons at bottom.
- Table: none (form fields).
- Dialog/popup: none (EBMS native window, not app modal).
- Notes: EBMS (ERP) screenshot, not the Wiseline app.
- Verified: pass3

###### Screen (332,594) — EBMS coil product "Lots" tab
- File: `p1_071_x332_y594.png`
- Header/tabs: EBMS window, tab bar General/Purchasing/Pricing/Count/Lots(active)/Components/Component of/Accessories/Advanced/Parts Calculate/Website/Lost Sale/Return/Activity/Documents/Drawing Template/Production/Elevate E-Commerce/Custom.
- Controls: Checkbox "Show the Lot Selection dialog while scanning and [dropdown] when overselling" (unchecked); Search field; View dropdown "Active"; "Auto-assign on receive" checkbox (unchecked). Buttons on right: New Lot..., Properties..., Adjust..., Remove. OK/Cancel/New/Delete/Print at bottom.
- Table: Columns Lot Number, On Hand, Received, Shipped, Processed, Lot Date. Rows: 37067677 / 1533 / (blank) / (blank) / 1533 / 1/20/2024; 37067678 / 158 / (blank) / (blank) / 158 / 1/20/2024.
- Dialog/popup: none (EBMS native window).
- Notes: EBMS source screen, not the Wiseline app — not previously described in this file.
- Verified: pass3

###### Screen (334,630) — Coil row expanded, three coils (totals updated)
- File: `p1_077_x334_y630.png`
- Header/tabs: Same Coils tab.
- Table: CS488783 Bright White row totals now Width 48, Count 3, Total Linear Feet 5,422, Total Weight 13,868. Expanded sub-table: 37067677 (4.125/1,533/3,986, Rollforming☐/Trim☑/Slinet☐); 37067678 (0.5/158/411, Rollforming☐greyed/Trim☑/Slinet☑); 37067692 (8.5/3,731/9,701, Rollforming☑/Trim☐/Slinet☐greyed). Base rows below unchanged.
- Indicators: A third coil (37067692) has been added versus Screen 073, and the Bright White row totals updated accordingly.
- Dialog/popup: none.
- Notes: Not a confirmation dialog — that content is on p1_082/p1_083.
- Verified: pass3


### Manager's View of Trim Production tab (309,714)

- The Production tab will be the same for both the Manager and the Worker. (293,719)
- "This would be the Manager's view in the Production tab. The Manger would be able to go into any of the Production (Machine) tabs and have the same authority as a worker." (291,724)
- We will need all these fields under the Production tab in EBMS. (220,610)

#### Screens (4)

##### Screen (268,649) — Coil Adjustment, coil-depletion confirm popup
- File: `p1_078_x268_y649.png`
- Header/tabs: Coils tab background behind modal.
- Controls: Apply (green), Cancel (red), both partly covered by the confirm popup.
- Table: none.
- Dialog/popup: "Coil Adjustment" modal with fields Coil Thickness 0, Linear Feet 0, Weight 0, Material Thickness 0.017, Product ID CS488783, Coil # 37067678. Confirm sub-popup: "You have entered the coil size as 0, this will completely deplete this coil and delete it, are you sure want to continue?" Buttons: "Yes, Deplete & Delete Coil" (green), "No" (red).
- Notes: This is not the Slinet Production-tab cutlist list — that list is shown on p1_084/085.
- Verified: pass3

##### Screen (300,718) — Slinet Production tab, base cutlist list
- File: `p1_084_x300_y718.png`
- Illustrates: "This would be the Manager's view in the Production tab. The Manger would be able to go into any of the Production (Machine) tabs and have the same authority as a worker." (291,724)
- Header/tabs: Trim pill; top-right "Completed cutlists history for the past 90 days". Tabs Unscheduled/Scheduled/Production(active)/Coils. "Stock Manufacturing" button (green). Machine sub-tabs Slinet(active)/Press Brake/V1/V2/Rollformer/Caps/Wrapping, plus "Coils" button.
- Table: Columns Production Date, Gauge/Colour, Priority, Recut, Done/Cutlist Coils. Rows (Wed. May 08/2024): 28Ga.-Black, 28Ga.-Bright Red, 28Ga.-Bright White, 28Ga.-Coffee Brown, 28Ga.-Colorbond Bronze, 28Ga.-Dark Red, 28Ga.-Melcher's Green, 26Ga.-Black, 26Ga.-Dark Red; divider; Thu. May 09/2024: 28Ga.-Black, 28Ga.-Stone Grey. All "Done" buttons pale/disabled.
- Indicators: Orange divider between Wed 08 and Thu 09 groups.
- Dialog/popup: none.
- Verified: pass3

##### Screen (471,283) — Slinet Production tab, base cutlist list (duplicate)
- File: `p1_085_x471_y283.png`
- Header/tabs: Trim pill; top-right "Completed cutlists history for the past 90 days". Tabs Unscheduled/Scheduled/Production(active)/Coils. "Stock Manufacturing" button (green). Machine sub-tabs Slinet(active)/Press Brake/V1/V2/Rollformer/Caps/Wrapping, plus "Coils" button.
- Table: Same list as Screen (300,718)/p1_084: Columns Production Date, Gauge/Colour, Priority, Recut, Done/Cutlist Coils. Rows (Wed. May 08/2024): 28Ga.-Black, 28Ga.-Bright Red, 28Ga.-Bright White, 28Ga.-Coffee Brown, 28Ga.-Colorbond Bronze, 28Ga.-Dark Red, 28Ga.-Melcher's Green, 26Ga.-Black, 26Ga.-Dark Red; divider; Thu. May 09/2024: 28Ga.-Black, 28Ga.-Stone Grey. All "Done" buttons pale/disabled.
- Indicators: Orange divider between Wed 08 and Thu 09 groups.
- Dialog/popup: none.
- Notes: Pixel-identical in content to Screen (300,718)/p1_084 (no visible differences).
- Verified: pass3

##### Screen (1011,288) — Trim / Press Brake — bendlist list view
- File: `p1_276_x1011_y288.png`
- Illustrates: (1004,289)-(1009,290) "The Stock Manufacturing tab needs to be on ALL of these tabs."
- Header/tabs: "Trim" pill; "Completed bendlists for the past 90 days" button top-right; Search box; green "Stock Manufacturing" button below Trim pill. Tabs: Slinet, Press Brake (active), V1, V2, Rollformer, Caps, Wrapping, Coils.
- Table: Columns: Production Date | Gauge/Colour | Priority | Remanufacture | (Done button). Rows (all with light-green disabled "Done" buttons): Wed May08/2024–28Ga.Black; 28Ga.Bright Red; 28Ga.Bright White; 28Ga.Coffee Brown; 28Ga.Colorbond Bronze; 28Ga.Dark Red; 28Ga.Melcher's Green; 26Ga.Black; 26Ga.Dark Red; then Thurs May09/2024–28Ga.Black; 28Ga.Stone Grey.
- Indicators: Orange horizontal divider between Wed/Thurs groups; expand-chevron icons at left of each row.
- Notes: All "Done" buttons appear disabled (pale green), i.e. no bendlist fully complete yet.
- Verified: pass3


### Trim Worker (664,256)

- Trim Workers should be able to see everything from here down. (657,256)
- "All the Worker windows should just be a list of the released uncompleted orders/line items. As the Manager releases orders to production, the new cutlists and bendslists should just be added to the windows that the workers are working off of. A Worker should not need to select days of the week, it needs to just be a list. This list of cutlists and bendlists needs to always sort primarily by Production Date and then have a distinct line between the different days. See example: ----->" (667,260)

### Trim Production (671,255)

"For the images below, Press Brake, V1, V2, Rollformer and Caps are considered to be Machines and are all the same. Everything below should be applied to all the Machines in the Trim department (category) except for the Slinet and the Wrapping tab." (661,276)

#### Slinet (483,278)

##### Screens (10)

###### Screen (492,550) — Slinet tab, Recut still pending (duplicate)
- File: `p1_140_x492_y550.png`
- Same as Screen (518,529) — identical duplicate: collapsed table, orange Recut badge "1" shown on the Wed 28Ga.-Bright White row, Done buttons pale/disabled, Cutlist Coils enabled.
- Notes: entries for this file and Screen (492,566) were previously swapped — this file is the collapsed table, not the expanded awaiting-Complete row.
- Verified: pass3

###### Screen (507,365) — Slinet cutlist tab, lower rows (duplicate)
- File: `p1_130_x507_y365.png`
- Same as Screen (546,340) — identical duplicate strip of bottom rows
- Verified: pass3

###### Screen (507,391) — Slinet tab lower rows (duplicate)
- File: `p1_132_x507_y391.png`
- Same as Screen (507,365) — identical duplicate
- Verified: pass3

###### Screen (507,417) — Slinet tab lower rows (duplicate)
- File: `p1_134_x507_y417.png`
- Same as Screen (507,391) — identical duplicate
- Verified: pass3

###### Screen (507,443) — Slinet tab lower rows (duplicate)
- File: `p1_136_x507_y443.png`
- Same as Screen (507,417) — identical duplicate
- Verified: pass3

###### Screen (518,529) — Slinet tab, Recut column highlighted orange
- File: `p1_139_x518_y529.png`
- Illustrates: Recut column value "1" highlighted orange for Wed 05/08 28Ga.-Bright White row
- Table: same columns; Recut cell shows orange badge "1" on the (first) Bright White row, all Done buttons pale, Cutlist Coils buttons enabled
- Indicators: orange Recut badge = pending recut/remanufacture quantity
- Verified: pass3

###### Screen (534,283) — Slinet cutlist tab
- File: `p1_123_x534_y283.png`
- Illustrates: "Only the Manager can set Priorities" region / Priority colour coding (500,281)
- Header/tabs: same as above but **Slinet** tab active; columns differ (Recut instead of Remanufacture)
- Table: columns Production Date | Gauge/Colour | Priority | Recut | Done | Cutlist Coils. Rows: Wed 05/08 28Ga.-Bright White Priority "NOW" (red banner); Wed 28Ga.-Bright White "ASAP" (orange banner); Wed 28Ga.-Bright White "By 10:00" (yellow banner); Wed 28Ga.-Bright White "By 3:00" (yellow banner); Wed 28Ga.-Bright White (no priority); Wed 28Ga.-Black; Wed 28Ga.-Bright Red; Wed 28Ga.-Bright White; Wed 28Ga.-Coffee Brown; Wed 28Ga.-Colorbond Bronze; Wed 28Ga.-Dark Red; Wed 28Ga.-Melcher's Green; Wed 26Ga.-Black; Wed 26Ga.-Dark Red; divider; Thu 05/09 28Ga.-Black "By 10:00"; Thu 28Ga.-Stone Grey. 16 rows visible.
- Indicators: Priority column colour-coded banners: red=NOW, orange=ASAP, yellow=By [time]; orange horizontal divider between Wed/Thu groups; Done buttons all pale/disabled; Cutlist Coils buttons all enabled (white/bordered)
- Notes: illustrates priority sort order (NOW > ASAP > By-times > none) combined with production date grouping
- Verified: pass3

###### Screen (534,303) — Slinet cutlist tab (duplicate)
- File: `p1_124_x534_y303.png`
- Same as Screen (534,283) — identical duplicate
- Verified: pass3

###### Screen (546,340) — Slinet cutlist tab, bottom rows only
- File: `p1_126_x546_y340.png`
- Illustrates: continuation of priority list, rows below the fold
- Table: columns Production Date | Gauge/Colour | Priority | Recut | Done | Cutlist Coils (headers cropped off the top), showing the bottom 8 rows only: Wed 28Ga.-Coffee Brown; Wed 28Ga.-Colorbond Bronze; Wed 28Ga.-Dark Red; Wed 28Ga.-Melcher's Green; Wed 26Ga.-Black; Wed 26Ga.-Dark Red; divider; Thu 28Ga.-Black; Thu 28Ga.-Stone Grey. All Done buttons pale/disabled, Cutlist Coils buttons enabled (white/bordered).
- Notes: cropped/scrolled view of the same table as Screen (534,283); this is a standalone capture, not a duplicate of Screen (546,324) — that file actually shows an unrelated expanded cutlist detail table
- Verified: pass3

###### Screen (546,350) — Slinet cutlist tab, tab bar strip only
- File: `p1_127_x546_y350.png`
- Header/tabs only: Trim pill, Stock Manufacturing button, Completed cutlists banner, Search box, Slinet(active)/Press Brake/V1/V2/Rollformer/Caps/Wrapping tab bar, Coils tab
- Notes: thin strip screenshot showing just the header/tab bar (no table rows)
- Verified: pass3


##### Priorities (500,281)

- Workers can NOT change Priorities (560,284)
- This tab needs to primarily sort by Production Date, then Priority and then Gauge/Colour. (498,284)
- Cutlist order example: 1st cutlist is the "NOW" order (525,286); 2nd cutlist is the 2 "ASAP" orders (525,288); 3rd cutlist is the "By 10:00" order (525,289); 4th cutlist is the "By 3:00" order (525,290); 5th cutlist is the rest of the orders without a priority (525,291)
- Even though this cutlist has a Priority assigned to it, it gets pushed down as it has a later Production Date than the orders on top of it. (526,316)

###### Screens (2)

###### Screen (916,283) — Trim / Wrapping — table with Priority column populated
- File: `p1_234_x916_y283.png`
- Illustrates: (912,281)-(915,282) "Priorities"; (943,285)-(948,286) "This tab needs to primarily sort by Production Date, then Priority and then ID."
- Header/tabs: same as above, Wrapping active.
- Controls: none.
- Table: Same columns as Screen (885,283) but Priority column filled: 330652/WJ Roofing/8/—/NOW(red)/—/Bent/TED8262/Eave Drip 2" Black; 330652/WJ Roofing/4/—/NOW(red)/—/Bent/TEW8262/End Wall Bright White 2/12 Pitch; 330652/WJ Roofing/25/—/NOW(red)/—/Wrapped(green)/TJC8262/J-Channel Bright White; 330653/Haines Roofing/10/—/ASAP(orange)/—/Bent/TBT8262/Base Trim Bright White; 330657/Arnold Contracting/16/—/ASAP(orange)/—/Bent/TBT8262/Base Trim Bright White; 330657/Arnold Contracting/3/—/ASAP(orange)/—/Bent/TDE8262/Drip Edge Bright White; 330657/Arnold Contracting/7/—/ASAP(orange)/—/Bent/TGD8262/Gable Divider Bright White; 330657/Arnold Contracting/15/—/ASAP(orange)/—/Bent/TJC8262/J-Channel Bright White; 330659/Upright Construction/2/—/By 10:00(yellow)/—/Cut/TEW8262/End Wall Bright White; 330659/Upright Construction/7/—/By 10:00(yellow)/—/Cut/TEW8262/End Wall Bright White 8/12 Pitch; 330660/DAP Roofing Inc./13/—/By 3:00(yellow)/—/Bent/TJC8262/J-Channel Bright White.
- Indicators: Priority badges colour-coded: red "NOW", orange "ASAP", yellow "By 10:00" / "By 3:00".
- Dialog/popup: none.
- Notes: 11 rows visible.
- Verified: pass3

###### Screen (916,296) — Trim / Wrapping — Priority table with "By 10:00" badge
- File: `p1_236_x916_y296.png`
- Same as Screen (846,284) (bypassed-row table, not 916,283) except: the 330624/DAP Roofing Inc./22/TED8262 "Eave Drip 2" Black" row (last row shown, at bottom edge) now has a yellow "By 10:00" Priority badge instead of a blank Priority cell. Otherwise identical rows including the purple "Bypassed" 330640 row and green/red Notes dots.
- Verified: pass3


##### Stock Orders (652,281)

Stock Orders would have an icon in the Production Date column showing that it's a Stock Order. (585,288)

##### Cutlists

- "These cutlists would be created automatically as soon as the order is Released To Production. It should combine line items that have the same Color/Gauge combination and Priority at the time that the orders were Released To Production. It should never add to an existing cutlist. For example, if you were to Release To Production an order that has 28Ga. Black trims on it, it would create a cutlist for that order. Afterwards, if you go and Release To Production another order that has 28Ga. Black on it, it should create another cutlist since they weren't Released To Production at the same time." (459,287)
- "The cutlists should combine line items that are identical in the following ways: Gauge/Colour combination, Width and Length combination, Priority, Machine. See the example below." (507,291)
- Click the drop down of the cutlist you want to work on. (465,306)
- "The items within the dropdown cutlists need to be primarily sorted by width and then length. The smallest width goes on top and the largest goes on the bottom. Then it sorts by length after that. For example, if there are multiple different lengths of the same width, the shortest one would be on top of the other ones. Also, it needs to display the quantities from the order minus the amount that's being pulled from stock, not the number of line items." (461,327)
- The Total column should display the combined number of all the quantities within that row. (464,301)
- The cutlist should highlight any length that is NOT 120". (465,337)
- Clicking on a number in the Total column would open this window (551,347)
- "Here you can see all the line items for the size that you clicked and the Sales Orders that they belongs too." (538,353)
- Order example table: Order #1 (503,298) / Order #2 (517,298) with sample line-item text: "28Ga. Bright White - TDE - 5 pcs. 4" x 120" for P.B. 28Ga. Bright White - TJC - 20 pcs. 4" x 120" for Rollformer 28Ga. Bright White - TBT - 5 pcs. 4" x 120" for P.B." (499,299) and "28Ga. Bright White - TJC - 25 pcs. 4" x 120" for Rollformer 28Ga. Bright White - TGD - 6 pcs. 4" x 120" for P.B." (512,299)

###### Screens (1)

###### Screen (254,436) — Cutlists/bendlists worker view (Slinet tab)
- File: `p1_047_x254_y436.png`
- Illustrates: (461,327)-(469,333) "The items within the dropdown cutlists need to be primarily sorted by width and then length..." and general Slinet worker tab context
- Header/tabs: "Trim" pill; top-right "Completed cutlists history for the past 90 days"; left green button "Stock Manufacturing"; search box; sub-tabs: Slinet (active), Press Brake, V1, V2, Rollformer, Caps, Wrapping, and far-right "Coils"
- Controls: none additional
- Table: columns Production Date | Gauge/Colour | Priority | Recut | [action]. Rows (cutlist groups, collapsed): Wed May08/2024 28Ga.-Black (Done greyed, Cutlist Coils enabled); Wed May08/2024 28Ga.-Bright Red; Wed May08/2024 28Ga.-Bright White; Wed May08/2024 28Ga.-Coffee Brown — EXPANDED showing sub-table; Wed May08/2024 28Ga.-Colorbond Bronze; Wed May08/2024 28Ga.-Dark Red; Wed May08/2024 28Ga.-Melcher's Green; Wed May08/2024 26Ga.-Black; Wed May08/2024 26Ga.-Dark Red; (divider line) Thu May09/2024 28Ga.-Black; Thu May09/2024 28Ga.-Stone Grey. Expanded sub-table columns: Width | Length | Total | P.B. | V1 | V2 | Rollformer | Vented | Caps | Flat Stock | Operator Notes | Complete: rows 11.75/28/2/—/—/—/—/—/2/—/(notes cell yellow)/No; 14/120/9/—/—/—/9/—/—/—/—/No; 22/120/8/—/—/8/—/—/—/—/—/No; 24/120/18/—/—/—/—/18/—/—/—/No
- Indicators: Length cell "28" highlighted red (non-120" length flag); "Complete" column shows disabled grey "No" toggle buttons for each row; a horizontal brown/orange divider line separates Wednesday's cutlists from Thursday's
- Notes: this is the Trim Worker "Trim Production" Slinet sub-tab, listing cutlists as a flat sorted list
- Verified: pass3


##### Expanding a row within a cutlist (498,321)

- "The Operator Notes is NOT connected to anything, it is just a place for the operator to make notes to help keep track of things while cutting." (499,329)
- "There should be NO pop-up when changing from "No" to "Yes", but there needs to be pop-up when changing from "Yes" to "No" asking if you are sure you want to mark this row as NOT completed." (499,334)
- When a row is marked as Yes in the Complete column, it needs to get crossed out. (499,338)

###### Screens (7)

###### Screen (471,298) — Slinet cutlist expanded (line items grid, all incomplete)
- File: `p1_087_x471_y298.png`
- Illustrates: "The items within the dropdown cutlists need to be primarily sorted by width and then length..." (461,327)
- Table: Row "28Ga.-Bright White" (Wed 08/2024) expanded, sub-columns Width/Length/Total/P.B./V1/V2/Rollformer/Vented/Caps/Flat Stock/Operator Notes/Complete. Rows: 4/120/61/16/-/-/45/-/-/-/32/No; 8/120/53/16/5/-/32/-/-/-/-/No; 10/120/18/6/-/-/12/-/-/4/-/No; 10/144(red)/26/-/26/-/-/-/-/-/-/No; 12/120/29/11/18/-/-/-/-/-/-/No; 14/120/25/8/-/-/17/-/-/-/-/No; 16.25/164.75(red)/8/-/-/8/-/-/-/-/-/No; 18/32/4/-/-/-/-/-/4/-/-/No; 20.75/120/21/-/-/8/13/-/-/-/-/No; 48/120/0/-/-/-/-/-/-/1,3/-/No.
- Indicators: Length cells highlighted red for 144 and 164.75 (not 120"). Operator Notes column pale yellow. All Complete toggles show "No".
- Dialog/popup: none.
- Verified: pass3

###### Screen (471,324) — Slinet cutlist expanded, two rows marked "Yes"
- File: `p1_089_x471_y324.png`
- Illustrates: "There should be NO pop-up when changing from "No" to "Yes"..." (499,334)
- Same expanded grid as Screen (471,298)/p1_087 except: row width 12/length 120 and row width 20.75/length 120 now show strikethrough text with Complete = "Yes" (green check); all other rows remain "No".
- Notes: Content originally miscaptioned as a "Line Item Note popup" belongs here instead.
- Verified: pass3

###### Screen (471,350) — Slinet cutlist expanded, all rows marked "Yes" (Done enabled)
- File: `p1_092_x471_y350.png`
- Illustrates: "Once ALL the rows are marked as Complete, then the Done button needs to become available." (463,351)
- Same expanded grid as Screen (471,298)/p1_087 except: ALL rows now strikethrough with Complete = "Yes" (green check); "Done" button for 28Ga.-Bright White now solid/enabled green instead of pale.
- Verified: pass3

###### Screen (471,503) — "Are you sure you are done with this cutlist?" confirm popup
- File: `p1_109_x471_y503.png`
- Illustrates: nearby "Once ALL the rows are marked as Complete, then the Done button needs to become available. The Worker needs to adjust the coil/coils that he used for this cutlist before clicking the Done button." (463,351)
- Dialog/popup: Body: "Are you sure you have made all the necessary coil adjustments and that you are done with this cutlist?" Buttons: Yes (green), No (red). Background: expanded Bright White cutlist grid, all rows Complete=Yes/crossed out, Done button solid green.
- Verified: pass3

###### Screen (546,324) — Expanded cutlist row, Wed 28Ga.-Bright White (no rows completed yet)
- File: `p1_125_x546_y324.png`
- Illustrates: "In this example you can see that the middle 2 line items are both assigned to V2, but the 1 is marked as Vented..." (252,429)-(265,432)
- Header/tabs: Slinet tab active, same header as Screen (534,283); above the expanded row, two collapsed cutlist rows are still visible (Wed 05/08 28Ga.-Black, Wed 05/08 28Ga.-Bright Red, both pale/disabled Done)
- Table: expanded cutlist for Wed 05/08/2024, 28Ga.-Bright White. Sub-columns: Width | Length | Total | P.B. | V1 | V2 | Rollformer | Vented | Caps | Flat Stock | Operator Notes | Complete. Rows: 4/120/61/16/-/45/-/-/-/-/32/No; 8/120/53/16/5/32/-/-/-/-/-/No; 10/120/18/6/-/12/-/-/-/4/-/No; 10/144(red-highlighted length)/26/-/26/-/-/-/-/-/-/No; 12/120/29/11/18/-/-/-/-/-/-/No (not struck through here); 14/120/25/8/-/17/-/-/-/-/-/No; 16.25/164.75(red)/8/-/-/8/-/-/-/-/-/No; 18/32/4/-/-/-/-/4/-/-/-/No; 20.75/120/21/-/-/8/13/-/-/-/-/No (not struck through here); 48/120/0/-/-/-/-/-/-/1,3/-/No
- Indicators: red-highlighted Length cells (144, 164.75) flag lengths that are not 120"; yellow "Operator Notes" column background; every row still shows a plain pale-grey "No" Complete toggle — none marked complete yet
- Notes: this is an earlier-state duplicate of the same expanded row shown in Screen (507,350) — that file shows the 12/120 and 20.75/120 rows already struck through with a green "Yes" Complete; this file does not. This entry previously (incorrectly) described a cropped bottom-of-table view; that content actually belongs to Screen (546,340).
- Verified: pass3

###### Screen (546,354) — Line item order detail popup (12"x120" Bright White)
- File: `p1_129_x546_y354.png`
- Illustrates: "Here you can see all the line items for the size that you clicked and the Sales Orders that they belongs too." (538,353)-(544,355)
- Dialog/popup: title "12" x 120" - 28Ga. - Bright White"; red X close button. Three order cards:
  1. Customer Name: H F H Inc; Order #: 330605; PO: G-5793416. Table Qty Ordered|Stock|Qty To Manufacture|Product ID|Description|Drawing: 4|-|4|TOCWJ8783|Outside Corner with J 3-1/4" Bright White|(drawing icon)
  2. Customer Name: Arnold Contracting; Order #: 330616; PO: 376 Main St. Rows: 3|-|3|TTC8783|Track Cover Bright White; 10|4|6|TGSR8783|Gable Starter F Reroof 3-1/2" Bright White; 4|-|4|TJTF18783|Jamb Trim Flat 1" Bright White 1" Out, 1.625" Face, 8" Jamb
  3. Customer Name: A.W.C.; Order #: 330618; PO: Bob's Shop. Rows: 4|-|4|TCT8783|Custom Trim 12" Flat Stock with 6 Bends Bright White; 8|-|8|TGF8783|Gambrel Flashing Bright White
- Notes: each card has a Drawing placeholder icon per row
- Verified: pass3

###### Screen (471,314) — Slinet base cutlist list (unchanged)
- File: `p1_088_x471_y314.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion: Coffee Brown through Stone Grey), no differences.
- Verified: pass3


##### Using multiple coils on a cutlist (499,347)

We need to be able to make a coil adjustment at anytime, it doesn't matter how much of the cutlist has been cut already or not. (501,353)

###### Screens (1)

###### Screen (471,340) — Slinet base cutlist list (unchanged)
- File: `p1_091_x471_y340.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


##### Cutlist Coils (489,373) / (525,373)

- Clicking the Cutlist Coils button will open this window (489,373 / 525,373)
- "These coils all match the "Color" of the cutlist and if they are all checked off as being in the Slinet, then they would all show up in the Cutlist Coils coil list. Gauge and Width do NOT matter, any gauge and/or width of coil will show up as long as it is checked off as being in the Slinet and matches the "Color", as shown here." (426,341)
- Multiple qualifing coils in the Slinet at the same time (464,347)
- "The Cutlist Coils coil list is make up of ONLY the coils that are checked off as being in the Slinet and that match the "Color" of the cutlist. Gauge and width do NOT matter, any gauge and/or width of coil will show up as long as it is checked off as being in the Slinet and matches the "Color"." (463,379)
- Clicking in the Coil Thickness column opens a key pad (486,399 / 522,399)
- Enter the new Coil Thickness (485,425)
- Enter "0" as the Coil Thickness because you used up the entire coil (521,424)
- Clicking the Apply button when the Coil Thickness has been entered as "0" would give you this pop up (512,450)
- The Apply button ONLY becomes available if the Coil Thickness number changes. (464,436)
- Clicking the Apply button would give you this pop up (477,451)
- "Once ALL the rows are marked as Complete, then the Done button needs to become available. The Worker needs to adjust the coil/coils that he used for this cutlist before clicking the Done button." (463,351)
- After making all the necessary coil adjustments and the Worker is done with the cutlist then he would click the Done button to remove the cutlist from the Production tab. (465,481)
- Clicking the Done button would give you this pop up (486,501)
- "Clicking Yes will remove the entire cutlist from the Slinet tab. It will remain available within the Completed Cutlists tab for the next 90 days. It should keep the same formatting." (499,515)

###### Screens (16)

###### Screen (251,671) — Coil row expanded with note added to 37067677
- File: `p1_081_x251_y671.png`
- Header/tabs: Same Coils tab.
- Table: CS488783 Bright White row (Width 48, Count 3, Total Linear Feet 5,422, Total Weight 13,868) expanded: 37067677 (4.125/1,533/3,986, Rollforming☐/Trim☑/Slinet☐, Note: "Trim only, No Board & Batten"); 37067678 (0.5/158/411, Rollforming☐greyed/Trim☑/Slinet☑, no note); 37067692 (8.5/3,731/9,701, Rollforming☑/Trim☐/Slinet☐greyed, no note).
- Indicators: Note text visible only on the 37067677 row.
- Dialog/popup: none.
- Notes: Not a Slinet "Cutlist Coils" modal — this is the Coils-tab coil-note view.
- Verified: pass3

###### Screen (283,692) — "Have you checked with the Trim department" confirm popup
- File: `p1_083_x283_y692.png`
- Header/tabs: Same Coils tab, expanded CS488783 sub-table behind modal (Location/Slinet columns partly visible).
- Dialog/popup: Body: "Have you checked with the Trim department to ensure that it is ok to move this coil to the Rollforming department?" Buttons: Yes (green), No (red).
- Notes: none.
- Verified: pass3

###### Screen (317,692) — "Have you checked with Rollforming" confirm popup
- File: `p1_082_x317_y692.png`
- Illustrates: "Clicking this check box to move the coil to the Trim department would give you this pop up" (320,689)
- Header/tabs: Same Coils tab, expanded CS488783 sub-table behind modal (Location/Slinet columns partly visible).
- Dialog/popup: Body: "Have you checked with the Rollforming department to ensure that it is ok to move this coil to the Trim department?" Buttons: Yes (green), No (red).
- Notes: Not a "Cutlist Coils / Coil Adjustment" 4-row table — that content is on p1_090.
- Verified: pass3

###### Screen (423,283) — Slinet cutlist list, Rollforming-pending icons
- File: `p1_086_x423_y283.png`
- Same base list as Screen (300,718) except: a small house/building icon appears next to the 2nd "28Ga.-Black" row and next to a new "28Ga.-Charcoal" row (inserted between 28Ga.-Bright White and 28Ga.-Coffee Brown), indicating a pending Rollforming-related flag.
- Notes: This is the content originally miscaptioned under a different Screen number as showing a "pending Rollforming icon."
- Verified: pass3

###### Screen (434,338) — Cutlist Coils / Coil Adjustment modal (4-row table)
- File: `p1_090_x434_y338.png`
- Header/tabs: Modal titled "Cutlist Coils / Coil Adjustment" over Slinet Production tab.
- Controls: Apply (disabled/pale green), Cancel (red).
- Table: Columns Product ID, Width (in.), Gauge, Color, Coil #, Coil Thickness, Linear Feet, Weight (lbs.), Note. Rows: CS218783/21.25/26/Bright White/F534976/3.25/989/1,314; CS26488783/48/26/Bright White/37069342/5.75/1,938/5,814; CS488783/48/28/Bright White/37067692/8.5/3,731/9,701; CS488783/48/28/Bright White/37067678/0.5/158/411.
- Indicators: Alternating blue/white row shading.
- Notes: Matches spec note about multiple qualifying coils in Slinet showing regardless of gauge/width, matching only Color.
- Verified: pass3

###### Screen (471,375) — Cutlist Coils modal, single-row adjustment (8.5" coil)
- File: `p1_096_x471_y375.png`
- "Cutlist Coils / Coil Adjustment" modal, single row: CS488783/48/28/Bright White/37067692/8.5/3,731/9,701. Apply button disabled/pale, Cancel red.
- Verified: pass3

###### Screen (471,401) — Coil Thickness keypad
- File: `p1_098_x471_y401.png`
- Illustrates: "Clicking in the Coil Thickness column opens a key pad" (486,399)/(522,399)
- Header/tabs: Modal "Cutlist Coils / Coil Adjustment" (single coil 37067692) with numeric keypad overlay.
- Controls: Coil Thickness field active (blue border, value "8.5"), input box with "inches" label and "Enter" button (green); numeric keypad 1-9, 0, ".", backspace arrow; Cancel button (red) below keypad. Apply button (disabled/pale) partially visible behind keypad.
- Dialog/popup: Title "Cutlist Coils / Coil Adjustment" with keypad sub-popup.
- Verified: pass3

###### Screen (471,427) — Cutlist Coils modal, adjusted coil (7.875" thickness)
- File: `p1_101_x471_y427.png`
- Same layout as Screen (471,375)/p1_096 except: Coil Thickness now 7.875, Linear Feet 3,381, Weight 8,791 (updated from 8.5/3,731/9,701); Apply button now enabled (solid green).
- Verified: pass3

###### Screen (471,453) — Cutlist Coils "push to EBMS" confirm popup
- File: `p1_104_x471_y453.png`
- Illustrates: "Are you sure you want to make this adjustment and push the new linear feet amount back to EBMS?" (466,461)
- Header/tabs: Confirm popup over Cutlist Coils/Coil Adjustment modal (table headers Product ID/Width/Gauge partially visible behind, row CS488783/48/28).
- Dialog/popup: Body: "Are you sure you want to make this adjustment and push the new linear feet amount back to EBMS?" Buttons: "Yes, Make Adjustment" (green), "No" (red).
- Verified: pass3

###### Screen (507,375) — Cutlist Coils / Coil Adjustment popup
- File: `p1_131_x507_y375.png`
- Illustrates: "Clicking the Cutlist Coils button will open this window" (489,373)-(494,374)
- Dialog/popup: title "Cutlist Coils / Coil Adjustment"; table Product ID | Width (in.) | Gauge | Color | Coil # | Coil Thickness | Linear Feet | Weight (lbs.) | Note — one row: CS488783 | 48 | 28 | Bright White | 37067678 | 0.5 | 158 | 411 | (blank); buttons Apply (disabled/pale), Cancel (red)
- Notes: opened from the "Cutlist Coils" button on a cutlist row
- Verified: pass3

###### Screen (507,401) — Cutlist Coils keypad popup
- File: `p1_133_x507_y401.png`
- Illustrates: "Clicking in the Coil Thickness column opens a key pad" (522,399)-(526,400)
- Dialog/popup: Cutlist Coils / Coil Adjustment table same as Screen (507,375), with Coil Thickness field focused (blue outline, value "0.5"); numeric keypad overlay with digits 1-9, 0, ".", back-arrow, green "Enter" button, red "Cancel" button
- Notes: keypad matches Vented/Coil Thickness-entry pattern used elsewhere
- Verified: pass3

###### Screen (507,427) — Cutlist Coils showing depleted coil (0 values)
- File: `p1_135_x507_y427.png`
- Illustrates: "Enter '0' as the Coil Thickness because you used up the entire coil" (521,424)-(526,426)
- Dialog/popup: same Cutlist Coils / Coil Adjustment table now showing Coil Thickness 0, Linear Feet 0, Weight 0 for coil 37067678; Apply button now enabled (green), Cancel red
- Notes: precedes the "Deplete & Delete Coil" confirmation
- Verified: pass3

###### Screen (507,453) — Deplete & Delete Coil confirmation popup
- File: `p1_137_x507_y453.png`
- Illustrates: "By clicking Yes, Deplete & Delete Coil the coil would be zeroed out in EBMS and deleted out of the App." (502,461)-(506,464)
- Dialog/popup: title "You have entered the coil size as 0, this will completely deplete this coil and delete it, are you sure you want to continue?"; buttons "Yes, Deplete & Delete Coil" (green), "No" (red); nested over the Cutlist Coils / Coil Adjustment modal
- Notes: same pattern as the general Coil Adjustment deplete confirmation
- Verified: pass3

###### Screen (762,384) — Coil Thickness-style keypad popup, with +/- keys, over Stock modal
- File: `p1_213_x762_y384.png`
- Illustrates: (486,399)-(490,400) "Clicking in the Coil Thickness column opens a key pad" (analogous keypad, with plus/minus)
- Header/tabs: Trim pill; Completed orders button; Search; Machine tabs incl. **Wrapping**(active)
- Controls: numeric keypad 1-9, 0, "+", "-", back-arrow, red "X"; "___ pcs." field with green "Enter" button
- Table: same Stock Manufacturing modal table as Screen (762,334); row for TDE8262 Drip Edge Black selected (blue-bordered blank Wrapped cell)
- Dialog/popup: keypad over "Stock" modal
- Notes: this keypad variant includes +/- adjustment keys. Corrects a prior mis-transcription that described an "Order detail / package window (Select Location state)" here; that content is actually in Screen (819,410) (file p1_215).
- Verified: pass3

###### Screen (471,365) — Slinet base cutlist list (unchanged)
- File: `p1_094_x471_y365.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3

###### Screen (471,391) — Slinet base cutlist list (unchanged)
- File: `p1_097_x471_y391.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


##### Overdue Cutlists (498,526)

- Overdue cutlists need to be highlighted. (508,530)
- "Example: If it is Thursday, May 09/2024 and there are cutlists from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday cutlists to be highlighted as overdue." (508,531)

###### Screens (2)

###### Screen (507,469) — Slinet tab with two rows highlighted red (overdue)
- File: `p1_138_x507_y469.png`
- Illustrates: "Overdue cutlists need to be highlighted." (508,530)-(516,531) and example text (508,531)-(516,535)
- Table: same Slinet cutlist columns; top two rows "Wed 05/08 28Ga.-Black" and "Wed 05/08 28Ga.-Bright Red" are highlighted solid red (overdue), remaining rows below are Thursday 05/09 entries: 28Ga.-Bright White, Coffee Brown, Colorbond Bronze, Dark Red, Melcher's Green, 26Ga.-Black, 26Ga.-Dark Red, 28Ga.-Black, 28Ga.-Stone Grey
- Indicators: red row highlight = overdue cutlist (Wednesday cutlists still open on Thursday)
- Verified: pass3

###### Screen (471,519) — Slinet base cutlist list (unchanged)
- File: `p1_110_x471_y519.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


##### Remanufacture Request from the Machine tab (501,545)

"This is the new Remanufacture cutlist from one of the Machines. Opening it shows just what needs to be Remanufactured." (487,562)

##### Remanufacture / Recut (519,586)

- Once the Worker marks the material as Complete, then the Recut column changes to green and the Done button becomes available. (519,586) — also (478,586)
- Marking it as Complete will also change the Remanufacture column to green in the Machine tab. (519,593)
- "Marking it as Complete will also change the Remanufacture column to green in the Machine tab but leave the Remanufacture column in the Wrapping tab as orange. The Remanufacture column in the Wrapping tab should only change to green once the Machine has marked it as Bent (Complete)." (478,590)

###### Screens (5)

###### Screen (450,550) — Slinet list showing Recut badge "2" (orange)
- File: `p1_111_x450_y550.png`
- Illustrates: "Once the Worker marks the material as Complete, then the Recut column changes to green and the Done button becomes available." (478,586)
- Header/tabs: Same Slinet Production tab list.
- Table: Same rows as Screen (300,718)/p1_084, but 2nd row "28Ga.-Black" now shows Recut column value "2" highlighted orange, Done still pale/disabled for that row; other rows unchanged.
- Indicators: Orange badge "2" in Recut column signaling a pending remanufacture/recut quantity.
- Notes: none.
- Verified: pass3

###### Screen (450,566) — Recut row expanded showing remanufacture line item
- File: `p1_112_x450_y566.png`
- Same base list as Screen 111, with the "28Ga.-Black / Recut 2" row expanded: sub-table Width 6, Length 120, Total 2, P.B. 2, other machine columns blank, Complete toggle "No" (disabled/grey).
- Indicators: Recut "2" badge still orange; Complete = No (grey, not yet actionable).
- Verified: pass3

###### Screen (450,583) — Recut row completed, Done enabled (green Yes)
- File: `p1_113_x450_y583.png`
- Illustrates: "Once the Worker marks the material as Complete, then the Recut column changes to green and the Done button becomes available." (478,586) / "Marking it as Complete will also change the Remanufacture column to green in the Machine tab." (519,593)
- Same expanded row as Screen 112 except: Recut badge now solid GREEN "2" (was orange), Done button for that cutlist now solid/enabled green, and Complete toggle now "Yes" (green check) for the line item (width 0/length 120/total 2/P.B. 2).
- Indicators: Recut badge color change orange→green signals remanufacture completion, matching spec.
- Verified: pass3

###### Screen (492,566) — Expanded cutlist showing Recut=1, one row awaiting Complete
- File: `p1_141_x492_y566.png`
- Illustrates: "Once the Worker marks the material as Complete, then the Recut column changes to green and the Done button becomes available." (478,586)-(482,590)
- Table: expanded row for Wed 28Ga.-Bright White (Recut orange "1"); sub-table Width|Length|Total|P.B.|V1|V2|Rollformer|Vented|Caps|Flat Stock|Operator Notes|Complete: one row 6|120|1|1|-|-|-|-|-|-|-|No (grey/pale "No" toggle)
- Indicators: orange Recut badge "1" on parent row
- Notes: entries for this file and Screen (492,550) were previously swapped — this file is the expanded, not-yet-completed state.
- Verified: pass3

###### Screen (492,583) — Expanded cutlist, Recut=1 marked Complete (Done/green)
- File: `p1_142_x492_y583.png`
- Illustrates: "Once the Worker marks the material as Complete, then the Recut column changes to green and the Done button becomes available." (478,586)-(482,590)
- Same as Screen (492,566) except: Recut badge now solid dark green "1"; parent "Done" button now dark green and enabled; sub-table Complete toggle now green "Yes" for the 6/120 row.
- Notes: corrects an earlier claim that this file was a bare header/tab strip with no rows — it is in fact the expanded, completed state of Screen (492,566).
- Verified: pass3


#### Line Item Notes (648,297) / (639,315)

- "The Manager and Workers should be able to add and view Line Item Notes at any point in production. These notes are just within the app, they do not come from or push back to EBMS." (639,315)
- Clicking this button opens the Line Item Note. (632,324)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (639,334)
- If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again. (639,376)

##### Screens (9)

###### Screen (366,424) — Line Item Note popup (unread, red X)
- File: `p1_100_x366_y424.png`
- Illustrates: "Clicking this button opens the Line Item Note." (632,324)
- Header/tabs: Modal "Line Item Note" over app background.
- Controls: Text input "Leave your note here..." with send arrow icon (green).
- Indicators: Red X (unread) and plain green checkmark icon on the note card (neither highlighted).
- Dialog/popup: Title "Line Item Note". Note card: avatar "TM" (Trim Manager), email "trimmanager@wiseline.ca", timestamp "Tue. May 07/2024 10:42", body "Special instructions, talk to manager before bending". Icons: red X (left), green check (right), both plain/unstyled.
- Verified: pass3

###### Screen (366,442) — Line Item Note, checkmark clicked (green highlight)
- File: `p1_102_x366_y442.png`
- Same single-note "Line Item Note" modal as Screen (366,424)/p1_100 except: the green checkmark button is now shown enlarged/highlighted (full green pill), indicating it was clicked — "clicking the checkmark ... changes the note color from red to green." (379,426)
- Verified: pass3

###### Screen (366,461) — Line Item Note, second note added (Trim Worker)
- File: `p1_105_x366_y461.png`
- Illustrates: "If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again." (379,466)
- "Line Item Note" modal now shows TWO note cards: 1) TM Trim Manager, trimmanager@wiseline.ca, Tue. May 07/2024 10:42, "Special instructions, talk to manager before bending", green pill (dealt with, top edge visible). 2) TW Trim Worker, trimworker@gmail.caom [sic], Tue. May 07/2024 2:31, "Last bend needs to be finished at V1", red X icon and green check icon both plain (unread/new note).
- Notes: Email typo "trimworker@gmail.caom" transcribed verbatim.
- Verified: pass3

###### Screen (627,332) — Line Item Note popup (unread, one note)
- File: `p1_162_x627_y332.png`
- Illustrates: "Clicking this button opens the Line Item Note." (632,324)-(636,326)
- Dialog/popup: title "Line Item Note"; one note card: avatar "TM", author "Trim Manager", email trimmanager@wiseline.ca, timestamp "Tue, May 07/2024 10:42", text "Special instructions, talk to manager before bending"; red X (unchecked) and green checkmark buttons at bottom of card; text input "Leave your note here..." with send arrow button
- Indicators: red X button active = note unread/undealt-with (red state)
- Verified: pass3

###### Screen (627,351) — Line Item Note popup (checked/green)
- File: `p1_166_x627_y351.png`
- Illustrates: "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green." (829,336)-(835,340) [equivalent Wrapping-tab note text, same UI pattern]
- Same as Screen (627,332) except: the checkmark button is now the active/filled state — full-width green bar replaces the red X / green check pair, indicating the note has been marked read (green = dealt with)
- Verified: pass3

###### Screen (627,371) — Line Item Note popup (two notes, second unread)
- File: `p1_169_x627_y371.png`
- Illustrates: "If a second note is added that has not been 'Checked-off' yet then the note should be highlighted in red again." (639,376)-(643,380)
- Dialog/popup: title "Line Item Note"; two note cards: (1) TM Trim Manager, trimmanager@wiseline.ca, Tue May 07/2024 10:42, "Special instructions, talk to manager before bending", shown checked (green bar, read); (2) TW Trim Worker, trimworker@gmail.caom [sic — typo for .com], Tue May 07/2024 2:31, "Last bend needs to be finished at V1", red X / green check buttons active (unread, red state); text input "Leave your note here..." with send button
- Verified: pass3

###### Screen (817,334) — Line Item Note popup (unread, red X)
- File: `p1_205_x817_y334.png`
- Illustrates: (380,408)-(385,413)/(639,315)-(643,320) "The Manager and Workers should be able to add and view Line Item Notes at any point in production..."
- Header/tabs: title "Line Item Note" (modal header)
- Dialog/popup: Note card — avatar "TM", "Trim Manager", "trimmanager@wiseline.ca", timestamp "Tue, May 07/2024 10:42"; note text "Special instructions, talk to manager before bending"; red X (left) and green checkmark (right) action buttons; bottom text field placeholder "Leave your note here..." with green send-arrow button
- Indicators: red X = mark unread/not dealt with (note stays red); green check = mark read/dealt with
- Notes: red X icon shown filled/solid indicating currently unread state. Corrects a prior mis-transcription that described this file as showing the note in a "marked read" green state; only one note is present here, in the unread (red X/green check) state.
- Verified: pass3

###### Screen (817,354) — Line Item Note popup, marked read (single note)
- File: `p1_208_x817_y354.png`
- Illustrates: (379,426)-(385,431)/(829,336)-(835,340) "In the note, you can click the checkmark indicating that you've read the note... changing the note color from red to green."
- Dialog/popup: same "Line Item Note" card as (817,334) except: the red-X/green-check control area is replaced by a single solid green bar (read/dealt-with state); only the one Trim Manager note is present, no second note
- Notes: corrects a prior mis-transcription that described a second (Trim Worker) note here; that second note is shown in Screen (817,374) (file p1_211), not this file.
- Verified: pass3

###### Screen (817,374) — Line Item Note popup, second note added (unread again)
- File: `p1_211_x817_y374.png`
- Illustrates: (379,466)-(383,470)/(829,387)-(833,390) "If a second note is added that has not been 'Checked-off' yet then the note should be highlighted in red again."
- Dialog/popup: "Line Item Note" card — first note (TM, Trim Manager, Tue May 07/2024 10:42, "Special instructions, talk to manager before bending") shown with green solid bar (read); a second note added below: avatar "TW", "Trim Worker", "trimworker@gmail.caom" [sic], timestamp "Tue, May 07/2024 2:31", text "Last bend needs to be finished at V1", with red X and green check icons (unread state)
- Indicators: green bar = note 1 read; red X / green check pair on note 2 = unread, awaiting action
- Notes: confirms the "highlighted red again" behavior. Email typo "gmail.caom" visible. Corrects a prior mis-transcription that described this file as a Coil Thickness +/- keypad; that keypad is actually shown in Screen (762,384) (file p1_213).
- Verified: pass3


#### Machines (671,278)

##### Screens (13)

###### Screen (592,283) — Press Brake bendlist tab (Machine tab, with two icon-flagged rows)
- File: `p1_122_x592_y283.png`
- Illustrates: "Trim Production" (671,255) / Machines tab annotations
- Header/tabs: department pill "Trim"; top-right "Stock Manufacturing" button (green) and "Completed bendlists for the past 90 days"; tab bar Slinet / **Press Brake** (active) / V1 / V2 / Rollformer / Caps / Wrapping, plus separate "Coils" tab at far right; Search... box
- Table: columns Production Date | Gauge/Colour | Priority | Remanufacture | (Done button). Rows (all Wednesday, May 08/2024 unless noted, all Done buttons pale/disabled): 28Ga.-Black; 28Ga.-Black (second row, small building/location icon next to the date); 28Ga.-Bright Red; 28Ga.-Bright White; 28Ga.-Charcoal (small building/location icon next to the date); 28Ga.-Coffee Brown; 28Ga.-Colorbond Bronze; 28Ga.-Dark Red; 28Ga.-Melcher's Green; 26Ga.-Black; 26Ga.-Dark Red; then a red horizontal divider line; Thursday, May 09/2024 28Ga.-Black; Thursday, May 09/2024 28Ga.-Stone Grey. Total 13 rows visible.
- Indicators: orange horizontal rule separates Wednesday from Thursday date groups; Done buttons pale green (disabled, nothing complete yet); two rows carry a small building/location icon next to the date whose purpose is not explained by nearby annotations
- Notes: matches the "distinct line between the different days" behavior described at (667,260)-(678,265); this file is NOT identical to Screen (682,256) or Screen (660,283) — those show the plain 11-row table without the two icon-flagged rows
- Verified: pass3

###### Screen (612,306) — Press Brake bendlist, Dark Red expanded (Cut status)
- File: `p1_158_x612_y306.png`
- Illustrates: Status progression "Not Started"→"In Progress"/Cut (650,318)-(659,325)
- Table: expanded row Wed 05/08/2024, 26Ga.-Dark Red. Sub-columns same as Screen (660,299). Rows: 4/120/8/-/8/TBT8250/Base Trim Dark Red/-/Press Brake/Cut(light blue badge)/No/📷/Notes(green dot); 5/120/5/-/5/TRG8250/Base Trim Dark Red/-/Press Brake/Cut/No/📷/Notes; 8/120/9/-/9/TCT8250/Custom Trim 8" F.S. with 3 Bends Dark Red/-/Press Brake/Cut/No/📷/Notes; 10/120/16/-/16/TCT8250/Custom Trim 10" F.S. with 6 Bends Dark Red/-/Press Brake/Cut/No/📷/Notes(red dot)
- Indicators: light-blue "Cut" status badge (vs grey "Not Started")
- Verified: pass3

###### Screen (612,327) — Press Brake bendlist, Dark Red expanded (duplicate)
- File: `p1_161_x612_y327.png`
- Same as Screen (612,306) — identical duplicate
- Verified: pass3

###### Screen (612,347) — Press Brake bendlist, Dark Red expanded (duplicate)
- File: `p1_164_x612_y347.png`
- Same as Screen (612,306) — identical duplicate
- Verified: pass3

###### Screen (612,366) — Press Brake bendlist, Dark Red expanded (duplicate, Cut status unchanged)
- File: `p1_168_x612_y366.png`
- Same as Screen (612,306) — identical duplicate: all 4 rows still show light-blue "Cut" status and grey "No" Complete toggle, Press Brake button still present, nothing struck through, and the parent Done button remains pale/disabled.
- Notes: corrects an earlier claim that this file shows all rows Bent/Complete with the Machine button removed — that state actually appears in Screen (660,373), and for the Bright White row, not Dark Red.
- Verified: pass3

###### Screen (660,283) — Press Brake bendlist tab (duplicate)
- File: `p1_154_x660_y283.png`
- Same as Screen (682,256) — identical duplicate. (Corrects an earlier claim of duplicating Screen (592,283), which actually has two extra icon-flagged rows.)
- Verified: pass3

###### Screen (660,299) — Expanded Press Brake bendlist (Bright White, Not Started)
- File: `p1_156_x660_y299.png`
- Illustrates: "The Qty to Manufacture column needs to show the difference between the Qty Ordered and Stock columns." (687,302)-(695,303)
- Table: expanded row Wed 05/08/2024, 28Ga.-Bright White (Done button pale). Sub-columns: Width|Length|Qty Ordered|Stock|Qty to Manufacture|ID|Description|Remanufacture|Machine|Status|Complete|Drawing|Line Item Notes. Rows: 4/120/8/4/4/TBT8783/Base Trim Bright White/-/Press Brake/Not Started(grey)/(blank)/📷/Notes(green dot); 4/120/15/-/15/TBT8783/Base Trim Bright White/-/Press Brake/Not Started/(blank)/📷/Notes; 4/120/12/-/12/TGD8783/Gable Divider Bright White/-/Press Brake/Not Started/(blank)/📷/Notes; 6/120/19/-/19/TED8783/Eave Drip Bright White 8/12 Pitch/-/Press Brake/Not Started/(blank)/📷/Notes; 10/120/4/3/1/TEW8783/End Wall Bright White/-/Press Brake/Not Started/(blank)/📷/Notes(red dot); 10/144(red-highlighted)/4/-/4/TEW8783/End Wall Bright White/-/Press Brake/Not Started/(blank)/📷/Notes; 10/120/7/-/7/TSW8783/Side Wall Bright White/-/Press Brake/Not Started/(blank)/📷/Notes; 12/120/3/-/3/TPC8783/Pitch Change Bright White 2/12-18/12/-/Press Brake/Not Started/(blank)/📷/Notes; 12/120/4/-/4/TOC8783/Outside Corner Bright White/-/Press Brake/Not Started/(blank)/📷/Notes; 14/120/8/-/8/TOCWJ8783/Outside Corner with J 3-1/4" Bright White/-/Press Brake/Not Started/(blank)/📷/Notes
- Indicators: red-highlighted Length cell (144); green dot / red dot in Line Item Notes column indicate note read-state (green=dealt with, red=unread); the Complete column shows no toggle at all while Status is "Not Started" (the No/Yes toggle only appears once a row reaches Cut or later)
- Verified: pass3

###### Screen (660,315) — Press Brake bendlist tab, bottom rows only
- File: `p1_159_x660_y315.png`
- Table: columns Production Date | Gauge/Colour | Priority | Remanufacture | (Done) (headers cropped off the top), bottom rows only: Wed 28Ga.-Coffee Brown; Wed 28Ga.-Colorbond Bronze; Wed 28Ga.-Dark Red; Wed 28Ga.-Melcher's Green; Wed 26Ga.-Black; Wed 26Ga.-Dark Red; divider; Thu 28Ga.-Black; Thu 28Ga.-Stone Grey. All Done buttons pale/disabled.
- Notes: cropped/scrolled view of the same table as Screen (682,256); corrects an earlier claim of duplicating the full table in Screen (592,283)
- Verified: pass3

###### Screen (660,324) — Press Brake bendlist, In Progress status
- File: `p1_160_x660_y324.png`
- Same as Screen (660,299) except: Status column now shows orange "In Progress" badge for all rows instead of grey "Not Started" (Bright White line items)
- Verified: pass3

###### Screen (660,340) — Press Brake bendlist tab, bottom rows only (duplicate)
- File: `p1_163_x660_y340.png`
- Same as Screen (660,315) — identical duplicate. (Corrects an earlier claim of duplicating Screen (592,283).)
- Verified: pass3

###### Screen (660,349) — Press Brake bendlist, Bright White expanded, mixed statuses
- File: `p1_165_x660_y349.png`
- Illustrates: progression of individual line items through Cut / In Progress / Bent+Complete states within one bendlist row
- Table: expanded row Wed 05/08/2024, 28Ga.-Bright White. Sub-columns same as Screen (660,299). Rows: 4/120/8/4/4/TBT8783/Base Trim Bright White/-/(no Machine button)/Bent(red)/Yes(green)/📷/Notes(green dot); 4/120/15/-/15/TBT8783/Base Trim Bright White/-/Press Brake/Cut(blue)/No/📷/Notes; 4/120/12/-/12/TGD8783/Gable Divider Bright White/-/(no Machine button)/Bent(red)/Yes(green)/📷/Notes; 6/120/19/-/19/TED8783/Eave Drip Bright White 8/12 Pitch/-/Press Brake/Cut(blue)/No/📷/Notes; 10/120/4/3/1/TEW8783/End Wall Bright White/-/Press Brake/Cut(blue)/No/📷/Notes(red dot); 10/144(red-highlighted)/4/-/4/TEW8783/End Wall Bright White/-/Press Brake/In Progress(orange)/No/📷/Notes; 10/120/7/-/7/TSW8783/Side Wall Bright White/-/(no Machine button)/Bent(red)/Yes(green)/📷/Notes; 12/120/3/-/3/TPC8783/Pitch Change Bright White 2/12-18/12/-/Press Brake/Cut(blue)/No/📷/Notes; 12/120/4/-/4/TOC8783/Outside Corner Bright White/-/(no Machine button)/Bent(red)/Yes(green)/📷/Notes; 14/120/8/-/8/TOCWJ8783/Outside Corner with J 3-1/4" Bright White/-/Press Brake/In Progress(orange)/No/📷/Notes
- Indicators: red-highlighted Length cell (144); rows with status "Bent" are struck through with green "Yes" Complete and no Machine button; Cut/In Progress rows remain un-struck with grey "No" and keep the Press Brake button
- Notes: corrects an earlier claim that this duplicates Screen (660,324) (which shows all rows uniformly "In Progress") — this capture instead shows a mix of Cut, In Progress, and completed/Bent rows
- Verified: pass3

###### Screen (660,364) — Press Brake bendlist tab, bottom rows only (duplicate)
- File: `p1_167_x660_y364.png`
- Same as Screen (660,315) — identical duplicate. (Corrects an earlier claim of duplicating Screen (592,283).)
- Verified: pass3

###### Screen (682,256) — Press Brake bendlist tab
- File: `p1_153_x682_y256.png`
- Illustrates: "Trim Production" (671,255) / Machines tab annotations
- Header/tabs: department pill Trim; Stock Manufacturing green button; "Completed bendlists for the past 90 days"; tab bar Slinet / **Press Brake** (active) / V1/V2/Rollformer/Caps/Wrapping; Coils tab; Search box
- Table: columns Production Date | Gauge/Colour | Priority | Remanufacture | (Done button). Rows (all Wed May 08/2024 unless noted, all Done buttons pale/disabled): 28Ga.-Black; 28Ga.-Bright Red; 28Ga.-Bright White; 28Ga.-Coffee Brown; 28Ga.-Colorbond Bronze; 28Ga.-Dark Red; 28Ga.-Melcher's Green; 26Ga.-Black; 26Ga.-Dark Red; divider; Thu 28Ga.-Black; Thu 28Ga.-Stone Grey. 11 rows visible.
- Notes: this is the plain Press Brake table without the two extra icon-flagged rows seen in Screen (592,283) — this entry previously (incorrectly) claimed it was identical to that file
- Verified: pass3


##### Priorities (688,281)

- Workers can NOT change Priorities (912,287) — same rule shown here too
- This tab needs to primarily sort by Production Date, then Priority and then Gauge/Colour. (687,284)
- Bendlist order example: 1st bendlist is the "NOW" order (695,286); 2nd bendlist is the 2 "ASAP" orders (694,288); 3rd bendlist is the "By 10:00" order (694,289); 4th bendlist is the "By 3:00" order (694,290); 5th bendlist is the rest of the orders without a priority (694,292)

###### Screens (2)

###### Screen (703,283) — Press Brake bendlist tab with priority banners
- File: `p1_155_x703_y283.png`
- Illustrates: Priority colour coding applied to the Press Brake bendlist, mirroring the Slinet cutlist pattern
- Header/tabs: same header, but **Press Brake** tab active (not Slinet); Remanufacture column present (no Recut/Cutlist Coils columns)
- Table: columns Production Date | Gauge/Colour | Priority | Remanufacture | (Done). Rows: Wed 28Ga.-Bright White "NOW" (red); Wed 28Ga.-Bright White "ASAP" (orange); Wed 28Ga.-Bright White "By 10:00" (yellow); Wed 28Ga.-Bright White "By 3:00" (yellow); Wed 28Ga.-Bright White (no priority); Wed 28Ga.-Black; Wed 28Ga.-Bright Red; Wed 28Ga.-Bright White; Wed 28Ga.-Coffee Brown; Wed 28Ga.-Colorbond Bronze; Wed 28Ga.-Dark Red; Wed 28Ga.-Melcher's Green; Wed 26Ga.-Black; Wed 26Ga.-Dark Red; divider; Thu 28Ga.-Black "By 10:00"; Thu 28Ga.-Stone Grey. 16 rows visible, all Done buttons pale/disabled.
- Indicators: same NOW/ASAP/By-time colour coding as the Slinet cutlist tab
- Notes: corrects an earlier claim that this duplicates Screen (534,283) — that file is the Slinet tab (Cutlist Coils/Recut columns); this one is the Press Brake tab (Remanufacture column)
- Verified: pass3

###### Screen (703,304) — Press Brake bendlist tab with priority banners (duplicate)
- File: `p1_157_x703_y304.png`
- Same as Screen (703,283) — identical duplicate. (Corrects an earlier claim of duplicating the Slinet tab, Screen (534,283).)
- Verified: pass3


##### Stock Orders

Qty to Manufacture column needs to show the difference between the Qty Ordered and Stock columns; Qty Ordered - Stock = Qty to Manufacture. (687,302 / 686,304)

##### Bendlists

- "These bendlists would be created automatically as soon as the orders are Released To Production. It should combine line items that have the same Colour/Gauge combination and Priority at the time that the orders were Released To Production. It should never add to an existing bendlist. For example, if you were to Release To Production an order that has 28Ga. Black trims on it, it would create a bendlist for that order. Afterwards, if you go and Release To Production another order that has 28Ga. Black on it, it should create another bendlist since they weren't Released To Production at the same time." (648,283)
- Click the drop down on a bendlist to see all the line items that were assigned to the Machine you are working on. (653,304)
- The bendlist should highlight any length that is NOT 120". (654,311)
- "The line items need to be primarily sorted by width and then length. The smallest width goes on top and the largest goes on the bottom. Then it sorts by length after that. For example, if there are multiple different lengths of the same width, the shortest one would be on top of the other ones." (650,330)
- "Workers needs to be able to change the Machine a line item is assigned to. If the Worker changes the Machine for a line item, then that line item needs to disappear out of this bendlist and appear in the bendlist of the Machine it got reassigned to. It would create a new bendlist for the Machine that the line item was reassigned to with just this line item in it. The new bendlist would inherit everything from the bendlist it came from, except the Machine." (650,338)
- "As long as the Slinet Worker has NOT marked any of the material lines as Complete (Cut), then the Status would show Not Started within all the Machine bendlists. Once the Slinet Worker marks the first material line as Complete (Cut), then all the Status's for every line item connected to that cutlist would change to In Progress. All the line items connected to that cutlist need to change to In Progress, even for all the Machines that that line item isn't assigned to, showing that the Slinet is working on that Gauge / Color." (650,318)
- "As long as the Status is Not Started, then the Complete button is NOT available, as soon as the Status changes to In Progress then the Complete button becomes available. We need to be able to mark a line item as Complete even if it hasn't been marked as Cut yet. Then when the Slinet Worker marks it as Cut it would still remain as Bent, Bent needs to override Cut." (686,329)
- There should be a pop-up asking you to confirm when changing the Complete from "Yes" to "No", but no pop-up when changing from "No" to "Yes". (687,357)
- When a row is marked as Complete, it needs to get crossed out and the Machine button would disappear. (653,358)
- When all the rows within a bendlist are marked Complete, then the Done button should become available. (688,378)
- Clicking the Done button would give you this pop up (677,397)
- "Clicking Yes will remove the entire bendlist from the Machine tab. It will remain available within the Completed Bendlists tab for the next 90 days. It should keep the same formatting." (687,411)

##### Overdue Bendlists (685,423)

- Overdue bendlists need to be highlighted. (678,426)
- "Example: If it is Thursday, May 09/2024 and there are bendlists from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday bendlists to be highlighted as overdue." (678,427)

###### Screens (21)

###### Screen (618,447) — Press Brake bendlist list, header visible, Remanufacture badge (amber "2")
- File: `p1_176_x618_y447.png`
- Illustrates: no adjacent annotation (misfiled in a prior pass under Machine Capacities — this image is not an admin/Machines screen)
- Header/tabs: Department pill "Trim"; "Completed bendlists for the past 90 days" button; Search box; Machine tabs Slinet/**Press Brake**(active)/V1/V2/Rollformer/Caps/Wrapping/Coils
- Controls: all rows collapsed, greyed "Done" buttons throughout
- Table: columns Production Date, Gauge/Colour, Priority, Remanufacture, [Done]. Rows (all Wednesday, May 08/2024 unless noted): 28Ga.-Black; 28Ga.-Black (Remanufacture badge, amber, "2"); 28Ga.-Bright Red; 28Ga.-Bright White; 28Ga.-Coffee Brown; 28Ga.-Colorbond Bronze; 28Ga.-Dark Red; 28Ga.-Melcher's Green; 26Ga.-Black; 26Ga.-Dark Red; (orange separator) Thursday, May 09/2024 - 28Ga.-Black; Thursday, May 09/2024 - 28Ga.-Stone Grey
- Indicators: amber/orange pill "2" in Remanufacture column on the second 28Ga.-Black row
- Dialog/popup: none
- Notes: this is a Press Brake bendlist list, not a Machines/admin screen; corrects a prior mis-transcription. Not pixel-identical to Screen (618,463) — that file shows the same layout with a green (not amber) "2" badge.
- Verified: pass3

###### Screen (618,463) — Press Brake bendlist list, header visible, Remanufacture badge (green "2")
- File: `p1_180_x618_y463.png`
- Illustrates: no adjacent annotation (misfiled in a prior pass as a "Create Location form" — this image has no location form on it at all)
- Header/tabs: Department pill "Trim"; "Completed bendlists for the past 90 days" button; Search box; Machine tabs Slinet/**Press Brake**(active)/V1/V2/Rollformer/Caps/Wrapping/Coils
- Controls: all rows collapsed, greyed "Done" buttons throughout
- Table: same row set as Screen (618,447): 28Ga.-Black; 28Ga.-Black (Remanufacture badge, green, "2"); 28Ga.-Bright Red; 28Ga.-Bright White; 28Ga.-Coffee Brown; 28Ga.-Colorbond Bronze; 28Ga.-Dark Red; 28Ga.-Melcher's Green; 26Ga.-Black; 26Ga.-Dark Red; (orange separator) Thursday 28Ga.-Black; Thursday 28Ga.-Stone Grey
- Indicators: green pill "2" in Remanufacture column on the second 28Ga.-Black row (Screen 618,447 shows the same layout but amber, not green)
- Dialog/popup: none
- Notes: corrects a prior mis-transcription that described a "Create Location" modal; no such modal appears in this file.
- Verified: pass3

###### Screen (618,479) — Press Brake bendlist, TED8262 Eave Drip Black row expanded (Complete = No)
- File: `p1_183_x618_y479.png`
- Illustrates: no adjacent annotation (misfiled in a prior pass as "Locations list for Trim department" — no Locations admin table appears on this image)
- Header/tabs: not visible in the expanded-row region (cropped); Trim pill and Press Brake tab visible above in the collapsed part of the table
- Controls: collapsed 28Ga.-Black row above; expanded 28Ga.-Black row (bold-bordered, green "2" Remanufacture badge) showing one line item
- Table: columns Width, Length, Qty Ordered, Stock, Qty to Manufacture, ID, Description, Remanufacture, Machine, Status, Complete, Drawing, Line Item Notes. Row: 6/120/2/(blank)/2/TED8262/Eave Drip Black 6/12 Pitch/(blank)/Press Brake/blue "Cut"/grey "No"/(drawing icon)/green Notes dot
- Indicators: green "2" Remanufacture badge; blue = Cut status; grey "No" = not complete
- Dialog/popup: none
- Notes: corrects a prior mis-transcription; this is a Press Brake bendlist expansion, not a Locations admin list.
- Verified: pass3

###### Screen (618,498) — Press Brake bendlist, TED8262 Eave Drip Black row expanded (Bent, Complete = Yes)
- File: `p1_188_x618_y498.png`
- Illustrates: no adjacent annotation (misfiled in a prior pass as a "Create Location form" — no such form appears on this image)
- Header/tabs: not visible in the expanded-row region (cropped); Trim pill and Press Brake tab visible above
- Controls: collapsed 28Ga.-Black row above; expanded 28Ga.-Black row (bold-bordered, green "2" Remanufacture badge)
- Table: row: 6/120/2/(blank)/2/TED8262/Eave Drip Black 6/12 Pitch/(blank)/(blank machine)/red "Bent"/green "Yes"/(drawing icon)/green Notes dot (row struck through)
- Indicators: green "2" Remanufacture badge; red = Bent status; green "Yes" = Complete
- Dialog/popup: none
- Notes: corrects a prior mis-transcription; same underlying line item as Screen (618,479) but in its later, completed (Bent/Complete=Yes) state rather than in-progress (Cut/Complete=No).
- Verified: pass3

###### Screen (660,373) — Press Brake bendlist, Bright White expanded, all rows Bent/Complete
- File: `p1_170_x660_y373.png`
- Illustrates: "As long as the Status is Not Started, then the Complete button is NOT available, as soon as the Status changes to In Progress then the Complete button becomes available." (686,329)-(695,335); "When a row is marked as Complete, it needs to get crossed out and the Machine button would disappear." (653,358)-(658,361)
- Table: expanded row Wed 05/08/2024, 28Ga.-Bright White. Sub-columns same as Screen (660,299). All 10 rows now show red "Bent" status badge, green "Yes" Complete toggle, strikethrough row text, and no Machine button. The Bright White parent row's Done button is now solid dark green and enabled; the Black and Bright Red parent rows above it remain pale/disabled.
- Indicators: strikethrough text on completed rows; red "Bent" badge; green Complete "Yes" toggle; dark-green enabled "Done" button on the Bright White parent row only
- Notes: corrects an earlier claim that this file duplicates Screen (612,366) (Dark Red, unchanged Cut status) — this is a distinct, later-state capture for the Bright White row
- Verified: pass3

###### Screen (660,389) — Press Brake bendlist list (collapsed rows)
- File: `p1_171_x660_y389.png`
- Illustrates: no adjacent annotation (crop shows a generic collapsed bendlist-day list, used repeatedly as backdrop for later popups)
- Header/tabs: not visible in this crop (cropped to table body only)
- Controls: none besides row expand carets (▽/▷)
- Table: columns not shown (cropped); rows visible — Wednesday, May 08/2024 / 28Ga. - Coffee Brown; Wednesday, May 08/2024 / 28Ga. - Colorbond Bronze; Wednesday, May 08/2024 / 28Ga. - Dark Red; Wednesday, May 08/2024 / 28Ga. - Melcher's Green; Wednesday, May 08/2024 / 26Ga. - Black; Wednesday, May 08/2024 / 26Ga. - Dark Red; (red separator line — new day) Thursday, May 09/2024 / 28Ga. - Black; Thursday, May 09/2024 / 28Ga. - Stone Grey. Each row has a greyed-out "Done" button.
- Indicators: red horizontal line separates Wednesday rows from Thursday rows (day boundary)
- Dialog/popup: none
- Notes: this exact crop is byte-identical (confirmed via checksum) to files 173, 178, 179, 184, 185, 189, 190 in this batch — it is the unchanging bottom portion of the Press Brake bendlist table showing later, not-yet-worked days, visible underneath scrolled/expanded content or dialogs above it.
- Verified: pass3

###### Screen (660,399) — Press Brake bendlist window (Done confirmation popup)
- File: `p1_172_x660_y399.png`
- Illustrates: (677,397)-(682,398) "Clicking the Done button would give you this pop up"
- Header/tabs: Department pill "Trim" (top-left); "Completed bendlists for the past 90 days" button (top-right); Search box (top-right); Machine tab bar: Slinet, **Press Brake** (active/white), V1, V2, Rollformer, Caps, Wrapping, Coils (far right, separated). Green "Stock Manufacturing" button below the Trim pill.
- Controls: two collapsed Wednesday rows (28Ga.-Black, 28Ga.-Bright Red) each with a greyed "Done" button; expanded row Wednesday, May 08/2024 - 28Ga. Bright White (bold-bordered/selected) with a green enabled "Done" button
- Table: columns Width, Length, Qty Ordered, Stock, Qty to Manufacture, ID, Description, Remanufacture, Machine, Status, Complete, Drawing, Line Item Notes. All 10 rows are struck-through with red "Bent" status and green "Yes" Complete — this is a fully-completed Bright White bendlist. Visible rows (top few, before the dialog occludes ID/Description for rows 4-8): 4/120/8/4/4/TBT8783/Base Trim Bright White (green Notes dot); 4/120/15/(blank)/15/TBT8783/Base Trim Bright White; 4/120/12/(blank)/12/TGD8783/Gable Divider Bright White; 6/120/10/(blank)/(obscured by dialog); 10/120/4/3/(obscured, red Notes dot); 10/144(highlighted red)/4/(blank)/(obscured); 10/120/7/(blank)/(obscured); 12/120/3/(blank)/3/TPC8783/Pitch Change Bright White 2/12-16/12; 12/120/4/(blank)/4/TOC8783/Outside Corner Bright White; 14/120/8/(blank)/8/TOCWJ8783/Outside Corner with J 3-1/4" Bright White
- Indicators: red = Bent status (all rows); green checkmark "Yes" = Complete (all rows); red dot on one "Notes" link = unread note, green dot = read; strike-through text on all rows
- Dialog/popup: "Are you sure that you are done with this bendlist?" with green "Yes" and red "No" buttons; dialog visually occludes the middle Width/Length/Qty/ID/Description columns for several rows
- Notes: Length "144" cell highlighted red (non-120" length per rule at (465,337)). No row in this crop shows blue "Cut", orange "In Progress", or grey "No" — every visible row is already Bent/Complete=Yes (corrects a prior mis-transcription that fabricated mixed statuses).
- Verified: pass3

###### Screen (660,415) — Press Brake bendlist list (duplicate of 171)
- File: `p1_173_x660_y415.png`
- Illustrates: same region as Screen (660,389); no adjacent annotation
- Header/tabs: not visible (cropped)
- Controls: greyed "Done" buttons
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Indicators: red separator line between Wednesday and Thursday groups
- Dialog/popup: none
- Notes: duplicate crop of the same table region (see 171).
- Verified: pass3

###### Screen (660,447) — Press Brake bendlist, Bright White expanded (no dialog)
- File: `p1_177_x660_y447.png`
- Illustrates: no adjacent annotation
- Header/tabs: Department pill "Trim"; "Completed bendlists..." button; Search; Machine tabs Slinet/**Press Brake**(active)/V1/V2/Rollformer/Caps/Wrapping/Coils
- Controls: two collapsed Wednesday rows (28Ga.-Black, 28Ga.-Bright Red, greyed Done); expanded Wednesday, May 08/2024 - 28Ga. Bright White row (green enabled Done)
- Table: same Bright White row set as Screen (707,447)/(660,399), fully visible with no dialog: 4/120/8/4/4/TBT8783/Base Trim Bright White (Bent, Yes, green Notes dot); 4/120/15/(blank)/15/TBT8783/Base Trim Bright White/Press Brake/Cut/No; 4/120/12/(blank)/12/TGD8783/Gable Divider Bright White (Bent, Yes); 6/120/19/(blank, blue-bordered selected)/19/TED8783/Eave Drip Bright White 8/12 Pitch/Press Brake/Cut/No; 10/120/4/3/1/TEW8783/End Wall Bright White/Press Brake/Cut/No (red Notes dot); 10/144(highlighted red)/4/(blank)/4/TEW8783/End Wall Bright White/Press Brake/In Progress/No; 10/120/7/(blank)/7/TSW8783/Side Wall Bright White (Bent, Yes); 12/120/3/(blank)/3/TPC8783/Pitch Change Bright White 2/12-18/12/Press Brake/Cut/No; 12/120/4/(blank)/4/TOC8783/Outside Corner Bright White (Bent, Yes); 14/120/8/(blank)/8/TOCWJ8783/Outside Corner with J 3-1/4" Bright White/Press Brake/In Progress/No
- Indicators: red=Bent, blue=Cut, orange=In Progress, green Yes; red dot on one Notes
- Dialog/popup: none (this is the same expanded table as Screen (660,399) with the "Are you sure" popup dismissed/not yet triggered)
- Notes: not a duplicate of the collapsed-list crop (171/173) as previously logged — it is the full expanded Bright White table, pixel-identical in content to Screen (707,447).
- Verified: pass3

###### Screen (660,462) — Press Brake bendlist list (duplicate of 171)
- File: `p1_179_x660_y462.png`
- Illustrates: no adjacent annotation
- Header/tabs: not visible (cropped)
- Controls: greyed "Done" buttons
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Dialog/popup: none
- Notes: duplicate crop.
- Verified: pass3

###### Screen (660,472) — Press Brake keypad entry (duplicate of 181)
- File: `p1_182_x660_y472.png`
- Illustrates: numeric-entry pattern, same family as (707,447)/(707,472)
- Header/tabs: Trim pill; Press Brake active tab
- Controls: "___ pcs." + green "Enter"; keypad 1-9,0, back-arrow, red "X"; underlying Eave Drip Bright White row selected (blue-bordered blank Stock cell)
- Table: same Bright White bendlist rows as (660,399)
- Dialog/popup: keypad popup
- Notes: corrects a prior mis-transcription that described a "Create Location" modal with "Number of Orders = 12" — no such form appears here; this file is the same Press Brake keypad as (707,472), not a Locations admin screen.
- Verified: pass3

###### Screen (660,488) — Press Brake bendlist list (duplicate of 171)
- File: `p1_185_x660_y488.png`
- Illustrates: no adjacent annotation
- Header/tabs: not visible (cropped)
- Controls: greyed "Done" buttons
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Dialog/popup: none
- Notes: corrects a prior mis-transcription that described a Wrapping-tab order list (Stock orders, house icon, order # prefix "S"); no such table appears on this file — it is the plain Press Brake collapsed-list crop. The Wrapping order list this annotation refers to is shown in Screen (762,283).
- Verified: pass3

###### Screen (660,498) — Press Brake bendlist, Bright White expanded, Bright Red row Remanufacture "1"
- File: `p1_187_x660_y498.png`
- Illustrates: no adjacent annotation
- Header/tabs: Trim pill; Completed bendlists button; Search; Machine tabs Slinet/**Press Brake**(active)/V1/V2/Rollformer/Caps/Wrapping/Coils
- Controls: collapsed 28Ga.-Black row (greyed Done); collapsed 28Ga.-Bright Red row with amber "1" Remanufacture badge (greyed Done); expanded 28Ga.-Bright White row (green Done)
- Table: this crop is missing the Eave Drip (TED8783, 6/120/19) row entirely — 9 rows visible, not 10: 4/120/8/4/4/TBT8783 Base Trim Bright White (struck, Bent, Yes, green Notes dot); 4/120/15/blank/15/TBT8783 Base Trim Bright White (Cut, No); 4/120/12/blank/12/TGD8783 Gable Divider Bright White (struck, Bent, Yes); 10/120/4/3/1/TEW8783 End Wall Bright White (Cut, No, red Notes dot); 10/144/4/blank/4/TEW8783 End Wall Bright White (In Progress, No — the 144 cell is plain, not red-highlighted in this crop); 10/120/7/blank/7/TSW8783 Side Wall Bright White (struck, Bent, Yes); 12/120/3/blank/3/TPC8783 Pitch Change Bright White 2/12-16/12 (Cut, No); 12/120/4/blank/4/TOC8783 Outside Corner Bright White (struck, Bent, Yes); 14/120/8/(cut off at bottom of crop) TOCWJ8783
- Indicators: red=Bent, blue=Cut, orange=In Progress, green Yes; red dot on one Notes; amber "1" Remanufacture badge on the Bright Red row
- Dialog/popup: none
- Notes: corrects a prior mis-transcription that swapped this file's content with Screen (707,498)'s "Qty to Manufacture = 18" edit; that edit is on file 186, not this one. Also corrects a claim that the Eave Drip row appears here — it does not, unlike the other Bright White expansions in this batch.
- Verified: pass3

###### Screen (660,513) — Press Brake bendlist list (duplicate of 171)
- File: `p1_189_x660_y513.png`
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Dialog/popup: none
- Notes: duplicate crop of the collapsed bendlist tail.
- Verified: pass3

###### Screen (689,425) — Press Brake bendlist, red-highlighted overdue rows
- File: `p1_174_x689_y425.png`
- Illustrates: (685,423)-(692,424) "Overdue Bendlists" and (678,426)-(686,431) "Overdue bendlists need to be highlighted... Example: If it is Thursday, May 09/2024 and there are bendlists from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday bendlists to be highlighted as overdue."
- Header/tabs: Department pill "Trim"; "Completed bendlists for the past 90 days" button; Search box; Machine tabs: Slinet, **Press Brake** (active), V1, V2, Rollformer, Caps, Wrapping, Coils
- Controls: "Done" buttons on each row are the greyed/disabled light-green italic style (not enabled) — no row here has been expanded/selected
- Table: columns Production Date, Gauge/Colour, Priority, Remanufacture, [Done]. Rows: Wednesday, May 08/2024 - 28Ga. Black (red-highlighted row); Wednesday, May 08/2024 - 28Ga. Bright Red (red-highlighted row); (orange separator) Thursday, May 09/2024 - 28Ga. Bright White; Thursday, May 09/2024 - 28Ga. Coffee Brown; Thursday, May 09/2024 - 28Ga. Colorbond Bronze; Thursday, May 09/2024 - 28Ga. Dark Red; Thursday, May 09/2024 - 28Ga. Melcher's Green; Thursday, May 09/2024 - 26Ga. Black; Thursday, May 09/2024 - 26Ga. Dark Red; Thursday, May 09/2024 - 28Ga. Black; Thursday, May 09/2024 - 28Ga. Stone Grey
- Indicators: two Wednesday rows highlighted solid red with darker red border = overdue bendlists; orange horizontal line separates Wednesday (overdue, previous day) from Thursday (current day) groups
- Dialog/popup: none
- Notes: confirms text annotation — overdue rows for the prior incomplete day are highlighted red at the top of the current day's list.
- Verified: pass3

###### Screen (707,447) — Press Brake bendlist, Bright White expanded (full status column, no dialog)
- File: `p1_175_x707_y447.png`
- Illustrates: no adjacent annotation (corrects a prior mis-transcription that described a numeric keypad popup here — no keypad appears on this file)
- Header/tabs: Department pill "Trim"; "Completed bendlists..." button; Search; Machine tabs Slinet/**Press Brake**(active)/V1/V2/Rollformer/Caps/Wrapping/Coils
- Controls: two collapsed Wednesday rows (28Ga.-Black, 28Ga.-Bright Red, greyed Done); expanded Wednesday, May 08/2024 - 28Ga. Bright White row (green enabled Done); Eave Drip Bright White 8/12 Pitch row has an empty blue-bordered/selected Stock cell
- Table: full row set, all visible (no dialog covering it): 4/120/8/4/4/TBT8783/Base Trim Bright White (struck-through, red Bent, green Yes, green Notes dot); 4/120/15/(blank)/15/TBT8783/Base Trim Bright White/Press Brake/blue Cut/grey No; 4/120/12/(blank)/12/TGD8783/Gable Divider Bright White (struck-through, red Bent, green Yes); 6/120/19/(blank, blue-bordered selected)/19/TED8783/Eave Drip Bright White 8/12 Pitch/Press Brake/blue Cut/grey No; 10/120/4/3/1/TEW8783/End Wall Bright White/Press Brake/blue Cut/grey No (red Notes dot); 10/144(highlighted red)/4/(blank)/4/TEW8783/End Wall Bright White/Press Brake/orange In Progress/grey No; 10/120/7/(blank)/7/TSW8783/Side Wall Bright White (struck-through, red Bent, green Yes); 12/120/3/(blank)/3/TPC8783/Pitch Change Bright White 2/12-18/12/Press Brake/blue Cut/grey No; 12/120/4/(blank)/4/TOC8783/Outside Corner Bright White (struck-through, red Bent, green Yes); 14/120/8/(blank)/8/TOCWJ8783/Outside Corner with J 3-1/4" Bright White/Press Brake/orange In Progress/grey No
- Indicators: red = Bent, blue = Cut, orange = In Progress, green Yes = Complete; red dot on one Notes link, green dot on another
- Dialog/popup: none
- Notes: this is the same expanded Bright White table as Screen (660,399), just without the "Are you sure" confirmation dialog on top, so the full Status/Complete grid is visible.
- Verified: pass3

###### Screen (707,462) — Press Brake bendlist list (duplicate of 171)
- File: `p1_178_x707_y462.png`
- Illustrates: no adjacent annotation
- Header/tabs: not visible (cropped)
- Controls: greyed "Done" buttons
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Notes: this is not a Coil Suppliers popup as previously logged; it is the same collapsed bendlist-tail crop as 171/173/179/184/185/189/190.
- Verified: pass3

###### Screen (707,472) — Press Brake keypad entry (large keypad, Enter highlighted, no minus)
- File: `p1_181_x707_y472.png`
- Illustrates: numeric-entry pattern, same family as (707,447)
- Header/tabs: same as (707,447) — Trim pill, Press Brake active tab
- Controls: "___ pcs." + green "Enter"; keypad 1-9,0, back-arrow, red "X"
- Table: same underlying Bright White bendlist as (707,447)
- Dialog/popup: keypad popup
- Notes: Screen (707,447) was mis-logged in a prior pass as this same keypad — it actually has no keypad (see corrected entry for 175/p1_175). This file (181) is the genuine keypad screen; (660,472)/p1_182 is its near-duplicate.
- Verified: pass3

###### Screen (707,488) — Press Brake bendlist list (duplicate of 171)
- File: `p1_184_x707_y488.png`
- Illustrates: no adjacent annotation
- Header/tabs: not visible (cropped)
- Controls: greyed "Done" buttons
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Dialog/popup: none
- Notes: corrects a prior mis-transcription that described a Press Brake keypad; no keypad appears on this file — it is the plain collapsed-list crop.
- Verified: pass3

###### Screen (707,498) — Press Brake bendlist, Bright White expanded, Qty to Manufacture edited to 18
- File: `p1_186_x707_y498.png`
- Illustrates: (503,433)/(477,451)-(482,452) style Apply/edit pattern; qty-edit for the Eave Drip row
- Header/tabs: Trim pill; Completed bendlists button; Search; Machine tabs Slinet/**Press Brake**(active)/V1/V2/Rollformer/Caps/Wrapping/Coils
- Table: same Bright White row set as Screen (660,399) except: row Width 6/Length 120/Qty Ordered 19/Stock 1/Qty to Manufacture changed to 18 (down from 19), ID TED8783, Eave Drip Bright White 8/12 Pitch, Machine Press Brake, Status blue Cut; row 6 (144-highlighted End Wall) unchanged
- Indicators: red=Bent, blue=Cut, orange=In Progress, green Yes; red dot on one Notes
- Dialog/popup: none
- Notes: shows Stock value 1 applied, reducing Qty to Manufacture from 19 to 18. Corrects a prior mis-transcription that described this file as a duplicate keypad crop.
- Verified: pass3

###### Screen (707,514) — Press Brake bendlist list (duplicate of 171)
- File: `p1_190_x707_y514.png`
- Table: identical to Screen (660,389) — byte-identical file (checksum-confirmed)
- Indicators: red separator line
- Notes: duplicate crop.
- Verified: pass3


##### Remanufacture Request in the Machine tabs (670,442) / from the Wrapping tab (627,442) / Pulling Stock in the Machine tabs (716,442)

- "When a Remanufacture Request is made from the Wrapping tab, then a new bendlist for that line item is created and sent to the appropriate Machine. The Remanufacture column in the new bendlist needs to then be orange and show the qty. that needs to be remanufactured." (608,446)
- Once the Slinet Worker marks the material as Cut (Complete), then the Remanufacture column needs to change from orange to green here in the Machine tab. (613,462)
- From here the Worker would have to put another coil into the Slinet and check off that it is in the Slinet to be able to continue working on this cutlist. (502,469)
- A Remanufacture bendlist from the Wrapping tab needs to only show the qty. that was requested to be remanufactured, NOT the full amount that was ordered. (612,482)
- Clicking in the Remanufacture column open a keypad. (677,470)
- Clicking in the Stock column open a keypad. (714,470)
- If a worker damages a piece and decides to use some from stock then he needs to be able to enter that into the Stock column. (700,451)
- Even if there is already a number in the Stock column, we still need to be able to change the number to anything from zero up to the Qty Ordered. (699,482)
- "When you enter a quantity in the Remanufacture column, then that line item gets removed from the current bendlist and a new bendlist is created with only that line item in it." (653,488)
- "Changing the amount being pulled from stock shouldn't make any different in regards to manufacturing batches. The manufacturing batch should only be created and push back to EBMS once all the line items have been wrapped and the Worker clicks the Order Complete button. To create the manufacturing batch it just needs to look at the Qty ordered minus the amount that has been pulled from stock and then manufacture the difference between those 2 numbers. This way it makes no difference who or how many times the number being pulled from stock changes, as long as it's the right number when the order is completed." (697,492)
- "This needs to create a new cutlist that inherits the same Production Date, Gauge/Colour, Priority and Machine as was assigned to this line item. This is then sent to the Slinet." (647,494)
- Enter the amount that needs to be Remanufactured (668,495 / 711,495)
- It should display the quantity that was requested in the Remanufature column. (686,501)
- Marking it as Complete will change the Remanufacture column to green in the Wrapping tab. (612,501)
- The Qty To Manufacture column would also need to automatically be updated. (703,509)
- "It should be highlighted in orange until it has been marked as Cut (Complete) by the Slinet. After is has been marked as Cut, then it should be highlighted in green." (686,514)
- This is the new bendlist with the line item that had a Remanufacture quantity attached to it. (655,535)
- A Remanufacture bentlist from a Machine tab needs to show the full Qty. Ordered and then the Qty. that was requested to be remanufactured in the Remanufacture column. (653,546)

###### Screens (9)

###### Screen (858,597) — Trim / Wrapping — Remanufacture cell selected, no keypad
- File: `p1_267_x858_y597.png`
- Same as base order modal (808,517) except: Remanufacture cell for the TED8262 row (Bent status, Left To Wrap=10) selected/outlined blue, empty — no keypad shown. Create & Print/See Packages/Order Complete disabled, Select Location enabled.
- Verified: pass3

###### Screen (858,618) — Trim / Wrapping — Remanufacture keypad open
- File: `p1_269_x858_y618.png`
- Same as base order modal except: keypad overlay open over the TED8262 row's Remanufacture cell ("___ pcs." + green Enter button; number pad 1-9,0,⌫,X close).
- Verified: pass3

###### Screen (858,639) — Trim / Wrapping — Remanufacture "2" entered (orange highlight)
- File: `p1_272_x858_y639.png`
- Illustrates: (883,656)-(892,659) "After entering the amount you need to have remanufactured, then that line item should be highlighted in orange and show the amount to remanufactured..."
- Same base modal except: TED8262 row shows Stock="2" AND Remanufacture cell shows "2" highlighted solid orange.
- Verified: pass3

###### Screen (858,659) — Trim / Wrapping — full table, Remanufacture=2 orange highlighted row
- File: `p1_273_x858_y659.png`
- Same as Screen (885,283) full-table view except: row 330632/Upright Construction/10/—/—/2(orange)/Bent/TED8262/Eave Drip 2" Black 6/12 Pitch — Remanufacture column shows "2" highlighted orange instead of blank.
- Verified: pass3

###### Screen (858,679) — Trim / Wrapping — full table, Remanufacture=2 green highlighted row
- File: `p1_274_x858_y679.png`
- Same as Screen (858,659) except: the Remanufacture "2" cell is now highlighted solid green instead of orange (per annotation: green once the Machine has marked it Bent/Complete).
- Verified: pass3

###### Screen (858,700) — Trim / Wrapping — order modal, Remanufacture=2 green
- File: `p1_275_x858_y700.png`
- Same as Screen (858,639) order-detail modal except: TED8262 row's Stock cell is blank (not "2") and its Remanufacture cell shows "2" highlighted green (not orange) — completed remanufacture state.
- Verified: pass3

###### Screen (912,597) — Trim / Wrapping — Stock cell selected, no keypad
- File: `p1_268_x912_y597.png`
- NOT identical to Screen (858,597): here the TED8262 row's Stock cell (not Remanufacture) is selected/outlined blue and empty; Remanufacture column is untouched. No keypad overlay shown. Create & Print/See Packages/Order Complete disabled, Select Location enabled.
- Verified: pass3

###### Screen (912,618) — Trim / Wrapping — Stock keypad open
- File: `p1_270_x912_y618.png`
- NOT identical to Screen (858,618): keypad overlay here is anchored over the TED8262 row's Stock cell (positioned further left, over the ID/Description columns), not the Remanufacture cell. Same keypad fields ("___ pcs." + green Enter button; number pad 1-9,0,⌫,X close).
- Verified: pass3

###### Screen (912,639) — Trim / Wrapping — TED8262 row shows Stock=2, no Remanufacture value
- File: `p1_271_x912_y639.png`
- Same base modal except: TED8262 row now shows Stock="2" (Left To Wrap still 10); Remanufacture cell is blank/unhighlighted (no orange, no value).
- Verified: pass3


### Wrapping (896,278)

##### Priorities (912,281)

- Workers can NOT change Priorities (729,284)
- This tab needs to primarily sort by Production Date, then Priority and then ID. (943,285 / 878,285)
- This tab needs to primarily sort by Production Date, then Priority and then Gauge/Colour. (730,305)
- Even though this line item has a Priority assigned to it, it gets pushed down as it has a later Production Date than the line items on top of it. (943,305)
- Even though this bendlist has a Priority assigned to it, it gets pushed down as it has a later Production Date than the orders on top of it. (730,317)

##### Stock Orders (876,281)

"Stock Orders would have an icon in the Production Date column showing that it's a Stock Order. The Order# would have a prefix of "S" and be it's own series of numbers. The Customer Name would say Stock." (755,283)

##### Line items in Wrapping

- "This tab shows every individual line item from every order as soon as they have been Released To Production." (878,288)
- Stock and Manufactured items will all appear in the same tab. We don't need separate tabs for them. (878,293)
- Line items that don't have a Status of either Bent or Stock need to be blocked from being Wrapped. (879,328)
- Clicking a line item opens the order but only shows trims, not line items in other Departments (categories). (899,323)
- Clicking a Stock line item opens the Stock order. (778,331)

###### Screens (6)

###### Screen (762,507) — Trim / Wrapping — table rows (Stock/Cut/Not Started statuses)
- File: `p1_229_x762_y507.png`
- Illustrates: no adjacent annotation (crop is a bare row strip); nearest heading area (876,281)-(881,282) "Stock Orders"
- Header/tabs: none visible (row-only crop).
- Controls: none.
- Table: Columns implied: Production Date | Order# | Customer Name | Qty Ordered | Stock | (blank) | Status | ID | Description. Rows: Wed. May 08/2024 | 330632 | Upright Construction | 6 | 6 | — | Stock (yellow) | TGS8262 | Gable Starter F Black; Wed. May 08/2024 | 330612 | H F H Inc | 12 | — | — | Cut (blue) | TJC8262 | J-Channel Black; Wed. May 08/2024 | S10125 | Stock (house icon) | 120 | — | — | Not Started (grey) | TSG8306 | Snow Guard Charcoal; Wed. May 08/2024 | S10125 | Stock (house icon) | 120 | — | — | Cut (blue) | TSW8306 | Side Wall Charcoal; Thurs. May 09/2024 | 330624 | DAP Roofing Inc. | 22 | — | — | Not Started (grey) | TED8262 | Eave Drip 2" Black (Notes); Thurs. May 09/2024 | 330623 | A.W.C. | 8 | — | — | Not Started (grey) | TEW8262 | End Wall Black (Notes).
- Indicators: Status color chips: yellow=Stock, blue=Cut, grey=Not Started. Stock-order rows (S10125) show a small house/warehouse icon before the order#.
- Dialog/popup: none.
- Notes: Same underlying row data reused throughout this batch as background scenery behind modals.
- Verified: pass3

###### Screen (762,532) — Trim / Wrapping — table rows
- File: `p1_232_x762_y532.png`
- Same as Screen (762,507) except: identical content (duplicate crop of the same row strip).
- Verified: pass3

###### Screen (808,517) — Trim / Wrapping — order detail modal, initial state
- File: `p1_231_x808_y517.png`
- Illustrates: no adjacent annotation; nearest (876,342)-(884,345) "Auto Fill and/or Manually Entering Amounts to Package"
- Header/tabs: "Trim" pill, "Completed orders for the past 90 days", Search box. Tabs: Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping (active), Coils.
- Controls: Order-detail modal columns: Auto Fill buttons (some green enabled, some red "no-entry" disabled icon) for 7 rows; Select Location (green, enabled), Create & Print (greyed/disabled), Package Weight (white box, empty/disabled), See Packages (green, enabled), Order Complete (greyed/disabled).
- Table: Columns: Qty Ordered | Stock | Left To Wrap | Wrapping | Status | Remanufacture | ID | Description | Length | Line Item Notes. Rows: 6/6/6/—/Stock(yellow)/—/TGS8262/Gable Starter F Black/10'0"(120"); 10/4/10/—/Cut(blue,disabled AutoFill)/—/TSG8262/Snow Guard Black; 5/—/5/—/Cut(blue,disabled)/—/TRC8262/Ridge Cap Black 6/12 Pitch; 10/—/10/—/Bent(red)/—/TED8262/Eave Drip Black 6/12 Pitch; 2/—/2/—/Bent(red)/—/TEW8262/End Wall Black 6/12 Pitch; 5/—/5/—/Bent(red)/—/TSW8262/Side Wall Black; 1/—/1/—/Not Started(grey,disabled)/—/TCFK8262/Chimney Kit Black.
- Indicators: Status colour chips yellow/blue/red/grey as above; red "no-entry" circle icon overlaying disabled Auto Fill buttons.
- Dialog/popup: none (base order modal, no popup).
- Notes: Footer fields: Customer Name "Upright Construction", Order# 330632, PO# "Shop Addition", Salesman "Joel Thiessen", Ship Date "Thursday, May 09/2024", Ship Via "Delivery", Priority (blank), Trim Location "405" (not blank).
- Verified: pass3

###### Screen (885,283) — Trim / Wrapping — full table view
- File: `p1_233_x885_y283.png`
- Illustrates: (835,298)-(844,303) "When the Manager makes an order Bypass Production, then the line items would appear here in the Wrapping tab..."; (878,301) "Line items that bypassed production"
- Header/tabs: "Trim" pill, "Completed orders for the past 90 days", Search. Tabs: Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping (active), Coils.
- Controls: none (table only, no modal).
- Table: Columns: Production Date | Order # | Customer Name | Qty Ordered | Stock | Priority | Remanufature | Status | ID | Description | Line Item Notes. 16 visible rows (Wed. May 08/2024 through Thurs. May 09/2024), e.g.: 330632/Upright Construction/1/—/—/—/Not Started/TCFK8262/Chimney Kit Black; 330602/DAP Roofing Inc./3/3/—/—/Stock/TED8262/Eave Drip 2" Black; 330621/Arnold Contracting/5/—/—/—/Cut/TED8262/Eave Drip 2" Black 12/12 Pitch; 330618/Ontario Metal Products Ltd./6/—/—/—/Wrapped/TED8262/Eave Drip 2" Black; 330632/Upright Construction/10/—/—/—/Bent/TED8262/Eave Drip 2" Black 6/12 Pitch; 330606/Ontario Metal Products Ltd./24/—/—/—/Bent/TED8262/Eave Drip 2" Black 2/12 Pitch (Notes=green dot); 330614/Ontario Metal Products Ltd./13/10/—/—/Cut/TEW8262/End Wall Black; 330603/Jireh Tools/16/—/—/—/Bent/TEW8262/End Wall Black 12/12 Pitch (Notes=red dot); 330632/Upright Construction/2/—/—/—/Bent/TEW8262/End Wall Black 6/12 Pitch; 330632/Upright Construction/6/6/—/—/Stock/TGS8262/Gable Starter F Black; 330612/H F H Inc/12/—/—/—/Cut/TJC8262/J-Channel Black; 330632/Upright Construction/5/—/—/—/Cut/TED8262/Ridge Cap Black 6/12 Pitch. Total visible rows in screenshot: 16 (last 4: 330632 Snow Guard/Side Wall, 330624 DAP, 330623 A.W.C.).
- Indicators: Status colour chips yellow=Stock, blue=Cut, green=Wrapped, red=Bent, grey=Not Started; green/red dot in Notes column for two rows.
- Dialog/popup: none.
- Notes: Orange horizontal divider line between the Wed. May 08 and Thurs. May 09 date groups.
- Verified: pass3

###### Screen (885,305) — Trim / Wrapping — full table, row selected
- File: `p1_237_x885_y305.png`
- Same as Screen (885,283) except: row "330632 / Upright Construction / 10 / Bent / TED8262 / Eave Drip 2" Black 6/12 Pitch" is highlighted/selected (blue outline box).
- Verified: pass3

###### Screen (885,389) — Wrapping detail modal (Trim, Wrapping tab)
- File: `p1_248_x885_y389.png`
- Illustrates: (878,401)-(883,403) "Once a location has been selected, then the Create & Print button becomes available." / (876,427)-(883,432) "The labels should be identified by a code made up of 3 parts..." / (846,414)-(854,418) "If you are trying to create another package... location name should highlight in red..."
- Header/tabs: department pill "Trim"; green "Stock Manufacturing" button; top-right "Completed orders for the past 90 days" button; Search box; tab bar Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping (active/white); right "Coils" tab. Modal has red "X" close button top-right.
- Controls: per-row "Auto Fill" buttons (green; some show a red "no entry" circle/slash icon overlaid meaning disabled), "Notes" buttons (green) in Line Item Notes column, bottom buttons: "Select Location" (green), "Create & Print" (green), a numeric weight display "15.62 lbs." (white box, disabled-looking), "See Packages" (greyed/disabled), "Order Complete" (greyed/disabled)
- Table: columns Qty Ordered | Stock | Left To Wrap | Wrapping | Status | Remanufacture | ID | Description | Length | Line Item Notes. Rows: 6/6/6/(blank) Stock(yellow) TGS8262 "Gable Starter F Black" 10'0"(120") Notes; 10/4/10/(blank) Cut(light blue) TSG8262 "Snow Guard Black" 10'0"(120") Notes, Auto Fill shows disabled icon; 5/(blank)/5/(blank) Cut(light blue) TRC8262 "Ridge Cap Black 6/12 Pitch" 10'0"(120") Notes, Auto Fill disabled; 10/(blank)/10/5 Bent(red) TED8262 "Eave Drip Black 6/12 Pitch" 10'0"(120") Notes; 2/(blank)/2/(blank) Bent(red) TEW8262 "End Wall Black 6/12 Pitch" 10'0"(120") Notes; 5/(blank)/5/(blank) Bent(red) TSW8262 "Side Wall Black" 10'0"(120") Notes; 1/(blank)/1/(disabled icon) Not Started(grey) TCFK8262 "Chimney Kit Black" 10'0"(120") Notes, Auto Fill disabled
- Indicators: Status column color-coded dots/badges: yellow "Stock", light blue "Cut" (x2), red "Bent" (x3), grey "Not Started"; several "Auto Fill" buttons show a red circle-slash (disabled) icon
- Dialog/popup: modal over the Wrapping tab table; below the item table: Customer Name "Upright Construction", Order # "330632", PO# "Shop Addition", Salesman "Joel Thiessen", Ship Date "Thursday, May 09/2024", Ship Via "Delivery", Priority (blank), Trim Location "405" (boxed); buttons Select Location, Create & Print, weight "15.62 lbs.", See Packages (disabled), Order Complete (disabled)
- Notes: background table (behind modal) partially visible on left/right edges with additional rows
- Verified: pass3


##### Line items that bypassed production (880,301)

"When the Manager makes an order Bypass Production, then the line items would appear here in the Wrapping tab and have a Status of Bypassed. From here the wrapping process would be the same as any other order. The Remanufacture column needs say N/A and the Remanufacturing function needs to be unavailable from these orders." (835,298)

###### Screens (1)

###### Screen (846,284) — Trim / Wrapping — table with Bypassed row
- File: `p1_235_x846_y284.png`
- Illustrates: (835,298)-(844,303) "When the Manager makes an order Bypass Production, then the line items would appear here in the Wrapping tab and have a Status of Bypassed... The Remanufacture column needs say N/A..."
- Header/tabs: same as Screen (885,283).
- Controls: none.
- Table: Same as Screen (885,283) plus one additional row: Wed. May 08/2024 | 330640 | H F H Inc | 4 | — | — | N/A | Bypassed (purple) | TJC8262 | J-Channel Black. 17 rows total visible.
- Indicators: New "Bypassed" status chip is purple/violet, distinct from yellow/blue/green/red/grey used elsewhere.
- Dialog/popup: none.
- Notes: Remanufacture column shows "N/A" for the bypassed row only.
- Verified: pass3


##### Line Item Notes (875,303)

- "The Manager and Workers should be able to add and view Line Item Notes at any point in production. These notes are just within the app, they do not come from or push back to EBMS." (828,308)
- Clicking this button opens the Line Item Note. (822,326)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (829,336)
- If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again. (829,387)

##### Auto Fill and/or Manually Entering Amounts to Package (876,342)

- Clicking the Auto Fill button would automatically fill whatever is in the Left To Wrap column into the Wrapping column (845,342)
- Input the amount you are going to wrap. (892,344)
- After clicking an Auto Fill button, then it changes to a delete button, which, if clicked would remove the number from the Wrapping column. (838,353)
- "The Worker does NOT have to use the Auto Fill function, he needs to also be able to just click on a line item within the Wrapping column and then manually type in any number between 1 and the number in the Left To Wrap column." (838,373)
- The Left To Wrap column would always show the difference between the Qty Ordered and Wrapped columns. (755,412)
- Once the Left To Wrap column is zero, then that trim's Status needs to automatically change to Wrapped and the Auto Fill button needs to grey out. (877,459)
- Enter the amount that was manufactured (767,407)
- Clicking on the stock item you are Wrapping opens a keypad. (766,382)
- "As a Worker wraps the Stock, he would enter what he has wrapped here in the Wrapped column. We need to be able to add or subtact from the amonut in the Wrapped column on the keypad, or just enter a completely new amount. Example: If a Worker had already wrapped 50 pcs. and enter that, then later he wraps 10 more pcs. he needs to just type +10 on the keypad. The new number in the Wrapped column would then show 60 pcs." (750,386)
- Once there is any value in the Wrapped column, then the check box becomes available. (755,417)
- "The Worker would then check off the stock items that he is done wrapping. Once at least 1 box is checked, then the Create Manufacturing Batch button becomes available." (754,440)
- Clicking the Create Manufacturing Batch button would give you this pop up (775,458)
- "Clicking Yes, Create Manufacturing Batch would create the Manufacturing Batch, make the Left To Wrap and Wrapped columns blank, enter the amount(s) manufactured into the Qty Manufactured column, the check box would be replaced with a Manufactured icon and the Status would updated to Wrapped." (763,485)
- "Once a Manufacturing Batch has been created for ALL of the rows, then the Stock line items would automatically disappear out of the Wrapping window and this Stock Order would move to the Completed Orders tab." (754,517)

###### Screens (19)

###### Screen (762,283) — Wrapping tab, full order list (Trim department)
- File: `p1_198_x762_y283.png`
- Illustrates: (755,283)-(760,289) "Stock Orders would have an icon in the Production Date column... Order# prefix 'S'... Customer Name would say Stock."
- Header/tabs: Department pill "Trim"; "Completed orders for the past 90 days" button; Search box; Machine tabs Slinet/Press Brake/V1/V2/Rollformer/Caps/**Wrapping**(active)/Coils
- Table: columns Production Date, Order #, Customer Name, Qty Ordered, Stock, Priority, Remanufacture, Status, ID, Description, Line Item Notes. All 16 rows visible, Wed May 08/2024 unless noted: (house icon) S10125/Stock/150/–/red Bent/TBT8262/Base Trim Black; 330632/Upright Construction/1/–/grey Not Started/TCFK8262/Chimney Kit Black/Notes; (house) S10125/Stock/150/–/red Bent/TDE8262/Drip Edge Black; 330602/DAP Roofing Inc./3/Stock 3/yellow Stock/TED8262/Eave Drip 2" Black/Notes; 330621/Arnold Contracting/5/–/blue Cut/TED8262/Eave Drip 2" Black 12/12 Pitch/Notes; 330618/Ontario Metal Products Ltd./6/–/green Wrapped/TED8262/Eave Drip 2" Black/Notes; 330632/Upright Construction/10/–/red Bent/TED8262/Eave Drip 2" Black 6/12 Pitch/Notes; 330606/Ontario Metal Products Ltd./24/–/red Bent/TED8262/Eave Drip 2" Black 2/12 Pitch/Notes (green dot); 330632/Upright Construction/5/–/blue Cut/TED8262/Ridge Cap Black 6/12 Pitch/Notes; 330632/Upright Construction/10/Stock 4/blue Cut/TED8262/Snow Guard Black/Notes; 330632/Upright Construction/5/–/red Bent/TED8262/Side Wall Black/Notes; 330614/Ontario Metal Products Ltd./13/Stock 10/blue Cut/TEW8262/End Wall Black/Notes; 330603/Jireh Tools/16/–/red Bent/TEW8262/End Wall Black 12/12 Pitch/Notes (red dot); 330632/Upright Construction/2/–/red Bent/TEW8262/End Wall Black 6/12 Pitch/Notes; (house) S10125/Stock/100/–/blue Cut/TEW8262/End Wall Black; (house) S10125/Stock/80/–/blue Cut/TEW8306/End Wall Charcoal
- Indicators: house icon = Stock order; red=Bent, blue=Cut, yellow=Stock, green=Wrapped, grey=Not Started; green/red dot on Notes = read/unread note
- Notes: 16 rows total in this crop, no continuation below the visible fold in this file; a further-scrolled continuation is shown in Screen (762,301).
- Verified: pass3

###### Screen (762,301) — Wrapping tab, table continuation (bottom rows)
- File: `p1_199_x762_y301.png`
- Illustrates: continuation of table from (762,283)
- Table: rows: 330632/Upright Construction/6/Stock 6/yellow Stock/TGS8262/Gable Starter F Black/Notes; 330612/H F H Inc/12/–/blue Cut/TJC8262/J-Channel Black/Notes; (house) S10125/Stock/120/–/grey Not Started/TSG8306/Snow Guard Charcoal; (house) S10125/Stock/120/–/blue Cut/TSW8306/Side Wall Charcoal; (orange separator line — new day) Thu May 09/2024 330624/DAP Roofing Inc./22/–/grey Not Started/TED8262/Eave Drip 2" Black/Notes; Thu May 09/2024 330623/A.W.C./8/–/grey Not Started/TEW8262/End Wall Black/Notes
- Indicators: orange horizontal separator between Wednesday and Thursday rows
- Notes: same bottom-of-table crop repeats identically across many other files in this batch (202, 207, 209, 212, 214, 217, 220, 223, 226) as the visible tail beneath scrolled dialogs.
- Verified: pass3

###### Screen (762,308) — Wrapping tab list (duplicate of 198, selection highlight)
- File: `p1_201_x762_y308.png`
- Illustrates: same table as (762,283)
- Table: same as Screen (762,283) except: row "(house) S10125/Stock/150/–/red Bent/TDE8262/Drip Edge Black" is highlighted/selected (blue border box)
- Notes: otherwise identical data.
- Verified: pass3

###### Screen (802,308) — Wrapping tab, order list (same rows as 198, different order)
- File: `p1_200_x802_y308.png`
- Illustrates: no adjacent annotation
- Header/tabs: same as (762,283) — Trim pill, Wrapping active tab
- Table: same row set as Screen (762,283)/(762,301) combined, but NOT in the same order — top "Base Trim Black" (S10125 Stock) row is scrolled out of view; visible order top to bottom: Chimney Kit Black (Not Started); Eave Drip 2" Black (Stock, 3/3); Eave Drip 2" Black 12/12 Pitch (Cut); Eave Drip 2" Black (Wrapped); Eave Drip 2" Black 6/12 Pitch (Bent); Eave Drip 2" Black 2/12 Pitch (Bent, green Notes dot); End Wall Black (Cut, 13/10); End Wall Black 12/12 Pitch (Bent, red Notes dot); End Wall Black 6/12 Pitch (Bent); Gable Starter F Black (Stock, 6/6); J-Channel Black (Cut); Ridge Cap Black 6/12 Pitch (Cut); Snow Guard Black (Cut, 10/4); Side Wall Black (Bent); (orange separator) Thu May 09/2024 Eave Drip 2" Black (Not Started); End Wall Black (Not Started) — Gable Starter/J-Channel appear mid-list here instead of after the Wednesday group as in files 198/199, and no Charcoal Stock (S10125, house-icon) rows are visible in this crop
- Dialog/popup: none — this file has no Stock Manufacturing modal on it
- Notes: corrects a prior mis-transcription that described a "Stock Manufacturing window (Wrapping tab, checkboxes unchecked)" here; that modal is actually shown in Screen (762,334) (file p1_204). Also not truly "identical" to 198 — same rows but reordered, not a straight duplicate.
- Verified: pass3

###### Screen (802,329) — Wrapping tab, full order list (own row set, scrolled differently than 198)
- File: `p1_203_x802_y329.png`
- Illustrates: no adjacent annotation
- Header/tabs: Trim pill; Stock Manufacturing (green, active); Completed orders button; Search; Machine tabs Slinet/Press Brake/V1/V2/Rollformer/Caps/**Wrapping**(active)/Coils
- Table: columns Production Date, Order #, Customer Name, Qty Ordered, Stock, Priority, Remanufacture, Status, ID, Description, Line Item Notes. Rows (top to bottom): 330632 Upright Construction/1/Not Started/TCFK8262/Chimney Kit Black; 330602 DAP Roofing Inc./3(Stock 3)/Stock/TED8262/Eave Drip 2" Black; 330621 Arnold Contracting/5/Cut/TED8262/Eave Drip 2" Black 12/12 Pitch; 330618 Ontario Metal Products Ltd./6/Wrapped/TED8262/Eave Drip 2" Black; 330632 Upright Construction/10/Bent/TED8262/Eave Drip 2" Black 6/12 Pitch; 330606 Ontario Metal Products Ltd./24/Bent/TED8262/Eave Drip 2" Black 2/12 Pitch (Notes button has green dot); 330614 Ontario Metal Products Ltd./13(Stock 10)/Cut/TEW8262/End Wall Black; 330603 Jireh Tools/16/Bent/TEW8262/End Wall Black 12/12 Pitch (Notes button has red dot); 330632 Upright Construction/2/Bent/TEW8262/End Wall Black 6/12 Pitch; 330632 Upright Construction/6(Stock 6)/Stock/TGS8262/Gable Starter F Black; 330612 H F H Inc/12/Cut/TJC8262/J-Channel Black; 330632 Upright Construction/5/Cut/TED8262/Ridge Cap Black 6/12 Pitch; 330632 Upright Construction/10(Stock 4)/Cut/TED8262/Snow Guard Black; 330632 Upright Construction/5/Bent/TED8262/Side Wall Black; then Thursday, May09/2024 rows: 330624 DAP Roofing Inc./22/Not Started/TED8262/Eave Drip 2" Black; 330623 A.W.C./8/Not Started/TEW8262/End Wall Black
- Dialog/popup: none — this file has no Line Item Note popup on it
- Notes: corrects a prior mis-transcription that described a "Line Item Note popup (unread, red X)" here; that popup is actually shown in Screen (817,334) (file p1_205). Also corrects a prior claim that this table matched Screen (762,283)/198 — that file starts at a different scroll row (Stock S10125 Base Trim Black) and is not the same content.
- Verified: pass3

###### Screen (802,349) — Wrapping tab list (duplicate of 203, not 198)
- File: `p1_206_x802_y349.png`
- Table: identical to Screen (802,329) (file p1_203) — same row set (Chimney Kit Black through the two Thursday Not Started rows)
- Notes: duplicate crop. Corrects a prior mis-transcription that called this identical to Screen (762,283)/198; that file has a different row set (starts at Stock S10125 Base Trim Black).
- Verified: pass3

###### Screen (847,324) — Trim / Wrapping — order detail modal, base state
- File: `p1_238_x847_y324.png`
- Same as Screen (808,517) except: Trim Location field in footer is empty (no "405"); same 7 rows/statuses. All four footer buttons (Select Location, Create & Print, See Packages, Order Complete) are disabled/greyed here — Select Location is NOT enabled in this state, unlike Screen (808,517) where it is green/enabled.
- Verified: pass3

###### Screen (847,345) — Trim / Wrapping — order detail modal, one row Wrapping entered
- File: `p1_240_x847_y345.png`
- Same as Screen (808,517) except: row "TEW8262 End Wall Black 6/12 Pitch" now has Auto Fill replaced by a red "Delete" button and Wrapping column shows "2"; Package Weight box shows "10.41 lbs." and Select Location button is enabled (green).
- Verified: pass3

###### Screen (847,365) — Trim / Wrapping — numeric keypad for Wrapping column
- File: `p1_244_x847_y365.png`
- Illustrates: (892,344)-(896,345) "Input the amount you are going to wrap."
- Table: base order modal (10.41 lbs state) with TSW8262 row's Wrapping cell selected (blue outline), overlaid by a keypad.
- Dialog/popup: Keypad widget: text field "___ pcs." + green "Enter" button; number pad 1–9, 0, back-arrow (⌫), red "X" close.
- Notes: Confirms manual numeric entry path for the Wrapping column (as opposed to Auto Fill).
- Verified: pass3

###### Screen (885,325) — Trim / Wrapping — order detail modal (duplicate)
- File: `p1_239_x885_y325.png`
- Same as Screen (847,324) — identical duplicate.
- Verified: pass3

###### Screen (885,346) — Trim / Wrapping — order detail modal, TED8262 wrapping entered
- File: `p1_241_x885_y346.png`
- Same as base order modal (808,517) except: TED8262 row (Bent) now shows Wrapping="5" and its Auto Fill button has been replaced by a red "Delete" button (Left To Wrap still 10); all other rows unchanged from base. Package Weight box shows "15.62 lbs." Select Location enabled (green), Create & Print disabled, See Packages disabled (not enabled).
- Verified: pass3

###### Screen (762,325) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_202_x762_y325.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop.
- Verified: pass3

###### Screen (762,351) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_207_x762_y351.png`
- Table: identical to Screen (762,301) — rows Gable Starter F Black/J-Channel Black/Snow Guard Charcoal(Stock)/Side Wall Charcoal(Cut)/two Thursday Not Started rows (DAP Eave Drip, A.W.C. End Wall)
- Notes: duplicate crop, confirmed pixel-identical to (762,301).
- Verified: pass3

###### Screen (762,358) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_209_x762_y358.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop, confirmed pixel-identical.
- Verified: pass3

###### Screen (762,376) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_212_x762_y376.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop, confirmed pixel-identical.
- Verified: pass3

###### Screen (762,401) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_214_x762_y401.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop, confirmed pixel-identical.
- Verified: pass3

###### Screen (762,427) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_217_x762_y427.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop, confirmed pixel-identical.
- Verified: pass3

###### Screen (762,452) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_223_x762_y452.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop, confirmed pixel-identical.
- Verified: pass3

###### Screen (762,478) — Wrapping tab table continuation (duplicate of 199)
- File: `p1_226_x762_y478.png`
- Table: identical to Screen (762,301)
- Notes: duplicate crop, confirmed pixel-identical.
- Verified: pass3


##### Wrapping multiple line items in the same package (893,431)

Enter the amount you want to wrap from multiple item lines and print your label. (880,453)

###### Screens (7)

###### Screen (762,334) — Stock Manufacturing modal (Wrapping tab, checkboxes unchecked)
- File: `p1_204_x762_y334.png`
- Illustrates: (1009,302)-(1016,303) "Clicking the Stock Manufacturing button opens this window."
- Header/tabs: Trim pill; Completed orders button; Search; Machine tabs Slinet/Press Brake/V1/V2/Rollformer/Caps/**Wrapping**(active)/Coils
- Controls: red "X" close button
- Table: columns Qty Ordered, Left To Wrap, Wrapped, Qty. Manufactured, Status, ID, Description, Length. Rows: checkbox(unchecked)/100/100/–/–/blue Cut/TEW8262/End Wall Black/10'0" (120"); checkbox(unchecked)/150/150/–/–/red Bent/TDE8262/Drip Edge Black/10'0" (120"); checkbox(unchecked)/150/150/–/–/red Bent/TBT8262/Base Trim Black/10'0" (120"); checkbox(unchecked)/80/80/–/–/blue Cut/TEW8306/End Wall Charcoal/10'0" (120"); checkbox(unchecked)/120/120/–/–/blue Cut/TSW8306/Side Wall Charcoal/10'0" (120"); checkbox(unchecked)/120/120/–/–/grey Not Started/TSG8306/Snow Guard Charcoal/10'0" (120")
- Indicators: large "Stock" heading under the table; all checkboxes unchecked; greyed "Create Manufacturing Batch" button (disabled)
- Dialog/popup: this whole panel is a modal window titled implicitly "Stock" (large centered text)
- Notes: underlying background table (Wednesday Wrapping order rows) visible behind/around the modal. Corrects a prior mis-transcription that logged this file as a plain duplicate of Screen (762,283).
- Verified: pass3

###### Screen (762,410) — Stock Manufacturing modal, one row selected with checkbox and partial wrap (2/148)
- File: `p1_216_x762_y410.png`
- Illustrates: (750,386)-(760,392) "As a Worker wraps the Stock, he would enter what he has wrapped here in the Wrapped column... Example: If a Worker had already wrapped 50 pcs. and enter that, then later he wraps 10 more pcs... type +10..."
- Header/tabs: Trim pill; Completed orders button; Search; Wrapping active
- Table: columns Qty Ordered, Left To Wrap, Wrapped, Qty. Manufactured, Status, ID, Description, Length. Rows: checkbox(unchecked)/100/100/–/–/blue Cut/TEW8262/End Wall Black/10'0"(120"); checkbox(checked, green)/150/2/148/–/red Bent/TDE8262/Drip Edge Black/10'0"(120"); checkbox(unchecked)/150/150/–/–/red Bent/TBT8262/Base Trim Black/10'0"(120"); checkbox(unchecked)/80/80/–/–/blue Cut/TEW8306/End Wall Charcoal/10'0"(120"); checkbox(unchecked)/120/120/–/–/blue Cut/TSW8306/Side Wall Charcoal/10'0"(120"); checkbox(unchecked)/120/120/–/–/grey Not Started/TSG8306/Snow Guard Charcoal/10'0"(120")
- Controls: greyed "Create Manufacturing Batch" button (disabled — no rows confirmed complete yet)
- Indicators: large "Stock" heading; row 2 (Drip Edge) has 148 Wrapped, only 2 Left To Wrap, checkbox checked green
- Dialog/popup: "Stock" modal window
- Notes: shows partial-wrap-in-progress state before Create Manufacturing Batch is available.
- Verified: pass3

###### Screen (762,434) — Stock Manufacturing modal, two rows confirmed, batch button enabled
- File: `p1_220_x762_y434.png`
- Illustrates: state following (762,410)/(762,461) — checked rows before final creation
- Table: same Stock Manufacturing modal table; rows: unchecked/100/100/–/–/blue Cut/TEW8262/End Wall Black; checked(green)/150/2/148/–/red Bent/TDE8262/Drip Edge Black; checked(green)/150/0/150/–/red Bent/TBT8262/Base Trim Black; remaining rows unchecked (End Wall Charcoal, Side Wall Charcoal, Snow Guard Charcoal, all Cut/Not Started)
- Controls: "Create Manufacturing Batch" button now green/enabled (two rows checked)
- Dialog/popup: "Stock" modal window, no confirmation dialog on top
- Notes: corrects a prior mis-transcription that logged this file as a plain Wrapping-table duplicate; it is a Stock Manufacturing modal state with the batch button freshly enabled.
- Verified: pass3

###### Screen (762,461) — Stock Manufacturing modal, confirm manufacturing batch popup
- File: `p1_224_x762_y461.png`
- Illustrates: (763,485)-(773,488) "Clicking Yes, Create Manufacturing Batch would create the Manufacturing Batch, make the Left To Wrap and Wrapped columns blank, enter the amount(s) manufactured into the Qty Manufactured column, the check box would be replaced with a Manufactured icon and the Status would updated to Wrapped."
- Table: same Stock modal table as (762,410)/(762,434): row 1 unchecked/100/100 Cut; row 2 checked/150/2/148 Bent (Drip Edge Black); row 3 checked/150/0/150 Bent (Base Trim Black); remaining rows unchecked (End Wall Charcoal, Side Wall Charcoal, Snow Guard Charcoal)
- Dialog/popup: "This will create a manufacturinf [sic] batch, are you sure that the amount(s) in the Wrapped column is (are) correct?" — red "No" and green "Yes, Create Manufacturing Batch" buttons
- Controls: "Create Manufacturing Batch" button visible below (green, enabled)
- Notes: typo "manufacturinf" in the popup text (literal transcription).
- Verified: pass3

###### Screen (762,490) — Stock Manufacturing modal, batch created (two rows now Wrapped/manufactured icon)
- File: `p1_227_x762_y490.png`
- Illustrates: "Clicking Yes, Create Manufacturing Batch would create the Manufacturing Batch, make the Left To Wrap and Wrapped columns blank, enter the amount(s) manufactured into the Qty Manufactured column, the check box would be replaced with a Manufactured icon and the Status would updated to Wrapped."
- Table: same Stock modal; rows: unchecked/100/100/–/–/blue Cut/TEW8262/End Wall Black; "manufactured" icon (small stack/box glyph, no checkbox)/150/–/148/green Wrapped/TDE8262/Drip Edge Black; "manufactured" icon/150/–/150/green Wrapped/TBT8262/Base Trim Black; unchecked/80/80/–/–/blue Cut/TEW8306/End Wall Charcoal; unchecked/120/120/–/–/blue Cut/TSW8306/Side Wall Charcoal; unchecked/120/120/–/–/grey Not Started/TSG8306/Snow Guard Charcoal
- Indicators: green "Wrapped" status and manufactured icon replace checkbox for the two completed rows; Left To Wrap/Wrapped columns now blank for those rows, Qty Manufactured populated (148, 150)
- Dialog/popup: none (popup dismissed)
- Notes: greyed "Create Manufacturing Batch" button remains at bottom (disabled, since no further rows checked).
- Verified: pass3

###### Screen (802,369) — Stock Manufacturing modal, Wrapped cell selected (empty, blue border)
- File: `p1_210_x802_y369.png`
- Illustrates: same modal as (762,334)
- Table: same Stock Manufacturing modal table as Screen (762,334); row 2 (Drip Edge Black) has its blank Wrapped cell selected (blue-bordered), checkboxes otherwise unchecked
- Dialog/popup: "Stock" modal, red "X" close button, greyed "Create Manufacturing Batch" button
- Notes: corrects a prior mis-transcription that described a keypad or Line Item Notes popup here; no keypad or notes panel is present — this is the same Stock modal as (762,334)/(802,308)/(762,308-region) with one cell selected.
- Verified: pass3

###### Screen (885,435) — Trim / Wrapping — order modal, package weight 36.46 lbs
- File: `p1_254_x885_y435.png`
- Same as Screen (885,412) except: TEW8262 now Delete button/Wrapping="2" (Bent, not yet wrapped) and TSW8262 now Delete button/Wrapping="5" (Bent); TED8262 unchanged (Auto Fill, Left To Wrap=5, Wrapping blank). Package Weight = "36.46 lbs."; Create & Print and See Packages both enabled (green); Order Complete remains disabled.
- Verified: pass3


##### Select Location (876,366) — "Clicking the Auto Fill" flow leading into location selection

- When you're working on a new order (nothing has been Wrapped for this order yet), then once there is an amount in the Wrapping column, then the Select Location button becomes available. (878,358)
- Clicking this button opens the list of locations. (890,365)
- "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into. Example: If a Worker in the Trim department (category) goes to select a location, the location window needs to default to Trim locations. That being said the Worker should still be able to choose a different department (category) to select a location there too." (876,366)
- When selecting a location, you need to be able to just click on an available location. (912,369)
- Click on the location you are wanting to select. (899,386)
- When you open the location window on an order that already has a location, it needs to be highlighted. (950,382)
- Once a location has been selected, then the Create & Print button becomes available. (878,401)
- Clicking the Create & Print button will print the label, reset the Wrapping column and update the Left to Wrap column. (890,409)

###### Screens (3)

###### Screen (717,130) — Location selection popup (multi-warehouse grid)
- File: `p1_152_x717_y130.png`
- Illustrates: "This is how locations would show up in production when Workers are selecting locations." (722,125)-(726,128)
- Dialog/popup: red X close button top-right; warehouse tabs Warehouse #1(active)/Warehouse #2/Warehouse #3; department tabs Trim(active)/Rollforming/Accessories; location-type column headers "1 of 1"/Wooden/Small/Medium/Large/Long, each with a list of numbered location buttons: 1 of 1: 101-106; Wooden: 201-212; Small: 301-318; Medium: 401-410; Large: 501-510; Long: 601-616
- Notes: all location buttons appear white/available (no greyed-out or highlighted ones shown)
- Verified: pass3

###### Screen (819,410) — Order detail / package window (Select Location state, no packages yet)
- File: `p1_215_x819_y410.png`
- Illustrates: (890,365)-(895,366) "Clicking this button opens the list of locations."; (878,401)-(883,403) "Once a location has been selected, then the Create & Print button becomes available."
- Header/tabs: Trim pill; Completed orders button; Search; Wrapping tab active
- Table: columns Qty Ordered, Stock, Left To Wrap, Wrapping, Status, Remanufacture, ID, Description, Length, Line Item Notes. Rows (order 330632, Upright Construction): "Auto Fill"/6/6/0/–/green Wrapped/–/TGS8262/Gable Starter F Black/10'0"(120")/Notes; "Delete"(red)/10/4/10/10/red Bent/–/TSG8262/Snow Guard Black/10'0"(120")/Notes; "Auto Fill"/5/–/0/–/green Wrapped/–/TRC8262/Ridge Cap Black 6/12 Pitch/10'0"(120")/Notes; "Auto Fill"/10/–/0/–/green Wrapped/–/TED8262/Eave Drip Black 6/12 Pitch/10'0"(120")/Notes; "Auto Fill"/2/–/0/–/green Wrapped/–/TEW8262/End Wall Black 6/12 Pitch/10'0"(120")/Notes; "Auto Fill"/5/–/0/–/green Wrapped/–/TSW8262/Side Wall Black/10'0"(120")/Notes; "Auto Fill"/1/–/0/–/green Wrapped/–/TCFK8262/Chimney Kit Black/10'0"(120")/Notes
- Controls: order header fields — Customer Name: Upright Construction, Order #: 330632, PO#: Shop Addition, Salesman: Joel Thiessen, Ship Date: Thursday, May 09/2024, Ship Via: Delivery, Priority: (blank), Trim Location: red badge "405"; buttons "Select Location" (green), "Create & Print" (green), weight box "41.67 lbs.", "See Packages" (green), "Order Complete" (greyed/disabled)
- Indicators: red "405" location badge; row with active red "Delete" button = Snow Guard Black in progress (Bent, not yet wrapped)
- Dialog/popup: this whole panel is the order detail modal
- Notes: one location (405) assigned; Order Complete disabled because Snow Guard Black line still Left To Wrap = 10. Corrects a prior mis-transcription that logged this file as a plain Wrapping-table duplicate.
- Verified: pass3

###### Screen (885,367) — Trim / Wrapping — Select Location window (Warehouse/location grid)
- File: `p1_245_x885_y367.png`
- Illustrates: (876,366)-(883,373) "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into..."; (899,386)-(903,388) "Click on the location you are wanting to select."
- Header/tabs: Location picker modal over order modal over main Wrapping table. Warehouse tabs: "Warehouse #1" (active), Warehouse #2, Warehouse #3. Department tabs: Trim (active), Rollforming, Accessories.
- Controls: Location-type column headers: "1 of 1", Wooden, Small, Medium, Large, Long — each a grey pill/button. Location number buttons 101–616 grouped by column; greyed-out ones (e.g. 102,104,105,204,304,306...) are unavailable, bold black ones are available. "405" is outlined green (currently highlighted/selected).
- Table: n/a (button grid, not a data table).
- Indicators: Green outline on "405" (the location already assigned to this order, per annotation "When you open the location window on an order that already has a location, it needs to be highlighted").
- Dialog/popup: none additional.
- Notes: Grey/disabled numbers = already-occupied locations; black/available numbers = free locations.
- Verified: pass3


##### This will show the combined weight (912,358)

"This will show the combined weight of the trims you are planning to wrap. We need to be able to set a Max Weight per package (ex. 45 lbs)." (912,358)

###### Screens (2)

###### Screen (847,384) — Trim / Wrapping — order modal, TEW8262 + TSW8262 wrapping=2
- File: `p1_247_x847_y384.png`
- Table: base order modal rows except TEW8262 (Delete button, Wrapping="2") and TSW8262 (Auto Fill still, Wrapping="2"); TED8262 unchanged (Auto Fill, Left To Wrap=10, Wrapping blank).
- Controls: Select Location enabled (green); Create & Print disabled; See Packages disabled; Order Complete disabled.
- Indicators: Package Weight box shows normal (not red) "20.83 lbs."; Trim Location field is empty (no "405").
- Notes: Corrects prior claim of red/over-limit weight and a "405" location — neither is present in this image.
- Verified: pass3

###### Screen (923,346) — Trim / Wrapping — Over Weight popup (duplicate)
- File: `p1_243_x923_y346.png`
- Same as Screen (951,346) — identical duplicate.
- Verified: pass3


##### Over Weight Packages (912,365)

- If the package you are trying to create is heavier than the Max Weight, then this box needs to be highlighted in red. (940,365)
- "If you try to "Create & Print" when the potential package is over the weight limit, you will get a pop up asking if you want to continue with the over weight package. If you agree, it will override the weight limit and create the package and print the label." (951,365)

###### Screens (1)

###### Screen (951,346) — Trim / Wrapping — Over Weight confirmation popup
- File: `p1_242_x951_y346.png`
- Illustrates: (912,365)-(916,367) "Over Weight Packages"; (951,365)-(959,369) "If you try to 'Create & Print' when the potential package is over the weight limit, you will get a pop up asking if you want to continue with the over weight package..."
- Header/tabs: same as prior order modal screens.
- Table: same rows as (885,346) but TED8262 Wrapping="10", TSW8262 Wrapping="5" (Delete buttons on both); Package Weight box shows "57.29 lbs." highlighted red.
- Controls: Select Location (green enabled), Create & Print (green enabled), See Packages (disabled), Order Complete (disabled).
- Dialog/popup: Title/body: "The package you are trying to create is over the weight limit, are you sure you want to continue?" Buttons: "No" (red), "Yes, Create & Print" (green).
- Notes: Package Weight field itself shown in red highlight to indicate over-limit.
- Verified: pass3


##### Over Weight on a Location (879,407)

- "If you are trying to create another package that combined with the packages already on the order will be over the Max Weight for the location, then the location name should highlight in red indicating that you need to select another location." (846,414)
- "If you try to "Create & Print" when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit. If you disagree, then you will need to chose another Location to be able to Create & Print." (861,440)
- "If you try to "Create & Print" when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit. If you agree, it will override the weight limit and create the package and print the label." (796,440)
- If you override the weight limit on a Location, then that Location name needs to be highlighted in red. (797,464)

###### Screens (2)

###### Screen (803,432) — Order detail, Over Weight on a Location confirmation popup
- File: `p1_218_x803_y432.png`
- Illustrates: (861,440)-(868,446) "If you try to 'Create & Print' when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit. If you disagree, then you will need to chose another Location..."
- Header/tabs: Trim pill; Completed orders button; Search; Wrapping active
- Table: same order-detail rows as Screen (819,410) — order 330632 Upright Construction (Auto Fill/Delete rows), all Wrapped status except Snow Guard Black (Bent, red Delete button)
- Controls: order header same as (819,410): Trim Location badge red "405"; buttons Select Location, Create & Print, weight "41.67 lbs.", See Packages, Order Complete (disabled)
- Dialog/popup: "With this package the location will be over the weight limit, are you sure you want to continue?" — red "No" and green "Yes, Create & Print" buttons
- Notes: matches annotation on overriding a location's weight limit.
- Verified: pass3

###### Screen (834,432) — Order detail, same Over Weight popup (duplicate of 218)
- File: `p1_219_x834_y432.png`
- Illustrates: same as (803,432)
- Dialog/popup: identical "With this package the location will be over the weight limit..." popup, No/Yes Create & Print buttons
- Table: same order detail table as (819,410)/(803,432)
- Notes: duplicate of Screen (803,432).
- Verified: pass3


##### Multiple Locations (912,385) / Adding a second location (835,429)

- Clicking on a second Location needs to add that Location to the order as well, now this order has 2 Locations. (937,395)
- Once you select a second Location, then the first Location needs to be highlighted in orange indicating to not put any more packages on that location. Now you can Create & Print. (861,462)

###### Screens (6)

###### Screen (803,452) — Order detail, no active over-weight popup (post-confirmation, single location 405)
- File: `p1_221_x803_y452.png`
- Illustrates: (846,414)-(854,418) "If you are trying to create another package that combined with the packages already on the order will be over the Max Weight for the location, then the location name should highlight in red indicating that you need to select another location."
- Table: same order 330632 rows as (819,410), all now "Wrapped" (green) including Snow Guard Black (Auto Fill button, Wrapped)
- Controls: Trim Location badge red "405"; "Create & Print" greyed/disabled; "Package Weight" box empty/greyed; "Select Location", "See Packages", "Order Complete" (green, enabled) buttons
- Dialog/popup: none
- Notes: Order Complete now enabled since all lines Wrapped; location "405" still shown red (over weight flag persists).
- Verified: pass3

###### Screen (834,452) — Order detail, second location added (405 amber, 410 added)
- File: `p1_222_x834_y452.png`
- Illustrates: (861,462)-(865,467) "Once you select a second Location, then the first Location needs to be highlighted in orange indicating to not put any more packages on that location. Now you can Create & Print."
- Table: same order rows as (803,452), Snow Guard Black row shows red "Delete" button (Bent status) — mixed with other Wrapped rows
- Controls: Trim Location badges: "405" (amber/orange highlighted) and "410" (new, unhighlighted); "Create & Print" green enabled; "Select Location", "See Packages" green; "Order Complete" greyed
- Indicators: amber highlight on location 405 = full/do-not-use; 410 = newly added active location
- Notes: confirms two-location behavior from the annotation.
- Verified: pass3

###### Screen (885,412) — Trim / Wrapping — order modal, after first package created
- File: `p1_251_x885_y412.png`
- Table: base order modal rows, all still Auto Fill/Bent except TED8262's Left To Wrap reduced to "5" (from 10), Wrapping column blank; TEW8262 and TSW8262 unchanged (Bent, Auto Fill).
- Controls: Trim Location "405". Select Location enabled (green), Create & Print disabled, Package Weight box empty (placeholder text, no value), See Packages enabled (green).
- Notes: Reflects state after package "01-330632-01" (5×TED8262) was created, reducing TED8262's Left To Wrap.
- Verified: pass3

###### Screen (924,397) — Trim / Wrapping — location grid, 410 selected
- File: `p1_250_x924_y397.png`
- Same as Screen (885,367) except: both "405" and "410" are now outlined green (405 remains highlighted, 410 gains the same green outline) — reflects choosing a second location in addition to the first.
- Verified: pass3

###### Screen (951,396) — Trim / Wrapping — footer strip showing two locations
- File: `p1_249_x951_y396.png`
- Illustrates: (937,395)-(945,396) "Clicking on a second Location needs to add that Location to the order as well, now this order has 2 Locations."
- Header/tabs: n/a (footer-only crop).
- Controls: Trim Location field now shows two boxes: "405" and "410". Package Weight button (disabled, grey/placeholder text). Left edge shows a partially-cropped green (enabled) button (likely Select Location); See Packages disabled (pale green); Order Complete disabled (pale green).
- Table: n/a.
- Notes: Confirms UI supports multiple location chips on one order.
- Verified: pass3

###### Screen (924,377) — Trim / Wrapping — Select Location grid (duplicate)
- File: `p1_246_x924_y377.png`
- Same as Screen (885,367) — identical duplicate.
- Verified: pass3


##### Removing Locations (932,416)

- "To remove a Location from an order you would click on the Location you want to remove, this would give you a pop-up ask to confirm this action." (937,437)
- "As locations are assigned to orders they grey out and become unavailable." (982,392)
- "For locations to become available again (reset) they need to be removed from an order manually." (972,396) or "When the last trim package has been scanned onto the truck by shipping, then after 15 mins. the location becomes available again (reset)." (972,399) — See Shipping Department (988,414)
- "If a worker wants to remove all the Locations from an order, then the worker needs to be forced to select a new Location. An order with existing packages HAS to have a Location." (950,475)

###### Screens (3)

###### Screen (924,439) — Trim / Wrapping — Remove Location confirmation
- File: `p1_256_x924_y439.png`
- Illustrates: (937,437)-(947,439) "To remove a Location from an order you would click on the Location you want to remove, this would give you a pop-up ask to confirm this action."
- Header/tabs: Location grid modal (Warehouse #1/Trim, same grid as before) with only 405 green-outlined (410 is a plain black/available button, not highlighted).
- Dialog/popup: Title/body: "Are you sure you want to remove this location from this order?" Buttons: "No" (red), "Yes" (green).
- Notes: Confirms destructive-location-removal requires confirmation, consistent with spec.
- Verified: pass3

###### Screen (924,478) — Trim / Wrapping — location grid, "must select location" popup
- File: `p1_259_x924_y478.png`
- Illustrates: (950,475)-(954,480) "If a worker wants to remove all the Locations from an order, then the worker needs to be forced to select a new Location. An order with existing packages HAS to have a Location."
- Dialog/popup: Title/body: "An order with existing packages needs to have at least 1 location, please select a location to continue." Button: "Ok" (green).
- Notes: Location grid behind popup shows 405 unhighlighted this time (no location currently selected), forcing the user to pick one.
- Verified: pass3

###### Screen (924,419) — Trim / Wrapping — location grid, both locations selected
- File: `p1_253_x924_y419.png`
- Same as Screen (924,397)/(950,397) — identical duplicate; both "405" and "410" are green-outlined (not just 405).
- Verified: pass3


##### Labels

- "The labels should be identified by a code made up of 3 parts. The 1st part is the department (category) ID, the second part is the order number and then the last part is the number of packages wrapped for the order, which just keeps counting up as you create packages." (876,427)
- "Each department (category) will need to be assigned a unique number code to identify and keep labels separate between departments (categories). Example: Trim - 01, Rollforming - 02, Accessories - 03" (868,427)

##### Reprinting Labels (896,476) / See Packages (911,425)

- Once the first package has been created, then the See Packages button becomes available. (911,425)
- Clicking the See Packages button opens a list of the packages already on the order. (903,475)
- Here you can reprint a label for an existing package. (911,486)

###### Screens (5)

###### Screen (825,476) — Reprint Labels / See Packages window over order detail
- File: `p1_225_x825_y476.png`
- Illustrates: (903,475)-(908,477) "Clicking the See Packages button opens a list of the packages already on the order."; (911,486)-(915,487) "Here you can reprint a label for an existing package."
- Header/tabs: order header behind: Customer Name Upright Construction, Order # 330632, PO Shop Addition, Location 405
- Dialog/popup: "Packages" window — Customer Name: Upright Construction; Order #: 330632; PO: Shop Addition; Location: 405; list — "01 - 330632 - 01" / "5 - TED8262" / red "Delete" / "Reprint"; "01 - 330632 - 02" / "2 - TEW8262 / 5 - TSW8262" / red "Delete" / "Reprint"; five empty grey placeholder rows below
- Controls: some "Auto Fill" buttons in background order table shown crossed-out/disabled (red circle-slash icon) — greyed unavailable state
- Notes: empty grey rows likely placeholders for additional future packages.
- Verified: pass3

###### Screen (876,414) — Package label
- File: `p1_252_x876_y414.png`
- Illustrates: (876,427)-(883,432) "The labels should be identified by a code made up of 3 parts..."
- Header/tabs: n/a (standalone label graphic).
- Table: n/a.
- Dialog/popup: Printed label content: "Customer: Upright Contruction [sic]" / "Sales Order #: 330632" / "PO #: Shop Addition" / line item "5 - TED8262" / "Weight: 15.62 lbs." / barcode / code "01 - 330632 - 01".
- Notes: Typo "Contruction" (missing 's') present verbatim on label. Package code format confirmed: department-order-package sequence.
- Verified: pass3

###### Screen (876,438) — Package label #2
- File: `p1_255_x876_y438.png`
- Illustrates: same as (876,414) region.
- Dialog/popup: Label: "Customer: Upright Contruction" / "Sales Order #: 330632" / "PO #: Shop Addition" / items "2 - TEW8262" and "5 - TSW8262" / "Weight: 36.46 lbs." / barcode / code "01 - 330632 - 02".
- Notes: Demonstrates a package combining two different line items (multi-item package), matching heading "Wrapping multiple line items in the same package."
- Verified: pass3

###### Screen (885,479) — Trim / Wrapping — See Packages window
- File: `p1_260_x885_y479.png`
- Illustrates: (903,475)-(908,477) "Clicking the See Packages button opens a list of the packages already on the order."; (911,486)-(915,487) "Here you can reprint a label for an existing package."
- Header/tabs: Trim pill, Completed orders button, Search. Tabs same, Wrapping active.
- Table: Header fields: Customer Name "Upright Construction", Order#330632, PO "Shop Addition", Location "405". Packages | Qty/Description | Delete/Reprint buttons. Rows: 01-330632-01 / 5-TED8262 (Delete red, Reprint white); 01-330632-02 / 2-TEW8262 / 5-TSW8262 (Delete red, Reprint white).
- Indicators: none unusual.
- Notes: 5 empty grey placeholder rows below the 2 populated ones (list capacity/empty-state rows). Corrects prior omission of the Delete buttons.
- Verified: pass3

###### Screen (924,459) — Trim / Wrapping — location grid duplicate
- File: `p1_258_x924_y459.png`
- Same as Screen (885,367) — identical duplicate (405 highlighted green, grid unchanged).
- Verified: pass3


##### Deleting a Package (874,474)

- If something was packaged wrong, then we need to be able to delete that package and repackage the items that were in it. (852,480)
- Clicking the Delete button would give you this pop up (840,494)
- Clicking Yes will delete the package and put the number of pcs. that were in the package back into the Left To Wrap column. (835,523)
- "Deleting a package will make that package number invalid, if anyone tries to scan the bar code on the deleted label will need to get a messge that this package has been deleted." (835,528)
- "If the line item that was in the deleted package had a Status of Wrapped already, then after deleting, that Status would have to change back to Bent again. If the Qty Ordered column and Stock column are equal, then it would have to change back to Stock." (808,536)

###### Screens (2)

###### Screen (825,497) — Trim / Wrapping — Delete Package confirmation
- File: `p1_228_x825_y497.png`
- Illustrates: (874,474)-(881,475) "Deleting a Package"; (835,523)-(840,526) "Clicking Yes will delete the package and put the number of pcs. that were in the package back into the Left To Wrap column."
- Header/tabs: "Trim" pill top-left; "Completed orders for the past 90 days" button top-right; Search box. Tab bar: Slinet, Press Brake, [Wrapping active — obscured by modal], Coils.
- Controls: Behind the modals — Auto Fill buttons (some green enabled, some disabled/red "no" icon overlay), left panel list of Wrapping rows with Qty Ordered values 6,10,5,10,2,5,1.
- Table: Order/package window: Customer Name "Upright Construction", Order # 330632, PO "Shop Addition", Location "405". Packages table columns: Packages | Qty/Description | (Delete/Reprint buttons). Rows: "01 - 330632 - 01" / "5 - TED8262" (Delete, Reprint); "01 - 330632 - 02" / "2 - TEW8262 / 5 - TSW8262" (Delete, Reprint).
- Indicators: Red X close buttons (top-right of each modal). Red "Delete" buttons, black-outline "Reprint" buttons.
- Dialog/popup: Title/body: "Are you sure you want to delete this package?" Buttons: "No" (red), "Yes, Delete Package" (green).
- Notes: Nested modal stack — order/packages window open behind the delete-confirm popup, itself over the main Wrapping table. Top-left shows "Trim" (white pill) with green "Stock Manufacturing" pill below it (not a plain "Trim" pill alone).
- Verified: pass3

###### Screen (843,517) — Trim / Wrapping — order/packages modal, one package deleted
- File: `p1_263_x843_y517.png`
- Same as Screen (825,497)'s underlying packages window except: no confirm popup shown; package "01 - 330632 - 02" row now reads "Deleted" (italic grey) in place of the Qty/Description, its Delete/Reprint buttons removed while "01 - 330632 - 01" keeps its Delete (red) and Reprint (white) buttons.
- Verified: pass3


##### Over riding the weight limit (818,429) — see Over Weight sections above.

An unlabeled block with "?????????" appears at (814,473) — unclear callout, see Unclear section.

### Overdue Trims To Be Wrapped (911,497)

- Overdue trims to be wrapped need to be highlighted. (937,501)
- "Example: If it is Thursday, May 09/2024 and there are trims from Wednesday, May 08/2024 that are not wrapped yet, then we need those Wednesday trims to be highlighted as overdue." (937,503)

#### Screens (1)

##### Screen (948,500) — Trim / Wrapping — table with red highlighted overdue rows
- File: `p1_261_x948_y500.png`
- Illustrates: (937,501)-(945,502) "Overdue trims to be wrapped need to be highlighted."; (937,503)-(945,506) example about Thursday/Wednesday overdue trims.
- Table: Same Wrapping table columns as Screen (885,283). Three rows highlighted in solid red block: 330602/DAP Roofing Inc./3/3/Stock/TED8262/Eave Drip 2" Black; 330621/Arnold Contracting/5/Cut/TED8262/Eave Drip 2" Black 12/12 Pitch; 330614/Ontario Metal Products Ltd./13/10/Bent/TEW8262/End Wall Black. Below (not highlighted): further Thursday May 09 rows (330624, 330623, 330624, 330627, 330628, 330624, 330628, 330631, 330634, 330635, 330638) all Not Started/Cut status.
- Indicators: Red block highlight spans the 3 overdue rows (all under Wed. May 08/2024, still incomplete as of Thurs.).
- Notes: Confirms overdue highlighting is a solid red row background, not just a badge.
- Verified: pass3


### Completing an Order (895,499)

- Once the Left To Wrap column is ALL zeros, then the Order Complete button becomes available. (879,506)
- Clicking the Complete Order button would give you this pop up (899,521)
- "This would cause the web app to create a manufacturing batch and push it back into EBMS. To create the manufacturing batch it just needs to look at the Qty ordered minus the amount that has been pulled from stock and then manufacture the difference between those 2 numbers. This way it makes no difference who or how many times the number being pulled from stock changes, as long as it's the right number when the order is completed." (911,535)
- Clicking Yes would make this order disappear out of the Wrapping tab and appear in the Completed Orders tab and create a manufaturing batch (903,543)

#### Screens (3)

##### Screen (885,456) — Trim / Wrapping — order modal, all rows Wrapped
- File: `p1_257_x885_y456.png`
- Same as Screen (885,435) except: TEW8262 and TSW8262 rows now show Status "Wrapped" (green), Left To Wrap = 0 for both, Auto Fill buttons for those rows now greyed/disabled (light green "Auto Fill" text, non-clickable); TED8262 row still Bent (red), Auto Fill enabled, Left To Wrap=5, Wrapping column blank.
- Verified: pass3

##### Screen (885,503) — Trim / Wrapping — order modal, all rows Wrapped, ready to complete
- File: `p1_262_x885_y503.png`
- Table: all 7 rows show Status "Wrapped" (green), Left To Wrap = 0, Auto Fill buttons all disabled (light green), no Remanufacture cell selected.
- Controls: Trim Location "405". Select Location enabled, Create & Print disabled, Package Weight box empty placeholder, See Packages enabled (green), Order Complete enabled (bright green).
- Notes: This is the same fully-wrapped, order-complete-ready state as Screen (885,524)/(885,547) precede — not a Remanufacture-entry screen; no cell is selected here. Corrects prior claim of an empty Location field and a selected Remanufacture cell, neither of which is present.
- Verified: pass3

##### Screen (885,524) — Trim / Wrapping — Order Complete confirmation
- File: `p1_264_x885_y524.png`
- Illustrates: (899,521)-(903,523) "Clicking the Complete Order button would give you this pop up"; (903,543)-(911,545) "Clicking Yes would make this order disappear out of the Wrapping tab and appear in the Completed Orders tab and create a manufaturing batch"
- Table: order modal, all 7 rows Wrapped (green), Left To Wrap = 0 throughout, Auto Fill buttons all disabled/light.
- Dialog/popup: Title/body: "Are you sure you are done with this order and that you want to create a manufacturing batch for it?" Buttons: "No" (red), "Yes, Create Manufacturing Batch" (green).
- Notes: Footer buttons: Select Location (enabled), Create & Print (disabled), Package Weight (white box empty), See Packages (enabled), Order Complete (enabled, green) sits below/behind popup.
- Verified: pass3


### Completed Orders tab (895,543)

- "When you open the Completed Orders tab you should be able to view all the completed orders for the past 90 days. The completed orders should be displayed here and appear like this." (912,545)
- Clicking on an order opens it in this window (900,567)
- "Within the Completed Orders tab we need to be able to see a list of the line items ordered and how many were pulled from stock. We also need a list of the packages that were created for this order and what was put into each package." (878,571)
- Within the Completed Orders tab we need to be able to reprint package labels and change/add/remove locations if necessary. (912,576)

#### Screens (3)

##### Screen (762,515) — Trim / Wrapping — Stock manufacturing summary popup
- File: `p1_230_x762_y515.png`
- Illustrates: (754,517)-(760,522) "Once a Manufacturing Batch has been created for ALL of the rows, then the Stock line items would automatically disappear out of the Wrapping window and this Stock Order would move to the Completed Orders tab."
- Header/tabs: "Trim" pill, "Completed orders for the past 90 days" button, Search box. Tabs: Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping (active), Coils.
- Controls: Behind modal — Auto Fill buttons per row (mixed enabled/disabled).
- Table: Modal table columns: Qty Ordered | Stock | Left To Wrap | Wrapped | Qty. Manufactured | Status | ID | Description | Length. Rows: 100/—/—/100/Wrapped/TEW8262/End Wall Black/10'0"(120"); 150/—/—/148/Wrapped/TDE8262/Drip Edge Black/10'0"(120"); 150/—/—/150/Wrapped/TBT8262/Base Trim Black/10'0"(120"); 80/—/—/80/Wrapped/TEW8306/End Wall Charcoal/10'0"(120"); 120/—/—/120/Wrapped/TSW8306/Side Wall Charcoal/10'0"(120"); 120/—/—/121/Wrapped/TSG8306/Snow Guard Charcoal/10'0"(120"). Large word "Stock" centered below table.
- Indicators: All Status chips green "Wrapped".
- Dialog/popup: Title "Stock" (large centered text, not a dialog box per se — appears to be a section/category label within the modal). "Create Manufacturing Batch" button greyed out (disabled) at bottom.
- Notes: This is the Stock-order variant of the order-detail modal (compare Screen 885,479 which is the manufactured/customer-order variant).
- Verified: pass3

##### Screen (885,547) — Trim / Completed Orders tab
- File: `p1_265_x885_y547.png`
- Illustrates: (912,545)-(917,550) "When you open the Completed Orders tab you should be able to view all the completed orders for the past 90 days..."
- Header/tabs: "Trim" pill; "Completed orders for the past 90 days" button now appears active/outlined (selected state) top-right. Tabs: Slinet, Press Brake, V1, V2, Rollformer, Caps, Wrapping, Coils (all inactive — no tab highlighted, consistent with a separate top-right toggle view).
- Table: Columns: Ship Date | Production Date | Completed Date & Time | Order # | Customer Name | Trim Location. 18 rows visible, e.g.: Thurs May09/Wed May08/Wed May08 4:16am/330615/DAP Roofing Inc./231; .../330605/H F H Inc/258,310; .../330609/Arnold Contracting/108; .../330632/Upright Construction/405 (row highlighted/selected, blue outline); .../330608/Jireh Tools/218; .../330616/Arnold Contracting/118; .../330631/Jireh Tools/219; .../330618/A.W.C./345; then Wed May08 group: 330609/Arnold Contracting/208; 330615/DAP Roofing Inc./312; 330616/Arnold Contracting/207; 330618/A.W.C./608,217; 330631/Jireh Tools/302,303; 330619/A.W.C./314; 330636/Jireh Tools/218,220; then Mon May06/Fri May03 group: 330632/Jireh Tools/217; 330638/H F H Inc/306,307; ending 330639/Upright Construction/110.
- Indicators: Selected row (330632) outlined in blue.
- Notes: Multiple Trim Location values per row possible (e.g. "608, 217" / "306, 307") confirming multi-location orders appear here too.
- Verified: pass3

##### Screen (885,570) — Trim / Completed order detail popup
- File: `p1_266_x885_y570.png`
- Illustrates: (900,567)-(904,569) "Clicking on an order opens it in this window"; (878,571)-(884,576) "Within the Completed Orders tab we need to be able to see a list of the line items ordered and how many were pulled from stock. We also need a list of the packages that were created..."
- Table: Left table columns: Qty Ordered | Stock | ID | Description | Length | Line Item Notes. Rows: 6/6/TGS8262/Gable Starter F Black/10'0"(120"); 10/4/TSG8262/Snow Guard Black; 5/—/TRC8262/Ridge Cap Black 6/12 Pitch; 10/—/TED8262/Eave Drip Black 6/12 Pitch; 2/—/TEW8262/End Wall Black 6/12 Pitch; 5/—/TSW8262/Side Wall Black; 1/—/TCFK8262/Chimney Kit Black. Right table columns: Packages | Qty/Description | Reprint. Rows: 01-330632-01/5-TED8262(Reprint); 02/2-TEW8262/5-TSW8262(Reprint); 03/5-TED8262; 04/6-TGS8262; 05/10-TSG8262; 06/1-TCFK8262; 07/5-TRC8262 (all with Reprint buttons).
- Notes: Footer: Customer Name Upright Construction, Order#330632, PO Shop Addition, Salesman Joel Thiessen, Ship Date Thursday May09/2024, Ship Via Delivery, Trim Location 405. Single "Select Location" button (green) at bottom — per (912,576) allows changing/adding locations even after completion.
- Verified: pass3


### Remanufacture in the Wrapping tab (867,592) / Pulling Stock in the Wrapping tab (922,592)

- If a worker damages a piece, he needs to be able to request for is to be remanufactured in the Remanufature column. (850,600)
- If a worker damages a piece and decides to use some from stock then he needs to be able to enter that into the Stock column. (905,600)
- Clicking in the Remanufacture column opens a keypad. (871,615)
- Clicking in the Stock column open a keypad. (918,616)
- Should only be able to enter a number between 1 and the Qty Ordered. (851,624)
- Even if there is already a number in the Stock column, we still need to be able to change the number to anything from zero up to the Qty Ordered. (904,624)
- "Changing the amount being pulled from stock shouldn't make any different in regards to manufacturing batches. The manufacturing batch should only be created and push back to EBMS once all the line items have been wrapped and the Worker clicks the Order Complete button. To create the manufacturing batch it just needs to look at the Qty ordered minus the amount that has been pulled from stock and then manufacture the difference between those 2 numbers. This way it makes no difference who or how many times the number being pulled from stock changes, as long as it's the right number when the order is completed." (901,633)
- "This needs to create a new cutlist that inherits the same Production Date, Gauge/Colour, Priority and Machine as was assigned to this line item. This is then sent to the Slinet. It needs to also create a new bendlist that inherits the same Production Date, Gauge/Colour, Priority and Machine as was assigned to this line item. This is then sent to the appropiate Machine." (848,634)
- Enter the amount that needs to be Remanufactured (865,636)
- Enter the amount that you are pulling from stock (915,636)
- "After entering the amount you need to have remanufactured, then that line item should be highlighted in orange and show the amount to remanufactured. This needs to show up within the order window and also within the main Wrapping window on that line item." (883,656)
- "This should stay highlighted in orange until the Machine has marked it as Bent (Complete). After it is mark as Bent, then it should change to being highlighted in green." (848,677)

### Sales in EBMS (1002,124)

- "Each Department (category) needs be completely separate from the others. For example, everything that's done in the Trim department (category) should not affect anything in the Rollforming department (category). Each department (category) should be able to Release To Production without the other departments (categories) having to schedule their items. For example: A Trim Manager should be able to release the scheduled trims to production without the Rollforming Manager having to schedule their items first." (1059,206)
- Salesmen need to push orders into the app (1051,207)
- All Unscheduled (1050,210)
- Admin (1045,211): Admin should be able to do everything in every Department (category). (1037,210)

### Rollforming (1114,231) → See Page 2 (1118,282)

- Stock Manufacturing (1021,283): The Stock Manufacturing tab needs to be on ALL of these tabs. (1004,289)
- Clicking the Stock Manufacturing button opens this window. (1009,302)
- Enter the new stock items (1013,320)
- When the Worker clicks the Create Manufacturing Batch button, then a manufacturing batch needs to be created in EBMS. (1025,338)
- Coil tab in the Worker window (1057,283): "The Coils tab in the Worker windows would be filtered by the coil filter in the Manager window. It needs to operate with the same authorities and in the same way as the Managers Coil tab." (1057,303)

### Shipping (1272,231) → See Page 3 (1265,282)

### Unclear / open questions

- Block at (814,473), text "?????????" — placeholder/unresolved callout in the Wrapping/packaging area; no accompanying explanation on the page.
- Block at (613,109), text "?" inside a purple square in the Warehouses/Locations flow — unlabeled, target of an arrow but no explanatory text found near it.
- The "Rescheduing or Unscheduing an Order" heading and "Reviewing Order / Reviewing a Stock Order / Priorities" numbered items (1,2,3 at (310,392),(310,395),(312,396)) appear to be flow-sequence markers on the diagram rather than text content — included as-is; exact numbered order/purpose of "1/2/3" not explained in the text blocks.


### Other screens on this page (6)

Screens whose annotated section did not match a heading above. Ordered by board position (x, then y).

#### Screen (434,354) — Slinet base cutlist list (unchanged)
- File: `p1_093_x434_y354.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


#### Screen (471,417) — Slinet base cutlist list (unchanged)
- File: `p1_099_x471_y417.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


#### Screen (471,443) — Slinet base cutlist list (unchanged)
- File: `p1_103_x471_y443.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


#### Screen (471,469) — Slinet base cutlist list (unchanged)
- File: `p1_106_x471_y469.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


#### Screen (471,477) — Slinet cutlist expanded, all "Yes"/Done enabled (duplicate)
- File: `p1_107_x471_y477.png`
- Same as Screen (471,350)/p1_092 — expanded Bright White cutlist, all rows Complete=Yes (crossed out), Done button enabled/solid green.
- Verified: pass3


#### Screen (471,493) — Slinet base cutlist list (unchanged)
- File: `p1_108_x471_y493.png`
- Same base list as Screen (300,718)/p1_084 (bottom portion), no differences.
- Verified: pass3


---

## Page 2 — Rollforming

_Legend and Overall Notes are repeated at the top of this page; see [Board-wide notes](#board-wide-notes-legend-priorities-warehouseslocations-machines)._

### Department flow map
The board arranges three top-level department sections left to right: **Trim** → "See Page 1" (353, 296); **Rollforming** (this page, 521, 250)-(600, 269); **Shipping** → "See Page 3" (1339, 296). All feed from **Sales in EBMS** (742, 155)-(833, 222).

- "Salesmen need to push orders into the app" (786, 228)
- "Admin should be able to do everything in every Department (category)." (774, 232), label "Admin" (781, 232)
- "Each Department (category) needs be completely separate from the others. For example, everything that's done in the Trim department (category) should not affect anything in the Rollforming department (category). Each department (category) should be able to Release To Production without the other departments (categories) having to schedule their items. For example: A Trim Manager should be able to release the scheduled trims to production without the Rollforming Manager having to schedule their items first." (793, 228)

### Rollforming Manager

- "Rollforming Managers should be able to see and edit everything from here down. Including what the Worker can see and do." (508, 258), label "Rollforming Manager" (514, 259)

#### Screens (43)

##### Screen (157,97) — Priorities settings table
- File: `p2_000_x157_y97.png`
- Illustrates: "Priorities need to be department (category) specific..." (143,97); "We need to be able to create a hierarchy on how Priorities will be sorted..." (149,102)
- Header/tabs: Top tab bar: Users, Machines, Warehouses, Location Types, Loactions [sic], Trucks, **Priorities** (active). Below it a department tab strip: **Trim** (active), Standing Seam, Rollforming, Board & Batten, Accessories, Shipping.
- Controls: Search box "Search..." (empty). No visible add/create button in this crop.
- Table: Columns: Colour | Names | Hierarchy | Actions. Rows (12 shown): red swatch "Now" (1); orange swatch "ASAP" (2); yellow swatch "By 8:00" (3); yellow "By 9:00" (4); yellow "By 10:00" (5); yellow "By 11:00" (6); yellow "By 12:00" (7); yellow "By 1:00" (8); yellow "By 2:00" (9); yellow "By 3:00" (10); yellow "By 4:00" (11); yellow "By 5:00" (12).
- Indicators: Colour swatch column: red for "Now", orange for "ASAP", yellow for all "By __:00" priorities. "..." Actions menu icon per row.
- Dialog/popup: none.
- Notes: Hierarchy numbers ascending 1–12, top row (Now) has heavier black divider under it separating it from rest.
- Verified: pass3

##### Screen (224,132) — Warehouses tab, populated list
- File: `p2_001_x224_y132.png`
- Illustrates: "First you would have to create a Warehouse" (260,96); "Clicking this button would open this window where you would enter the Name, Address and Description of the Warehouse you want to create." (264,109)
- Header/tabs: Tab bar: Users, Machines, **Warehouses** (active), Location Types, Loactions, Trucks, Priorities. Search box top right.
- Controls: Green "+ Create Warehouse" button, top right, enabled.
- Table: Columns: Name | Address | Description | Default | Action. Rows: "Warehouse #1" / "20 Clearview Dr. Tillsonburg" / "Wise Line's primary warehouse in the production plant" / ✔ (default) / "..."; "Warehouse #2" / "52219 John Wise Line, Aylmer" / "Wise Line's secondary warehouse for large order packs" / (blank) / "..."; "Warehouse #3" / "590 Barth Side Road, Langton" / "Wise Line's overflow warehouse" / (blank) / "...".
- Indicators: Checkmark in Default column only for Warehouse #1.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (252,102) — Warehouses tab, empty state
- File: `p2_002_x252_y102.png`
- Illustrates: same as Screen (224,132) — "First you would have to create a Warehouse" (260,96)
- Header/tabs: Same tab bar as Screen (224,132), Warehouses active.
- Controls: Same "+ Create Warehouse" green button.
- Table: Same headers (Name, Address, Description, Default, Action), no rows — empty state.
- Indicators: none.
- Dialog/popup: none.
- Notes: Represents the "before creating a Warehouse" state.
- Verified: pass3

##### Screen (252,117) — Create Warehouse modal
- File: `p2_005_x252_y117.png`
- Illustrates: "Clicking this button would open this window where you would enter the Name, Address and Description of the Warehouse you want to create." (264,109)
- Header/tabs: Background shows Warehouses tab table (empty). Modal titled "Create Warehouse" with red "X" close button top right.
- Controls: Fields: Name (placeholder "Warehouse Name"), Address (placeholder "123 Main St"), Description (placeholder "Enter Warehouse Description", textarea). Green "Create" button, enabled.
- Table: n/a (modal).
- Indicators: none.
- Dialog/popup: "Create Warehouse" — fields Name, Address, Description; button "Create".
- Notes: all fields empty/placeholder text only.
- Verified: pass3

##### Screen (252,132) — Warehouses tab, single row
- File: `p2_009_x252_y132.png`
- Illustrates: same region as Screen (224,132)
- Header/tabs: Same tab bar, Warehouses active.
- Controls: Green "+ Create Warehouse" button.
- Table: Same columns as Screen (224,132) but only one row: "Warehouse #1" / "20 Clearview Dr. Tillsonburg" / "Wise Line's primary warehouse in the production plant" / ✔ (default) / "...".
- Indicators: Checkmark Default on Warehouse #1.
- Dialog/popup: none.
- Notes: Shows the single-warehouse (before others added) state referenced by (246,139) "If we have multiply Warehouses then there needs to be a way to select the default Warehouse."
- Verified: pass3

##### Screen (290,102) — Location Type tab, empty state
- File: `p2_003_x290_y102.png`
- Illustrates: "Second you would have to create a Location Type" (298,97); "We need to be able to create these Location Types for each department (category) independently." (285,102)
- Header/tabs: Tab bar with **Location Type** active; department sub-tabs: Trim (active), Standing Seam, Rollforming, Board & Batten, Accessories.
- Controls: Green "+ Create Location Type" button top right.
- Table: Columns: Name | Warehouse | Description | Action — no rows (empty).
- Indicators: none.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (290,117) — Create Location Type modal
- File: `p2_006_x290_y117.png`
- Illustrates: "Clicking this button would open this window where you would enter the Name and Description of the Location Type you want to create. You would also select a Warehouse from the dropdown of existing Warehouses." (304,109)
- Header/tabs: Modal shows grey "Trim" pill header, red "X" close button.
- Controls: Fields: Name (placeholder "Location Type Name"), Warehouse dropdown (placeholder "Warehouse", chevron), Description (textarea placeholder "Enter Location Type Description"). Green "Create" button, enabled.
- Table: n/a.
- Indicators: none.
- Dialog/popup: "Create Location Type" — fields Name, Warehouse, Description; button "Create".
- Notes: Grey "Trim" tab pill at top of modal indicates department context.
- Verified: pass3

##### Screen (290,132) — Location Type tab, one row ("Small")
- File: `p2_010_x290_y132.png`
- Illustrates: near Screen (290,102) region
- Header/tabs: Location Type tab active, Trim sub-tab active.
- Controls: Green "+ Create Location Type" button.
- Table: Columns Name | Warehouse | Description | Action. One row: "Small" / "Warehouse #1" / "Small Trim Carts, 18" wide" / "...".
- Indicators: none.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (328,102) — Locations tab, empty state
- File: `p2_004_x328_y102.png`
- Illustrates: "Third you would have to create a Location" (336,97); "We need to be able to create these Locations for each department (category) independently." (323,102)
- Header/tabs: Tab bar with **Locations** active; department sub-tabs Trim (active), Standing Seam, Rollforming, Board & Batten, Accessories.
- Controls: Green "+ Create Location" button top right.
- Table: Columns: Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action — no rows.
- Indicators: none.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (328,117) — Create Location (default, Multi Order = No)
- File: `p2_007_x328_y117.png`
- Illustrates: (340,108)-(348,112) "Clicking this button would open this window where you would enter the Name, Max Weight and Description of the Location you want to create. You would also select a Warehouse from the dropdown of existing Warehouses, a Location Type from the dropdown of existing Location Types within that Warehouse and you have to decide if this is a Multi Order location." / (334,135)-(343,136) "Not A Multi Order Location"
- Header/tabs: tab bar Users, Machines, Warehouses, Location(s cut off) visible behind modal; sub-tabs Trim (active/white), St(andard Seam, cut off); top-right green "+ Create Location" button visible behind modal; red "X" close button on modal
- Controls: Name field (placeholder "Location Name"), Warehouse dropdown (placeholder "Warehouse"), Location Type dropdown (placeholder "Location Type"), Max Weight field (placeholder "0", suffix "lbs"), Multi Order toggle set to "No" (grey/unchecked, disabled-looking), Number of Orders field (placeholder "0", greyed/disabled), Description textarea (placeholder "Enter Location Description"), Create button (green)
- Table: background table columns Name | Warehouse | ... | Multi Order | Action (obscured by modal, no visible rows)
- Indicators: Multi Order toggle shown grey "No" (default/disabled state); Number of Orders field greyed out since Multi Order is No
- Dialog/popup: title "Create Location"; fields as above; single button "Create" (no visible Cancel in this crop)
- Notes: this is the default/empty state of the Create Location modal, contrasts with page-1 filled Multi-Order examples
- Verified: pass3

##### Screen (328,140) — Locations tab, single row, Multi Order off
- File: `p2_011_x328_y140.png`
- Illustrates: "All Location Names have to be unique within the entire app, can never be doubled up." (323,123)
- Header/tabs: Tab bar: Users, Machines, Warehouses, Location Types, **Locations** (active), Trucks, Priorities. Department sub-tabs: Trim (active), Standing Seam, Rollforming, Board & Batten, Accessories.
- Controls: Green "+ Create Location" button top right.
- Table: Columns: Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action. One row: "301" / "Warehouse #1" / "Small" / "1200 lbs" / "1200 lbs, 18" Wide Small Trim Cart" / grey unchecked checkbox with "0" / "...".
- Indicators: Multi Order checkbox greyed/unchecked, value 0.
- Dialog/popup: none.
- Notes: this is the table row, not the Create Location modal — the modal for this state is a separate crop.
- Verified: pass3

##### Screen (347,160) — Location picker window
- File: `p2_013_x347_y160.png`
- Illustrates: "This is how locations would show up in production when Workers are selecting locations." (351,156)
- Header/tabs: Warehouse tabs: Warehouse #1 (active), Warehouse #2, Warehouse #3. Department sub-tabs: Trim (active), Rollforming, Accessories. Red "X" close button top right.
- Controls: Column header pill "1 of 1" (grey, active) alongside Location Type columns: Wooden, Small, Medium, Large, Long (each grey pill header).
- Table: Six columns of location buttons: "1 of 1": 101–106. Wooden: 201–212. Small: 301–318. Medium: 401–410. Large: 501–510. Long: 601–616. Each entry a white pill button with number.
- Indicators: none highlighted/selected.
- Dialog/popup: Location-selection window (not a form, a picker).
- Notes: Grid of tappable location codes per Location Type column.
- Verified: pass3

##### Screen (351,127) — Create Location modal, Multi Order on (Yes, 0 orders)
- File: `p2_008_x351_y127.png`
- Illustrates: "If you want this to be a Multi Order Location than you would toggle "On" the Multi Order button. This would make the Number of Orders text box become available..." (359,126)
- Header/tabs: Grey "Trim" pill header modal, red "X" close.
- Controls: Fields all empty/placeholder: Name (placeholder "Location Name"), Warehouse dropdown (placeholder), Location Type dropdown (placeholder), Max Weight (placeholder "0", unit "lbs"), Multi Order toggle green "✔ Yes" (on), Number of Orders field enabled, value "0", Description textarea. Green "Create" button.
- Table: n/a.
- Indicators: Multi Order toggle green/enabled; Number of Orders shows "0".
- Dialog/popup: "Create Location" modal.
- Notes: none.
- Verified: pass3

##### Screen (356,140) — Locations tab, single row, Multi Order on (12)
- File: `p2_012_x356_y140.png`
- Illustrates: same as (380,142) Multi Order explanation.
- Header/tabs: Same tab bar as Screen (328,140), Locations active, Trim sub-tab active.
- Controls: Green "+ Create Location" button top right.
- Table: Same columns as Screen (328,140). One row: "301" / "Warehouse #1" / "Small" / "3500 lbs" / "1200 lbs, 18" Wide Small Trim Cart" / green checked checkbox with "12" / "...".
- Indicators: Multi Order checkbox green/checked, value 12.
- Dialog/popup: none.
- Notes: Max Weight now shows "3500 lbs" while Description text still says "1200 lbs" — literal inconsistency in the mock data. This is the table row, not the Create Location modal.
- Verified: pass3

##### Screen (364,127) — Create Location modal, Multi Order on (Yes, 12 orders)
- File: `p2_016_x364_y127.png`
- Illustrates: Multi Order toggle explanation (359,126); matches the finished example referenced in annotation (380,142) "This example would be able to be used 12 times... within 3500 lbs."
- Header/tabs: Grey "Trim" pill header modal, red "X" close.
- Controls: Same fields as Screen (351,127) except Number of Orders value is "12" instead of "0"; all other fields still empty/placeholder.
- Table: n/a.
- Indicators: Multi Order toggle green "Yes", Number of Orders "12".
- Dialog/popup: "Create Location" modal.
- Notes: none.
- Verified: pass3

##### Screen (426,102) — Machines tab, department accordion
- File: `p2_014_x426_y102.png`
- Illustrates: "Machines, Rollforming" (395,86); "Clicking this button would open this window where you would be able to create a list of coil suppliers." (439,109)
- Header/tabs: Tab bar: Users, **Machines** (active), Warehouses, Location Types, Loactions, Trucks, Priorities. Search box top right.
- Controls: Three collapsible department rows: "Trim" with green "6 Machine(s)" badge and chevron; "Rollforming" with green "5 Machine(s)" badge, grey "Coil Suppliers" button, chevron; "Accessories" (collapsed, no badge visible in crop).
- Table: n/a (accordion list).
- Indicators: Green pill badges show machine counts.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

##### Screen (426,113) — Machines tab, Coil Suppliers popup open
- File: `p2_015_x426_y113.png`
- Illustrates: "Clicking this button would open this window where you would be able to create a list of coil suppliers." (439,109)
- Header/tabs: Same as Screen (426,102).
- Controls: "Coil Suppliers" popup opened from Rollforming row; green "Add" button at bottom.
- Table: List of suppliers with red circular "X" delete icon each: "Taylor", "Color Steel", "Cascadia".
- Indicators: Red circular X delete icons per row.
- Dialog/popup: "Coil Suppliers" — list Taylor / Color Steel / Cascadia, each removable; "Add" button.
- Notes: none.
- Verified: pass3

##### Screen (491,513) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_064_x491_y513.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) — exact duplicate.
- Verified: pass3

##### Screen (491,521) — Expanded order 330618 line items (Select Supplier/Coil Number & Create Cutlist enabled)
- File: `p2_067_x491_y521.png`
- Illustrates: "As soon as the Manager selects at least 1 line item, then the Select Supplier / Coil Number and the Create Cutlist buttons become available." (540,467)
- Same as Screen (549,469) — identical table/state.
- Verified: pass3

##### Screen (491,531) — EBMS "Products" screenshot — Components tab
- File: `p2_070_x491_y531.png`
- Illustrates: "Screenshot from EBMS" (500,537 / 659,508 / 473,624 / etc.) — this is an EBMS application screenshot, not the Wiseline app
- Header/tabs: Windows-style app titled "Products\Metal\Dia. Rib Siding 29Ga. Classic/Txt.\{FEET}' {INCHES}" ({Height}") 29Ga. 36" Diamond Rib White White" with min/close controls. Tab bar: General, Purchasing, Pricing, Count, **Components** (active), Accessories, Advanced, Parts Calculate, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production, Elevate E-Commerce, Custom Prices, Roll Options, etc.
- Controls: Product field "MDR8317", Category dropdown "Dia. Rib Siding 29Ga. Classic/Txt."; right-side buttons: Insert, New, Properties, Delete, Move Up, Move Down, Copy From..., Show All, Show None (Printed Doc. group). Bottom: checkbox "Assembly Kit - Inventory is maintained only at the component level." (checked), "Fixed manufacturing cost of $2.86" (unchecked, greyed), dropdown "Never" for "prompt user to configure components to order" (greyed), "Use this item's sales G/L for components" (unchecked). OK / Cancel / New / Delete / Print buttons at bottom right.
- Table: Columns: Category, Quantity, Component, Measure, Description, Weight, Base Price, Cost, Total Cost, Quantity Formula (Inventory). Row: (Single Component) | 1.00 | CS8317 WHITE WHITE | ft | 29ga x 41.2" Coil White White | 2.05 | 4.63 | 2.8634 | 2.8634 | {Height}/12.
- Indicators: highlighted (blue) selected row.
- Dialog/popup: this is an EBMS desktop window, not a Wiseline modal.
- Notes: Bottom summary: Total Weight 2.05, Total Base Price $4.63, Total Cost $2.8634, Total Items 1.000000. This is the "Screenshot from EBMS" referenced by annotations showing how the coil-to-product relationship is defined in EBMS.
- Verified: pass3

##### Screen (527,482) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_056_x527_y482.png`
- Illustrates: same as Screen (549,461) — no unique adjacent annotation
- Header/tabs: Same as Screen (549,461) — full tab bar including Slit Line, not cropped.
- Controls/Table: Same as Screen (549,461); this is an exact duplicate screenshot.
- Notes: Exact duplicate of Screen (549,461).
- Verified: pass3

##### Screen (527,490) — "Select Supplier / Coil Number" modal
- File: `p2_058_x527_y490.png`
- Illustrates: "Clicking the Select Supplier / Coil Number button will open this window." (533,478)
- Header/tabs: background shows expanded order 330618 line items behind modal.
- Controls: Modal title "Select Supplier / Coil Number". Two list panels: "Supplier" (dropdown "Undefined", list: Undefined (selected/highlighted blue), Color Steel, Taylor, Cascadia) and "Coil Number" (dropdown "Undefined", list: Undefined (selected), "Select Coil Number" search field greyed/disabled). Buttons: "Cancel" (red), "Assign" (green).
- Table: background line-item table same as Screen (549,469).
- Indicators: blue highlight on selected "Undefined" list items.
- Dialog/popup: "Select Supplier / Coil Number" — Supplier list (Undefined, Color Steel, Taylor, Cascadia), Coil Number list (Undefined, search disabled), Cancel/Assign buttons.
- Notes: none.
- Verified: pass3

##### Screen (527,501) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_060_x527_y501.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) — exact duplicate.
- Verified: pass3

##### Screen (527,509) — "Select Supplier / Coil Number" modal, Supplier = Taylor selected
- File: `p2_062_x527_y509.png`
- Illustrates: "This drop down of Suppliers would be created and come from the Machines tab." (519,494/563,493)
- Same as Screen (527,490) except: Supplier field now shows "Taylor" (selected, no longer showing dropdown list); Coil Number dropdown open showing "Undefined" (highlighted) and "Select Coil Number" search field.
- Verified: pass3

##### Screen (527,520) — Rollforming / Scheduled / Tuff Rib & Diamond Rib (header/tab strip only)
- File: `p2_065_x527_y520.png`
- Illustrates: no adjacent annotation
- Header/tabs: same tab bars as Screen (549,461), cropped to show only header, tab bar, machine sub-tabs and date strip (no table rows visible).
- Controls: "Export and/or Release To Production" greyed button; date strip identical to Screen (549,461).
- Verified: pass3

##### Screen (527,525) — "Select Coil Number" lot list modal (CS8317 White White)
- File: `p2_068_x527_y525.png`
- Illustrates: "Clicking on Select Coil Number will open this window" (698,493)
- Header/tabs: background shows order rows table (330605–330615 partially visible) plus expanded 330618.
- Controls: red "X" close button top-right of modal.
- Table: Modal title "CS8317 WHITE WHITE - 29ga. X 41.2" Coil White White". Columns: Lot Number, On Hand, Received, Shipped, Processed, Lot Date. Rows: EP8C39C01 | 4,108.737864 | | | 4,108.737864 | 12/11/25. EP8C39C02 | 8,464.000000 | | | 8,464.000000 | 12/11/25. EP8C39C03 | 4,108.737864 | | | 4,108.737864 | 12/11/25. EP8C39C04 | 8,464.000000 | | | 8,464.000000 | 12/11/25. EP8C39C05 | 8,464.000000 | | | 8,464.000000 | 12/11/25. EP8C39C06 | 4,050.000000 | | | 4,050.000000 | 12/11/25. F6786659 | | | | 26.193333 | (no date). F7350023 | 83.427884 | | | 83.427884 | 11/25/25. F7350025 | 3,392.534175 | | 17.660000 | 3,392.534175 | 02/19/26. F7350026 | 3,071.698501 | | 285.870000 | 3,071.698501 | 02/19/26. FNJ4150C03 | 4,516.019417 | | | 4,516.019417 | 01/22/25. FNJ4151C04 | 644.315918 | | | 644.315918 | 01/22/25. FOF4209C01 | 3,322.379741 | | | 3,322.379741 | 09/08/25. (13 rows total, all shown.)
- Dialog/popup: Lot Number listing for coil CS8317 White White, red X close button (top right, no label).
- Notes: rows appear as alternating grey stripes; some cells greyed/blank placeholders.
- Verified: pass3

##### Screen (527,540) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_071_x527_y540.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) — exact duplicate.
- Verified: pass3

##### Screen (527,548) — "Select Supplier / Coil Number" modal, Coil Number = 7350025
- File: `p2_073_x527_y548.png`
- Illustrates: "Clicking on a specific Lot Number would auto fill that number into the Coil Number field." (531,538 / 584,538)
- Same as Screen (527,490) except: Supplier field = "Taylor", Coil Number field = "7350025" (both shown as plain filled text fields, no dropdown open). Cancel (red) / Assign (green) buttons.
- Verified: pass3

##### Screen (527,561) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_075_x527_y561.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) — exact duplicate.
- Verified: pass3

##### Screen (527,569) — Expanded order 330618, Supplier/Coil assigned to first 2 line items
- File: `p2_077_x527_y569.png`
- Illustrates: "When the Manager clicks Assign, then the selected Supplier and/or Coil Number get assigned to the selected line items and appear here." (541,558)
- Same as Screen (549,469) except: "Select Supplier / Coil Number" and "Create Cutlist" buttons now greyed/disabled; first two line items (Qty 8 and 25, MDR8317 189"/160") now show Supplier/Coil Number = "Taylor / 7350025" instead of "Undefined / Undefined"; their checkboxes have reverted to unchecked (plain green outline, no checkmark), same as the other rows.
- Verified: pass3

##### Screen (549,461) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_054_x549_y461.png`
- Illustrates: no adjacent annotation (nearest is "Rollforming Scheduled" (558,272)/(717,366) region text about Machine tabs)
- Header/tabs: "Rollforming" department pill (top-left, active/black). Top-right: "Completed orders for the past 90 days" button, Search box (placeholder "Search...").
- Controls: Main tab bar — Unscheduled, **Scheduled** (active), Production, Queue, Coils, Wrapping. Machine sub-tab bar — **Tuff Rib & Diamond Rib** (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated, Slit Line. "Export and/or Release To Production" button (greyed/disabled, italic). Day strip: "All Scheduled Orders", calendar icon "Wednesday May 08/2024" (active/selected), "Mon. May 06/2024 (1000 / 5000)", "Tue. May 07/2024 (1000 / 5000)", "Wed. May 08/2024 (1000 / 5000)" (active/dark border), "Thu. May 09/2024 (1000 / 5000)", "Fri. May 10/2024 (1000 / 5000)".
- Table: Columns: E, R, (blank/expand chevron), Ship Date, Production Date, Order #, Customer Name, Gauge / Color, PO, Salesman, Ship Via, Priority, Reviewed, Status, Loc., Order Notes. Rows (5 visible): 330605 | H F H Inc | Thursday, May 09/2024 | Wed. May 08/2024 | 29Ga. Black / 26Ga. Black | ABC 123 | Joel Thieseen | Pickup | Select Priority | | | | Notes (red dot). 330609 | Arnold Contracting | Thursday, May 09/2024 | Wed. May 08/2024 | 26GA. Ebony | ABC 123 | Henry Goertzen | Pickup | Select Priority | | | | Notes. 330615 | DAP Roofing Inc. | Thursday, May 09/2024 | Wed. May 08/2024 | 29Ga. Ebony / 29Ga. Melcher's Green / 29Ga. White White | ABC 123 | Jake Fehr | Delivery | Select Priority | | | | Notes. 330616 | Arnold Contracting | Thursday, May 09/2024 | Wed. May 08/2024 | 29Ga. Black | ABC 123 | Jake Fehr | Pickup | Select Priority | | | | Notes (green dot). 330617 | Ontario Metal Products Ltd. | Thursday, May 09/2024 | Wed. May 08/2024 | 29Ga. Black | ABC 123 | Jacob Redecop | Delivery | Select Priority | | | | Notes.
- Indicators: red dot on order 330605's Notes button, green dot on order 330616's Notes button (unread vs read note state).
- Dialog/popup: none.
- Notes: E/R checkbox columns empty (unchecked). Row expand chevrons at left of each row.
- Verified: pass3

##### Screen (549,469) — Rollforming / Scheduled / Tuff Rib & Diamond Rib (expanded order 330618)
- File: `p2_055_x549_y469.png`
- Illustrates: "Once an order is in the Scheduled tab, then it needs to display the line items like this..." (679,416)
- Header/tabs: Same as Screen (549,461), showing expanded order row for 330618 (A.W.C.) and the line-item table beneath it.
- Controls: "Select Supplier / Coil Number" button (green, enabled), "Create Cutlist" button (green, enabled).
- Table: Order header row 330618 | A.W.C. | Thursday, May 09/2024 | Wed. May 08/2024 | Pickup | Select Priority | Notes (green dot). Line-item columns: (coil icon), (checkbox), Qty Ordered, # From Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Rows: 8 | | 8 | MDR8317 | 15'9" (189") 29Ga. 36" Diamond Rib White White | 189" | Undefined/Undefined | | Notes (checked, green box). 25 | | 25 | MDR8317 | 13'4" (160") 29Ga. 36" Diamond Rib White White | 160" | Undefined/Undefined | | Notes (red dot, checked). 12 | | 12 | MDR8317 | 10'6" (126") 29Ga. 36" Diamond Rib White White | 126" | Undefined/Undefined | | Notes (unchecked box). 14 | | 14 | MTR8262 | 14'6" (174") 29Ga. 36" Tuff Rib Black | 174" | Undefined/Undefined | | Notes (green dot). 3 | 3 | 0 | MTR8262 | 12'3" (147") 29Ga. 36" Tuff Rib Black | 147" | Undefined/Undefined | Stock (yellow badge) | Notes. 16 | | 16 | MTR8306 | 16'0" (192") 29Ga. 36" Tuff Rib Charcoal | 192" | Undefined/Undefined | | Notes. 28 | 2 | 26 | MTR8306 | 11'3" (135") 29Ga. 36" Tuff Rib Charcoal | 135" | Undefined/Undefined | | Notes. 22 | | 22 | MTR8306 | 8'4" (100") 29Ga. 36" Tuff Rib Charcoal | 100" | Undefined/Undefined | | Notes. Below, two more collapsed order rows: 330622 Ontario Metal Products Ltd., 330629 Ontario Metal Products Ltd.
- Indicators: red/green dot badges on Notes buttons; yellow "Stock" status badge; orange horizontal divider lines separating Product ID groups (MDR8317/MTR8262/MTR8306 sections).
- Dialog/popup: none.
- Notes: Coil icon at left of each line item (not yet a scissor icon since not slit).
- Verified: pass3

##### Screen (551,581) — Rollforming / Scheduled, order 330618 Reviewed toggle marked (icon)
- File: `p2_079_x551_y581.png`
- Illustrates: "This should be a toggle button that can be toggled when the order is collapsed as well as when the order is expanded..." (543,583)
- Header/tabs: Rollforming pill, tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping, machine sub-tabs Tuff Rib & Diamond Rib (active) etc.
- Controls: "Export and/or Release To Production" greyed. Date strip same as before.
- Table: same 8 order rows (330605–330629) as earlier screens; E and R checkboxes both checked (green) on row 330618 only; other rows unchecked. Row 330618 "Reviewed" column now shows a document/checkmark icon (reviewed indicator) instead of blank.
- Indicators: green checked checkboxes (E, R) on order 330618; reviewed icon (document with checkmark) in Reviewed column for 330618.
- Verified: pass3

##### Screen (571,482) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_057_x571_y482.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) except: identical duplicate screenshot.
- Verified: pass3

##### Screen (571,490) — "Create Cutlist" modal
- File: `p2_059_x571_y490.png`
- Illustrates: "Clicking the Create Cutlist button will open this window." (581,478)
- Same as Screen (527,490) except: modal titled "Create Cutlist"; buttons are "Cancel" (red) / "Create" (green); a disabled pink/red button bar visible below the modal buttons (greyed out, no visible label - appears to be a placeholder "Assign"-style button, disabled).
- Dialog/popup: "Create Cutlist" — Supplier list (Undefined, Color Steel, Taylor, Cascadia), Coil Number list (Undefined, search disabled), Cancel/Create buttons, plus a disabled reddish button below.
- Verified: pass3

##### Screen (571,501) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_061_x571_y501.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) — exact duplicate.
- Verified: pass3

##### Screen (571,509) — "Create Cutlist" modal, Supplier = Taylor selected
- File: `p2_063_x571_y509.png`
- Illustrates: same as Screen (527,509)
- Same as Screen (571,490) except: Supplier field shows "Taylor" selected; Coil Number dropdown open showing "Undefined" highlighted.
- Verified: pass3

##### Screen (571,520) — Rollforming / Scheduled (header/tab strip only)
- File: `p2_066_x571_y520.png`
- Illustrates: no adjacent annotation
- Same as Screen (527,520) — exact duplicate (header/tabs only, no table).
- Verified: pass3

##### Screen (571,525) — "Select Coil Number" — coil list then lot list (two-panel)
- File: `p2_069_x571_y525.png`
- Illustrates: "This window would show the Lot Numbers for the coil that is connected to the Product ID that you selected." (678,498)
- Header/tabs: background same order table.
- Controls: red "X" close button.
- Table: Left panel "29ga. White White Coils" — columns ID, Description; rows: CS148317 | 29ga x 14-1/8" BB Coil White White. CS218317 | 29ga x 21-1/4" SS Coil White White. CS438317 WHITE WHITE | 29ga x 43" Coil White White. CS448317 WHITE WHITE | 29ga x 44.72" Coil White White. CS8317 WHITE WHITE | 29ga x 41.2" Coil White White (highlighted/selected, blue border). Right panel same lot table as Screen (527,525) for CS8317 WHITE WHITE.
- Dialog/popup: two-panel modal, coil selection list + lot number detail table, red X close.
- Notes: selected coil row outlined in blue.
- Verified: pass3

##### Screen (571,540) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_072_x571_y540.png`
- Illustrates: no adjacent annotation
- Same as Screen (549,461) except: machine sub-tab bar cropped, only shows Tuff Rib & Diamond Rib, Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated (Slit Line cut off).
- Verified: pass3

##### Screen (571,548) — "Create Cutlist" modal, Coil Number = 7350025
- File: `p2_074_x571_y548.png`
- Illustrates: same as Screen (527,548)
- Same as Screen (571,490) except: Supplier = "Taylor", Coil Number = "7350025" filled in. Cancel (red) / Create (green) buttons.
- Verified: pass3

##### Screen (571,561) — Rollforming / Scheduled / Tuff Rib & Diamond Rib
- File: `p2_076_x571_y561.png`
- Illustrates: no adjacent annotation
- Same as Screen (571,540) — machine sub-tab bar cropped (Slit Line cut off), not a full-width duplicate of (549,461).
- Verified: pass3

##### Screen (571,569) — Same order, coil icon changed to scissor icon on assigned rows
- File: `p2_078_x571_y569.png`
- Illustrates: "This coil icon would change to a scissor icon indicating that this line item needs to be slit." (566,565)
- Same as Screen (527,569) except: the leftmost icon for the first two line items (Qty 8, 25 — MDR8317 189"/160", Supplier=Taylor) is now a scissor icon instead of a coil icon; remaining rows still show coil icon.
- Verified: pass3


#### Rollforming Unscheduled
Tab label "Rollforming Unscheduled" (558, 272).

- "This Sorts the line item into the Rollforming department (category)." (542, 276)
- "The "Profile" assigned to a line item will look back to the Machine connected to that "Profile" and sort the line items into the apropriate Machine." (516, 277)
- "Select the Machine you are wanting to Manage" (558, 276)
- "Managing the Slit Line" (572, 277), numbered callouts "1" (560, 279), "2" (562, 278)
- "Each Machine tab only shows the line items that are assigned to that Machine via inputs through the "Roll Options" tab in EBMS" (542, 280)
- "The Gauge / Color column would show all the materials that are on the order." (573, 283)
- "The Name assigned here would have to exactly match the Name given to the Machine in the app." (541, 284)

**Scheduling Entire Order vs Scheduling Partial Order** — labels "Scheduling Entire Order" (555, 294), "Scheduling Partial Order" (562, 294), "Or" (560, 295); "Order Notes" (506, 297).

- "Go to the Unscheduled tab and choose the Machine you want to Manage." (515, 298)
- "Once you have selected at least one order, then the Schedule button should become available. We need to be able to expand & collapse orders, check & deal with notes and set Priorities without losing the orders we've selected." (513, 301)
- "These Order Notes would be imported from the Salesman (EBMS). There would be a red indicator showing that you haven't dealt with this note yet." (499, 304)
- "Select all the orders you want to Schedule." (515, 308)
- "Clicking the Schedule button will open a Calendar" (525, 311)
- "Clicking this button opens the note." (492, 312)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (498, 320)
- "Select the Production Date and click Set Date, this will make the order disappear out of the Unscheduled tab and appear in the Scheduled tab." (514, 321)

Partial-order path:
- "Open the dropdown on the order that you want to partially schedule." (572, 298)
- "Line items need to be sorted by Product ID and then have a distinct line between them." (571, 303)
- "Select the line items you are wanting to schedule." (572, 320)
- "As soon as you select at least 1 line item, then the Split Order button becomes available." (571, 323)
- "Clicking the Split Order button opens the calendar." (579, 330)
- "Select the Production Date for the selected line items. This will schedule those line items and reset the Split Order function." (571, 339)
- "The Gauge / Color column would have to update to show only the gauge & color that is valid after splitting the order." (601, 345)
- "When part of an order has been scheduled, there should be an indication that this order has been split, on both sub-orders." (570, 349)
- "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be grayed out and completely uneditable in the Unscheduled tab. Once all the line items are Scheduled, the order will disappear in the Unscheduled tab within the Rollforming department (category)." (568, 353)

##### Screens (14)

###### Screen (475,300) — Rollforming Unscheduled tab, main table
- File: `p2_017_x475_y300.png`
- Illustrates: "This Sorts the line item into the Rollforming department (category)." (542,276); "Select the Machine you are wanting to Manage" (558,276)
- Header/tabs: "Rollforming" pill (department). Top-right "Completed orders for the past 90 days" button. Tab bar: **Unscheduled** (active), Scheduled, Production, Queue, Coils, Wrapping. Machine sub-tabs: **Tuff Rib & Diamond Rib** (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated, Slit Line. Search box top right.
- Controls: Grey/disabled "Schedule" button (top left, greyed until a row is selected). Each row has an unchecked green-bordered checkbox and an expand chevron.
- Table: Columns: (checkbox) | (expand) | Entry Date | Ship Date | Order # | Customer Name | Address | City | Gauge / Color | PO | Salesman | Ship Via | Priority | Order Notes. 11 rows shown, all "Monday, May 06/2024" entry date except last two "Friday, May 10/2024" ship date: 330605 H F H Inc / 123 Main St. / Tillsonburg / 29Ga. Black / 26Ga. Black / ABC 123 / Joel Thieseen / Pickup / Select Priority / Notes(red dot); 330608 Jireh Tools / 29Ga. Charcoal / Henry Wall / Delivery / Select Priority / Notes; 330609 Arnold Contracting / 26GA. Ebony / Henry Goertzen / Pickup / Select Priority / Notes; 330615 DAP Roofing Inc. / 29Ga. Ebony / 29Ga. Melcher's Green / 29Ga. White White / Jake Fehr / Delivery / Select Priority / Notes; 330616 Arnold Contracting / 29Ga. Black / Jake Fehr / Pickup / Select Priority / Notes(green dot); 330617 Ontario Metal Products Ltd. / 29Ga. Black / Jacob Redecop / Delivery / Select Priority / Notes; 330618 A.W.C. / 29Ga. Black / 29Ga. Charcoal / 29Ga. White White / Henry Wall / Pickup / Select Priority / Notes(green dot); 330622 Ontario Metal Products Ltd. / 29Ga. Tan / 29Ga. Coffee Brown / Jacob Redecop / Delivery / Select Priority / Notes; 330629 Ontario Metal Products Ltd. / 26Ga. Coffee Brown / Jacob Redecop / Delivery / Select Priority / Notes; 330631 Jireh Tools / 26Ga. Charcoal / Henry Goertzen / Delivery / Select Priority / Notes; 330632 Upright Construction / 29Ga. Black / Sepia Brown / Joel Thieseen / Delivery / Select Priority / Notes. All rows show "123 Main St." / "Tillsonburg" for Address/City.
- Indicators: Order Notes: red dot on 330605 (unread), green dot on 330616 and 330618 (read/resolved). Ship Date is Thursday, May 09/2024 for the first eight rows (330605–330622) and Friday, May 10/2024 for the last three (330629, 330631, 330632). All row checkboxes green-outlined, unchecked.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (475,314) — Rollforming Unscheduled tab, main table
- File: `p2_018_x475_y314.png`
- Illustrates: Same as Screen (475,300).
- Header/tabs: Pixel-identical to Screen (475,300) (`p2_017_x475_y300.png`) — confirmed by opening both; no visible differences at this crop/resolution.
- Controls: Same as Screen (475,300).
- Table: Same as Screen (475,300).
- Indicators: Same as Screen (475,300).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (475,330) — Rollforming Unscheduled tab, main table
- File: `p2_019_x475_y330.png`
- Illustrates: Same as Screen (475,300).
- Header/tabs: Pixel-identical to Screen (475,300) (`p2_017_x475_y300.png`) — confirmed by opening both; no visible differences at this crop/resolution.
- Controls: Same as Screen (475,300).
- Table: Same as Screen (475,300).
- Indicators: Same as Screen (475,300).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (488,317) — Order Note popup (unread, red X only)
- File: `p2_034_x488_y317.png`
- Illustrates: "Clicking this button opens the note." (492,312)
- Header/tabs: none (standalone popup).
- Controls: Red circular "X" button and green circular check button, both present.
- Table: n/a.
- Indicators: none.
- Dialog/popup: "Order Note" popup — avatar "JT" / "Joel Thiessen" / "joelthiessen@wiseline.ca" / timestamp "Tue. May 07/2024 10:42" / body text "Would like this order by lunch tomorrow" / red X and green check action buttons.
- Notes: none.
- Verified: pass3

###### Screen (488,333) — Order Note popup, confirmed/read (green button solid)
- File: `p2_036_x488_y333.png`
- Illustrates: "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green." (498,320)
- Header/tabs: none (standalone popup).
- Controls: Same as Screen (488,317) except: green check button now shown as a solid green pill/bar (post-click confirmed state) instead of a small circular icon; red X button no longer shown.
- Table: n/a.
- Indicators: Solid green bar replacing the red/green icon pair — visually indicates "read" state.
- Dialog/popup: Same note content ("Would like this order by lunch tomorrow", Joel Thiessen).
- Notes: none.
- Verified: pass3

###### Screen (522,299) — Unscheduled tab, all rows checked, Schedule active
- File: `p2_031_x522_y299.png`
- Illustrates: "Select all the orders you want to Schedule." (515,308)
- Header/tabs: Same as Screen (475,300).
- Controls: "Schedule" button now green/enabled (top left).
- Table: Same 11-row table as Screen (475,300), except: checkboxes are green-checked (✓) on rows 330605, 330609, 330615, 330616, 330617, 330618, 330622, 330629 (8 of 11); rows 330608, 330631, 330632 remain unchecked.
- Indicators: Checked rows show solid green checkbox with white check; Order Notes red dot (330605), green dots (330616, 330618) as before.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (522,313) — Schedule calendar popup
- File: `p2_032_x522_y313.png`
- Illustrates: "Clicking the Schedule button will open a Calendar" (525,311)
- Header/tabs: Background shows Unscheduled tab table with rows checked (same as Screen (522,299)).
- Controls: Calendar popup: month "May 2024" with left/right arrow navigation; red "X" close; date grid Su–Sa; "8" highlighted green (selected); green "Set Date" button; grey "Cancel" button.
- Table: n/a (calendar).
- Indicators: Selected date (8) highlighted green circle.
- Dialog/popup: Calendar — title "May 2024", buttons "Cancel" / "Set Date".
- Notes: none.
- Verified: pass3

###### Screen (549,281) — Rollforming Unscheduled tab, main table (duplicate)
- File: `p2_028_x549_y281.png`
- Illustrates: Same as Screen (475,300).
- Header/tabs: Confirmed by opening both `p2_028_x549_y281.png` and `p2_017_x475_y300.png` — pixel-identical: same 11-row table, same header/tab layout, same Order Notes red/green dots.
- Controls: "Schedule" button greyed/disabled; no rows checked.
- Table: Same 11-row Unscheduled table as Screen (475,300) (330605...330632).
- Indicators: Order Notes red dot (330605), green dots (330616, 330618), as in Screen (475,300).
- Dialog/popup: none.
- Notes: genuine duplicate, confirmed pixel-identical.
- Verified: pass3

###### Screen (577,297) — Unscheduled order expanded, Split Order visible
- File: `p2_030_x577_y297.png`
- Illustrates: "Go to the Unscheduled tab and choose the Machine you want to Manage." (515,298); "Once you have selected at least one order, then the Schedule button should become available..." (513,301)
- Header/tabs: Same as Screen (475,300); row 330605 H F H Inc expanded.
- Controls: Green/enabled "Split Order" button; greyed "Schedule" button (top, no rows checked in the main list).
- Table: Columns: (checkbox) | Qty Ordered | Product ID | Description | Length | Line Item Notes. Rows: 12/MDR8262/"11'1" (133") 29Ga. 36" Diamond Rib Black"/133"/Notes; 25/MDR8262/"16'8" (200") 29Ga. 36" Diamond Rib Black"/200"/Notes (orange divider follows); 5/MTR268262/"12'6" (150") 26Ga. 36" Tuff Rib Black"/150"/Notes(green); 16/MTR268262/"12'0" (144") 26Ga. 36" Tuff Rib Black"/144"/Notes; 15/MTR268262/"14'3" (171") 26Ga. 36" Tuff Rib Black"/171"/Notes.
- Indicators: Green-outlined checkboxes per line item, all unchecked; orange divider line between Product ID groups.
- Dialog/popup: none.
- Notes: Below the expanded order, remaining unscheduled orders continue in collapsed rows (330608 onward).
- Verified: pass3

###### Screen (577,314) — Unscheduled order expanded, first line-item group checked
- File: `p2_033_x577_y314.png`
- Illustrates: intermediate state leading into the Split Order calendar (Screen (577,332) shows this same table as its background).
- Header/tabs: Same tab/day layout as Screen (577,297); row 330605 H F H Inc expanded, rows 330608 onward collapsed below.
- Controls: Green "Split Order" button (enabled); "Schedule" button greyed/disabled (pale grey pill, no rows checked in the main list).
- Table: Same 5-row line-item table as Screen (577,297) (12/MDR8262, 25/MDR8262, 5/MTR268262, 16/MTR268262, 15/MTR268262), except: the first two rows (12, 25 — MDR8262 group) are now green-checked; the three MTR268262 rows remain unchecked.
- Indicators: Green checkmarks on the two MDR8262 rows; orange divider between the MDR8262 and MTR268262 groups; green Notes dot on the "5" row.
- Dialog/popup: none.
- Notes: this is NOT identical to Screen (577,297) — two checkboxes differ. It is identical to the background of Screen (577,332) minus the calendar popup.
- Verified: pass3 This is not a duplicate of Screen (522,299) — no rows are checked here.

###### Screen (577,332) — Split Order calendar popup
- File: `p2_035_x577_y332.png`
- Illustrates: "Clicking the Split Order button opens the calendar." (579,330)
- Header/tabs: Background shows expanded order 330605 with Split Order button and line items (same as Screen (577,297)) with only the first two line items (12, 25 — the MDR8262 group) green-checked; the three MTR268262 rows remain unchecked.
- Controls: Calendar popup: "May 2024", "8" selected/highlighted green; "Cancel" and "Set Date" buttons; red "X" close.
- Table: Background table same as Screen (577,297) but the first two rows are now checked.
- Indicators: Selected date "8" highlighted.
- Dialog/popup: Calendar — "May 2024", "Cancel" / "Set Date".
- Notes: none.
- Verified: pass3

###### Screen (730,300) — Rollforming / Unscheduled / Slit Line tab, expanded order with Split Order
- File: `p2_120_x730_y300.png`
- Illustrates: (677,299)-(684,303) "Once you have selected at least one order, then the Schedule button should become available. We need to be able to expand & collapse orders, check & deal with notes and set Priorities without losing the ordered we've selected."
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Unscheduled(active)/Scheduled/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line(active, boxed); search box
- Controls: greyed "Schedule" button; greyed "Split Order" button (green) on expanded row
- Table: columns checkbox, expand arrow, Entry Date, Ship Date, Order #, Customer Name, Requested By, Gauge/Color, Salesman, Priority, Order Notes. Row1 (expanded, boxed): Monday May 06/2024 | Thursday May 09/2024 | 330605 | H F H Inc | Sales Order icon | 29Ga.Black/26Ga.Black | Joel Thieseen | Select Priority | Notes(red dot). Sub-table: Qty Ordered, Product ID, Description, Length, Line Item Notes — 3 | MTC128262 | 300'0"(3600") 29Ga. 11-7/8" Trough Coil Black | 3600" | Notes; 1 | MTC128262 | 100'0"(1200")... | 1200" | Notes; 3 | MTC12268262 | 150'0"(1800") 26Ga. 11-7/8" Trough Coil Black | 1800" | Notes. Remaining rows: 330608 Jireh Tools (Sales Order), 330609 Arnold Contracting (Standing Seam), 330615 DAP Roofing Inc (Sales Order), 330616 Arnold Contracting (Sales Order), 330617 Ontario Metal Products Ltd (Board & Batten), 330618 A.W.C. (Tuff Rib & Diamond Rib) x3 rows different gauge/colors, 330631 Jireh Tools (Corrugated), 330632 Upright Construction (Board & Batten) — 11 rows total visible
- Indicators: green checkboxes throughout; red dot / green dot on Notes buttons; orange divider between the two line-item groups
- Verified: pass3

###### Screen (730,315) — Rollforming / Unscheduled / Slit Line tab, expanded order 330605 with 2 line items checked, Split Order enabled
- File: `p2_122_x730_y315.png`
- Illustrates: (725,321)-(729,323) "Select the line items you are wanting to schedule." / (725,324)-(729,326) "As soon as you select at least 1 line item, then the Split Order button becomes available."
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Unscheduled(active)/Scheduled/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line(active, boxed); search box
- Controls: greyed "Schedule" button; "Split Order" button green/enabled on expanded row
- Table: same columns/rows as Screen (730,300); order 330605 expanded, sub-table rows for MTC128262 (3, 300'0"/3600") and MTC128262 (1, 100'0"/1200") now have checked green checkboxes; third row MTC12268262 (3, 150'0"/1800") unchecked
- Indicators: red dot Notes badge row1 (330605); green dot Notes badge row4 (330616)
- Verified: pass3

###### Screen (730,332) — Rollforming / Unscheduled — calendar/date-picker popup open over the expanded row
- File: `p2_123_x730_y332.png`
- Illustrates: (733,330)-(737,331) "Clicking the Split Order button opens the calendar."
- Header/tabs: same as Screen (730,315), background table with order 330605 expanded, two line items checked
- Dialog/popup: Title "May 2024" with < > month nav, red X close. Calendar grid Su-Sa, dates 1-31, "8" highlighted green (selected = Wed May 08/2024). Buttons: Cancel (red), Set Date (green)
- Verified: pass3


#### Rollforming Scheduled
Tab labels "Rollforming Scheduled" (717, 366) / (558, 369); "Viewing Partial Order" (569, 369).

- "When viewing a partially scheduled order in the Scheduled tab, the line items that are still unscheduled or scheduled to a different day should appear but be grayed out and completely uneditable." (569, 379)

**Reviewing Order / Priorities** — "Reviewing Order" (718, 385)/(559, 388), "Priorities" (685, 387)/(527, 390).

- "Go to the Scheduled tab and choose the Machine you want to Manage." (543, 392)
- "Choose the day you want to work on, this day tab should show your maximum capacity for the day and how much is already assigned to that day." (572, 393)
- "Only the Manager can set Priorities" (498, 394)
- "Sales Order from EBMS vs Material Request from a Rollforming Machine" annotations (714, 401), (759, 297)-(768, 299)
- "Line Item Notes" (536, 403)
- "The Coils Tab" (581, 403)
- "Clicking the Coils tab would open a window with the coils folders and sub-folders from EBMS. You would then select the appropriate folders for the coil you are looking for." (585, 406)
- "Click the dropdown for the order you are wanting to review." (543, 407) / (679, 408)
- "It needs to default the Supplier and Coil Number as Undefined, meaning that the Worker can use any Coil Number from any Supplier to slit the order." (709, 408)
- "The Manager and Workers should be able to add and view Line Item Notes at any point in production. These notes are just within the app, they do not come from or push back to EBMS." (526, 410)
- "The line items need to initially be sorted primarily by Product ID and then by Length. That being said, the Manager needs to be able to drag & drop to rearrange the line item order within it's own Product ID section, can NOT be dragged across the "line"." (573, 411)
- "We need a distinct line between the different Product IDs." (681, 413) / (544, 416)
- "By selecting a specific coil it would show you the Lot Numbers within that coil." (616, 414)
- "This would show you all the coils in the selected folder." (585, 414)
- "Once an order is in the Scheduled tab, then it needs to display the line items like this. Show what was ordered on one line. Then however many are in the Qty Orderd column, that many seperate lines underneth with only a Qty of 1 on each line. This way a different Supplier and/or Coil Number can be assigned to each Coil sold." (679, 416)
- "Clicking this button opens the Line Item Note." (521, 421)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (527, 429)
- "If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again." (528, 464)
- "It needs to default to using a coil for every line item. It needs to also default to the Supplier and Coil Number be Undefined, meaning that the Worker can use any Coil Number from any Supplier to roll the order." (541, 431)
- "Here the Manager can decide if he wants a coil to come from Stock by checking it off in the Stock column." (680, 438)
- "Checking the Stock check box on a line item will open this window" (688, 447)
- "If a line item's Status is Stock, then there is no coil or slit icon and no check box for that line item." (542, 453)
- "Here the Manager can enter how many to use from stock, this would be subtracted from the amount ordered and the remaining amount would show up in the Qty To Produce column. If the amount ordered and the amount being pulled from stock are equal, then the Status would automatically change to Stock." (574, 453)
- "Here the Manager has 2 options, he can just assign a Supplier and leave the Coil Number as Undefined, or, he can assign a Supplier and a Coil Number. He should only be able to assign a Coil Number if he has selected a Supplier." (678, 456) / (519, 489)
- "The Select Coil Number option needs to be greyed out and unavailable if no Supplier has been selected." (709, 459) / (595, 492) / (550, 493)
- "This drop down of Suppliers would be created and come from the Machines tab." (678, 460) / (563, 493) / (519, 494)
- "As soon as the Manager selects at least 1 line item, then the Select Supplier / Coil Number and the Create Cutlist buttons become available. Also any line items NOT within the same Product ID section as the one selected need to become unavaiable." (540, 467)

**Select Supplier / Coil Number vs Create Cutlist** — buttons "Select Supplier / Coil Number" (547, 479), "Create Cutlist" (569, 479).

- "Clicking the Select Supplier / Coil Number button will open this window." (533, 478)
- "Clicking the Create Cutlist button will open this window." (581, 478)
- "After selecting a Supplier, then the Manager can leave the Coil Number as Undefined or he can click Select Coil Number." (678, 482) / (563, 510) / (519, 511)
- "Here the Manager has 3 options, he can just leave the Supplier and Coil Number as Undefined, or, he can just assign a Supplier and leave the Coil Number as Undefined, or, he can assign a Supplier and a Coil Number. He should only be able to assign a Coil Number if he has selected a Supplier." (563, 488)
- Field labels: "Update Image" (663, 492) / (655, 507), "Product ID" (666, 493)/(598, 563)/(507, 522)/(481, 609), "Product ID in EBMS" (654, 497)/(495, 526)
- "Clicking on Select Coil Number will open this window" (698, 493) / (539, 518) / (584, 518)
- "This window would show the Lot Numbers for the coil that is connected to the Product ID that you selected." (678, 498) / (520, 527)
- "Coil conneted to the Product ID" (665, 505) / (506, 534) / (480, 621)
- "Clicking on a specific Lot Number would auto fill that number into the Coil Number field." (690, 509) / (531, 538) / (584, 538)
- "Clicking on a coil would open a list of all the Lot Numbers connected to that coil." (565, 527)
- "How this list of coil is created" (600, 531)
- "This list of coils would be made up of any coil that is the same Color and Gauge as the Product ID that you are creating a cutlist for, and has a Production Type of Coil." (597, 543)
- "Any Product ID in EBMS that has a Production Type of Coil, and the same Color and Gauge as the Product ID that you are creating a cutlist for would then be pulled into this coil list." (615, 581)
- "This Product ID would then be pulled into the list of coils to pick from." (601, 588)
- "When the Manager clicks Assign, then the selected Supplier and/or Coil Number get assigned to the selected line items and appear here." (541, 558)
- "When the Manager clicks Create, then the selected Supplier and/or Coil Number get assigned to the selected line items and appear here." (586, 558)
- "This coil icon would change to a scissor icon indicating that this line item needs to be slit." (566, 565)
- "Product ID in EBMS with Color and Gauge" (609, 571)
- "This Material code comes from the coil that is connected to the Product ID that you need to rollform." (493, 614)

**Order review toggle**
- "This should be a toggle button that can be toggled when the order is collapsed as well as when the order is expanded. When toggling it "on" there should NOT be a pop-up but when toggling it from "on" to "off", then there should be a pop-up asking you to confirm that you want to do that mark the order as unreviewed." (543, 583)

##### Screens (21)

###### Screen (465,600) — Rollforming Scheduled tab, top rows (abbreviated)
- File: `p2_021_x465_y600.png`
- Illustrates: same as Screen (475,392).
- Header/tabs: Same as Screen (475,392) except: crop shows only top 5 rows (330605–330617) of the same table.
- Controls: Same "Export and/or Release To Production" greyed button.
- Table: Same as Screen (475,392), truncated to first 5 rows (330605, 330609, 330615, 330616, 330617).
- Indicators: Same colour coding as Screen (475,392).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (465,608) — Order expanded: Select Supplier/Create Cutlist + line items
- File: `p2_022_x465_y608.png`
- Illustrates: "Line items need to be sorted by Product ID and then have a distinct line between them." (571,303); "As soon as you select at least 1 line item, then the Split Order button becomes available." (571,323)
- Header/tabs: Same tab/day strip as Screen (475,392), row 330618 A.W.C. expanded.
- Controls: Green "Select Supplier / Coil Number" and "Create Cutlist" buttons (enabled — two line items are checked).
- Table: Columns: (coil icon) | (checkbox) | Qty Ordered | # From Stock | Qty To Produce | Product ID | Description | Length | Supplier/Coil Number | Status | Line Item Notes. Rows: 8/—/8/MDR8317/15'9" (189") 29Ga. 36" Diamond Rib White White/189"/Undefined / Undefined/Notes, checkbox checked; 25/—/25/MDR8317/13'4" (160") .../160"/Undefined / Undefined/Notes(red), checkbox checked (orange divider follows); 12/—/12/MDR8317/10'6" (126") .../126"/Undefined/Undefined/Notes, unchecked; 14/—/14/MTR8262/14'6" (174") 29Ga. 36" Tuff Rib Black/174"/Undefined/Undefined/Notes(green), unchecked; 3/3/0/MTR8262/12'3" (147")…/147"/no coil icon or checkbox/Undefined/Undefined/Status "Stock" (yellow badge)/Notes (orange divider follows); 16/—/16/MTR8306/16'0" (192") 29Ga. 36" Tuff Rib Charcoal/192"/Undefined/Undefined/Notes, unchecked; 28/2/26/MTR8306/11'3" (135")…/135"/Undefined/Undefined/Notes, unchecked; 22/—/22/MTR8306/8'4" (100")…/100"/Undefined/Undefined/Notes, unchecked.
- Indicators: Coil icon per row (except the Stock row); yellow "Stock" status badge on the line item with equal Qty Ordered/# From Stock (3/3); red/green Notes dot indicators; orange horizontal divider lines separating Product ID groups; first two rows have green-checked checkboxes.
- Dialog/popup: none.
- Notes: Two collapsed rows below (330622, 330629) visible at bottom edge.
- Verified: pass3

###### Screen (475,392) — Rollforming Scheduled tab, day strip
- File: `p2_020_x475_y392.png`
- Illustrates: "If orders have Priorities assigned to them then they are sorted primarily by Production Date and secondarily by Priority." (468,394)
- Header/tabs: Tab bar: Unscheduled, **Scheduled** (active), Production, Queue, Coils, Wrapping. Machine sub-tabs same as before. Date strip: "All Scheduled Orders" pill, calendar icon "Wednesday May 08/2024" (active/selected), then day pills "Mon. May 06/2024 (1000 / 5000)", "Tue. May 07/2024 (1000 / 5000)", "Wed. May 08/2024 (1000 / 5000)" (highlighted white/active), "Thu. May 09/2024 (1000 / 5000)", "Fri. May 10/2024 (1000 / 5000)".
- Controls: Grey/disabled "Export and/or Release To Production" button top left.
- Table: Columns: E | R | (expand) | Ship Date | Production Date | Order # | Customer Name | Gauge / Color | PO | Salesman | Ship Via | Priority | Reviewed | Status | Loc. | Order Notes. 8 rows visible, all Production Date Wed. May 08/2024: 330605 H F H Inc, "NOW" priority (red); 330609 Arnold Contracting, "ASAP" (orange); 330615 DAP Roofing Inc., "ASAP" (yellow-orange); 330616 Arnold Contracting, "By 10:00" (yellow); 330617 Ontario Metal Products Ltd., "By 3:00" (yellow); 330618 A.W.C., "Select Priority"; 330622 Ontario Metal Products Ltd., "Select Priority"; 330629 Ontario Metal Products Ltd. (partially visible at bottom edge), "Select Priority".
- Indicators: Priority pills color-coded: NOW=red, ASAP=orange/yellow-orange, By 10:00/By 3:00=yellow. Order Notes red dot (330605), green dots (330616, 330618).
- Dialog/popup: none.
- Notes: Day pills show capacity fractions "(1000 / 5000)" for each day.
- Verified: pass3

###### Screen (503,406) — Expanded order 330615, Select Supplier/Create Cutlist active, all rows checked
- File: `p2_041_x503_y406.png`
- Illustrates: "As soon as the Manager selects at least 1 line item, then the Select Supplier / Coil Number and Create Cutlist buttons become available." (540,467)
- Header/tabs: Same day-strip/tab layout as Screen (475,392); Scheduled tab active, Wed. May 08/2024 selected; row 330615 DAP Roofing Inc. expanded (330605, 330609 collapsed above it).
- Controls: Green "Select Supplier / Create Cutlist" button, enabled.
- Table: Columns Qty Ordered | # From Stock | Qty To Produce | Product ID | Description | Length | Supplier / Coil Number | Line Item Notes. Rows: 14/—/14/MDR9822/"18'11" (227") 29Ga. 36" Diamond Rib Ebony"/227"/Undefined / Undefined/Notes, checked; 21/—/21/MDR9822/"11'1" (133")…"/133"/Undefined / Undefined/Notes(red), checked; 38/—/38/MTR8307/"12'8" (152") 29Ga. 36" Tuff Rib Melcher's Green"/152"/Undefined / Undefined/Notes, checked (orange divider follows); 16/—/16/MTR8317/"18'0" (96") 29Ga. 36" Tuff Rib White White"/96"/Undefined / Undefined/Notes(green), checked.
- Indicators: Red Notes dot on row 2, green Notes dot on row 4; all four checkboxes checked (unlike the 3-of-4 variant at Screen (593,406)).
- Dialog/popup: none.
- Notes: differs from Screen (593,406) — here all 4 line items are checked, not 3.
- Verified: pass3

###### Screen (503,424) — Expanded order 330615, Select Supplier/Create Cutlist active, all rows checked (duplicate)
- File: `p2_045_x503_y424.png`
- Illustrates: Same as Screen (503,406).
- Header/tabs: Identical to Screen (503,406) (`p2_041_x503_y406.png`) — confirmed by opening both; row 330615 DAP Roofing Inc. expanded, same 4-row line-item table, all 4 checkboxes checked, buttons enabled.
- Controls: Same as Screen (503,406).
- Table: Same as Screen (503,406).
- Indicators: Same as Screen (503,406).
- Dialog/popup: none.
- Notes: not the same as Screen (593,406) — that file is the Coils tab, not this table.
- Verified: pass3

###### Screen (503,440) — Expanded order 330615 detail, all rows checked (duplicate)
- File: `p2_048_x503_y440.png`
- Illustrates: Same as Screen (503,406).
- Header/tabs: Identical to Screen (503,406) (`p2_041_x503_y406.png`) — confirmed by opening both; order 330615 DAP Roofing Inc. expanded with same 4-row MDR9822/MTR8307/MTR8317 table, all 4 checkboxes checked, buttons enabled.
- Controls: Same as Screen (503,406).
- Table: Same as Screen (503,406).
- Indicators: Same as Screen (503,406).
- Dialog/popup: none.
- Notes: not the same as Screen (593,406) — that file is the Coils tab.
- Verified: pass3

###### Screen (503,456) — Expanded order 330615 detail, all rows checked (duplicate)
- File: `p2_052_x503_y456.png`
- Illustrates: Same as Screen (503,406).
- Header/tabs: Identical to Screen (503,406) (`p2_041_x503_y406.png`) — confirmed by opening both; order 330615 DAP Roofing Inc. expanded, same 4-row MDR9822/MTR8307/MTR8317 table, all 4 checkboxes checked, buttons enabled.
- Controls: Same as Screen (503,406).
- Table: Same as Screen (503,406).
- Indicators: Same as Screen (503,406).
- Dialog/popup: none.
- Notes: not the same as Screen (593,406) — that file is the Coils tab.
- Verified: pass3

###### Screen (516,427) — Line Item Note popup (Manager note, unread)
- File: `p2_046_x516_y427.png`
- Illustrates: "The Manager and Workers should be able to add and view Line Item Notes at any point in production..." (526,410)
- Header/tabs: Popup titled "Line Item Note".
- Controls: Red circular "X" and green circular check buttons; text input field placeholder "Leave your note here..." with green send-arrow button at bottom.
- Table: n/a.
- Indicators: none.
- Dialog/popup: "Line Item Note" — avatar "RM" / "Rollforming Manager" / "rollforingmanager@wiseline.ca" [sic] / "Tue. May 07/2024 10:42" / body "Special instructions, talk to manager before rolling" / red X + green check buttons.
- Notes: Email typo "rollforingmanager" (missing "m") transcribed literally.
- Verified: pass3

###### Screen (516,443) — Line Item Note popup, confirmed (green bar)
- File: `p2_050_x516_y443.png`
- Illustrates: "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green." (527,429)
- Header/tabs: Popup titled "Line Item Note".
- Controls: Same as Screen (516,427) except: the red X / green check icon pair is replaced by a single solid green bar (confirmed/read state); text input field still present at bottom.
- Table: n/a.
- Indicators: Solid green bar = read/dealt-with state.
- Dialog/popup: "Line Item Note" — same content (Rollforming Manager, "Special instructions, talk to manager before rolling") shown as resolved.
- Notes: none.
- Verified: pass3

###### Screen (516,459) — Line Item Note popup, two notes (Manager + Worker)
- File: `p2_053_x516_y459.png`
- Illustrates: "If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again." (528,464)
- Header/tabs: Popup titled "Line Item Note".
- Controls: Text input field placeholder "Leave your note here..." with green send button.
- Table: n/a.
- Indicators: First note (Rollforming Manager) shown resolved with solid green bar; second note below it shown unread with red circular "X" and green circular check icons.
- Dialog/popup: "Line Item Note" — Note 1: avatar "RM" / "Rollforming Manager" / "rollforingmanager@wiseline.ca" / "Tue. May 07/2024 10:42" / "Special instructions, talk to manager before rolling" (resolved, green bar). Note 2: avatar "RW" / "Rollforming Worker" / "rollforingworker@gmail.caom" [sic] / "Tue. May 07/2024 2:31" / "Was wrapped with the wrap that doesn't have the logos." / red X + green check (unresolved).
- Notes: Email "rollforingworker@gmail.caom" has a visible typo ("caom" instead of "com"), transcribed literally.
- Verified: pass3

###### Screen (549,393) — Scheduled tab, day strip (top rows)
- File: `p2_039_x549_y393.png`
- Illustrates: "Choose the day you want to work on, this day tab should show your maximum capacity for the day and how much is already assigned to that day." (572,393)
- Header/tabs: Same day strip as Screen (475,392): Wed. May 08/2024 selected, capacities "(1000 / 5000)" shown on each day pill.
- Controls: "Export and/or Release To Production" greyed.
- Table: Full 8-row Scheduled table for Wed. May 08/2024 (330605, 330609, 330615, 330616, 330617, 330618, 330622, and 330629 partially visible at the bottom edge), same columns as Screen (475,392).
- Indicators: All Priority cells show the "Select Priority" placeholder (no NOW/ASAP/By-time badges visible in this crop); Order Notes red dot (330605), green dots (330616, 330618).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (549,405) — Rollforming Scheduled tab
- File: `p2_040_x549_y405.png`
- Illustrates: (543,407)-(548,408) "Click the dropdown for the order you are wanting to review." / (536,403)-(539,405) "Line Item Notes" / (544,416)-(548,418) "We need a distinct line between the different Product IDs."
- Header/tabs: department pill "Rollforming"; top-right "Completed orders for the past 90 days" button; Search box; tab bar Unscheduled, Scheduled (active/white), Production, Queue, Coils, Wrapping; sub-tab bar Tuff Rib & Diamond Rib (active/white), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated, Slit Line; date strip: "All Scheduled Orders", "Wednesday May 08/2024" (calendar icon, active/white), "Mon. May 06/2024 (1000/5000)", "Tue. May 07/2024 (1000/5000)", "Wed. May 08/2024 (1000/5000)", "Thu. May 09/2024 (1000/5000)", "Fri. May 10/2024 (1000/5000)"; greyed/disabled "Export and/or Release To Production" button (green outline, disabled look)
- Table: columns E | R | (expand) | Ship Date | Production Date | Order # | Customer Name | Gauge/Color | PO | Salesman | Ship Via | Priority | Reviewed | Status | Loc. | Order Notes. Rows: Thursday, May 09/2024 | Wed. May 08/2024 | 330605 | H F H Inc | 29Ga. Black / 26Ga. Black | ABC 123 | Joel Thieseen | Pickup | Select Priority | | | | Notes (red dot); Thursday, May 09/2024 | Wed. May 08/2024 | 330609 | Arnold Contracting | 26GA. Ebony | ABC 123 | Henry Goertzen | Pickup | Select Priority | | | | Notes; Thursday, May 09/2024 | Wed. May 08/2024 | 330615 | DAP Roofing Inc. | 29Ga. Ebony / 29Ga. Melcher's Green / 29Ga. White White | ABC 123 | Jake Fehr | Delivery | Select Priority | | | | Notes; Thursday, May 09/2024 | Wed. May 08/2024 | 330616 | Arnold Contracting | 29Ga. Black | ABC 123 | Jake Fehr | Pickup | Select Priority | | | | Notes (green dot); Thursday, May 09/2024 | Wed. May 08/2024 | 330617 | Ontario Metal Products Ltd. | 29Ga. Black | ABC 123 | Jacob Redecop | Delivery | Select Priority | | | | Notes (5 rows visible)
- Indicators: Order Notes "Notes" button has a red dot badge on row 330605, green dot badge on row 330616; E checkboxes empty/enabled (green outline) on all rows, R checkboxes empty but greyed/disabled-looking; "Export and/or Release To Production" button greyed/disabled
- Dialog/popup: none
- Notes: "Wed. May 08/2024" date pill in date strip is white/active (selected); Product ID/Gauge-Color cell for order 330615 lists three colors stacked, consistent with annotation about needing a distinct line between Product IDs
- Verified: pass3

###### Screen (549,413) — Expanded order 330618, Select Supplier inactive
- File: `p2_043_x549_y413.png`
- Illustrates: "As soon as the Manager selects at least 1 line item, then the Select Supplier / Coil Number and Create Cutlist buttons become available." (540,467); "If a line item's Status is Stock, then there is no coil or slit icon and no check box for that line item." (542,453)
- Header/tabs: Same day-strip/tab layout as Screen (475,392); row 330618 A.W.C. expanded.
- Controls: Grey/disabled "Select Supplier / Coil Number" and "Create Cutlist" buttons — no line items are checked.
- Table: Columns (coil icon) | (checkbox) | Qty Ordered | # From Stock | Qty To Produce | Product ID | Description | Length | Supplier/Coil Number | Line Item Notes. 8 rows, all with coil icon + unchecked checkbox, no Stock badge visible in this crop: 8/—/8/MDR8317/189"/Undefined / Undefined/Notes; 25/—/25/MDR8317/160"/Undefined / Undefined/Notes(red); 12/—/12/MDR8317/126"/Undefined/Undefined/Notes; 14/—/14/MTR8262/174"/Undefined/Undefined/Notes(green); 3/—/3/MTR8262/147"/Undefined/Undefined/Notes; 16/—/16/MTR8306/192"/Undefined/Undefined/Notes; 28/—/28/MTR8306/135"/Undefined/Undefined/Notes; 22/—/22/MTR8306/100"/Undefined/Undefined/Notes.
- Indicators: red Notes dot row 2, green Notes dot row 4; header row 330618 has a green Order Notes dot.
- Dialog/popup: none.
- Notes: the Stock-status row (3/3/0, yellow "Stock" badge, no coil icon/checkbox) does NOT appear here — that row is at Screen (549,450)/`p2_051_x549_y450.png` instead, where row "3" reads 3/3/0 with the Stock badge and row "28" reads 28/2/26.
- Verified: pass3

###### Screen (549,424) — Scheduled tab, top rows (abbreviated)
- File: `p2_044_x549_y424.png`
- Illustrates: Same as Screen (549,393).
- Header/tabs: Same day-strip/tab layout as Screen (475,392), no row expanded.
- Controls: Greyed "Export and/or Release To Production" button.
- Table: Top rows only (330605, 330609, 330615, 330616, 330617) of the Scheduled table, same columns as Screen (475,392).
- Indicators: Order Notes red dot (330605), green dot (330616); Priority cells show "Select Priority" placeholder (no NOW/ASAP badge visible in this crop).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (549,432) — Expanded order 330618, Select Supplier inactive (duplicate)
- File: `p2_047_x549_y432.png`
- Illustrates: Same as Screen (549,413).
- Header/tabs: Identical to Screen (549,413) (`p2_043_x549_y413.png`) — confirmed by opening both; row 330618 A.W.C. expanded, same 8-row table (no Stock badge in this crop), all checkboxes unchecked, buttons greyed/disabled.
- Controls: Same as Screen (549,413).
- Table: Same as Screen (549,413).
- Indicators: Same as Screen (549,413).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (549,442) — Scheduled tab, top rows (abbreviated, duplicate)
- File: `p2_049_x549_y442.png`
- Illustrates: Same as Screen (549,393).
- Header/tabs: Identical to Screen (549,424) (`p2_044_x549_y424.png`) — confirmed by opening both; top rows only, no row expanded.
- Controls: Greyed "Export and/or Release To Production" button.
- Table: Same top-rows table as Screen (549,424).
- Indicators: Same as Screen (549,424).
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (577,372) — Scheduled tab, Select Supplier/Create Cutlist greyed
- File: `p2_038_x577_y372.png`
- Illustrates: "Viewing Partial Order" (569,369); "When viewing a partially scheduled order in the Scheduled tab, the line items that are still unscheduled or scheduled to a different day should appear but be grayed out and completely uneditable." (569,379)
- Header/tabs: Tab bar Unscheduled / **Scheduled** (active) / Production / Queue / Coils / Wrapping; day strip "Wednesday May 08/2024" selected; order 330605 expanded.
- Controls: "Select Supplier / Create Cutlist" button greyed/disabled.
- Table: Columns Qty Ordered | # From Stock | Qty To Produce | Product ID | Description | Length | Supplier / Coil Number | Line Item Notes. Rows: 12/—/12/MDR8262/"11'1" (133") 29Ga. 36" Diamond Rib Black"/133"/Undefined / Undefined/Notes; 25/—/25/MDR8262/"16'8" (200")…"/200"/Undefined / Undefined/Notes (orange divider); remaining 3 rows (5/16/15, MTR268262) shown greyed/dimmed as not-yet-scheduled-for-this-day.
- Indicators: Grey text for the not-yet-scheduled MTR268262 rows.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (686,472) — Rollforming / Scheduled tab list
- File: `p2_109_x686_y472.png`
- Illustrates: (717,366)-(721,368) "Rollforming Scheduled"
- Header/tabs: Rollforming pill; "Completed orders for the past 90 days" button; tabs Unscheduled/Scheduled(active)/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line(active, boxed); search box
- Controls: greyed "Release To Production" button; date strip "All Scheduled Orders", calendar icon "Wednesday May 08/2024" (active/boxed), Mon May 06/2024 (1000/5000), Tue May 07/2024 (1000/5000), Wed May 08/2024 (1000/5000), Thu May 09/2024 (1000/5000), Fri May 10/2024 (1000/5000)
- Table: columns Ship Date, Production Date, Order #, Customer Name, Requested By, Gauge/Color, Priority, Reviewed, Status, Loc., Order Notes. Rows: Thursday May 09/2024 | Wed. May 08/2024 | 330605 | H F H Inc | Sales Order icon | 29Ga. Black/26Ga. Black | Select Priority | | | | Notes(red dot); Thursday May 09/2024 | Wed. May 08/2024 | 330609 | Arnold Contracting | Standing Seam icon | 26GA. Ebony | Select Priority | | | | Notes
- Indicators: red dot badge on first row's Notes button
- Notes: none
- Verified: pass3

###### Screen (602,539) — Rollforming / Coils tab — coil lookup popup ("29ga. White White Coils")
- File: `p2_115_x602_y539.png`
- Illustrates: (600,531)-(605,533) "How this list of coil is created"; (682,502)-(693,508) "Here"
- Header/tabs: same header/tab bar as above (Scheduled active, Tuff Rib & Diamond Rib active)
- Table (background, partly obscured): E/R checkbox cols, Ship Date, Production Date, Order#, Customer Name, Gauge/Color, PO, Salesman, Ship Via, Priority, Reviewed, Status, Loc., Order Notes — 330605 H F H Inc, 330609 Arnold Contracting, 330615 DAP Roofing Inc.
- Dialog/popup: Left panel titled "29ga. White White Coils" — table columns ID, Description; rows CS148317 "29ga x 14-1/8" BB Coil White White", CS218317 "29ga x 21-1/4" SS Coil White White", CS438317 WHITE WHITE "29ga x 43" Coil White White", CS448317 WHITE WHITE "29ga x 44.72" Coil White White", CS8317 WHITE WHITE "29ga x 41.2" Coil White White" (row selected/highlighted blue). Right panel titled "CS8317 WHITE WHITE - 29ga. X 41.2" Coil White White" — table columns Lot Number, On Hand, Received, Shipped, Processed, Lot Date; rows: EP8C39C01 4,108.737864/—/—/4,108.737864/12-11-25; EP8C39C02 8,464.000000/—/—/8,464.000000/12-11-25; EP8C39C03 4,108.737864/.../12-11-25; EP8C39C04 8,464.000000/.../12-11-25; EP8C39C05 8,464.000000/.../12-11-25; EP8C39C06 4,050.000000/4,050.000000/12-11-25; F6786659 —/—/26.193333/—; F7350023 83.427884/—/83.427884/11-25-25; F7350025 3,392.534175/17.660000/3,392.534175/02-19-26; F7350026 3,071.698501/285.870000/3,071.698501/02-19-26; FNJ4150C03 4,516.019417/.../01-22-25; FNJ4151C04 644.315918/.../01-22-25; FOF4209C01 3,322.379741/.../09-08-25. Close button: red "X" top-right
- Notes: 13 rows visible in right table (EP8C39C01-06, F6786659, F7350023, F7350025, F7350026, FNJ4150C03, FNJ4151C04, FOF4209C01)
- Verified: pass3

###### Screen (610,574) — EBMS Products window, Production tab, Rollforming production type
- File: `p2_118_x610_y574.png`
- Illustrates: (469,614)-(471,615) "Product ID in EBMS"
- Header/tabs: Window title "Products\Meta\Dia. Rib Siding 29Ga. Classic/Txt.\{FEET}' {INCHES}" ({Height}") 29Ga. 36" Diamond Rib White White"; Product MDR8317; Category Dia. Rib Siding 29Ga. Classic/Txt.; sub-tabs include Production(active, rightmost visible before overflow arrows)
- Controls: Production Type dropdown = "Rollforming" (highlighted blue); Color field = "White White"; Gauge field = "29"; OK/Cancel/New/Delete/Print buttons bottom-right
- Notes: native EBMS window, mostly blank body below the 3 fields
- Verified: pass3

###### Screen (610,589) — EBMS Products window (Coil product), Production tab
- File: `p2_119_x610_y589.png`
- Illustrates: (615,581)-(621,583) "Any Product ID in EBMS that has a Production Type of Coil, and the same Color and Gauge as the Product ID that you are creating a cutlist for would then be pulled into this coil list."
- Header/tabs: Window title "Products\Coil Folder\Tuff Rib & Diamond Rib Coils\29 Ga. 41" Coils\29ga x 41.2" Coil White White"; Product CS8317 WHITE WHITE; Category "29 Ga. 41" Coils"; sub-tabs include Lots, Component of (differ from prior window); Production tab active
- Controls: Production Type dropdown = "Coil" (highlighted blue); Color = "White White"; Gauge = "29"
- Notes: native EBMS window
- Verified: pass3


#### Exporting and/or Releasing Orders to Production
Heading "Exporting and/or Releasing Orders to Production" (560, 593).

- "The check boxes to select orders to Export and Release To Production should only become available once the order has been checked as reviewed." (543, 590)
- "The Export and/or Release To Production button should only become available when you have selected at least one order to Export or Release." (544, 599)
- "Selecting "Export" needs to auto select "Release" as well, but selecting "Release" needs to only select "Release"." (542, 607)
- "Select all the orders you want to Export and/or Release To Production, then click the Export and/or Release To Production button." (548, 607)
- "Once an order(s) has been Exported and/or Released To Production, it should indicate that in the in the appropiate column. Also, the Status should change to Not Started." (544, 611)

##### Screens (5)

###### Screen (551,596) — Rollforming / Scheduled, Export/Release button enabled, more rows selected
- File: `p2_080_x551_y596.png`
- Illustrates: "The Export and/or Release To Production button should only become available when you have selected at least one order to Export or Release." (544,599)
- Same as Screen (551,581) except: R checkboxes now checked (green) on rows 330609, 330616, 330617, 330618, 330622, 330629 (330605 and 330615 remain unchecked); E checkboxes checked only on 330609, 330616, 330622, 330629 (330617 and 330618 have R checked but E still unchecked); "Export and/or Release To Production" button now active/enabled (solid green, not italic/greyed); Reviewed icon (document/checkmark) shown for every row; Status column still blank for all rows.
- Verified: pass3

###### Screen (551,610) — Rollforming / Scheduled, order rows exported/released (icons updated, Status populated)
- File: `p2_081_x551_y610.png`
- Illustrates: "Once an order(s) has been Exported and/or Released To Production, it should indicate that in the appropriate column." (544,611)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping; machine sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line. "Export and/or Release To Production" button greyed/disabled (italic). Date strip: All Scheduled Orders, Wednesday May 08/2024 (active), Mon06–Fri10 tabs (1000/5000 each).
- Table: Columns E,R,Ship Date,Production Date,Order #,Customer Name,Gauge/Color,PO,Salesman,Ship Via,Priority,Reviewed,Status,Loc.,Order Notes. Rows: 330605 H F H Inc — E/R plain unchecked checkboxes, Status blank, Notes (red dot). 330609 Arnold Contracting — E arrow/export icon, R stacked-boxes icon, Status "Not Started" (grey). 330615 DAP Roofing Inc. — E/R plain unchecked checkboxes, Status blank. 330616 Arnold Contracting — E/R icons, Status "Not Started" (grey), Notes (green dot). 330617 Ontario Metal Products Ltd. — E/R icons, Status "Not Started" (grey). 330618 A.W.C. — E/R icons, Status "Not Started" (grey), Notes (green dot). 330622 Ontario Metal Products Ltd. — E/R icons, Status "Not Started" (grey). 330629 Ontario Metal Products Ltd. — E/R icons, Status column blank (no badge).
- Indicators: on rows with icons the E/R checkboxes are replaced by an arrow/export icon and a stacked-boxes (package/release) icon; 330605 and 330615 still show plain (unchecked) checkboxes.
- Verified: pass3

###### Screen (602,554) — Rollforming / Scheduled / Tuff Rib & Diamond Rib table with E/R checkbox columns (background of coil popup, no popup)
- File: `p2_116_x602_y554.png`
- Illustrates: no adjacent annotation
- Header/tabs: Rollforming pill; Completed orders (past 90 days) button; tabs Unscheduled/Scheduled(active)/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line; date strip as in Screen (650,484)
- Controls: greyed "Export and/or Release To Production" button
- Table: columns E, R, (blank expand), Ship Date, Production Date, Order #, Customer Name, Gauge/Color, PO, Salesman, Ship Via, Priority, Reviewed, Status, Loc., Order Notes. Rows visible: 330605 H F H Inc 29Ga.Black/26Ga.Black ABC123 Joel Thieseen Pickup Select Priority — Notes(red dot); 330609 Arnold Contracting 26GA.Ebony ABC123 Henry Goertzen Pickup Select Priority — Notes; 330615 DAP Roofing Inc. 29Ga.Ebony/29Ga.Melcher's Green/29Ga.White White ABC123 Jake Fehr Delivery Select Priority — Notes
- Indicators: E/R checkboxes empty (green outline); red dot on row1 Notes
- Notes: identical crop to the background of Screen (602,539)'s coil popup, just without the popup open
- Verified: pass3

###### Screen (650,484) — Rollforming / Scheduled / Tuff Rib & Diamond Rib table with E/R checkbox columns
- File: `p2_111_x650_y484.png`
- Illustrates: (601,345)-(605,348) "The Gauge / Color column would have to update to show only the gauge & color that is valid after splitting the order." (nearest); also see (546,703) area not applicable — closest relevant annotation region is Export section text near x600
- Header/tabs: Rollforming pill; Completed orders (past 90 days) button; tabs Unscheduled/Scheduled(active)/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line; date strip as above
- Controls: greyed "Export and/or Release To Production" button
- Table: columns E, R, (blank expand), Ship Date, Production Date, Order #, Customer Name, Gauge/Color, PO, Salesman, Ship Via, Priority, Reviewed, Status, Loc., Order Notes. Rows: 330605 H F H Inc 29Ga.Black/26Ga.Black ABC123 Joel Thieseen Pickup Select Priority — Notes(red dot); 330609 Arnold Contracting 26GA.Ebony ABC123 Henry Goertzen Pickup Select Priority — Notes; 330615 DAP Roofing Inc. 29Ga.Ebony/29Ga.Melcher's Green/29Ga.White White ABC123 Jake Fehr Delivery Select Priority — Notes; 330616 Arnold Contracting 29Ga.Black ABC123 Jake Fehr Pickup Select Priority — Notes(green dot); 330617 Ontario Metal Products Ltd. 29Ga.Black ABC123 Jacob Redecop Delivery Select Priority — Notes
- Indicators: E/R checkboxes empty (green outline); red dot on row1 Notes, green dot on row4 Notes
- Verified: pass3

###### Screen (650,492) — Same as Screen (650,484) except: expanded order 330618 showing line-item detail with "Select Supplier / Coil Number" and "Create Cutlist" buttons
- File: `p2_112_x650_y492.png`
- Illustrates: (601,345)-(605,348) "The Gauge / Color column would have to update to show only the gauge & color that is valid after splitting the order."
- Table (expanded sub-table): columns Qty Ordered, # From Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Rows: 8/—/8 MDR8317 15'9"(189") 29Ga.36" Diamond Rib White White 189" Undefined/Undefined — Notes; 25/—/25 MDR8317 13'4"(160") ... 160" Undefined/Undefined — Notes(red dot); 12/—/12 MDR8317 10'6"(126") ...126" Undefined/Undefined — Notes; 14/—/14 MTR8262 14'6"(174") 29Ga.36" Tuff Rib Black 174" Undefined/Undefined — Notes(green dot); 3/3/0 MTR8262 12'3"(147") ...147" Undefined/Undefined Status="Stock"(yellow) — Notes; 16/—/16 MTR8306 16'0"(192") 29Ga.36" Tuff Rib Charcoal 192" — Notes; 28/2/26 MTR8306 11'3"(135")...135" — Notes; 22/—/22 MTR8306 8'4"(100")...100" — Notes
- Indicators: coil-icon glyphs left of each row (some checked green); orange divider lines between Product ID groups; yellow "Stock" badge
- Controls: "Select Supplier / Coil Number" and "Create Cutlist" buttons (green, enabled)
- Verified: pass3


#### Rescheduling or Unscheduling an Order / Queue
Heading "Rescheduing or Unscheduing an Order" (575, 620), "Queue" label (535, 622).

- "The order Status should remain Not Started until at least one line item on that order has the Status of Rolled or Wrapped. Then, the Status should change to In Progress and remain In Progress until all the line items on that order have the Status of Wrapped. This means that if a line item has Stock as its Status, the order Status will remain Not Started until that line item's Status is changed to Wrapped or another line item on that order is marked as Rolled or Wrapped." (540, 625)
- "As soon as a Location has been added to a line item it should display it here." (575, 627)
- "Choose the Machine's Queue that you want to work with." (497, 627)
- "If the Manger has assigned a Supplier and/or Coil Number to an order, then those need to be locked. To change them the Manager would have to go back into the order and change it there. If the Supplier and/or Coil Number is left as Undefined in the order, then we need to be able to assign one here if so desired but still remain unlocked so is can be changed it needed." (529, 628)
- "If an order has NOT been Release To Production yet, we need to be able to reschedule it to another day or unschedule that order." (583, 629)
- "As orders are Released to Production the materials need to be added to the Queue. This Queue needs to be a list of materials (coils) that is sorted by looking at the Production Date, Color & Gauge, Profile, Priority, Supplier, Coil Number and if there is a Cutlist Request or is it just coming from a coil. When all these match within Released Orders then it should combine the Linear Feet and display it as 1 row." (493, 630)
- "Clicking this button opens the calendar." (594, 633)
- "We need a distinct line between each Production Date." (499, 635)
- "The Queue needs to always sort by Production Date. The Manager needs to be able to drag and drop these material lines to rearrange them within there Production Date, can NOT be dragged across the "line"." (530, 641)
- "When you expand an order, you should be able to see the Status of each individual line item." (575, 644)
- "Here you would be able to reschedule the order to another day or unschedule that order. If you unschedule the order then it disappears from the scheduled tab and reappears in the unscheduled tab like a new order again. Rescheduling and Unscheduling an order also resets any edits that the Manager had already made to the order." (589, 646)
- "After an order has been Released To Production, then the Select Supplier / Coil Number and Create Cutlist button should disappear, and this See Packages button should appear." (541, 647)
- "Cutlist requests within the Queue" (496, 652); "Priorities Within the Queue" (513, 654)
- "Clicking the See Packages button open this window." (549, 654)
- "Even if a line has a Priority assigned to it, the Manager still needs to be able to rearange the order of the lines." (498, 662)
- "In this window the Manager would be able to see the packages that have been created by the Worker and the locations as the Worker wraps those packages." (543, 662)
- "If the Manager requests a material to be slit, then the Queue needs an icon showing that that material is waiting for the Slit Line to slit it. The Supplier and Coil Number need to be locked and say waiting for Slit Line. Once the Slit Line Worker marks the material as slit then the Supplier and Coil Number from the Slit Line will be automatically be filled in here in the Queue and the icon will change, showing that this material has been slit." (482, 666)

##### Screens (12)

###### Screen (457,655) — Rollforming Queue tab, waiting-for-Slit-Line variant
- File: `p2_024_x457_y655.png`
- Illustrates: "As orders are Released to Production the materials need to be added to the Queue..." (493,630); "The Queue needs to always sort by Production Date..." (530,641)
- Header/tabs: Tab bar: Unscheduled, Scheduled, Production, **Queue** (active), Coils, Wrapping. Machine sub-tabs: **Tuff Rib & Diamond Rib** (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated.
- Controls: none visible (read-only queue list).
- Table: Columns: Production Date | Material | Profile | L/F | Weight | Priority | Supplier | Coil Number | Slit Line. Rows (all Wednesday, May 08/2024 except last two Thursday May 09/2024): CS8317 White White/Diamond Rib/459/940/—/"waiting for Slit Line..." (locked)/"waiting for Slit Line..." (locked)/orange scissor icon; CS8317 White White/Diamond Rib/915/1874/—/Undefined/—/—; CS8262 Black/Tuff Rib/1476/3023/—/Undefined/—/—; CS9822 Ebony/Tuff Rib/732/1500/—/Cascadia (locked)/EP9C534C02 (locked)/—; CS269822 Ebony/Tuff Rib/245/586/—/Cascadia (locked)/—/—; CS268262 Black/Diamond Rib/231/552/—/Undefined/—/—; CS8306 Charcoal/Reversed Diamind [sic] Rib/832/1705/—/Undefined/—/—; CS8307 Melcher's Green/Tuff Rib/591/1211/—/Undefined/—/—; CS8315 Tan/Reversed Diamind Rib/832/1705/—/Color Steel (locked)/F7343659 (locked)/—; CS8326 Coffee Brown/Tuff Rib/591/1211/—/Cascadia (locked)/FOK4183C01 (locked)/—; CS268326 Coffee Brown/Tuff Rib/591/1414/—/Undefined/— (12 rows shown; more below the crop edge).
- Indicators: Lock icons next to Supplier/Coil Number cells that have been assigned or are waiting on Slit Line; orange scissor icon on first row = waiting for Slit Line.
- Dialog/popup: none.
- Notes: Priority column empty for all visible rows.
- Verified: pass3

###### Screen (457,669) — Rollforming Queue tab, sliced variant
- File: `p2_025_x457_y669.png`
- Illustrates: same as Screen (457,655).
- Header/tabs: Same tab bar and machine sub-tabs as Screen (457,655), Queue active.
- Controls: none visible (read-only queue list).
- Table: Same columns as Screen (457,655). First row differs: CS8317 White White/Diamond Rib/459/940/—/"Taylor" (locked)/"7350025A" (locked)/green scissor icon (already slit, not waiting). Remaining rows match Screen (457,655): CS8317 White White/Diamond Rib/915/1874; CS8262 Black/Tuff Rib/1476/3023; CS9822 Ebony/Tuff Rib/732/1500/Cascadia (locked)/EP9C534C02 (locked); CS269822 Ebony/Tuff Rib/245/586/Cascadia (locked); CS268262 Black/Diamond Rib/231/552; CS8306 Charcoal/Reversed Diamind Rib/832/1705; CS8307 Melcher's Green/Tuff Rib/591/1211; CS8315 Tan/Reversed Diamind Rib/832/1705/Color Steel (locked)/F7343659 (locked); CS8326 Coffee Brown/Tuff Rib/591/1211/Cascadia (locked)/FOK4183C01 (locked); CS268326 Coffee Brown/Tuff Rib/591/1414 (12 rows shown; more below the crop edge).
- Indicators: Green scissor icon on first row (already slit); lock icons on assigned Supplier/Coil Number cells elsewhere.
- Dialog/popup: none.
- Notes: Priority column empty for all visible rows.
- Verified: pass3

###### Screen (505,625) — Rollforming Queue tab, Tuff Rib & Diamond Rib
- File: `p2_084_x505_y625.png`
- Illustrates: "As orders are Released to Production the materials need to be added to the Queue..." (493,630)
- Header/tabs: Rollforming pill; tab bar Unscheduled/Scheduled/Production/**Queue**(active)/Coils/Wrapping; machine sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated.
- Controls: Search box top right.
- Table: Columns: Production Date, Material, Profile, L/F, Weight, Priority, Supplier, Coil Number, Slit Line. Rows (12 of more visible): Wed May 08/2024 | CS8317 White White | Diamond Rib | 585 | 1198 | | Taylor 🔒 | 7350025 🔒 | . Wed May 08/2024 | CS8317 White White | Tuff Rib | 915 | 1874 | | Undefined | | . Wed May 08/2024 | CS8262 Black | Tuff Rib | 1476 | 3023 | | Undefined | | . Wed May 08/2024 | CS9822 Ebony | Tuff Rib | 732 | 1500 | | Cascadia 🔒 | EP9C534C02 🔒 | . Wed May 08/2024 | CS269822 Ebony | Tuff Rib | 245 | 586 | | Cascadia 🔒 | | . Wed May 08/2024 | CS268262 Black | Diamond Rib | 231 | 552 | | Undefined | | . Wed May 08/2024 | CS8306 Charcoal | Reversed Diamind Rib | 832 | 1705 | | Undefined | | . Wed May 08/2024 | CS8307 Melcher's Green | Tuff Rib | 591 | 1211 | | Undefined | | . Wed May 08/2024 | CS8315 Tan | Reversed Diamind Rib | 832 | 1705 | | Color Steel 🔒 | F7343659 🔒 | . Wed May 08/2024 | CS8326 Coffee Brown | Tuff Rib | 591 | 1211 | | Cascadia 🔒 | FOK4183C01 🔒 | . Wed May 08/2024 | CS268326 Coffee Brown | Tuff Rib | 591 | 1414 | | Undefined | | . Thu May 09/2024 | CS268307 Melcher's Green | Diamond Rib | 4934 | 11801 | | Undefined | | . (total visible rows exceed 12; list continues with Thu May 09/2024 CS8317 White White Tuff Rib 861 1764 partially visible.)
- Indicators: lock icons on Supplier/Coil Number cells that are assigned (Taylor/7350025, Cascadia/EP9C534C02, Color Steel/F7343659, Cascadia/FOK4183C01); orange horizontal divider line between Wed May 08 and Thu May 09 groups.
- Notes: "Profile" column has typo "Reversed Diamind Rib" (sic, appears twice).
- Verified: pass3

###### Screen (505,639) — Rollforming Queue tab (same as Screen 505,625)
- File: `p2_087_x505_y639.png`
- Illustrates: same as Screen (505,625)
- Same as Screen (505,625) — identical table/state.
- Verified: pass3

###### Screen (541,639) — Cropped view of order row + expand chevron
- File: `p2_088_x541_y639.png`
- Illustrates: no adjacent annotation
- Header/tabs: top strip cropped, shows partial rows for order 330616/330617 (E/R checkboxes, Production Date "Wed. May 08/2024", Order # 330616/330617/330618), and expanded order 330618 with greyed/disabled "Select Supplier / Coil Number" and "Create Cutlist" buttons and start of line-item table (Qty Ordered/# From Stock/Qty To Produce columns, coil icons, checkboxes).
- Notes: Small cropped fragment, mostly duplicate content of earlier screens.
- Verified: pass3

###### Screen (551,625) — Rollforming Scheduled, Status column with Wrapped/In Progress badges (same as Screen 551,637)
- File: `p2_083_x551_y625.png`
- Illustrates: "Here you would be able to reschedule the order to another day or unschedule that order..." (589,646)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping; machine sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line. "Export and/or Release To Production" button greyed/disabled.
- Table: full table visible (not cropped). Rows: 330605 H F H Inc — Status blank, Notes (red dot). 330609 Arnold Contracting — Status "Wrapped" (green), Loc "1C". 330615 DAP Roofing Inc. — Status blank. 330616 Arnold Contracting — Status "Wrapped" (green), Loc "2D, 2A", Notes (green dot). 330617 Ontario Metal Products Ltd. — Status "In Progress" (yellow). 330618 A.W.C. — Status "In Progress" (yellow), Loc "2B", Notes (green dot). 330622 Ontario Metal Products Ltd. — Status "Not Started" (grey). 330629 Ontario Metal Products Ltd. — Status "Wrapped" (green), Loc "1C".
- Same as Screen (551,637) — identical state and fully visible table (not a partial crop).
- Verified: pass3

###### Screen (551,637) — Rollforming Scheduled, Status column with Wrapped/In Progress badges
- File: `p2_086_x551_y637.png`
- Illustrates: "The order Status should remain Not Started until at least one line item on that order has the Status of Rolled or Wrapped..." (540,625)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping; machine sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line. "Export and/or Release To Production" button greyed/disabled.
- Table (cropped, only top rows visible): 330605 H F H Inc — Status blank, Notes (red dot). 330609 Arnold Contracting — Status "Wrapped" (green), Loc "1C". 330615 DAP Roofing Inc. — Status blank. 330616 Arnold Contracting — Status "Wrapped" (green), Loc "2D, 2A". 330617 Ontario Metal Products Ltd. — Status "In Progress" (yellow); row cut off at bottom edge of crop, rows below (330618, 330622, 330629) not visible in this image.
- Verified: pass3

###### Screen (577,350) — Unscheduled tab, partial-order split state
- File: `p2_037_x577_y350.png`
- Illustrates: "When part of an order has been scheduled, there should be an indication that this order has been split, on both sub-orders." (570,349); "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be grayed out and completely uneditable in the Unscheduled tab." (568,353)
- Header/tabs: Same as Screen (475,300); order 330605 expanded, mouse cursor icon shown at left edge (scissors-like split indicator).
- Controls: "Split Order" button greyed/disabled.
- Table: Same 5-line-item table as Screen (577,297) except: the two MDR8262 rows (12 and 25) are greyed out and their checkboxes/values shown in light grey (uneditable, already scheduled), while the three MTR268262 rows remain black/editable with green checkboxes (5 with green Notes dot, 16, 15).
- Indicators: Greyed text for scheduled-out rows; scissors/split cursor icon at far left; green Notes dot on row "5".
- Dialog/popup: none.
- Notes: none.
- Verified: pass3

###### Screen (589,623) — Rollforming Scheduled, exported/released rows (same state as Screen 551,610)
- File: `p2_082_x589_y623.png`
- Illustrates: "As orders are Released to Production the materials need to be added to the Queue..." (493,630)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping; machine sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated.
- Same as Screen (551,610) — identical state: "Export and/or Release To Production" button greyed/disabled; Status "Not Started" badges on rows 330609, 330616, 330617, 330618, 330622 (330629 Status blank); E/R columns show arrow/export and stacked-boxes icons on those same rows, plain checkboxes on 330605/330615.
- Verified: pass3

###### Screen (589,635) — Rollforming Scheduled, calendar/reschedule popup open
- File: `p2_085_x589_y635.png`
- Illustrates: same as Screen (551,625) / "Here you would be able to reschedule the order to another day or unschedule that order..." (589,646)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping; machine sub-tabs Tuff Rib & Diamond Rib etc.
- Controls: Export/Release greyed. Date strip: All Scheduled Orders, Wednesday May 08/2024 (active), Mon.–Fri. tabs each showing (1000/5000). Calendar popup: month "May 2024" with ‹ › nav arrows; day grid Su Mo Tu We Th Fr Sa with dates 1–31; day "8" highlighted green (selected). Buttons: "Cancel" (white/outline), "Set Date" (green), "Unschedule" (green, full width below).
- Dialog/popup: Calendar popup — month May 2024, dates grid, Cancel / Set Date buttons, Unschedule button.
- Notes: background table rows partially visible with Status column, "Not Started" badges and export/package icons.
- Verified: pass3

###### Screen (730,348) — Rollforming / Unscheduled — row greyed/split-order-completed state
- File: `p2_124_x730_y348.png`
- Illustrates: (722,352)-(728,357) "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be grayed out and completely uneditable in the Unscheduled tab."
- Table: order 330605 row's Gauge/Color now reads "26Ga. Black" only (29Ga. Black portion removed); sub-table for the first two line items (3/MTC128262/300'0"(3600") and 1/MTC128262/100'0"(1200")) shown greyed-out/struck disabled text with empty/unchecked greyed checkboxes and no Notes button, third line item (3/MTC12268262/150'0"(1800")) remains active with green checkbox and enabled Notes button
- Indicators: greyed-out styling on split-scheduled lines; small drag/cursor icon top-left of table
- Verified: pass3

###### Screen (767,300) — Rollforming / Unscheduled — expanded order 330618 with slit detail sub-table
- File: `p2_121_x767_y300.png`
- Illustrates: (679,416)-(684,422) "Once an order is in the Scheduled tab, then it needs to display the line items like this..." (nearest by content, actual coords differ but describes same split-order concept)
- Table: same 11 order rows as Screen (730,300) but row 330618/Friday May 10/2024 (3rd Tuff Rib row) is expanded showing sub-table: columns Gauge/Color, Width, Linear Feet, Supplier/Coil Number — "29Ga. White White | 41" | 7024 | Taylor / 7350025"; then Qty/Length list: 8 | 15'9"(189"); 25 | 13'4"(160"); 12 | 10'6"(126")
- Indicators: red dot Notes badge row1; green dot Notes badge row4 (330616)
- Verified: pass3


#### Overdue Lines / Overdue Orders (Queue)
- "Overdue Lines in the Queue" (513, 671); "Overdue Orders" (560, 674)
- "Overdue lines need to be highlighted." (495, 675)
- "Example: If it is Thursday, May 09/2024 and there are lines from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday lines to be highlighted as overdue." (495, 676)
- "It is Thursday and there are orders that were scheduled for Wednesday that are not completed yet (overdue). The Wednesday tab should then be highlighted in red" (574, 678)
- "Whenever there is an order that is overdue, the day tab that has that order should be highlighted in red. Also, the calendar should be highlighted in red." (545, 679)
- "When you click on the day that has overdue orders within it, then you would see the orders that are overdue highlighted in red." (545, 688)
- "If there are overdue orders for a day that is not displayed in the week tabs then you should still see the highlighted calendar." (574, 700)
- "Clicking this button opens this." (546, 703)
- "The date that has the overdue order should be highlighted in red within the calendar." (574, 704)

##### Screens (15)

###### Screen (505,657) — Rollforming Queue tab with Priority badges (By 10:00, ASAP, By 3:00)
- File: `p2_091_x505_y657.png`
- Illustrates: "Even if a line has a Priority assigned to it, the Manager still needs to be able to rearrange the order of the lines." (498,662)
- Same as Screen (505,625) except: Priority column now populated — row CS9822 Ebony/Tuff Rib shows yellow badge "By 10:00"; row CS268262 Black/Diamond Rib shows orange badge "ASAP"; row CS8317 White White (Thu May 09/2024, Tuff Rib) shows yellow badge "By 3:00".
- Verified: pass3

###### Screen (505,674) — Rollforming Queue, overdue rows highlighted red
- File: `p2_093_x505_y674.png`
- Illustrates: "Overdue lines need to be highlighted." (495,675) / "If it is Thursday, May 09/2024 and there are lines from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday lines to be highlighted as overdue." (495,676)
- Same as Screen (505,657) except: top two rows (Wed May 08/2024, CS8326 Coffee Brown / CS268326 Coffee Brown, Tuff Rib) are highlighted in red (entire row background red) — Supplier Cascadia/FOK4183C01 lock icons still shown; remaining rows (Thu May 09/2024 group) shown normally with "By 3:00" yellow badge on one row.
- Verified: pass3

###### Screen (551,677) — Rollforming Scheduled, Thursday tab active/highlighted red (overdue)
- File: `p2_094_x551_y677.png`
- Illustrates: "It is Thursday and there are orders that were scheduled for Wednesday that are not completed yet (overdue). The Wednesday tab should then be highlighted in red" (574,678)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping; machine sub-tabs.
- Controls: Export/Release greyed. Date strip: "All Scheduled Orders", "Thursday May 09/2024" (calendar icon, highlighted red/active), Mon 06, Tue 07, "Wed. 08/2024 (1000/5000)" highlighted red, Thu 09 (active outline), Fri 10.
- Table: Columns E,R,Ship Date,Production Date,Order #,Customer Name,Gauge/Color,PO,Salesman,Ship Via,Priority,Reviewed,Status,Loc,Order Notes. Rows: 330628 DAP Roofing Inc. | Friday May 10/2024 | Thu May 09/2024 | 26Ga. Melcher's Green | ABC 123 | Jake Fehr | Pickup | Select Priority | | | | Notes (red dot). 330631 A.W.C. | Friday May 10/2024 | Thu May 09/2024 | 29Ga. White White | ABC 123 | Henry Wall | Pickup | Select Priority | | | | Notes. 330632 H F H Inc | Friday May 10/2024 | Thu May 09/2024 | 29Ga. Sepia Brown / 29Ga. Stone Grey | ABC 123 | Joel Thieseen | Delivery | Select Priority | | | | Notes. 330634 Ontario Metal Products Ltd. | Friday May 10/2024 | Thu May 09/2024 | 26Ga. Black | ABC 123 | Henry Goertzen | Pickup | Select Priority | | | | Notes (green dot). 330637 Ontario Metal Products Ltd. | Friday May 10/2024 | Thu May 09/2024 | 29Ga. Charcoal | ABC 123 | Jacob Redecop | Delivery | Select Priority | | | | Notes. 330641 Ontario Metal Products Ltd. | Friday May 10/2024 | Thu May 09/2024 | 29Ga. Black / 29Ga. Ebony | ABC 123 | Jake Fehr | Pickup | Select Priority | | | | Notes (green dot).
- Indicators: red highlight on "Wed. 08/2024" date tab and on "Thursday May 09/2024" active tab; red/green dot badges on Notes buttons.
- Verified: pass3

###### Screen (551,687) — Rollforming Scheduled, Wednesday tab selected showing overdue rows highlighted red
- File: `p2_095_x551_y687.png`
- Illustrates: "When you click on the day that has overdue orders within it, then you would see the orders that are overdue highlighted in red." (545,688)
- Header/tabs: same as Screen (551,677) but "Wednesday May 08/2024" tab now selected/active and highlighted solid red (white bold text on red fill, same style as the Thursday pill), all other day tabs normal.
- Table: 8 rows (330605–330629) same customers/gauges as earlier; rows with unresolved status highlighted red: 330615 DAP Roofing Inc. (Not Started, red row), 330618 A.W.C. (In Progress, Loc 2B, red row), 330622 Ontario Metal Products Ltd. (Not Started, red row); other rows (330605 Notes red dot, Loc 1E; 330609 Wrapped/1C, 330616 Wrapped/2D 2A, 330617 Wrapped/2D, 330629 Wrapped/1C) shown normally (not highlighted).
- Indicators: red row highlighting for overdue/incomplete orders; status badges Wrapped (green), In Progress (yellow), Not Started (grey).
- Verified: pass3

###### Screen (551,699) — Calendar popup showing overdue date "3" highlighted red, selected date "9" highlighted green
- File: `p2_096_x551_y699.png`
- Illustrates: "If there are overdue orders for a day that is not displayed in the week tabs then you should still see the highlighted calendar." (574,700) / "The date that has the overdue order should be highlighted in red within the calendar." (574,704)
- Header/tabs: Rollforming pill; tab bar Unscheduled/**Scheduled**/Production/Queue/Coils/Wrapping; machine sub-tabs.
- Controls: Date strip: "Thursday May 09/2024" tab highlighted red/active; Mon06–Fri10 tabs. Calendar popup: month "May 2024", grid Su-Sa, date "3" highlighted red, date "9" highlighted green (selected/today), Cancel (white) / Set Date (green) buttons.
- Table: background order rows for 330628 (DAP Roofing, red Notes dot), 330631 (A.W.C.), 330632 (H F H Inc), 330634 (green Notes dot), 330637, 330641 (green Notes dot) partially visible.
- Dialog/popup: Calendar — May 2024, date 3 red, date 9 green, Cancel/Set Date buttons.
- Verified: pass3

###### Screen (859,298) — Rollforming / Queue / Tuff Rib & Diamond Rib, row1 waiting for Slit Line
- File: `p2_126_x859_y298.png`
- Illustrates: (883,309)-(892,313) "...The Supplier and Coil Number need to be locked and say waiting for Slit Line. Once the Slit Line Worker marks the material as slit then the Supplier and Coil Number... will be automatically be filled in here in the Queue and the icon will change, showing that this material has been slit."
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Production/Queue(active)/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated; search box; right-side panel "Current Coil In The Rollformer" with blank Supplier/Coil Number/Gauge-Color fields
- Table: same columns as Screen (943,296): checkbox, Production Date, Material, Profile, L/F, Weight, Priority, Supplier, Coil Number, Slit Line. Row1 (CS8317 White White, Diamond Rib, 459/940): Supplier field italic "waiting for Slit Line..." (locked), Coil Number field italic "waiting for Slit Line..." (locked), Slit Line column shows yellow scissors icon; remaining rows unchanged from Screen (943,296) (CS8317 White White 915/1874; CS8262 Black Tuff Rib 1476/3023; CS9822 Ebony Tuff Rib 732/1500 Cascadia(lock) EP9C534C02(lock); CS269822 Ebony Tuff Rib 245/586 Cascadia(lock); CS268262 Black Diamond Rib 231/552; CS8306 Charcoal Reversed Diamind Rib 832/1705; CS8307 Melcher's Green Tuff Rib 591/1211; CS8315 Tan Reversed Diamind Rib 832/1705 Color Steel(lock) F7343659(lock); CS8326 Coffee Brown Tuff Rib 591/1211 Cascadia(lock) FOK4183C01(lock); CS268326 Coffee Brown Tuff Rib 591/1414; CS268307 Melcher's Green Diamond Rib 4934/11801; CS8317 White White Tuff Rib 861/1764 partly cut)
- Indicators: no Priority badges visible in this crop (Priority column blank throughout, unlike Screen (943,296) which shows "By 10:00"/"ASAP"); lock icons on locked Supplier/Coil Number fields; magnifier icon for unlocked rows
- Verified: pass3

###### Screen (859,312) — Rollforming / Queue / Tuff Rib & Diamond Rib, row1 slit completed
- File: `p2_128_x859_y312.png`
- Illustrates: (292 block, p2_292 text) "Once the Slit Line Worker has marked the material as slit, then these slit icons need to change to green and the Supplier and Coil Number that the Slit Line Worker entered needs to auto fill..."
- Header/tabs: same as Screen (943,296): Rollforming pill; Completed orders (past 90 days); tabs Production/Queue(active)/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated; right panel "Current Coil In The Rollformer" blank
- Table: row1 CS8317 White White Diamond Rib 459/940, Supplier "Taylor"(lock), Coil Number "7350025A"(lock), Slit Line column shows green scissors icon (slit completed); remaining rows unchanged from Screen (943,296) (undefined suppliers with magnifier, locked Cascadia/Color Steel rows, etc.)
- Indicators: no Priority badges visible in this crop (Priority column blank throughout)
- Verified: pass3

###### Screen (901,298) — Rollforming / Queue / Tuff Rib & Diamond Rib, base table state (row1 Taylor/7350025, no priority badges)
- File: `p2_127_x901_y298.png`
- Illustrates: no adjacent annotation beyond the general Queue description
- Header/tabs: same as Screen (943,296): Rollforming pill; Completed orders (past 90 days); tabs Production/Queue(active)/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated; search box; right panel "Current Coil In The Rollformer" blank
- Table: same rows as Screen (943,296) — row1 CS8317 White White Diamond Rib 459/940 Taylor(lock) 7350025(lock); remaining rows identical (CS8317 White White 915/1874; CS8262 Black Tuff Rib 1476/3023; CS9822 Ebony Tuff Rib 732/1500 Cascadia(lock) EP9C534C02(lock); CS269822 Ebony Tuff Rib 245/586 Cascadia(lock); CS268262 Black Diamond Rib 231/552; CS8306 Charcoal Reversed Diamind Rib 832/1705; CS8307 Melcher's Green Tuff Rib 591/1211; CS8315 Tan Reversed Diamind Rib 832/1705 Color Steel(lock) F7343659(lock); CS8326 Coffee Brown Tuff Rib 591/1211 Cascadia(lock) FOK4183C01(lock); CS268326 Coffee Brown Tuff Rib 591/1414; CS268307 Melcher's Green Diamond Rib 4934/11801; CS8317 White White Tuff Rib 861/1764 partly cut)
- Indicators: no Priority badges visible in this crop (Priority column blank throughout, unlike Screen (943,296)); lock icons on locked Supplier/Coil Number fields; magnifier icon for unlocked rows
- Verified: pass3

###### Screen (901,312) — Rollforming / Queue / Tuff Rib & Diamond Rib, base table state (same as row1 Taylor/7350025, no scissors icon)
- File: `p2_129_x901_y312.png`
- Illustrates: no distinct nearby annotation; minor state variant
- Header/tabs: same as Screen (943,296): Rollforming pill; Completed orders (past 90 days); tabs Production/Queue(active)/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated; right panel "Current Coil In The Rollformer" blank
- Table: row1 CS8317 White White Diamond Rib 459/940, Supplier "Taylor"(lock), Coil Number "7350025"(lock, no "A" suffix), Slit Line column blank (no scissors icon); remaining rows identical to Screen (943,296)
- Indicators: no Priority badges visible in this crop (Priority column blank throughout); this screenshot's content is effectively identical to Screen (901,298), not a coil-number-appended variant
- Verified: pass3

###### Screen (901,327) — Rollforming / Queue — Lot Number lookup popup for coil in Queue
- File: `p2_130_x901_y327.png`
- Illustrates: (901,325)-(905,327) "This list would show the Lot Numbers conneted to the coil of the row you are working on." (typo "conneted" verbatim)
- Dialog/popup: Title "CS8317 WHITE WHITE - 29ga. X 41.2 Coil White White"; Close red X. Table columns Lot Number, On Hand, Received, Shipped, Processed, Lot Date; same 13 rows as Screen (602,539) coil lookup (EP8C39C01...FOF4209C01)
- Notes: background Queue table partially visible/obscured behind popup
- Verified: pass3

###### Screen (901,343) — Rollforming / Queue / Tuff Rib & Diamond Rib, row2 Supplier auto-filled "Taylor" (unlocked)
- File: `p2_131_x901_y343.png`
- Illustrates: no distinct nearby annotation
- Header/tabs: same as Screen (943,296): Rollforming pill; Completed orders (past 90 days); tabs Production/Queue(active)/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated; right panel "Current Coil In The Rollformer" blank
- Table: row1 unchanged — CS8317 White White Diamond Rib 459/940, Supplier "Taylor"(lock), Coil Number "7350025"(lock); row2 CS8317 White White Diamond Rib 915/1874, Supplier now "Taylor" (dropdown, no lock icon), Coil Number "7350025" (no lock, magnifier icon); remaining rows unchanged from Screen (943,296)
- Indicators: row1 checkbox checked (green), row2 checkbox unchecked; no Priority badges visible in this crop
- Verified: pass3

###### Screen (901,359) — Rollforming / Queue — "Current Coil In The Rollformer" panel filled in, row1 checked
- File: `p2_132_x901_y359.png`
- Illustrates: (902,356)-(907,358) "When you put a coil into the Machine, check off that that coil is now in the Machine."
- Header/tabs: same as Screen (943,296); right panel now reads Supplier: Taylor, Coil Number: 7350025, Gauge/Color: 29Ga. White White (all underlined/filled)
- Indicators: row1 checkbox now checked (green checkmark) vs empty in earlier screens
- Verified: pass3

###### Screen (901,376) — Same as Screen (943,296) except: table scrolled down, rows 9-11 (CS8315 Tan, CS8326 Coffee Brown, CS268326 Coffee Brown) highlighted red, three rows outlined in red box
- File: `p2_133_x901_y376.png`
- Illustrates: (909,373)-(915,374) "Overdue Lines in the Queue" and (892,378)-(899,381) "Example: If it is Thursday, May 09/2024 and there are lines from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday lines to be highlighted as overdue."
- Indicators: red highlight fill across 3 rows (Wed May 08/2024 CS8315 Tan, CS8326 Coffee Brown, CS268326 Coffee Brown), red border box around them
- Verified: pass3

###### Screen (943,296) — Rollforming / Queue / Tuff Rib & Diamond Rib
- File: `p2_125_x943_y296.png`
- Illustrates: (883,309)-(892,313) "If the Manager requests a material to be slit, then the Queue needs an icon showing that that material is waiting for the Slit Line to slit it..."
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Production/Queue(active)/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated; search box; right-side panel "Current Coil In The Rollformer" with blank Supplier/Coil Number/Gauge-Color fields
- Table: columns checkbox, Production Date, Material, Profile, L/F, Weight, Priority, Supplier, Coil Number, Slit Line. 12 rows visible, e.g.: Wed May 08/2024 | CS8317 White White | Diamond Rib | 459 | 940 | — | Taylor(lock icon) | 7350025(lock icon) | —; ...915/1874...; CS8262 Black Tuff Rib 1476/3023; CS9822 Ebony Tuff Rib 732/1500 Priority "By 10:00"(yellow) Cascadia(lock) EP9C534C02(lock); CS269822 Ebony Tuff Rib 245/586 Cascadia(lock); CS268262 Black Diamond Rib 231/552 Priority "ASAP"(orange); CS8306 Charcoal Reversed Diamind Rib 832/1705; CS8307 Melcher's Green Tuff Rib 591/1211; CS8315 Tan Reversed Diamind Rib 832/1705 Color Steel(lock) F7343659(lock); CS8326 Coffee Brown Tuff Rib 591/1211 Cascadia(lock) FOK4183C01(lock); CS268326 Coffee Brown Tuff Rib 591/1414; CS268307 Melcher's Green Diamond Rib 4934/11801 (no priority badge); CS8317 White White Tuff Rib 861/1764 Priority "By 3:00"(yellow) (13th row, partly cut)
- Indicators: yellow "By 10:00" and "By 3:00" priority badges; orange "ASAP" badge; lock icons next to locked Supplier/Coil Number fields; magnifier icon for unlocked rows
- Note: "Profile" column has typos "Reversed Diamind Rib" (verbatim)
- Verified: pass3

###### Screen (1060,504) — Overdue Lines table, two rows highlighted red
- File: `p2_185_x1060_y504.png`
- Illustrates: (909,373)-(915,374) "Overdue Lines in the Queue"; (892,378)-(899,381) "Example: If it is Thursday, May 09/2024 and there are lines from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday lines to be highlighted as overdue."
- Header/tabs: Same header/tab strip; "Current Coil In The Rollformer" panel blank (Supplier/Coil Number/Gauge Color fields empty, underlined placeholders).
- Table: Two rows highlighted in solid red background/border: Wed May 08/2024 330622 Ontario Metal Products Ltd. ABC123 29Ga. Tan/29Ga. Coffee Brown Tuff Rib/Reversed Diamond Rib Jacob Redecop, Coil Number F7343659, FOK4183C01; Wed May 08/2024 330629 Ontario Metal Products Ltd. ABC123 26Ga. Coffee Brown Diamond Rib Jacob Redecop. Below (not highlighted): Thu May 09/2024 330628 DAP Roofing Inc. ABC123 26Ga. Melcher's Green Tuff Rib Jake Fehr; 330631 A.W.C. ABC123 29Ga. White White Tuff Rib Henry Wall; 330635 Ontario Metal Products Ltd. ABC123 29Ga. Black Diamond Rib Jacob Redecop; 330632 A.W.C. ABC123 29Ga. Black/29Ga. Charcoal/29Ga. White White Tuff Rib/Diamond Rib/Reversed Diamond Rib Henry Wall; 330639 Ontario Metal Products Ltd. ABC123 29Ga. Tan/29Ga. Coffee Brown Diamond Rib Jacob Redecop; 330637 Ontario Metal Products Ltd. ABC123 26Ga. Coffee Brown Tuff Rib Jacob Redecop; 330641 DAP Roofing Inc. ABC123 26Ga. Melcher's Green Tuff Rib Jake Fehr; 330645 A.W.C. ABC123 29Ga. White White Tuff Rib Henry Wall.
- Indicators: overdue rows shown with solid red fill and red border, matching the annotation.
- Notes: This is the "overdue rows" screen; it is NOT the Completed Orders tab table (that content lives at Screen (1017,526)/`p2_191`).
- Verified: pass3


#### Manager's view of Production / Wrapping tabs
- "Manager's View of The Production tab" (559, 710)
- "The Production tab will be the same for both the Manager and the Worker." (540, 715)
- "This would be the Manager's view in the Production tab. The Manger would be able to go into any of the Machine tabs and have the same authority as a worker." (540, 718)
- "Manager's View of The Wrapping tab" (559, 725)
- "The Wrapping tab will be the same for both the Manager and the Worker." (541, 730)
- "This would be the Manager's view in the Wrapping tab. The Manger would be able to go into any of the Machine tabs and have the same authority as a worker." (540, 733)

##### Screens (7)

###### Screen (551,714) — Rollforming Production tab
- File: `p2_097_x551_y714.png`
- Illustrates: "This would be the Manager's view in the Production tab. The Manger would be able to go into any of the Machine tabs and have the same authority as a worker." (540,718)
- Header/tabs: Rollforming pill. Tab bar: Unscheduled/Scheduled/**Production**(active)/Queue/Coils/Wrapping. Machine sub-tabs: Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line. Top-right: Search box, "Completed orders for the past 90 days" button, and box "Current Coil In The Rollformer" showing Supplier: Taylor, Coil Number: 7350025 (with copy icon), Gauge/Color: 29Ga. White White.
- Table: Columns: Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location, Coil Number, Source. Rows: Wed May 08/2024 | 330605 | H F H Inc | ABC 123 | 29Ga. Black/26Ga. Black | Tuff Rib/Diamond Rib | Joel Thieseen | | | | | (coil icon). Wed May 08/2024 | 330609 | Arnold Contracting | ABC 123 | 26GA. Ebony | Diamond Rib | Henry Goertzen | | | | | (coil icon). Wed May 08/2024 | 330615 | DAP Roofing Inc. | ABC 123 | 29Ga. Ebony/29Ga. Melcher's Green/29Ga. White White | Tuff Rib/Diamond Rib | Jake Fehr | | | | EP9C534C02 | (coil icon). Wed May 08/2024 | 330616 | Arnold Contracting | ABC 123 | 29Ga. Black | Tuff Rib | Jake Fehr | | | | | (coil icon). Wed May 08/2024 | 330617 | Ontario Metal Products Ltd. | ABC 123 | 29Ga. Black | Tuff Rib | Jacob Redecop | | | | | (coil icon). Wed May 08/2024 | 330618 | A.W.C. | ABC 123 | 29Ga. Black/29Ga. Charcoal/29Ga. White White | Tuff Rib/Diamond Rib | Henry Wall | | | | 7350025 | (scissors icon). Wed May 08/2024 | 330622 | Ontario Metal Products Ltd. | ABC 123 | 29Ga. Tan/29Ga. Coffee Brown | Tuff Rib/Reversed Diamond Rib | Jacob Redecop | | | | F7343659, FOK4183C01 | (scissors icon). Wed May 08/2024 | 330629 | Ontario Metal Products Ltd. | ABC 123 | 26Ga. Coffee Brown | Diamond Rib | Jacob Redecop | | | | | (coil icon). Thu May 09/2024 | 330628 | DAP Roofing Inc. | ABC 123 | 26Ga. Melcher's Green | Tuff Rib | Jake Fehr | | | | | (coil icon). Thu May 09/2024 | 330631 | A.W.C. | ABC 123 | 29Ga. White White | Reversed Diamond Rib | Henry Wall | | | | | (coil icon). (10 rows shown, orange divider line between Wed 08 and Thu 09 groups; total visible count 10.)
- Indicators: orange divider between date groups; scissor vs coil icon in Source column.
- Verified: pass3

###### Screen (551,729) — Rollforming Wrapping tab
- File: `p2_098_x551_y729.png`
- Illustrates: "This would be the Manager's view in the Wrapping tab. The Manger would be able to go into any of the Machine tabs and have the same authority as a worker." (540,733)
- Header/tabs: Rollforming pill. Tab bar: Unscheduled/Scheduled/Production/Queue/Coils/**Wrapping**(active). Machine sub-tabs: Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated (Slit Line not shown in Wrapping). Top-right: Search box, "Completed orders for the past 90 days", "Current Coil In The Rollformer" box (Supplier: Taylor, Coil Number: 7350025, Gauge/Color: 29Ga. White White).
- Table: Columns: Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location (no Coil Number/Source columns here). Rows same order list as Screen (551,714): 330605, 330609, 330615, 330616, 330617, 330618 (Status "In Progress", yellow badge), 330622, 330629, then Thu May 09/2024 group: 330628, 330631.
- Indicators: yellow "In Progress" status badge on order 330618; orange divider line between date groups.
- Verified: pass3

###### Screen (926,463) — Rollforming / Production tab header, "Current Coil In The Rollformer" panel filled
- File: `p2_134_x926_y463.png`
- Illustrates: (1007,312)-(1014,313) "Here in the Production tab you would see what is Currently In The Rollformer via. info from the Queue tab." (cross-reference from Worker column, same concept)
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Production(active)/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line; search box; right panel "Current Coil In The Rollformer": Supplier Taylor, Coil Number 7350025 (with copy icon), Gauge/Color 29Ga. White White
- Verified: pass3

###### Screen (926,482) — Rollforming / Production header/tabs and Current Coil In The Rollformer panel (no table rows)
- File: `p2_136_x926_y482.png`
- Illustrates: no distinct nearby annotation
- Header/tabs: "Rollforming" pill; "Completed orders for the past 90 days" (top right); tabs Production (active) / Queue / Coils / Wrapping; machine sub-tabs Tuff Rib & Diamond Rib (active) / Agra Rib & Titan Rib / Standing Seam / Board & Batten / Corrugated / Slit Line; Search box
- Controls: "Current Coil In The Rollformer" panel: Supplier Taylor, Coil Number 7350025 (copy icon), Gauge / Color 29Ga. White White
- Notes: cropped, no table rows visible
- Verified: pass3

###### Screen (926,504) — Rollforming / Production tab, base 5-row list, Current Coil In The Rollformer panel filled
- File: `p2_138_x926_y504.png`
- Illustrates: no distinct nearby annotation
- Header/tabs: Production (active) tab, Tuff Rib & Diamond Rib (active) sub-tab; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Table: columns Production Date/Order #/Customer Name/PO/Gauge-Color/Profile/Salesman/Priority/Status/Location/Coil Number/Source. 5 rows: 330605 H F H Inc, 330609 Arnold Contracting, 330615 DAP Roofing Inc. (Coil Number EP9C534C02), 330616 Arnold Contracting, 330617 Ontario Metal Products Ltd.
- Verified: pass3

###### Screen (956,521) — Rollforming / Production header/tabs and Current Coil In The Rollformer panel (no table rows)
- File: `p2_140_x956_y521.png`
- Illustrates: no distinct nearby annotation
- Header/tabs: Production (active) tab, Queue/Coils/Wrapping; Tuff Rib & Diamond Rib (active) sub-tab; Search box; "Completed orders for the past 90 days"
- Controls: Current Coil In The Rollformer panel: Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Notes: cropped, no table rows visible
- Verified: pass3

###### Screen (956,542) — Rollforming / Production tab, base 5-row list, Current Coil In The Rollformer panel filled
- File: `p2_142_x956_y542.png`
- Table: same 5-row base list as Screen (926,504) — 330605, 330609, 330615, 330616, 330617; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Verified: pass3


### Rollforming Worker

**Worker's Unscheduled / Scheduled (mirrors Manager view, Worker-restricted)**

- "All Unscheduled" label (786, 232)
- "Scheduling Partial Order" (720, 294)
- "Queue" (911, 292); "Priorities" (931, 294)
- "Cutlist requests within the Queue" (890, 295)
- "Priorities need to show here in the Queue but NOT be sorted by Priority. The Queue for the Worker needs to just be a mirror image of the Queue from the Manager. As the Manager drags lines up and down, these lines in the Worker view need to just follow suit." (935, 297)
- "Sales Order from EBMS vs Material Request from a Rollforming Machine" (754, 297)-(768, 299)
- "If the Manager assigned a Supplier and/or Coil Number to an order, then that needs to be locked so the worker can't edit and has to use the coil the Manager assigned." (925, 299)
- "Chose the Machine you are working with." (895, 299)
- "The check boxes need to only become available if a Supplier and Coil Number are present." (895, 300)
- "Open the dropdown on the order that you want to partially schedule." (725, 301)
- "Line items need to be sorted by Product ID and then have a destinct line between them." (724, 305)
- "Cutlists from a Machine do NOT have a Split Order option." (761, 308)
- "If the Manager requests a material to be slit, then the Queue needs an icon showing that that material is waiting for the Slit Line to slit it. The Supplier and Coil Number need to be locked and say waiting for Slit Line. Once the Slit Line Worker marks the material as slit then the Supplier and Coil Number from the Slit Line will be automatically be filled in here in the Queue and the icon will change, showing that this material has been slit." (883, 309)
- "If the Manager has NOT assigned a Supplier and/or Coil Number to an order, then the Worker needs to choose the Supplier from the drop down and assign the Coil Number of the coil that they will be using." (894, 313)
- "Select the line items you are wanting to schedule." (725, 321)
- "As soon as you select at least 1 line item, then the Split Order button becomes available." (725, 324)
- "This list would show the Lot Numbers conneted to the coil of the row you are working on." (901, 325)
- "Clicking on the search icon (magnifying glass) would open a window with a list of the Lot Numbers." (918, 325)
- "Clicking the Split Order button opens the calendar." (733, 330)
- "Select the Production Date for the selected line items. This will schedule those line items and reset the Split Order function." (725, 339)
- "Clicking on a specific Lot Number would auto fill that number into the Coil Number feild." (918, 341)
- "The Gauge / Color column would have to update to show only the gauge & color that is valid after splitting the order." (754, 346)
- "When part of an order has been scheduled, there should be an indication that this order has been split, on both sub-orders." (723, 348)
- "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be grayed out and completely uneditable in the Unscheduled tab. Once all the line items are Scheduled, the order will disappear in the Unscheduled tab within the Rollforming department (category)." (722, 352)
- "When you put a coil into the Machine, check off that that coil is now in the Machine." (902, 356)
- "When a coil is checked as being in the Machine, then it needs to auto fill the Supplier, the Coil Number and the Gauge & Color into here." (925, 359)
- "Viewing Partial Order" (727, 366)
- "When viewing a partially scheduled order in the Scheduled tab, the line items that are still unscheduled or scheduled to a different day should appear but be grayed out and completely uneditable." (728, 376)
- "Choose the day you want to work on, this day tab should show your maximum capacity for the day and how much is already assigned to that day." (731, 390)
- "Material Request from a Rollforming Machine" (720, 401)
- "Worker Auto Fills line items 1 & 3 and then manually inputs only part of the Qty Ordered for line item 2 and creates the package." (949, 465)
- "If the Qty Ordered and the Left To Package columns are NOT equel, then the Status needs to be In Progress. If the Left To Package column is zero, then the Status needs to be Rolled." (930, 500)
- "For any line that has the Status of Stock, even once the Left To Package column is zero, it needs to stay as Stock and NOT change to In Progress or Rolled. This should just change straight to Wrapped, and that should only happen once the package that it is in gets a location." (941, 521)

**Overdue Lines in the Queue (Worker view)**
- "Overdue Lines in the Queue" (909, 373)
- "Overdue lines need to be highlighted." (893, 377)
- "Example: If it is Thursday, May 09/2024 and there are lines from Wednesday, May 08/2024 that are not complete yet, then we need those Wednesday lines to be highlighted as overdue." (892, 378)

#### Screens (5)

##### Screen (1087,399) — Order expanded, all rows still slit-pending (yellow scissors)
- File: `p2_209_x1087_y399.png`
- Illustrates: (1124,360)-(1131,366) same annotation as Screen (1100,361)
- Header/tabs: 330618 row, top shows Coil Number "waiting..." with a yellow scissors icon top-right.
- Table: Rows 1–4 (MDR8317 ×3, MTR8262 14) show YELLOW scissors icons, Supplier/Coil "waiting.../waiting..." (locked; row 2 has red dot Notes, row 4 has green dot Notes); row 5 (3/3/0 MTR8262) Undefined/Undefined, Status "Stock" (yellow); rows 6–8 (MTR8306) also show YELLOW scissors icons, Supplier/Coil "waiting.../waiting..." (locked).
- Indicators: all rows (except the Stock row) still show yellow (waiting) scissors — none have turned green in this crop, unlike the claim of a fully slit-complete state.
- Verified: pass3

##### Screen (1087,418) — Order expanded, rows 1–3 slit-complete, rows 4 & 6–8 still waiting
- File: `p2_212_x1087_y418.png`
- Illustrates: (1124,360)-(1131,366) same annotation as Screens (1100,361) and (1087,399); "Once the Slit Line Worker has marked the material as slit, then these slit icons need to change to green and the Supplier and Coil Number that the Slit Line Worker entered needs to auto fill into the Supplier and Coil Number fields."
- Header/tabs: 330618 row, top shows Coil Number "7350025A" with green scissors icon and "waiting..." text.
- Table: Rows 1–3 (MDR8317) — GREEN scissors, Supplier/Coil now filled "Taylor/7350025A" (locked padlock); row 4 (MTR8262 14) — still YELLOW scissors, Supplier/Coil "waiting.../waiting..." (locked); row 5 (3/3/0) Status "Stock"; rows 6–8 (MTR8306) — still YELLOW scissors, Supplier/Coil "waiting.../waiting..." (locked), NOT yet filled with Color Steel/F846386.
- Notes: Only the MDR8317 line (rows 1–3) has completed slitting at this point; the MTR8262/MTR8306 lines are still pending, contrary to a claim that all rows were coil-locked with Color Steel values.
- Verified: pass3

##### Screen (1087,436) — Order expanded, all rows green scissors + full coil numbers (final production state)
- File: `p2_215_x1087_y436.png`
- Illustrates: same slit-completion annotations as Screen (1087,418)
- Header/tabs: 330618 row, top shows Coil Numbers "7350025A, F846372, F846386" with green scissors icon.
- Table: All rows now show green scissors icons; Supplier/Coil fully filled: rows 1–3 Taylor/7350025A; row 4 MTR8262 14 Color Steel/F84672 (note: earlier Screen 212 shows this line still "waiting.../waiting...", so this is the first screen where it is filled; also inconsistent as "F84672" vs. "F846372" used elsewhere for the same line — kept verbatim); row 5 Status "Stock"; rows 6–8 MTR8306 Color Steel/F846386.
- Notes: The coil-number inconsistency ("F84672" vs "F846372") for the MTR8262 14-pc line appears to be a typo in the mockup, flagged here rather than corrected.
- Verified: pass3

---

##### Screen (1100,343) — Order 330618 expanded, slit icons yellow (waiting)
- File: `p2_199_x1100_y343.png`
- Illustrates: (1051,333)-(1059,338) "If the Manager assigned a line item to be slit, then that line item needs to have a slit icon in yellow showing that it is waiting to be slit. The Supplier and Coil Number need to be locked... and show waiting..."
- Header/tabs: 330618 row expanded within Production tab; top-right of expanded row shows "waiting..." text and a yellow scissors icon (coil "F846386").
- Table: Expanded detail: Create Packages/Labels, See Packages buttons (green). Rows: 8/‑/8 MDR8317 15'9"(189")... 189" — yellow scissors icon, Supplier/Coil "waiting.../waiting..." (locked); 25/‑/25 MDR8317 13'4"(160")... — yellow scissors, waiting/waiting, red dot on Notes; 12/‑/12 MDR8317 10'6"(126")... — grey dropdown icon, Undefined/Undefined; 14/‑/14 MTR8262 14'6"(174") Tuff Rib Black — grey dropdown icon, Undefined/Undefined, green dot on Notes; 3/3/0 MTR8262 12'3"(147")... — Undefined/Undefined, Status "Stock" (yellow); 16/‑/16, 28/2/26, 22/‑/22 MTR8306 rows — Color Steel/F846386 (locked padlock icons).
- Indicators: yellow scissors = waiting to be slit; padlock icons on locked Supplier/Coil fields.
- Notes: This is the expanded/slit-icon screen; the plain background-only table is at Screen (1100,336)/`p2_198`.
- Verified: pass3

##### Screen (1100,361) — Order expanded, first two rows slit (green scissors)
- File: `p2_203_x1100_y361.png`
- Illustrates: (1111,385)-(1116,389) "Icon showing that material is waiting to be slit also the Coil Numbers are waiting for the Slit Line Worker to mark the material as slit and then it will auto fill."
- Header/tabs: 330618 row expanded; top shows Coil Number "7350025A" and green scissors icon (top-right of row).
- Table: Rows 1–2 (MDR8317: 8, 25) now show GREEN scissors icons and Supplier/Coil Taylor/7350025A (locked); row 3 (12) still shows a grey dropdown icon with Undefined/Undefined (not yet updated); row 4 MTR8262 14 still Undefined/Undefined dropdown, green dot Notes; row 5 MTR8262 3/3/0 Status "Stock"; rows 6–8 MTR8306 still Color Steel/F846386 locked (padlock).
- Indicators: green scissors = material has now been slit (vs. yellow = waiting); row 3 lags behind rows 1–2 in this crop.
- Verified: pass3


### Rollforming Production tab

- "Rollforming Production" (1048, 272)
- "Rollforming Workers should be able to see everything from here down." (1034, 272), label "Rollforming Worker" (1040, 272)
- "All the Worker windows should just be a list of the released uncompleted orders/line items. As the Manager releases orders to production, the new orders should just be added to the windows that the workers are working of off. A Worker should not need to select days of the week, it needs to just be a list. This list of orders needs to always sort primarily by Production Date and then have a distinct line between the different days. See example: ----->" (1045, 276)
- "Machines" tab label (1049, 292); "Priorities" (1070, 294)
- "This tab needs to primarily sort by Production Date and then by Priority" (1100, 296)
- "Workers can NOT change Priorities" (1100, 299)
- "Even though this order has a Priority assigned to it, it gets pushed down as it has a later Production Date than the orders on top of it." (1100, 303)
- Legend numbers on machine tabs: "Rollforming everything off of existing coils" (1035, 308), "1" (1048, 308); "Rollforming material that first has to be slit" (1058, 309), "2" (1052, 309)
- "Here in the Production tab you would see what is Currently In The Rollformer via. info from the Queue tab." (1007, 312)
- "These are the Coil Numbers that the Manager assigned to an order. If the Manager left the Coil Numbers as undefined, then this column would just stay blank." (1040, 313)
- "If the Manager assigned part of of an order to be rolled off of an existing coil and part of that order to be slit, then we need that indicated here. The slit icon needs to be yellow, indicating that it is still waiting for the Slit Line Worker to slit it." (1086, 315)
- "Chose the Machine you are working with." (1011, 315)
- "The Coil Number column should show waiting..., meaning that the material is not slit yet and waiting for the Coil Number to be auto filled from the Slit Line once the Slit Line Worker marks the material as slit." (1086, 321)
- "The Worker would look at what is in the rollformer and chose an order that matches that coil." (1040, 322)
- "Click the drop down to view the order you are about to roll." (1012, 331)
- "Click the drop down to view the order with the Slit request on it." (1055, 331)
- "If the Manager assigned a specific coil to some line items and assigned some line items to be slit, then it needs to show waiting... and the Coil Number for the line item that are just coming from an existing coil." (1125, 332)
- "If the Manager assigned a line item to be slit, then that line item needs to have a slit icon in yellow showing that it is waiting to be slit. The Supplier and Coil Number need to be locked (can NOT be edited by the Worker) and show waiting..., meaning that the material is not slit yet and waiting for the Supplier and Coil Number to be auto filled from the Slit Line once the Slit Line Worker marks the material as slit." (1051, 333)
- "If the Manager assigned a Supplier and/or Coil Number to the order, then that needs to show here and be locked (can NOT be edited by the Worker)." (1010, 333)
- "If a line item's Status is Stock, then there is no coil or slit icon and no drop down for Suppliers." (1010, 337)
- "Expand order to see details." (1096, 343) / (1083, 399)
- "If the Manager did NOT assign a Supplier and/or Coil Number to the order, then the Worker would have to select a Supplier from the drop down and input the Coil Number before being able to put those line items into a package." (1010, 346)
- "We need a copy button for the Coil Number so that the Worker can just copy and paste the Coil Number into the individual line items. The Worker needs to be able to also manually type in the Coil Number." (1040, 347)
- "Once the Slit Line Worker has marked the material as slit, then these slit icons need to change to green and the Supplier and Coil Number that the Slit Line Worker entered needs to auto fill into the Supplier and Coil Number fields." (1086, 349)
- "When part of an order has been assigned a specific coil and part is assigned to be slit" (1079, 361)
- "Once the Slit Line Worker marks the material as slit, then you would see both the Coil Number that the Manager assigned to the line items that are coming off of an existing coil and the Coil Number of the material that was just slit. Also the slit icons need to change to green and the Supplier and Coil Number that the Slit Line Worker entered needs to auto fill into the Supplier and Coil Number fields." (1124, 360)
- "Once the Left To Package column is ALL zeros in the Production tab, then the Status would change from In Progress to Rolled." (1144, 366)
- "Only after a Supplier and Coil Number are present, then the Worker can Create Packages & Print Labels." (1011, 367)
- "If a line item has the Status of Stock, then a Supplier and Coil Number are NOT required." (1043, 372)
- "When multiple materials types need to be slit" (1082, 376)
- "Clicking the Create Packages/Labels button open this." (1019, 381)

#### Screens (37)

##### Screen (972,403) — Rollforming Production tab, header strip
- File: `p2_162_x972_y403.png`
- Illustrates: (1049,292)-(1052,293) "Machines"; (1048,272)-(1052,274) "Rollforming Production" — nearest labels for this header strip
- Header/tabs: Department pill "Rollforming" (active/selected style, top-left). Top-right button "Completed orders for the past 90 days". Sub-tabs: Production (active), Queue, Coils, Wrapping. Machine tabs: Tuff Rib & Diamond Rib (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated, Slit Line. Search box "Search...". "Current Coil In The Rollformer" panel: Supplier: Taylor, Coil Number: 7350025 (with copy icon), Gauge/Color: 29Ga. White White.
- Controls: n/a (header only, no table visible)
- Table: not visible in this crop
- Indicators: none visible
- Notes: This exact header/current-coil strip recurs verbatim across most screens in this batch (163–215 region); later entries reference it as "Same as Screen (972,403)".
- Verified: pass3

##### Screen (972,421) — header strip (duplicate)
- File: `p2_165_x972_y421.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (972,440) — header strip (duplicate)
- File: `p2_170_x972_y440.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (972,482) — header strip (duplicate)
- File: `p2_180_x972_y482.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (972,502) — header strip (duplicate)
- File: `p2_184_x972_y502.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip. (Not the delete confirmation dialog — that is Screen (972,505)/`p2_186`.)
- Verified: pass3

##### Screen (987,521) — header strip (duplicate)
- File: `p2_189_x987_y521.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (1017,312) — Rollforming Production tab, extended list, Priority column empty
- File: `p2_147_x1017_y312.png`
- Illustrates: (473,397) "If orders have Priorities assigned to them then they are sorted primarily by Production Date and secondarily by Priority." — this capture shows the list before any Priority is set.
- Header/tabs: "Rollforming" pill; tabs Production (active) / Queue / Coils / Wrapping; machine sub-tabs Tuff Rib & Diamond Rib (active) / Agra Rib & Titan Rib / Standing Seam / Board & Batten / Corrugated / Slit Line; Search box; "Completed orders for the past 90 days" (top right).
- Controls: "Current Coil In The Rollformer" panel: Supplier Taylor, Coil Number 7350025 (copy icon), Gauge / Color 29Ga. White White.
- Table: Columns: [expand] | Production Date | Order # | Customer Name | PO | Gauge / Color | Profile | Salesman | Priority | Status | Location | Coil Number | Source. Rows (Wednesday, May 08/2024): 330605 H F H Inc, ABC 123, 29Ga. Black / 26Ga. Black, Tuff Rib / Diamond Rib, Joel Thiessen; 330609 Arnold Contracting, 26GA. Ebony, Diamond Rib, Henry Goertzen; 330615 DAP Roofing Inc., 29Ga. Ebony / 29Ga. Melcher's Green / 29Ga. White White, Tuff Rib / Diamond Rib, Jake Fehr, Coil Number EP9C534C02; 330616 Arnold Contracting, 29Ga. Black, Tuff Rib, Jake Fehr; 330617 Ontario Metal Products Ltd., 29Ga. Black, Tuff Rib, Jacob Redecop; 330618 A.W.C., 29Ga. Black / 29Ga. Charcoal / 29Ga. White White, Tuff Rib / Diamond Rib, Henry Wall, Coil Number 7350025; 330622 Ontario Metal Products Ltd., 29Ga. Tan / 29Ga. Coffee Brown, Tuff Rib / Reversed Diamond Rib, Jacob Redecop, Coil Number F7343659, FOK4183C01; 330629 Ontario Metal Products Ltd., 26Ga. Coffee Brown, Diamond Rib, Jacob Redecop; orange divider; (Thursday, May 09/2024) 330628 DAP Roofing Inc., 26Ga. Melcher's Green, Tuff Rib, Jake Fehr; 330631 A.W.C., 29Ga. White White, Reversed Diamond Rib, Henry Wall. Priority, Status and Location columns are empty on every row; Source column shows a coil icon on every row.
- Indicators: orange horizontal rule between the Wednesday and Thursday groups.
- Dialog/popup: none.
- Notes: The version of this list with Priority badges (NOW / ASAP / By 10:00 / By 3:00) is `p2_146_x1076_y296.png`.
- Verified: pass3

##### Screen (1017,324) — Rollforming / Production tab, base 5-row list (not the extended list), Current Coil In The Rollformer panel filled
- File: `p2_149_x1017_y324.png`
- Illustrates: no distinct nearby annotation
- Table: same 5-row base list as Screen (926,504) — 330605, 330609, 330615, 330616, 330617; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Verified: pass3

##### Screen (1017,331) — Rollforming / Production — expanded order 330618, no Status/Coil data yet (base expanded row)
- File: `p2_151_x1017_y331.png`
- Illustrates: (296) "Only after a Supplier and Coil Number are present, then the Worker can Create Packages & Print Labels."
- Table: expanded sub-table for 330618: row1 Taylor/7350025(locked); row2 Taylor/7350025(locked), Notes red dot; rows3-8 Undefined/Undefined; Status column blank except row5 "Stock"(yellow); Notes green dot row4; header order row's Coil Number column already shows "7350025"
- Buttons: Create Packages/Labels, See Packages (green)
- Verified: pass3

##### Screen (1017,343) — Rollforming / Production tab, base 5-row list (not the extended list), Current Coil In The Rollformer panel filled
- File: `p2_153_x1017_y343.png`
- Illustrates: no distinct nearby annotation
- Table: same 5-row base list as Screen (926,504) — 330605, 330609, 330615, 330616, 330617; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Verified: pass3

##### Screen (1017,350) — Same as Screen (1017,331), expanded order 330618 base state repeat
- File: `p2_155_x1017_y350.png`
- Illustrates: no distinct nearby annotation
- Verified: pass3

##### Screen (1017,361) — Rollforming / Production tab, base 5-row list (not the extended list), Current Coil In The Rollformer panel filled
- File: `p2_157_x1017_y361.png`
- Illustrates: no distinct nearby annotation
- Table: same 5-row base list as Screen (926,504) — 330605, 330609, 330615, 330616, 330617; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Verified: pass3

##### Screen (1017,368) — Rollforming / Production — expanded order 330618, rows 1-2 Supplier/Coil Number filled and locked, row3 filled but unlocked
- File: `p2_158_x1017_y368.png`
- Illustrates: no distinct nearby annotation
- Header: order row 330618 A.W.C., header Coil Number "7350025"; buttons Create Packages/Labels, See Packages (green)
- Table: expanded sub-table columns Qty. Ordered, Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Row1 8/—/8 MDR8317 15'9"(189") Taylor/7350025(locked); Row2 25/—/25 MDR8317 13'4"(160") Taylor/7350025(locked), Notes red dot; Row3 12/—/12 MDR8317 10'6"(126") Taylor/7350025(no lock); Row4 14/—/14 MTR8262 14'6"(174") Undefined/Undefined, Notes green dot; Row5 3/3/0 MTR8262 12'3"(147") Undefined/Undefined Status="Stock"(yellow); Rows6-8 MTR8306 16'0"(192")/11'3"(135")/8'4"(100") Undefined/Undefined
- Verified: pass3

##### Screen (1017,383) — Rollforming / Production tab header only, Current Coil In The Rollformer panel filled, no table rows visible
- File: `p2_159_x1017_y383.png`
- Illustrates: (296) "Only after a Supplier and Coil Number are present, then the Worker can Create Packages & Print Labels."
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Production(active)/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line; search box; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Notes: cropped, no table rows visible
- Verified: pass3

##### Screen (1017,403) — Rollforming / Production tab header only, Current Coil In The Rollformer panel filled, no table rows visible
- File: `p2_161_x1017_y403.png`
- Illustrates: (305) "Auto Fill and/or Manually Entering Amounts to Package" (section heading region)
- Header/tabs: identical to Screen (1017,383) — Production(active) tab, Tuff Rib & Diamond Rib(active), Current Coil In The Rollformer panel: Taylor / 7350025 / 29Ga. White White
- Notes: cropped, no table rows visible
- Verified: pass3

##### Screen (1017,422) — Rollforming Production tab, header strip
- File: `p2_166_x1017_y422.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip. (Not a modal/keypad screen despite the coordinate falling in the Auto Fill annotation range.)
- Verified: pass3

##### Screen (1017,444) — header strip (duplicate)
- File: `p2_172_x1017_y444.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (1017,463) — Rollforming Production tab, full order table
- File: `p2_176_x1017_y463.png`
- Illustrates: (1007,312)-(1014,313) "Here in the Production tab you would see what is Currently In The Rollformer via. info from the Queue tab."
- Header/tabs: Same header/tab strip as Screen (972,403).
- Table: Columns: Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location, Coil Number, Source. Rows (5 visible): Wed May 08/2024 330605 H F H Inc ABC123 29Ga. Black/26Ga. Black Tuff Rib/Diamond Rib Joel Thieseen; Wed May 08/2024 330609 Arnold Contracting ABC123 26GA. Ebony Diamond Rib Henry Goertzen; Wed May 08/2024 330615 DAP Roofing Inc. ABC123 29Ga. Ebony/29Ga. Melcher's Green/29Ga. White White Tuff Rib/Diamond Rib Jake Fehr, Coil Number EP9C534C02; Wed May 08/2024 330616 Arnold Contracting ABC123 29Ga. Black Tuff Rib Jake Fehr; Wed May 08/2024 330617 Ontario Metal Products Ltd. ABC123 29Ga. Black Tuff Rib Jacob Redecop. Each row has a Source column icon (coil roll icon).
- Indicators: none highlighted here.
- Verified: pass3

##### Screen (1017,485) — header strip (duplicate)
- File: `p2_181_x1017_y485.png`
- Illustrates: no adjacent annotation
- Identical to Screen (972,482) (`p2_180`) — byte-identical file, same header/current-coil strip. (This is NOT the See Packages modal; that content is at Screens (972,485)/(1017,488), files `p2_182`/`p2_183`.)
- Verified: pass3

##### Screen (1017,507) — header strip (duplicate)
- File: `p2_187_x1017_y507.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip. (Not an Auto Fill modal.)
- Verified: pass3

##### Screen (1039,296) — Rollforming / Production tab, extended list including 330618, 330622, 330629 (with Coil Number/Source data)
- File: `p2_145_x1039_y296.png`
- Illustrates: (1040,313)-(1046,316) "These are the Coil Numbers that the Manager assigned to an order. If the Manager left the Coil Numbers as undefined, then this column would just stay blank."
- Table: 8 rows — 330605 H F H Inc (Tuff Rib/Diamond Rib), 330609 Arnold Contracting (Diamond Rib), 330615 DAP Roofing Inc. (Tuff Rib/Diamond Rib, Coil Number EP9C534C02), 330616 Arnold Contracting (Tuff Rib), 330617 Ontario Metal Products Ltd. (Tuff Rib), 330618 A.W.C. (Tuff Rib/Diamond Rib, Coil Number 7350025), 330622 Ontario Metal Products Ltd. (Tuff Rib/Reversed Diamond Rib, Coil Numbers F7343659, FOK4183C01), 330629 Ontario Metal Products Ltd. (Diamond Rib) — orange divider line after row7; two more fully-visible rows follow: 330628 DAP Roofing Inc., 330631 A.W.C.
- Verified: pass3

##### Screen (1055,444) — header strip (duplicate)
- File: `p2_173_x1055_y444.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (1055,463) — header strip (duplicate)
- File: `p2_177_x1055_y463.png`
- Illustrates: no adjacent annotation
- Same as Screen (972,403) — identical header/current-coil strip.
- Verified: pass3

##### Screen (1059,273) — Rollforming / Production tab full base list
- File: `p2_144_x1059_y273.png`
- Illustrates: (1045,276)-(1055,280) "All the Worker windows should just be a list of the released uncompleted orders/line items..."
- Header/tabs: Production (active) tab, Tuff Rib & Diamond Rib (active) sub-tab; right panel Supplier Taylor, Coil Number 7350025, Gauge/Color 29Ga. White White
- Table: columns Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location, Coil Number, Source. 10 rows visible (same extended list as Screen (1039,296)): 330605 H F H Inc, 330609 Arnold Contracting, 330615 DAP Roofing Inc. (Coil Number EP9C534C02), 330616 Arnold Contracting, 330617 Ontario Metal Products Ltd., 330618 A.W.C. (Coil Number 7350025), 330622 Ontario Metal Products Ltd. (Coil Numbers F7343659, FOK4183C01), 330629 Ontario Metal Products Ltd.; orange divider after row7; then two more fully-visible rows (not cropped): 330628 DAP Roofing Inc., 330631 A.W.C.
- Verified: pass3

##### Screen (1061,312) — Rollforming / Production tab, extended list, Current Coil In The Rollformer panel blank, order 330618 Coil Number "waiting..."
- File: `p2_148_x1061_y312.png`
- Illustrates: (277) "The Coil Number column should show waiting..., meaning that the material is not slit yet..."
- Header/tabs: Production (active), Tuff Rib & Diamond Rib (active); right panel Supplier/Coil Number/Gauge Color all blank (underscores)
- Table: same rows as Screen (1039,296), no Priority badges, except order 330618 row shows italic "waiting..." in the Coil Number column with a yellow scissors icon in Source (instead of the coil icon)
- Verified: pass3

##### Screen (1061,324) — Same base list except: "Current Coil In The Rollformer" panel blank (Supplier/Coil Number/Gauge Color underscores empty)
- File: `p2_150_x1061_y324.png`
- Illustrates: no distinct nearby annotation
- Verified: pass3

##### Screen (1061,331) — Same as Screen (1017,331) except: rows 1 & 2 now show "waiting..." (italic) in Supplier/Coil Number and a yellow scissors icon in Source column top-right; header order row shows "waiting..." text and yellow scissors icon
- File: `p2_152_x1061_y331.png`
- Illustrates: (277) "The Coil Number column should show waiting..., meaning that the material is not slit yet and waiting for the Coil Number to be auto filled from the Slit Line once the Slit Line Worker marks the material as slit."
- Verified: pass3

##### Screen (1061,343) — Rollforming / Production tab, base 5-row list, Current Coil In The Rollformer panel blank
- File: `p2_154_x1061_y343.png`
- Illustrates: no distinct nearby annotation
- Header/tabs: Production (active), Tuff Rib & Diamond Rib (active); right panel Supplier/Coil Number/Gauge Color all blank (underscores)
- Table: same 5-row base list as Screen (926,504) — 330605, 330609, 330615, 330616, 330617
- Verified: pass3

##### Screen (1061,350) — Rollforming / Production — expanded order 330618, slit completed: header + rows 1-2 Coil Number "7350025A", green scissors icons
- File: `p2_156_x1061_y350.png`
- Illustrates: (292) "Once the Slit Line Worker has marked the material as slit, then these slit icons need to change to green and the Supplier and Coil Number that the Slit Line Worker entered needs to auto fill into the Supplier and Coil Number fields."
- Header: order row 330618 A.W.C., header Coil Number "7350025A", green scissors icons (x2) in header Source column; buttons Create Packages/Labels, See Packages (green)
- Table: row1 8/—/8 MDR8317 — green scissors icon in row Source column, Taylor/7350025A(locked); row2 25/—/25 MDR8317 — green scissors icon, Taylor/7350025A(locked), Notes red dot; row3 12/—/12 MDR8317 — Undefined/Undefined; row4 14/—/14 MTR8262 — Undefined/Undefined, Notes green dot; row5 3/3/0 MTR8262 — Undefined/Undefined, Status "Stock"(yellow); rows6-8 MTR8306 — Undefined/Undefined
- Verified: pass3

##### Screen (1076,296) — Rollforming / Production tab, extended list with Priority badges populated
- File: `p2_146_x1076_y296.png`
- Illustrates: (473,397) "If orders have Priorities assigned to them then they are sorted primarily by Production Date and secondarily by Priority." — this capture shows Priority badges filled in.
- Table: same rows/columns as Screen (1039,296), but Priority column now shows badges: 330605 "NOW" (red), 330609 "ASAP" (orange), 330615 "ASAP" (orange), 330616 "By 10:00" (yellow), 330628 "By 3:00" (yellow); remaining rows (330617, 330618, 330622, 330629, 330631) have no Priority badge
- Verified: pass3

##### Screen (1087,380) — Production tab header, plain (Slit Line context)
- File: `p2_206_x1087_y380.png`
- Illustrates: no adjacent unique annotation
- Same as Screen (1100,324)/(1100,355) — Production tab header/blank current coil panel, same background table; 330618 row shows "waiting..." with a yellow scissors icon in the Coil Number/Source column.
- Verified: pass3

##### Screen (1087,392) — Production tab header, plain (duplicate)
- File: `p2_208_x1087_y392.png`
- Illustrates: no adjacent annotation
- Same as Screen (1087,380) — Production tab header/blank current coil panel, same background table.
- Verified: pass3

##### Screen (1087,411) — Production tab header, plain (duplicate)
- File: `p2_211_x1087_y411.png`
- Illustrates: no adjacent annotation
- Same as Screen (1087,380) — Production tab header/blank current coil panel, same background table.
- Verified: pass3

##### Screen (1087,430) — Production tab header, plain (duplicate)
- File: `p2_214_x1087_y430.png`
- Illustrates: no adjacent annotation
- Same as Screen (1087,380) — Production tab header/blank current coil panel, same background table.
- Verified: pass3

##### Screen (1100,324) — Production tab, blank Current Coil panel
- File: `p2_196_x1100_y324.png`
- Illustrates: no directly adjacent annotation within 30pt; nearest is (1035,308)-(1043,309) "Rollforming everything off of existing coils" (labelled "1")
- Header/tabs: Production tab active; "Current Coil In The Rollformer" panel shows empty/blank Supplier, Coil Number, Gauge/Color fields (placeholder underscores).
- Table: Same 8 order rows as earlier Production screens (330605–330631), Coil Number column shows EP9C534C02 for 330615 row only; 330618 row shows a yellow scissors icon and "waiting..." in Coil Number/Source column.
- Indicators: yellow scissors icon on 330618 row signifies slit-pending material.
- Verified: pass3

##### Screen (1100,336) — Production tab, blank state (background table)
- File: `p2_198_x1100_y336.png`
- Illustrates: no directly adjacent unique annotation
- Same as Screen (1100,324) (`p2_196`) — Production tab header with blank Current Coil panel and same background order rows (330605–330617 visible). No order is expanded in this crop.
- Verified: pass3

##### Screen (1100,355) — Production tab, blank state variant
- File: `p2_201_x1100_y355.png`
- Illustrates: no directly adjacent unique annotation
- Same as Screen (1100,324) — Production tab header with blank Current Coil panel and same 5-row background table (330605–330617 visible).
- Verified: pass3


### Auto Fill and/or Manually Entering Amounts to Package
Heading "Auto Fill and/or Manually Entering Amounts to Package" (1003, 400).

- "Clicking the Auto Fill button would automatically fill whatever is in the Left To Package column into the Packaging column." (963, 404)
- "After clicking an Auto Fill button, then it changes to a delete button, which, if clicked would remove the number from the Packaging column." (963, 407)
- "Once you've clicked Auto Fill on 1 of the line items, then only the Auto Fill buttons within that section (same Product ID's) would remain available. The Auto Fill buttons for line items with a different Product ID would become unavailable." (963, 410)
- "Once the Slit Line Worker marks some of the material as slit, then those line items would show that they are slit and the Source column would show that some of the material has been slit and some is still waiting to be slit. The Coil Number of the slit material would appear in the Coil Number column and it would also still show waiting... because some material is still NOT slit." (1078, 414)
- "Enter what you want to package and create a label for." (1029, 421)
- "The Worker does NOT have to use the Auto Fill function, he needs to also be able to just click on a line item within the Packaging column and then manually type in any number between 1 and the number in the Left To Package column." (961, 428)
- "Once the Slit Line Worker has marked all the materials as slit, then the icon would change to fully green and all the Coil Numbers would appear here." (1111, 434)
- "Once at least one number has been entered in the Packaging column, then the Create & Print button becomes available." (1011, 435)
- "This will show the combined weight of the items you are planning to package. We need to be able to set a Max Weight per package (ex. 1,500 lbs)." (1041, 435)
- "Clicking the Create & Print button will create a package, print the label, reset the Packaging column and update the Left to Package column." (1020, 441)
- "Over Weight Packages" heading (1043, 441)
- "If the package you are planning to create is heavier than the Max Weight, this box will be highlighted in red." (1050, 460)
- "If you try to "Create & Print" when the potential package is over the weight limit, you will get a pop up asking if you want to continue with the over weight package. If you agree, it will override the weight limit and create the package and print the label." (1055, 482)
- "The labels should be identified by a code made up of 3 parts. The 1st part is the department (category) ID, the second part is the order number and then the last part is the number of packages for the order, which just keeps counting up as you create packages." (1010, 449)
- "Each department (category) will need to be assigned a unique number code to identify and keep labels separate between departments (categories). Example: Trim - 01 Rollforming - 02 Accessories - 03" (1003, 449)
- "Packaging only part of the Qty Ordered for a line item" (1002, 461)
- "Clicking the See Packages button opens a list of the packages already on the order." (1040, 464) / (1020, 482)
- "Once the Left To Package Column is zero then the Status for that line item automatically changes to Rolled. If the Worker packages only part of the Qty Ordered, then the Status for that line item automatically changes to In Progress." (1009, 464)
- "Deleting a Package" heading (1007, 480)
- "Reprinting Labels" heading (1026, 482)
- "If something was packaged wrong, then we need to be able to delete that package and repackage the items that were in it." (995, 488)
- "Here you can reprint a label for an existing package." (1040, 492)
- "Clicking the Delete button would give you this pop up" (987, 500)
- "Clicking Yes will delete the package and put the number of pcs. that were in the package back into the Left To Package column." (981, 529)
- "Deleting a package will make that package number invalid, if anyone tries to scan the bar code on the deleted label will need to get a messge that this package has been deleted." (980, 536)
- "If the line item that was in the deleted package had a Status of Wrapped already, then after deleting, that Status would have to change back to Rolled again. If the Qty Ordered column and Stock column are equal, then it would have to change back to Stock." (966, 559)

#### Screens (14)

##### Screen (926,466) — Rollforming / Production — Create Packages/Labels popup, first Auto Fill clicked (row1 → Delete)
- File: `p2_135_x926_y466.png`
- Illustrates: (317) "Once at least one number has been entered in the Packaging column, then the Create & Print button becomes available." / (309) "Once you've clicked Auto Fill on 1 of the line items, then only the Auto Fill buttons within that section (same Product ID's) would remain available."
- Header/tabs: background table columns Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location, Coil Number, Source (Rollforming/Slit Line icons)
- Dialog/popup: Title none visible (modal), close red X. Table columns Qty Ordered, Use Stock, Qty To Roll, Left To Package, Packaging, ID, Description, Line Item Notes. Rows (Qty Ordered/Use Stock/Qty To Roll/Left To Package, Packaging blank on all): 8/—/8/8 MDR8317 15'9"(189")...White White — Delete(red) row1; 25/—/25/12 MDR8317 13'4"(160") — Auto Fill(green) row2; 12/—/12/12 MDR8317 10'6"(126") — Delete(red); 14/—/14/14 MTR8262 14'6"(174") Tuff Rib Black — Auto Fill disabled(greyed, red "no" icon); 3/3/0/3 MTR8262 12'3"(147") — Auto Fill(green) enabled; 16/—/16/16 MTR8306 16'0"(192") Tuff Rib Charcoal — Auto Fill disabled; 28/2/26/28 MTR8306 11'3"(135") — Auto Fill disabled; 22/—/22/22 MTR8306 8'4"(100") — Auto Fill disabled
- Footer: Customer Name A.W.C., Order # 330618, PO# ABC 123, Salesman Henry Wall, Ship Date Thursday May 09/2024, Ship Via Delivery, Priority (blank), Location (blank). Buttons: Create & Print (green), weight box "848.72 lbs.", See Packages (green)
- Indicators: red "no-entry" circle icon over Auto Fill for disabled rows (different Product ID group than the one just filled)
- Verified: pass3

##### Screen (926,485) — Rollforming / Production — Create Packages/Labels popup, rows 1 & 3 fully packaged (Left To Package = 0)
- File: `p2_137_x926_y485.png`
- Illustrates: (308) "After clicking an Auto Fill button, then it changes to a delete button, which, if clicked would remove the number from the Packaging column."
- Table: header background only (Production Date/Order #/Customer Name/PO/Gauge-Color/Profile/Salesman/Priority/Status/Location/Coil Number/Source), same as Screen (926,463). Modal rows (Qty Ordered/Use Stock/Qty To Roll/Left To Package): row1 8/—/8/0 MDR8317 15'9"(189") — Auto Fill greyed/disabled; row2 25/—/25/13 MDR8317 13'4"(160") — Auto Fill(green, active); row3 12/—/12/0 MDR8317 10'6"(126") — Auto Fill greyed/disabled; row4 14/—/14/14 MTR8262 14'6"(174") Tuff Rib Black — Auto Fill disabled (red "no" icon); row5 3/3/0/3 MTR8262 12'3"(147") — Auto Fill(green, active); row6 16/—/16/16 MTR8306 16'0"(192") Tuff Rib Charcoal — Auto Fill disabled; row7 28/2/26/28 MTR8306 11'3"(135") — Auto Fill disabled; row8 22/—/22/22 MTR8306 8'4"(100") — Auto Fill disabled
- Buttons: Create & Print still greyed; Package Weight box empty; See Packages green
- Verified: pass3

##### Screen (956,524) — Same as Screen (926,466) modal except: rows 1-5 Left To Package = 0 (Auto Fill greyed/disabled), rows 6-8 Auto Fill now green/enabled (no red "no" icon), Location tags "2C"/"2D" shown
- File: `p2_141_x956_y524.png`
- Illustrates: (312) "Enter what you want to package and create a label for." — rows 1-5 (MDR8317 x3, MTR8262 x2) Auto Fill greyed/disabled, Left To Package 0; rows 6-8 (MTR8306 x3, Left To Package 16/28/22) Auto Fill green/active, no longer showing the red "no" icon; Packaging column empty throughout
- Buttons: Create & Print greyed, Package Weight box empty, See Packages green
- Verified: pass3

##### Screen (972,406) — Auto Fill modal, row 2 packaged via manual entry (25), keypad closed
- File: `p2_164_x972_y406.png`
- Illustrates: (1003,400)-(1013,402) "Auto Fill and/or Manually Entering Amounts to Package"
- Header/tabs: n/a — this is the modal, background table obscured as in Screen (1017,406).
- Table: Same as Screen (1017,406) except: row 1 (8/‑/8/8 MDR8317) button still green "Auto Fill" (unused); row 2 (25/‑/25/25 MDR8317) button now red "Delete" and Packaging = 25 (filled); row 3 (12/‑/12/12) Auto Fill still green; rows 4, 6-8 (MTR8262/MTR8306) still greyed/blocked, but the red "no entry" circle icons seen in Screen (1017,406) are NOT present here — just plain greyed Auto Fill buttons; row 5 (3/3/0/3) Auto Fill green.
- Controls: "Create & Print" now enabled (green); "Package Weight" box shows "686.67 lbs." (not red); "See Packages" enabled (green).
- Notes: This is the Auto Fill modal after row 2 was packaged via manual entry; it is not the header/current-coil strip.
- Verified: pass3

##### Screen (972,424) — Auto Fill modal, keypad entry for row 3
- File: `p2_167_x972_y424.png`
- Illustrates: (961,428)-(970,431) "The Worker does NOT have to use the Auto Fill function, he needs to also be able to just click on a line item within the Packaging column and then manually type in any number between 1 and the number in the Left To Package column."
- Header/tabs: background table obscured by modal, as in Screen (1017,406).
- Table: Same rows as (1017,406): row 1 (8/‑/8/8 MDR8317) Auto Fill green, unused; row 2 (25/‑/25/25 MDR8317) button already red "Delete" and Packaging = 25 (already committed, from before this crop); row 3 (12/‑/12/12 MDR8317) still shows "Auto Fill" (green, unclicked), Packaging cell selected (blue outline) with a numeric keypad popup overlay showing "___ pcs." input field, "Enter" button (green), digit keys 1–9, 0, backspace arrow, and red "X" close button — this is the row being manually entered, NOT row 2; rows 4, 6-8 greyed/blocked; row 5 Auto Fill green.
- Controls: "Create & Print" enabled (green); "Package Weight" shows "686.67 lbs." (enabled, not red); "See Packages" enabled.
- Dialog/popup: numeric keypad popup as described above, overlaying the Packaging cell of row 3 (12/‑/12/12 MDR8317), not row 2.
- Verified: pass3

##### Screen (972,443) — Auto Fill modal, partial manual entry on row 3
- File: `p2_171_x972_y443.png`
- Illustrates: (1050,460)-(1055,462) "If the package you are planning to create is heavier than the Max Weight, this box will be highlighted in red."
- Header/tabs: background table obscured by modal, as in Screen (1017,406).
- Table: Row 1 (8/‑/8/8 MDR8317) Auto Fill still green (unused); row 2 (25/‑/25/25) button red "Delete", Packaging = 25; row 3 (12/‑/12, Left To Package 12) button still shows "Auto Fill" (green) but Packaging cell already shows 6 (partial manual entry, not yet committed via Auto Fill/Delete); rows 4–5 (MTR8262) greyed/blocked; rows 6–8 (MTR8306) greyed/blocked.
- Controls: "Create & Print" enabled (green); "Package Weight" box reads "816.45 lbs." — plain box, not highlighted red; "See Packages" enabled.
- Notes: Distinct intermediate state, not an over-weight screen — the red-highlight annotation nearby refers to a later screen (e.g. Screen (1055,447)/p2_175), not this one.
- Verified: pass3

##### Screen (1004,440) — package label print preview
- File: `p2_169_x1004_y440.png`
- Illustrates: (1020,441)-(1025,443) "Clicking the Create & Print button will create a package, print the label, reset the Packaging column and update the Left to Package column."
- Header/tabs: n/a — this is a printed label mockup, not the app UI.
- Table: Columns Pcs. / Description / Weight. Rows: 8 | 15'9" (189") 29Ga. 36" Diamond Rib White White | 259.56 lbs.; 25 | 13'4" (160") 29Ga. 36" Diamond Rib White White | 686.67 lbs.; 12 | 10'6" (126") 29Ga. 36" Diamond Rib White White | 259.56 lbs. "Total Package Weight: 1205.79 lbs."
- Indicators: none (plain label)
- Notes: Bottom of label — Customer: A.W.C., Sales Order #: 330618, PO #: ABC 123, barcode with code "02 - 330618 - 01". Matches annotation: label code = department ID (02) + order number (330618) + package sequence (01).
- Verified: pass3

##### Screen (1017,386) — Rollforming / Production — Create Packages/Labels popup, all MDR8317 rows showing Auto Fill (not yet clicked)
- File: `p2_160_x1017_y386.png`
- Illustrates: no distinct nearby annotation
- Dialog/popup: same column layout as Screen (926,466) (Qty Ordered, Use Stock, Qty To Roll, Left To Package, Packaging, ID, Description, Line Item Notes). Rows: 8/—/8/8 MDR8317 — Auto Fill(green); 25/—/25/25 MDR8317 — Auto Fill(green); 12/—/12/12 MDR8317 — Auto Fill(green); 14/—/14/14 MTR8262 — Auto Fill disabled(red "no" icon); 3/3/0/3 MTR8262 — Auto Fill(green); 16/—/16/16 MTR8306 — Auto Fill disabled; 28/2/26/28 MTR8306 — Auto Fill disabled; 22/—/22/22 MTR8306 — Auto Fill disabled. Footer Customer A.W.C., Order# 330618, weight box empty, Create & Print greyed, See Packages green
- Notes: no Delete buttons present anywhere (differs from Screen (926,466), where rows1 and 3 already show Delete)
- Verified: pass3

##### Screen (1017,406) — Rollforming Production tab, order list with Create Packages modal (initial state)
- File: `p2_163_x1017_y406.png`
- Illustrates: (1003,400)-(1013,402) "Auto Fill and/or Manually Entering Amounts to Package"; (963,404)-(970,406) "Clicking the Auto Fill button would automatically fill whatever is in the Left To Package column into the Packaging column."
- Header/tabs: background table columns: Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location, Coil Number, Source. Visible background rows: Wed May 08/2024 330605 H F H Inc; 330609 Arnold Contracting; etc (partly obscured by modal).
- Controls: Modal (see Dialog) with 8 "Auto Fill" buttons (green, enabled) each next to a line item row; "Create Packages/Labels" button visible top-left of background table.
- Table: Modal table columns: Qty Ordered, Use Stock, Qty To Roll, Left To Package, Packaging, ID, Description, Line Item Notes. Rows: 8/‑/8/8 MDR8317 15'9" (189") 29Ga. 36" Diamond Rib White White (Auto Fill enabled); 25/‑/25/25 MDR8317 13'4" (160") ... (Auto Fill enabled); 12/‑/12/12 MDR8317 10'6" (126") ... (Auto Fill enabled); 14/‑/14/14 MTR8262 14'6" (174") 29Ga. 36" Tuff Rib Black (Auto Fill greyed/blocked with a red "no" circle icon); 3/3/0/3 MTR8262 12'3" (147") 29Ga. 36" Tuff Rib Black (Auto Fill enabled); 16/‑/16/16 MTR8306 16'0" (192") 29Ga. 36" Tuff Rib Charcoal (blocked); 28/2/26/28 MTR8306 11'3" (135") ... (blocked); 22/‑/22/22 MTR8306 8'4" (100") 29Ga. 36" Tuff Rib Charcoal (blocked). Below: Customer Name A.W.C., Order # 330618, PO# ABC 123, Salesman Henry Wall, Ship Date Thursday May 09/2024, Ship Via Delivery, Priority (blank), Location (blank).
- Indicators: Several Auto Fill buttons show a red "no entry" circle overlay, meaning disabled/blocked (rows without Supplier/Coil Number assigned yet).
- Dialog/popup: Modal titled implicitly by order info; buttons at bottom: "Create & Print" (greyed/disabled), "Package Weight" box (empty), "See Packages" (green, enabled).
- Notes: Matches annotation: Auto Fill buttons for line items with different Product ID become unavailable once one Auto Fill is clicked within a Product ID section.
- Verified: pass3

##### Screen (1017,426) — Auto Fill modal, first 3 rows packaged, weight not over limit
- File: `p2_168_x1017_y426.png`
- Illustrates: (1020,441)-(1025,443) "Clicking the Create & Print button will create a package, print the label, reset the Packaging column and update the Left to Package column."
- Header/tabs: background table obscured by modal, as in Screen (1017,406).
- Table: Rows 1–3 (MDR8317: 8, 25, 12) all now show red "Delete" buttons with Packaging filled = 8, 25, 12; rows 4–5 (MTR8262) still Auto Fill greyed/blocked; rows 6–8 (MTR8306) Auto Fill greyed/blocked with red no-entry icon.
- Controls: "Create & Print" enabled (green); "Package Weight" box reads "1205.79 lbs." — plain white box, NOT highlighted red in this crop (below the max-weight threshold that triggers the red state seen in later screens); "See Packages" enabled.
- Notes: Weight total (1205.79 lbs.) matches the 3 rows' combined weight shown later on the printed label (Screen 168's own label content is actually at file p2_169).
- Verified: pass3

##### Screen (1017,447) — Auto Fill modal, first 3 rows complete, rows 4–8 mixed
- File: `p2_174_x1017_y447.png`
- Illustrates: (1009,464)-(1016,467) "Once the Left To Package Column is zero then the Status for that line item automatically changes to Rolled."
- Table: Rows 1–3 (MDR8317: 8, 25, 12) show Left To Package = 0, Auto Fill buttons greyed/disabled (done); row 4 (14/‑/14/14 MTR8262) still blocked (red no-entry icon), Left To Package = 14 (unfilled); row 5 (3/3/‑/3 MTR8262) Auto Fill still green/enabled, Left To Package = 3; rows 6–8 (MTR8306: 16, 28, 22) still blocked (red no-entry icons), Left To Package unfilled.
- Controls: "Create & Print" and "Package Weight" both greyed/disabled; "See Packages" enabled (green).
- Notes: Rows 6–8 are NOT auto-filled in this crop — they remain blocked, unlike later screens where they become fillable once Coil Number is assigned.
- Verified: pass3

##### Screen (1017,510) — Auto Fill modal, all Left To Package zero, Location already assigned
- File: `p2_188_x1017_y510.png`
- Illustrates: (1144,426)-(1149,430) "Within the Completed Orders tab we need to be able to see a list of the line items ordered and how many were pulled from stock. We also need a list of the packages that were created for this order and what was put into each package."
- Table: Same 8 line items as Screen (1017,406) (Qty Ordered/Use Stock/Qty To Roll/Left To Package/Packaging/ID/Description/Notes columns), all rows show Left To Package = 0, but the Auto Fill buttons remain solid green (same style as the enabled state elsewhere) rather than greyed/pale — despite Left To Package being 0 for every row.
- Controls: "Create & Print" and "Package Weight" both greyed/disabled; "See Packages" enabled (green); bottom "Location:" field row shows two badges "2C" and "2D".
- Notes: This is the Auto Fill modal, not the See Packages modal — the Location badges appear alongside the summary fields at the bottom of this table view.
- Verified: pass3

##### Screen (1055,447) — Auto Fill modal, all rows filled, over max weight (red)
- File: `p2_175_x1055_y447.png`
- Illustrates: (1055,482)-(1062,485) "If you try to 'Create & Print' when the potential package is over the weight limit, you will get a pop up asking if you want to continue with the over weight package. If you agree, it will override the weight limit and create the package and print the label."
- Table: Rows 1–3 (MDR8317: 8, 25, 12) Left To Package = 0, greyed Auto Fill (done); row 4 (14/14 MTR8262) greyed, Left To Package = 0 (done); row 5 (3/3/0/3, Left To Package 0) greyed; rows 6–8 (MTR8306: 16, 28, 22) still show enabled green "Auto Fill" (unclicked), Left To Package still 16/28/22, Packaging column blank.
- Controls: "Create & Print" enabled (green); "Package Weight" box highlighted RED, reads "1553.93 lbs."; "See Packages" enabled.
- Dialog/popup: none in this crop — no confirmation pop-up shown (that appears in Screen (1055,466)/p2_178).
- Indicators: red weight box signals the package is over the max weight limit, even though rows 6–8 have not yet been packaged.
- Verified: pass3

##### Screen (1055,466) — over-weight confirm dialog, on top of the all-filled state
- File: `p2_178_x1055_y466.png`
- Illustrates: same as Screen (1055,447)
- Same as Screen (1055,447) (`p2_175`) — rows 1–5 greyed/done, rows 6–8 (MTR8306) show solid-green Auto Fill buttons (already applied), Left To Package 16/28/22 and Packaging 16/28/22 (row 7 Use Stock 2, Qty To Roll 26), weight box red "1553.93 lbs.", "Create & Print" and "See Packages" green — except: an additional dialog overlays reading "The package you are trying to create is over the weight limit, are you sure you want to continue?" with buttons "No" (red) and "Yes, Create & Print" (green). Confirmed identical underlying table state between the two files.
- Verified: pass3


### Completing an Order / Completed Orders tab
- "Completing an Order" heading (1026, 504)
- "Once the Left To Package column is ALL zeros, then the order would disappear from this window and appear in the Completed Orders tab." (1041, 510)
- "Overdue Orders" (1047, 502)
- "Overdue orders need to be highlighted." (1051, 504)
- "Example: If it is Thursday, May 09/2024 and there are orders from Wednesday, May 08/2024 that are not completed yet, then we need those Wednesday orders to be highlighted as overdue." (1050, 505)
- "Completed Orders tab" (1161, 398)
- "Going to this tab will show you a list of all the orders that are "Done"." (1041, 526)
- "If an order is "Done" Production but NOT all the packages have been wrapped yet, then it will show that it is still waiting for the Completed Date & Time and for more package locations." (1041, 532)
- "Clicking on an order opens it so you can view and still change location and/or reprint labels." (1022, 540) / (1164, 416)
- "This would say waiting... until all the packages have a Location, then the Completion Date & Time would get filled in." (1042, 544)
- "This would say waiting... until the Wrapping Worker gives all the packages a Location." (1042, 548)
- "Within the Completed Orders tab we need to be able to reprint package labels and change locations if necessary." (1012, 550) / (1175, 428)
- "When you open the Completed Orders tab you should be able to view all the completed orders for the past 90 days. The completed orders should be displayed here and appear like this." (1175, 401)
- "Within the Completed Orders tab we need to be able to see a list of the line items ordered and how many were pulled from stock. We also need a list of the packages that were created for this order and what was put into each package." (1144, 426)

#### Screens (10)

##### Screen (926,511) — Rollforming / Production — expanded order 330618 with Status column populated (Rolled/In Progress/Stock)
- File: `p2_139_x926_y511.png`
- Illustrates: (930,500)-(936,503) "If the Qty Ordered and the Left To Package columns are NOT equel, then the Status needs to be In Progress. If the Left To Package column is zero, then the Status needs to be Rolled." (typo "equel" verbatim)
- Table: expanded sub-table columns Qty. Ordered, Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Rows: 8/—/8 MDR8317 15'9"(189") Taylor/7350025(locked) Status="Rolled"(red badge); 25/—/25 MDR8317 13'4"(160") Taylor/7350025(locked) Status="In Progress"(orange badge) — Notes(red dot); 12/—/12 MDR8317 10'6"(126") Taylor/7350025 Status="Rolled"(red); 14/—/14 MTR8262 14'6"(174") Undefined/Undefined — Notes(green dot); 3/3/0 MTR8262 12'3"(147") Undefined/Undefined Status="Stock"(yellow); 16/—/16, 28/2/26, 22/—/22 MTR8306 rows Undefined/Undefined no status
- Buttons: Create Packages/Labels, See Packages (both green)
- Indicators: red "Rolled" badges, orange "In Progress" badge, yellow "Stock" badge
- Verified: pass3

##### Screen (972,485) — See Packages modal
- File: `p2_182_x972_y485.png`
- Illustrates: (1007,480)-(1014,481) "Deleting a Package"; (1026,482)-(1030,484) "Reprinting Labels"; (1020,482)-(1024,484) "Clicking the See Packages button opens a list of the packages already on the order."
- Header/tabs: background same order-table rows as Screen (1017,406).
- Table: Modal titled with Customer Name: A.W.C., Order #: 330618, PO: ABC 123. Columns: Packages, Qty/Description, Supplier/Coil Number, Location. Rows: "02-330618-01" — 8-15'9"(189") Diamond Rib White White / Taylor/7350025 / Location "2C" / Delete (red) / Reprint; 25-13'4"(160")... / Taylor/7350025; 12-10'6"(126")... / Taylor/7350025. "02-330618-02" — 14-14'6"(174") Tuff Rib Black / Color Steel/F846372 / Location "2D" / Delete / Reprint; 3-14'6"(174")... / Undefined/Undefined. "02-330618-03" — 16-16'0"(192") Tuff Rib Charcoal / Color Steel/F846386, Location shows "waiting..." / Delete / Reprint; 28-11'3"(135")... / Color Steel/F846386; 22-8'4"(100")... / Color Steel/F846386.
- Dialog/popup: modal with red X close button top-right; two empty grey placeholder rows at bottom (blank package slots). No confirmation dialog visible here.
- Notes: "waiting..." status shown in italics for package 03's location, meaning material still slit-pending. This file is byte-identical to `p2_183`.
- Verified: pass3

##### Screen (972,505) — Delete package confirmation dialog
- File: `p2_186_x972_y505.png`
- Illustrates: (981,529)-(985,532) "Clicking Yes will delete the package and put the number of pcs. that were in the package back into the Left To Package column."
- Header/tabs: background same See Packages modal as Screen (972,485)/(1017,488).
- Table: Same package rows as Screen (972,485), with a confirmation dialog overlaid.
- Dialog/popup: "Are you sure you want to delete this package?" with buttons "No" (red) and "Yes, Delete Package" (green).
- Notes: This entry is the delete-confirmation dialog overlaying the See Packages modal.
- Verified: pass3

##### Screen (987,524) — See Packages modal, package 3 deleted
- File: `p2_190_x987_y524.png`
- Illustrates: (1086,315)-(1091,319) "If the Manager assigned part of an order to be rolled off of an existing coil and part of that order to be slit, then we need that indicated here."
- Header/tabs: background same order-table rows as Screen (1017,406).
- Table: Modal — Customer: A.W.C., Order #: 330618, PO: ABC 123. Packages: "02-330618-01" — 8/25/12 Diamond Rib White White rows, Supplier/Coil Taylor/7350025, Location "2C", Delete/Reprint; "02-330618-02" — 14-14'6"(174") Tuff Rib Black, Color Steel/F846372, Location "2D", Delete/Reprint; 3-14'6"(174")... Undefined/Undefined. "02-330618-03" — shown as italic grey text "Deleted" in place of its rows (package was removed).
- Indicators: none highlighted besides the greyed-out "Deleted" label.
- Notes: Previously mislabeled as a Rollforming Production tab order-detail screen with slit icons; the actual image is this See Packages modal variant.
- Verified: pass3

##### Screen (1017,470) — Order detail row expanded, packages created (post-print)
- File: `p2_179_x1017_y470.png`
- Illustrates: (1011,367)-(1016,369) "Only after a Supplier and Coil Number are present, then the Worker can Create Packages & Print Labels."
- Header/tabs: background order row: Wed May 08/2024 330618 A.W.C. ABC123 29Ga. Black/29Ga. Charcoal/29Ga. White White Tuff Rib/Diamond Rib Henry Wall, Coil Number 7350025, expanded.
- Controls: "Create Packages/Labels" and "See Packages" buttons (both green, enabled) above expanded detail.
- Table: Expanded columns: Qty Ordered, Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Rows: 8/‑/8 MDR8317 15'9"(189") 29Ga. 36" Diamond Rib White White, 189", Taylor/7350025 (locked icons), Status "Rolled" (red badge); 25/‑/25 MDR8317 13'4"(160")..., 160", Taylor/7350025, Status "Rolled" (red badge, red dot on Notes button); 12/‑/12 MDR8317 10'6"(126")..., 126", Taylor/7350025, Status "Rolled" (red badge); 14/‑/14 MTR8262 14'6"(174") Tuff Rib Black, 174", Undefined/Undefined (dropdown arrow), Notes (green dot); 3/3/0 MTR8262 12'3"(147") Tuff Rib Black, 147", Undefined/Undefined, Status "Stock" (yellow badge); 16/‑/16 MTR8306 16'0"(192") Tuff Rib Charcoal, 192", Undefined/Undefined; 28/2/26 MTR8306 11'3"(135")..., 135", Undefined/Undefined; 22/‑/22 MTR8306 8'4"(100")..., 100", Undefined/Undefined. Below: further background rows 330622, 330629, 330628, 330631.
- Indicators: Status badges colour-coded — red "Rolled", yellow "Stock". Notes button on row 2 has a red dot indicator; row 4 (MTR8262 14/14) has a green dot indicator on Notes.
- Verified: pass3

##### Screen (1017,488) — See Packages modal (duplicate)
- File: `p2_183_x1017_y488.png`
- Illustrates: (995,488)-(1000,490) "If something was packaged wrong, then we need to be able to delete that package and repackage the items that were in it."
- Identical to Screen (972,485) (`p2_182`) — confirmed byte-identical file, same See Packages modal content, no confirmation dialog present. (The delete confirmation dialog itself is at Screen (972,505)/`p2_186`.)
- Verified: pass3

##### Screen (1017,526) — Completed Orders tab, full table
- File: `p2_191_x1017_y526.png`
- Illustrates: (1175,401)-(1182,403) "When you open the Completed Orders tab you should be able to view all the completed orders for the past 90 days."
- Header/tabs: Sub-tabs Production (active, white pill), Queue, Coils, Wrapping; Machine tabs Tuff Rib & Diamond Rib (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated, Slit Line.
- Table: Columns: Ship Date, Production Date, Completed Date & Time, Order #, Customer Name, Location. Rows (first 12 of more visible): Thu May 09/2024|Wed May 08/2024|Wed May 08/2024 9:16am|330638|Ontario Metal Products Ltd.|1E; Thu May 09/2024|Wed May 08/2024|Wed May 08/2024 9:28am|330635|Jireh Tools|2A; Thu May 09/2024|Wed May 08/2024|Thurs May 09/2024 8:08am|330639|Upright Construction|2C; Thu May 09/2024|Wed May 08/2024|Wed May 08/2024 2:57pm|330605|H F H Inc|2E, 2F; Thu May 09/2024|Wed May 08/2024|"Waiting..." (italic)|330618|A.W.C.|2C, 2D, waiting...; Wed May 08/2024|Tues May 07/2024|Tues May 07/2024 10:21am|330609|Arnold Contracting|1A; Wed May 08/2024|Tues May 07/2024|Tues May 07/2024 1:42pm|330615|DAP Roofing Inc.|1C; Wed May 08/2024|Tues May 07/2024|Wed May 08/2024 8:22am|330616|Arnold Contracting|2A; Tue May 07/2024|Mon May 06/2024|Mon May 06/2024 10:18am|330637|A.W.C.|2F; Tue May 07/2024|Mon May 06/2024|Mon May 06/2024 10:59am|330631|Jireh Tools|1F, 1E; Tue May 07/2024|Mon May 06/2024|Mon May 06/2024 11:37am|330619|A.W.C.|1B; Tue May 07/2024|Mon May 06/2024|Tues May 07/2024 2:24pm|330636|Jireh Tools|2B, 2C. (More rows continue below crop: 330632, 330638, 330639.)
- Notes: order 330618's Completed Date & Time shows "Waiting..." while Location shows "2C, 2D, waiting..." — indicates order not fully completed. Previously mislabeled as the Select Location warehouse-grid modal; that content is actually this file's Section is Completed Orders, not Wrapping's location picker.
- Verified: pass3

##### Screen (1017,544) — Completed order full detail (packages + line items combined)
- File: `p2_192_x1017_y544.png`
- Illustrates: (1042,544)-(1046,547) "This would say waiting... until all the packages have a Location, then the Completion Date & Time would get filled in."; (1042,548)-(1047,550) "This would say waiting... until the Wrapping Worker gives all the packages a Location."
- Header/tabs: background Completed Orders tab table (Ship Date/Production Date/Completed Date & Time/Order#/Customer/Location) visible at edges with one row selected (blue outline).
- Table: Modal shows Customer: A.W.C., Order #: 330618, PO: ABC 123, Salesman: Henry Wall, Location: "2C, 2D, waiting..." (italic), Completion Date & Time: "waiting..." (italic). Line item table (Qty Ordered, Stock, Product ID, Description, Length, Supplier/Coil Number) — 8 rows, Supplier/Coil Number values Taylor/7350025 for first 3 rows, Color Steel/F846372 and F846386 for the rest. Packages table below: 02-330618-01 (Taylor/7350025, Location "2C", Reprint); 02-330618-02 (Color Steel/F846372, Location "2D", Reprint); 02-330608-03 (Color Steel/F846386, Location "waiting...", Reprint) — note this row's package number is mistyped "330608" instead of "330618" (typo preserved).
- Notes: literal typo "02-330608-03" visible in the package ID (should read 330618); kept verbatim per instructions.
- Verified: pass3

##### Screen (1152,402) — Completed Orders tab, full table, 330618 row selected
- File: `p2_210_x1152_y402.png`
- Illustrates: (1175,428)-(1179,431) "Within the Completed Orders tab we need to be able to reprint package labels and change Locations if necessary."
- Header/tabs: Sub-tabs Production, Queue, Coils, Wrapping; Machine tabs Tuff Rib & Diamond Rib (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated.
- Table: Columns: Ship Date, Production Date, Completed Date & Time, Order #, Customer Name, Location. 330618 A.W.C. row is highlighted/selected (blue outline), showing Completed Date & Time "Wed. May 08/2024 3:45pm" and Location "2C, 2D, 1B". Other visible rows: 330638 Ontario Metal Products Ltd. (1E); 330635 Jireh Tools (2A); 330639 Upright Construction (2C); 330605 H F H Inc (2E, 2F); 330609 Arnold Contracting (1A); 330615 DAP Roofing Inc. (1C); 330616 Arnold Contracting (2A); 330637 A.W.C. (2F); 330631 Jireh Tools (1F, 1E); 330636 Jireh Tools (2B, 2C); 330632 Jireh Tools (2B); 330638 H F H Inc (2B, 1B); 330639 Upright Construction (1D).
- Notes: This is the plain Completed Orders table (not an expanded Wrapping order row as previously claimed); the full detail modal for this same state is at Screen (1152,420)/`p2_213`.
- Verified: pass3

##### Screen (1152,420) — Completed order detail modal, all packages located, Completion Date & Time filled
- File: `p2_213_x1152_y420.png`
- Illustrates: nearest relevant is (1042,544)-(1046,547) "This would say waiting... until all the packages have a Location, then the Completion Date & Time would get filled in."
- Header/tabs: background Completed Orders tab table row selected (blue outline) matching order 330618.
- Table: Modal — Customer: A.W.C., Order#: 330618, PO: ABC 123, Salesman: Henry Wall, Location: "2C, 2D, 1B", Completion Date & Time: "Wednesday, May 08/2024, 3:45pm" (now filled, no longer "waiting..."). Line item table (Qty Ordered, Stock, Product ID, Description, Length, Supplier/Coil Number) — 8 rows, Supplier/Coil Taylor/7350025 for first 3 rows, Color Steel/F846372 and F846386 for the rest. Packages table below: 02-330618-01 (Location "2C", Reprint); 02-330618-02 (Location "2D", Reprint); 02-330608-03 (Location "1B", Reprint) [package id typo "330608" instead of "330618", kept verbatim].
- Notes: This is the completed end-state of the order lifecycle shown across this batch.
- Verified: pass3


### Wrapping tab
- Tab label "Wrapping" (1161, 292)
- "As soon as at least 1 package has been created in an order by the Rollforming Worker, then this Status needs to change to In Progress and stay that way until the Left To Package column for that order is ALL zeros, then it needs to change to Rolled." (1145, 294)
- "Priorities" (1175, 294)
- "Choose the Machine that you are going to be Wrapping for." (1146, 299)
- "Expand the order of the package you are Wrapping. Here any package that has been created by the Rollforming Worker would appear." (1144, 315)
- "Clicking Select Loaction would open the list of Locations." (1164, 325)
- "When selecting a location, you need to be able to just click on an available location." (1175, 329)
- "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into. Example: If a Worker in the Rollforming department (category) goes to select a location, the location window needs to default to Rollforming locations. That being said the Worker should still be able to choose a different department (category) to select a location there too." (1143, 331)
- "Click on the location you are wanting to select." (1164, 343)
- "Once the Left To Package column is ALL zeros in the Production tab, then the Status would change from In Progress to Rolled." (1144, 366)
- "Once all the packages for the order have been created and as soon as you give the last package a Location, then the order should disappear out of the Wrapping tab and fill in the Completed Date & Time and the last Location into that order within the Completed Orders tab." (1144, 383)
- "Icon showing that material is waiting to be slit also the Coil Numbers are waiting for the Slit Line Worker to mark the material as slit and then it will auto fill." (1111, 385)
- "If a Supplier or Coil Number is missing for a line item, then that line item needs to be blocked from being packaged." (1040, 385)

#### Screens (13)

##### Screen (551,645) — Order 330618 expanded, "See Packages" button, Status = In Progress
- File: `p2_089_x551_y645.png`
- Illustrates: "After an order has been Released To Production, then the Select Supplier / Coil Number and Create Cutlist button should disappear, and this See Packages button should appear." (541,647)
- Header/tabs: order row 330618, expanded (chevron open) showing line items below: E (unchecked checkbox), R (package icon), Thursday May 09/2024, Wed May 08/2024, 330618, A.W.C., 29Ga. Black/29Ga. Charcoal/29Ga. White White, ABC 123, Henry Wall, Pickup, Select Priority, reviewed icon, Status "In Progress" (yellow), Loc "2C", Notes (green dot).
- Controls: "See Packages" button (green, enabled) replacing Select Supplier/Create Cutlist buttons.
- Table: line items — 8/8 MDR8317 189" White White, Supplier/Coil "Taylor/7350025", Status "Wrapped" (green). 25/25 MDR8317 160" White White, Taylor/7350025, Wrapped (green), Notes red dot. 12/12 MDR8317 126" White White, Taylor/7350025, Wrapped (green). 14/14 MTR8262 174" Black, "Color Steel/F846372", Status "Rolled" (red). 3/0(from stock 3) MTR8262 147" Black, Undefined/Undefined, Status "Stock" (yellow). 16/16, 28(2 stock)/26, 22/22 MTR8306 Charcoal rows — Undefined/Undefined, Status "Not Started" (grey).
- Indicators: colored status badges — green "Wrapped", red "Rolled", yellow "Stock"/"Not Started" (grey for Not Started).
- Verified: pass3

##### Screen (551,656) — Rollforming Scheduled, order list with Status badges (duplicate of 551,637)
- File: `p2_090_x551_y656.png`
- Illustrates: same as Screen (551,637)
- Same as Screen (551,637) — identical table/state (Wrapped/In Progress badges visible).
- Verified: pass3

##### Screen (551,664) — "Packages" modal for order A.W.C./330618
- File: `p2_092_x551_y664.png`
- Illustrates: "In this window the Manager would be able to see the packages that have been created by the Worker and the locations as the Worker wraps those packages." (543,662)
- Header/tabs: background shows order row + Status "In Progress" (yellow), Loc "2C".
- Controls: red "X" close button top-right.
- Table: Title "Packages: A.W.C. / 330618". Columns: Packages:, Qty / Description:, Location:. Rows: "02 - 330618 - 01" | 8 - 15'9" (189") 29Ga. 36" Diamond Rib White White | 2C. (same package #01) 25 - 13'4" (160") 29Ga. 36" Diamond Rib White White. (same) 12 - 10'6" (126") 29Ga. 36" Diamond Rib White White. "02 - 330618 - 02" | 14 - 14'6" (174") 29Ga. 36" Tuff Rib Black. (same package #02) 3 - 14'6" (174") 29Ga. 36" Tuff Rib Black. (remaining rows blank/empty placeholders below).
- Dialog/popup: "Packages: A.W.C. / 330618" — package groupings with quantities, descriptions and Location, red X close button.
- Verified: pass3

##### Screen (956,548) — Rollforming / Production — expanded order 330618, Status = Wrapped/Rolled (all green "Wrapped" badges except last two red "Rolled")
- File: `p2_143_x956_y548.png`
- Illustrates: (344) "This would say waiting... until all the packages have a Location, then the Completion Date & Time would get filled in." (nearest wrapping-status concept)
- Table: rows Status column: "Wrapped"(green) x4 (rows 1,2,3,4), "Wrapped"(green) row5, "Rolled"(red) rows 6-8 with Supplier/Coil "Color Steel/F846372" (row4), "Color Steel/F846386" (rows 6-8)
- Buttons: Create Packages/Labels, See Packages
- Indicators: green "Wrapped" badges, red "Rolled" badges
- Verified: pass3

##### Screen (1152,296) — Wrapping tab header
- File: `p2_193_x1152_y296.png`
- Illustrates: (1161,292)-(1164,293) "Wrapping"; (1145,294)-(1150,299) "As soon as at least 1 package has been created in an order by the Rollforming Worker, then this Status needs to change to In Progress and stay that way until the Left To Package column for that order is ALL zeros, then it needs to change to Rolled."
- Header/tabs: Department pill "Rollforming"; top-right "Completed orders for the past 90 days" button. Sub-tabs: Production, Queue, Coils, Wrapping (active). Machine tabs: Tuff Rib & Diamond Rib (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated.
- Table: Columns Production Date, Order #, Customer Name, PO, Gauge/Color, Profile, Salesman, Priority, Status, Location. Rows: Wed May 08/2024 330605 H F H Inc ABC123 29Ga. Black/26Ga. Black Tuff Rib/Diamond Rib Joel Thieseen; 330609 Arnold Contracting ABC123 26GA. Ebony Diamond Rib Henry Goertzen; 330615 DAP Roofing Inc. ABC123 29Ga. Ebony/29Ga. Melcher's Green/29Ga. White White Tuff Rib/Diamond Rib Jake Fehr; 330616 Arnold Contracting ABC123 29Ga. Black Tuff Rib Jake Fehr; 330617 Ontario Metal Products Ltd. ABC123 29Ga. Black Tuff Rib Jacob Redecop; 330618 A.W.C. ABC123 29Ga. Black/29Ga. Charcoal/29Ga. White White Tuff Rib/Diamond Rib Henry Wall — Status "In Progress" (yellow badge); 330622 Ontario Metal Products Ltd. ABC123 29Ga. Tan/29Ga. Coffee Brown Tuff Rib/Reversed Diamond Rib Jacob Redecop; 330629 Ontario Metal Products Ltd. ABC123 26Ga. Coffee Brown Diamond Rib Jacob Redecop; 330628 DAP Roofing Inc. ABC123 26Ga. Melcher's Green Tuff Rib Jake Fehr; 330631 A.W.C. ABC123 29Ga. White White Reversed Diamond Rib Henry Wall.
- Indicators: order 330618 shows "In Progress" yellow status badge; row separated from prior day rows by orange divider line.
- Verified: pass3

##### Screen (1152,310) — Wrapping tab, order 330618 expanded (Select Location)
- File: `p2_195_x1152_y310.png`
- Illustrates: (1144,315)-(1149,318) "Expand the order of the package you are Wrapping. Here any package that has been created by the Rollforming Worker would appear."
- Header/tabs: Same header/tab strip as Screen (1152,296).
- Table: 330618 A.W.C. row expanded (bold border), Status "In Progress". Expanded detail columns: Packages, Qty/Description, Supplier/Coil Number, Location. Rows: 02-330618-01 — 8-15'9"(189") Diamond Rib White White / Taylor/7350025; 25-13'4"(160")... / Taylor/7350025; 12-10'6"(126")... / Taylor/7350025 — "Select Location" button + "Reprint" button. 02-330618-02 — 14-14'6"(174") Tuff Rib Black / Color Steel/F846372 — "Select Location" + "Reprint"; 3-14'6"(174")... / Undefined/Undefined. Other rows (330622, 330629, 330628, 330631) collapsed below.
- Controls: "Select Location" buttons (enabled, white/outlined) for each package not yet located; "Reprint" buttons enabled.
- Verified: pass3

##### Screen (1152,327) — Select Location modal (Warehouse/grid)
- File: `p2_197_x1152_y327.png`
- Illustrates: (1143,331)-(1150,337) "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into..."
- Header/tabs: Modal tabs: Warehouse #1 (active), Warehouse #2, Warehouse #3. Sub-tabs: Trim, Rollforming (active), Accessories. Column headers "Left" / "Right".
- Controls: Grid of location buttons 1A–1L (Left) and 2A–2L (Right); greyed/disabled buttons: 1D, 1E, 1I, 1J, 2E, 2H, 2I, 2J (unavailable); enabled (white) buttons: 1A, 1B, 1C, 1F, 1H, 1K, 1L, 2A, 2B, 2D, 2F, 2G, 2K, 2L; "2C" shown selected with green outline/highlight.
- Dialog/popup: full-screen modal, red X close button top-right.
- Notes: location window defaults to the Worker's own department (Rollforming tab pre-selected here) but lets the Worker switch departments (Trim/Accessories tabs present). Standalone description — this is a distinct capture, not identical to Screen (1017,526)/`p2_191`, which is actually the Completed Orders tab table.
- Verified: pass3

##### Screen (1152,345) — Order expanded, one package located, one still needing Select Location
- File: `p2_200_x1152_y345.png`
- Illustrates: (1124,360)-(1131,366) "Once the Slit Line Worker marks the material as slit, then you would see both the Coil Number that the Manager assigned to the line items that are coming off of an existing coil and the Coil Number of the material that was just slit..."
- Header/tabs: 330618 row expanded, Status "In Progress" (yellow badge).
- Table: Packages: 02-330618-01 — 8/25/12 Diamond Rib White White rows, Supplier/Coil Taylor/7350025, Location "2C" (already assigned), Reprint; 02-330618-02 — 14-14'6"(174") Tuff Rib Black, Color Steel/F846372, "Select Location" button (not yet assigned), Reprint; 3-14'6"(174")... Undefined/Undefined.
- Indicators: Status badge yellow "In Progress" (not "Rolled" — only package 01 has a location so far). Location column shows "2C" in the collapsed row header.
- Verified: pass3

##### Screen (1152,361) — Wrapping tab table (plain, no expansion)
- File: `p2_202_x1152_y361.png`
- Illustrates: no directly adjacent unique annotation
- Same as Screen (1152,296) except: Priority and Status columns blank for all visible rows (no In Progress badge shown in this crop) — plain unexpanded 5-row table (330605–330617).
- Verified: pass3

##### Screen (1152,368) — Order 330618 expanded, Status Rolled, packages 02/03 need location
- File: `p2_204_x1152_y368.png`
- Illustrates: no adjacent annotation
- Header/tabs: 330618 row, Status "Rolled" (red badge), Location "2C" shown in collapsed row header.
- Table: Packages: 02-330618-01 (Taylor/7350025 ×3 rows, Location "2C" badge, Reprint); 02-330618-02 (Color Steel/F846372, "Select Location" button, Reprint; second row Undefined/Undefined); 02-330608-03 (Color Steel/F846386 ×3 rows, "Select Location" button, Reprint) [package id typo "330608" instead of "330618", kept verbatim].
- Notes: Previously mislabeled as a plain unexpanded Wrapping table (that content is actually at Screen (1152,380)/`p2_205`); file order was shifted by one between these two entries.
- Verified: pass3

##### Screen (1152,380) — Wrapping tab table (plain, no expansion)
- File: `p2_205_x1152_y380.png`
- Illustrates: (1146,366)-(1150,369) "Once the Left To Package column is ALL zeros in the Production tab, then the Status would change from In Progress to Rolled."
- Header/tabs: Sub-tabs Production, Queue, Coils, Wrapping (active); Machine tabs Tuff Rib & Diamond Rib (active), Agra Rib & Titan Rib, Standing Seam, Board & Batten, Corrugated.
- Table: plain 5-row Wrapping table (330605, 330609, 330615, 330616, 330617), Priority/Status/Location columns blank, no row expanded.
- Notes: Previously described as the expanded 330618 "Rolled" detail; that content is actually at Screen (1152,368)/`p2_204`. File order was shifted by one between these two entries.
- Verified: pass3

##### Screen (1152,387) — Order expanded, all three packages located (2C/2D/1B)
- File: `p2_207_x1152_y387.png`
- Illustrates: (1175,428)-(1179,431) "Within the Completed Orders tab we need to be able to reprint package labels and change Locations if necessary."
- Header/tabs: 330618 row, Status "Rolled" (red badge), Location "2C, 2D, 1B" shown in collapsed row header.
- Table: Packages: 02-330618-01 (Taylor/7350025, Location "2C", Reprint); 02-330618-02 (Color Steel/F846372, Location "2D", Reprint); 02-330608-03 (Color Steel/F846386, Location "1B", Reprint) — all three packages now have assigned locations (no more "Select Location" buttons, and no "Delete" buttons in this crop).
- Notes: Previously mislabeled as a Rollforming Worker slit-icon screen; the actual content is this fully-located Wrapping detail.
- Verified: pass3

##### Screen (1180,296) — Wrapping tab, Priority column populated
- File: `p2_194_x1180_y296.png`
- Illustrates: (1070,294)-(1073,295) "Priorities"; (1100,299)-(1106,299) "Workers can NOT change Priorities"
- Same as Screen (1152,296) except: Priority column now populated — 330605 "NOW" (red badge), 330609 "ASAP" (yellow/orange badge), 330615 "ASAP" (yellow/orange badge), 330616 "By 10:00" (yellow badge), 330628 "By 3:00" (yellow badge). Status column still shows 330618 "In Progress".
- Verified: pass3


### Slit Line (referenced tab, right of Rollforming block)
- Tab label "Slit Line" (1240, 292); "Priorities" (1254, 294)
- "This tab needs to primarily sort by Production Date and then by Priority" (1204, 296)
- "Workers can NOT change Priorities" (1204, 298)
- "Even though this order has a Priority assigned to it, it gets pushed down as it has a later Production Date than the orders on top of it." (1204, 303)

#### Screens (11)

##### Screen (602,535) — Rollforming / Scheduled / Tuff Rib & Diamond Rib header only
- File: `p2_114_x602_y535.png`
- Illustrates: no adjacent annotation text (header chrome, matches surrounding Coils section context)
- Header/tabs: Rollforming pill; Completed orders (past 90 days); tabs Unscheduled/Scheduled(active)/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line; date strip: All Scheduled Orders, Wednesday May 08/2024 (calendar icon, boxed), Mon May 06/2024(1000/5000), Tue May 07/2024(1000/5000), Wed May 08/2024(1000/5000), Thu May 09/2024(1000/5000), Fri May 10/2024(1000/5000)
- Controls: greyed "Export and/or Release To Production" button
- Notes: cropped, no table rows visible
- Verified: pass3

##### Screen (602,562) — Rollforming / Scheduled / expanded order 330618 with Select Supplier/Create Cutlist buttons
- File: `p2_117_x602_y562.png`
- Illustrates: (598,563)-(600,563) "Product ID"
- Header/tabs: order header row: Thursday, May 09/2024, Wed. May 08/2024 date, order# 330618, A.W.C., Sales Order-style icon, "29Ga. Black / 29Ga. Charcoal / 29Ga. White White", ABC 123, Henry Wall, Pickup, Select Priority, Notes(green dot)
- Controls: "Select Supplier / Coil Number" and "Create Cutlist" buttons (green, enabled)
- Table (expanded sub-table): columns Qty Ordered, # From Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Rows: 8/—/8 MDR8317 15'9"(189") 29Ga.36" Diamond Rib White White 189" Undefined/Undefined — Notes; 25/—/25 MDR8317 13'4"(160")...160" Undefined/Undefined — Notes(red dot); 12/—/12 MDR8317 10'6"(126")...126" Undefined/Undefined — Notes; 14/—/14 MTR8262 14'6"(174") 29Ga.36" Tuff Rib Black 174" Undefined/Undefined — Notes(green dot); 3/3/0 MTR8262 12'3"(147")...147" Status="Stock"(yellow) — Notes; 16/—/16 MTR8306 16'0"(192") 29Ga.36" Tuff Rib Charcoal 192" Undefined/Undefined — Notes; 28/2/26 MTR8306 11'3"(135")...135" Undefined/Undefined — Notes; 22/—/22 MTR8306 8'4"(100")...100" Undefined/Undefined — Notes
- Indicators: coil-icon glyphs left of each row (rows 1-2 checked green); orange divider lines between Product ID groups; yellow "Stock" badge; two greyed rows below (330622, 330629) partially visible at bottom
- Verified: pass3

##### Screen (686,297) — Same Slit Line Unscheduled tab, Schedule button enabled
- File: `p2_100_x686_y297.png`
- Illustrates: same as Screen (708,281)
- Same as Screen (708,281) except: "Schedule" button now solid green/enabled (not greyed); row checkboxes checked (green) except 330608, 330631 and 330632 are unchecked. Otherwise identical rows.
- Verified: pass3

##### Screen (686,311) — Slit Line Unscheduled, calendar/schedule popup open
- File: `p2_101_x686_y311.png`
- Illustrates: "Clicking the Schedule button will open a Calendar" (689,309/525,311)
- Same as Screen (686,297) except: a calendar popup is overlaid — month "May 2024", grid Su-Sa, date "8" highlighted green (selected), red "X" close icon top-right of popup, Cancel (white) / Set Date (green) buttons. Schedule button (visible behind popup) is solid green/enabled; row checkboxes checked (green) except 330608, 330631 and 330632, same pattern as Screen (686,297).
- Dialog/popup: Calendar — May 2024, date 8 selected, Cancel/Set Date buttons, X close.
- Verified: pass3

##### Screen (686,403) — Rollforming Scheduled / Slit Line, cropped (fewer rows)
- File: `p2_103_x686_y403.png`
- Illustrates: same as Screen (708,389)
- Same as Screen (708,389) except: only first two rows visible (330605, 330609), rest cropped out of frame.
- Verified: pass3

##### Screen (686,409) — Expanded order 330615 in Slit Line Scheduled, line item table
- File: `p2_104_x686_y409.png`
- Illustrates: "Once an order is in the Scheduled tab, then it needs to display the line items like this..." (679,416) / material request table
- Header/tabs: order row 330615 (DAP Roofing Inc., Thu May 09/2024, Wed May 08/2024, Sales Order, 29Ga. Black/29Ga. Melcher's Green/26Ga. White White).
- Controls: "Select Supplier / Coil Number" button (greyed/disabled).
- Table: Columns: (checkbox), Qty Ordered, Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes. Rows: 1 | (checked, stock checked) | 1 | MTC128262 | 150'0" (1800") 29Ga. 11-7/8" Trough Coil Black | 1800" | Undefined/Undefined | | Notes. 1 | (checked, stock checked) | 1 | MTC128262 | 300'0" (3600") 29Ga. 11-7/8" Trough Coil Black | 3600" | Undefined/Undefined | | Notes (red dot). 3 | (three sub-rows checked, stock checked ×3) | 1,1,1 | MTC128307 | 100'0" (1200") 29Ga. 11-7/8" Trough Coil Melcher's Green | 1200" | Undefined/Undefined | | Notes. 2 | (two sub-rows) | 1,1 | MTC12268317 | 250'0" (3000") 26Ga. 11-7/8" Trough Coil White White | 3000" | Undefined/Undefined | | Notes. 2 | (two sub-rows) | 1,1 | MTC12268317 | 500'0" (6000") 26Ga. 11-7/8" Trough Coil White White | 6000" | Undefined/Undefined | | Notes. Below, collapsed rows for 330616, 330617, 330618 (×2).
- Indicators: orange divider lines between Product ID groups; green checked checkboxes for Stock column.
- Notes: "Product ID in EBMS with Color and Gauge" annotation nearby explains the MTC-prefixed IDs.
- Verified: pass3

##### Screen (686,426) — Rollforming Scheduled / Slit Line (same as Screen 708,389, fewer rows)
- File: `p2_105_x686_y426.png`
- Illustrates: same as Screen (708,389)
- Same as Screen (708,389) except: only rows 330605 and 330609 visible (cropped).
- Verified: pass3

##### Screen (686,432) — Expanded order 330615 in Slit Line, one stock line item checked (checkbox filled)
- File: `p2_106_x686_y432.png`
- Illustrates: same as Screen (686,409)
- Same as Screen (686,409) except: one of the "1" sub-rows under the MTC12268317 250'0" group has its Stock checkbox shown as a checked/filled dark-outlined box (distinct visual state — filled/confirmed) versus the plain green outline checkboxes on other rows.
- Verified: pass3

##### Screen (686,449) — Rollforming Scheduled / Slit Line (same as Screen 686,426)
- File: `p2_107_x686_y449.png`
- Illustrates: same as Screen (708,389)
- Same as Screen (686,426) — identical cropped duplicate showing only rows 330605 and 330609.
- Verified: pass3

##### Screen (708,281) — Rollforming Unscheduled tab, Slit Line sub-tab
- File: `p2_099_x708_y281.png`
- Illustrates: "Rollforming Unscheduled" (558,272) / "Managing the Slit Line" (572,277)
- Header/tabs: Rollforming pill. Tab bar: **Unscheduled**(active)/Scheduled/Production/Queue/Coils/Wrapping. Machine sub-tabs: Tuff Rib & Diamond Rib/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/**Slit Line**(active).
- Controls: "Schedule" button greyed/disabled (pale/italic text). Search box top-right.
- Table: Columns: (checkbox), (blank/chevron), Entry Date, Ship Date, Order #, Customer Name, Requested By, Gauge/Color, Salesman, Priority, Order Notes. Rows (all checkboxes green/checked except 330608): 330605 | H F H Inc | Mon May 06/2024 | Thu May 09/2024 | Sales Order ($ icon) | 29Ga. Black/26Ga. Black | Joel Thieseen | Select Priority | Notes (red dot). 330608 | Jireh Tools | Mon May 06/2024 | Thu May 09/2024 | Sales Order | 29Ga. Charcoal | Henry Wall | Select Priority | Notes (unchecked row). 330609 | Arnold Contracting | Mon May 06/2024 | Thu May 09/2024 | Standing Seam (circle-arrow icon) | 26GA. Ebony | Henry Goertzen | Select Priority | (no Notes button). 330615 | DAP Roofing Inc. | Mon May 06/2024 | Thu May 09/2024 | Sales Order | 29Ga. Black/29Ga. Melcher's Green/29Ga. White White | Jake Fehr | Select Priority | Notes. 330616 | Arnold Contracting | Mon May 06/2024 | Thu May 09/2024 | Sales Order | 29Ga. Black | Jake Fehr | Select Priority | Notes (green dot). 330617 | Ontario Metal Products Ltd. | Mon May 06/2024 | Thu May 09/2024 | Board & Batten (circle-arrow icon) | 26Ga. Black | Jacob Redecop | Select Priority | (none). 330618 | A.W.C. | Mon May 06/2024 | Thu May 09/2024 | Tuff Rib & Diamond Rib (circle-arrow icon) | 29Ga. Black | Henry Wall | Select Priority | (none). 330618 | A.W.C. | Mon May 06/2024 | Thu May 09/2024 | Tuff Rib & Diamond Rib | 29Ga. Charcoal | Henry Wall | Select Priority | (none). 330618 | A.W.C. | Mon May 06/2024 | Fri May 10/2024 | Tuff Rib & Diamond Rib | 29Ga. White White | Henry Wall | Select Priority | (none). 330631 | Jireh Tools | Mon May 06/2024 | Fri May 10/2024 | Corrugated (circle-arrow icon) | 26Ga. Charcoal | Henry Goertzen | Select Priority | (none, checked). 330632 | Upright Construction | Mon May 06/2024 | Fri May 10/2024 | Board & Batten | 24Ga. Black | Joel Thieseen | Select Priority | (none, checked). (10 rows visible, total may exceed.)
- Indicators: "Requested By" column icons — $ icon for "Sales Order", circular arrow icon for department names (Standing Seam, Board & Batten, Tuff Rib & Diamond Rib, Corrugated) indicating requests routed from other machines/departments to Slit Line.
- Verified: pass3

##### Screen (708,389) — Rollforming Scheduled, Slit Line sub-tab
- File: `p2_102_x708_y389.png`
- Illustrates: "Rollforming Scheduled" (717,366) / "Reviewing Order" (718,385)
- Header/tabs: Rollforming pill. Tab bar: Unscheduled/**Scheduled**(active)/Production/Queue/Coils/Wrapping. Machine sub-tabs: ...Corrugated/**Slit Line**(active).
- Controls: "Release To Production" button (greyed/disabled, italic). Date strip: All Scheduled Orders, "Wednesday May 08/2024" (active), Mon06–Fri10 (1000/5000 each).
- Table: Columns: (checkbox), (chevron), Ship Date, Production Date, Order #, Customer Name, Requested By, Gauge/Color, Priority, Reviewed, Status, Loc., Order Notes. Rows: Thu May 09/2024 | Wed May 08/2024 | 330605 | H F H Inc | Sales Order ($ icon) | 29Ga. Black/26Ga. Black | Select Priority | | | | Notes (red dot). Thu May 09/2024 | Wed May 08/2024 | 330609 | Arnold Contracting | Standing Seam (circle icon) | 26GA. Ebony | Select Priority | | | | . Thu May 09/2024 | Wed May 08/2024 | 330615 | DAP Roofing Inc. | Sales Order | 29Ga. Black/29Ga. Melcher's Green/26Ga. White White | Select Priority | | | | . Thu May 09/2024 | Wed May 08/2024 | 330616 | Arnold Contracting | Sales Order | 29Ga. Black | Select Priority | | | | Notes (green dot). Thu May 09/2024 | Wed May 08/2024 | 330617 | Ontario Metal Products Ltd. | Board & Batten | 26Ga. Black | Select Priority | | | | . Wed May 08/2024 → Thu 09 | 330618 | A.W.C. | Tuff Rib & Diamond Rib | 29Ga. Black | Select Priority | | | | . 330618 | A.W.C. | Tuff Rib & Diamond Rib | 29Ga. Charcoal | Select Priority | | | | . Fri May 10/2024 | Wed May 08/2024 | 330618 | A.W.C. | Tuff Rib & Diamond Rib | 29Ga. White White | Select Priority | | | | . (8 rows visible.)
- Verified: pass3


### Cross-page references
- "See Page 1" (353, 296) — Trim department detail on Page 1.
- "See Page 3" (1339, 296) — Shipping department detail on Page 3.

#### Screens (5)

##### Screen (465,618) — EBMS Product Components window (screenshot from EBMS)
- File: `p2_023_x465_y618.png`
- Illustrates: "Product ID in EBMS" (469,614); "Screenshot from EBMS" (473,624)
- Header/tabs: EBMS desktop window titled "Products\Meta\Dia. Rib Siding 29Ga. Classic/Txt.\{FEET}' {INCHES}" ({Height}") 29Ga. 36" Diamond Rib White White" with red circular close icon. Sub-tabs: General, Purchasing, Pricing, Count, **Components** (active), Accessories, Advanced, Parts Calculate, Description, Website, Lost Sale/Return, Activity, Documents, Drawing Template, Production, Elevate E-Commerce, Custom Prices, Roll Options.
- Controls: Right-side buttons: Insert, New, Properties, Delete, Move Up (disabled), Move Down (disabled), Copy From..., Show All, Show None. Bottom buttons: OK, Cancel, New, Delete, Print (dropdown).
- Table: Columns: Category | Quantity | Component | Measure | Description | Weight | Base Price | Cost | Total Cost | Quantity Formula (Inventory). One row: "(Single Component)" / 1.00 / "CS8317 WHITE WHITE" / ft / "29ga x 41.2" Coil White White" / 2.05 / 4.63 / 2.8634 / 2.8634 / "{Height}/12".
- Indicators: Row highlighted blue (selected).
- Dialog/popup: EBMS native window (not an in-app modal) — this is a screenshot of the external ERP system.
- Notes: Checkbox "Assembly Kit - Inventory is maintained only at the component level" checked. Totals shown bottom-right: Total Weight 2.05, Total Base Price $4.63, Total Cost $2.8634, Total Items 1.000000.
- Verified: pass3

##### Screen (521,273) — EBMS Roll Options panel
- File: `p2_026_x521_y273.png`
- Illustrates: "The "Profile" assigned to a line item will look back to the Machine connected to that "Profile" and sort the line items into the apropriate Machine." (516,277)
- Header/tabs: Sub-tabs (partial, EBMS): General, Purchasing, Pricing, Count, Compone[nts].
- Controls: Fields: Profile dropdown "Tuff Rib"; checkbox "Roll Material:" (unchecked); Gauge "29"; Thickness "0.0145"; Width "40.8750"; Color "White White".
- Table: n/a.
- Indicators: none.
- Dialog/popup: EBMS "Roll Options" sub-panel screenshot.
- Notes: none.
- Verified: pass3

##### Screen (521,283) — EBMS Profiles table
- File: `p2_029_x521_y283.png`
- Illustrates: "The Name assigned here would have to exactly match the Name given to the Machine in the app." (541,284)
- Header/tabs: Window titled "Profiles:" (partial, top-left label visible).
- Controls: none (data grid).
- Table: Columns: Profile Name | Coverage | Package Capacity | Description | Machines. Rows: Agra Panel/36.0000/40/"Agra Panel 43.2""/Agra Rib & Titan Rib; Titan Panel/36.0000/40/"Titan Panel 44.25""/Agra Rib & Titan Rib; Board & Batten/10.0000/(blank)/"Board & Batten 14" Material"/Board & Batten; S.S. 1-1/2" Snaplock/16.0000/(blank)/"Standing Seam 1-1/2" Snaplock"/Standing Seam; S.S 2" Mechanical/16.0000/(blank)/"Standing Seam 2""/Standing Seam; DRIPSTOP Tuff Rib/36.0000/40/"DR!PSTOP [sic] Tuff Rib 40.875" Material"/Tuff Rib & Diamond Rib; Tuff Rib/36.0000/40/"Tuff Rib 40.875" Material"/Tuff Rib & Diamond Rib; REVERSED Diamond Rib/36.0000/40/"Rev. Diamond Rib 40.875" Material"/Tuff Rib & Diamond Rib; Diamond Rib/36.0000/40/"Diamond Rib 40.875" Material"/Tuff Rib & Diamond Rib. Blank row with "*" marker at bottom (new-row placeholder).
- Indicators: Selected row has blue focus rectangle on first empty cell.
- Dialog/popup: EBMS "Profiles" grid screenshot.
- Notes: "DR!PSTOP" appears to be a typo for "DRIPSTOP" in the source, transcribed literally.
- Verified: pass3

##### Screen (531,277) — EBMS Production Type panel
- File: `p2_027_x531_y277.png`
- Illustrates: "Each Machine tab only shows the line items that are assigned to that Machine via inputs through the "Roll Options" tab in EBMS" (542,280)
- Header/tabs: Sub-tabs (partial, EBMS): [Gen]eral, Purchasing, Pricing, Count, Components, Access[ories].
- Controls: Fields: "Production Type" dropdown "Rollforming"; Color "White White"; Gauge "29".
- Table: n/a.
- Indicators: none.
- Dialog/popup: EBMS panel screenshot.
- Notes: none.
- Verified: pass3

##### Screen (593,406) — Coils tab
- File: `p2_042_x593_y406.png`
- Illustrates: "Clicking the Coils tab would open a window with the coils folders and sub-folders from EBMS. You would then select the appropriate folders for the coil you are looking for." (585,406); "This would show you all the coils in the selected folder." (585,414)
- Header/tabs: Tab bar Unscheduled / Scheduled / Production / Queue / **Coils** (active) / Wrapping. Folder sub-tabs: Tuff Rib & Diamond Rib Coils (active), Standing Seam Coils, 24 Ga. 44.72" AZ50 Coil, 24 Ga. 43" Coils, 26 Ga. 44.72" AZ50 Coil, Agra Rib Coils, Board & Batten Coils. Second row of sub-tabs: 26 Ga. 41" Coils, 28 Ga. 41" Coils, 28 Ga. 41" Coils Colorbond, **29 Ga. 41" Coils** (active).
- Controls: none (browse-only).
- Table: Left table — ID | Description, 14 rows: CS8055 BUCKSKIN/"29ga x 41.2" Coil Buckskin"; CS8129 PEBBLE KHAKI; CS8229 DARK BROWN; CS8250 DARK RED; CS8259 TILE RED; CS8260 SLATE BLUE; CS8262 BLACK; CS8273 BONE WHITE; CS8305 STONE GREY; CS8306 CHARCOAL; CS8307 MELCHER GREEN; CS8315 TAN; **CS8317 WHITE WHITE** (selected, blue outline); CS8326 COFFEE BROWN. Right table — header "CS8317 WHITE WHITE - 29ga. X 41.2" Coil White White" with columns Lot Number | On Hand | Received | Shipped | Processed | Lot Date, 12 rows shown: EP8C39C01 4,108.737864 / — / — / 4,108.737864 / 12/11/25; EP8C39C02 8,464.000000/—/—/8,464.000000/12/11/25; EP8C39C03 4,108.737864/—/—/4,108.737864/12/11/25; EP8C39C04 8,464.000000/—/—/8,464.000000/12/11/25; EP8C39C05 8,464.000000/—/—/8,464.000000/12/11/25; EP8C39C06 4,050.000000/—/—/4,050.000000/12/11/25; F6786659 —/—/—/26.193333/—; F7350023 83.427884/—/—/83.427884/11/25/25; F7350025 3,392.534175/—/17.660000/3,392.534175/02/19/26; F7350026 3,071.698501/—/285.870000/3,071.698501/02/19/26; FNJ4150C03 4,516.019417/—/—/4,516.019417/01/22/25; FNJ4151C04 644.315918/—/—/644.315918/01/22/25; FOF4209C01 3,322.379741/—/—/3,322.379741/09/08/25.
- Indicators: Selected coil row (CS8317 WHITE WHITE) has blue outline highlight.
- Dialog/popup: none.
- Notes: none.
- Verified: pass3


### Unclear / open questions
- (254, 142)-(257, 151): bare "?" annotation next to the default-Warehouse note — no accompanying text explaining what's unresolved.
- (606, 416)-(610, 425): bare "?" annotation near the Scheduled-tab line-item display note — unclear what specific question it marks.
- (682, 502)-(693, 508): block reads only "Here" — a pointer/callout with no further text, purpose not stated on the page.
- (943, ...) purple "Here" pentagon marker visible in the overview render near the cutlist section has no attached text block explaining what it points to beyond proximity.


### Other screens on this page (3)

Screens whose annotated section did not match a heading above. Ordered by board position (x, then y).

#### Screen (650,501) — EBMS "Products" component window (external ERP screenshot)
- File: `p2_113_x650_y501.png`
- Illustrates: (473,624)-(477,625) "Screenshot from EBMS"
- Header/tabs: Windows title bar "Products\Meta\Dia. Rib Siding 29Ga. Classic/Txt.\{FEET}' {INCHES}" ({Height}") 29Ga. 36" Diamond Rib White White"; Product: MDR8317; Category: Dia. Rib Siding 29Ga. Classic/Txt.; sub-tabs General/Purchasing/Pricing/Count/Components(active)/Accessories/Advanced/Parts Calculate/Website/Lost Sale/Return/Activity/Documents/Drawing Template/Production/Elevate E-Commerce/Custom Prices/Roll Options
- Table: columns Category, Quantity, Component, Measure, Description, Weight, Base Price, Cost, Total Cost, Quantity Formula (Inventory). Row: (Single Component) | 1.00 | CS8317 WHITE WHITE | ft | 29ga x 41.2" Coil White White | 2.05 | 4.63 | 2.8634 | 2.8634 | {Height}/12
- Controls: right side buttons Insert, New, Properties, Delete, Move Up(greyed), Move Down(greyed), Copy From..., Printed Doc. Show All/Show None; checkbox "Assembly Kit - Inventory is maintained only at the component level" (checked); dropdown "Never" for "prompt user to configure components to order"(greyed); checkboxes "Fixed manufacturing cost of $2.86" and "Use this item's sales G/L for components" (unchecked, greyed); OK/Cancel/New/Delete/Print buttons at bottom
- Indicators: Total Weight 2.05, Total Base Price $4.63, Total Cost $2.8634, Total Items 1.000000
- Notes: This is a native EBMS desktop application window, not the app being specced
- Verified: pass3


#### Screen (686,455) — Rollforming / Scheduled / Tuff Rib & Diamond Rib (Select Supplier / Coil Number modal)
- File: `p2_108_x686_y455.png`
- Illustrates: (678,456)-(685,459) "Here the Manager has 2 options, he can just assign a Supplier and leave the Coil Number as Undefined, or, he can assign a Supplier and a Coil Number..."
- Header/tabs: Rollforming pill; top-right "Completed orders for the past 90 days"; tab bar Unscheduled/Scheduled(active)/Production/Queue/Coils/Wrapping; sub-tabs Tuff Rib & Diamond Rib(active)/Agra Rib & Titan Rib/Standing Seam/Board & Batten/Corrugated/Slit Line; date strip; search box
- Controls: greyed "Select Supplier / Coil Number" button (green, disabled look) top-left; order row "Notes" button (red dot = unread); modal buttons Cancel (red) and Assign (green, disabled/greyed here)
- Table: columns Qty Ordered, Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes — rows show Undefined/Undefined for Supplier/Coil Number; below modal: rows for orders 330616 (Sales Order, 29Ga. Black), 330617 (Board & Batten, 26Ga. Black), 330618 (Tuff Rib & Diamond Rib, 29Ga. Black), 330618 (Tuff Rib & Diamond Rib, 29Ga. Charcoal), 330618 (Tuff Rib & Diamond Rib, 29Ga. White White, partly cropped)
- Indicators: green checkboxes/Stock checkboxes; red dot on one Notes button; orange divider lines between line-item groups
- Dialog/popup: Title "Select Supplier / Coil Number". Body: two list boxes — Supplier (dropdown "Undefined", list: Undefined(highlighted), Color Steel, Taylor, Cascadia) and Coil Number (dropdown "Undefined", list "Undefined" highlighted, search box "Select Coil Number" with magnifier icon). Buttons: Cancel (red), Assign (green)
- Notes: order header row above table: "Thursday, May 09/2024", "Wed. May 08/2024" date button, order# 330615, "DAP Roofing Inc.", Sales Order icon, "29Ga. Black / 29Ga. Melcher's Green / 26Ga. White White", "Select Priority", Notes button
- Verified: pass3


#### Screen (686,478) — Rollforming / Scheduled / Tuff Rib & Diamond Rib (Select Supplier / Coil Number modal, Supplier chosen)
- File: `p2_110_x686_y478.png`
- Illustrates: (678,460)-(684,462) "This drop down of Suppliers would be created and come from the Machines tab."
- Header/tabs: order row above table: Thursday, May 09/2024, Wed. May 08/2024 date button, order# 330615, DAP Roofing Inc., Sales Order icon, "29Ga. Black / 29Ga. Melcher's Green / 26Ga. White White", Select Priority, Notes button
- Controls: greyed "Select Supplier / Coil Number" button top-left; modal buttons Cancel (red) and Assign (green, enabled)
- Table: columns Qty Ordered, Stock, Qty To Produce, Product ID, Description, Length, Supplier/Coil Number, Status, Line Item Notes — background rows all Undefined/Undefined; below modal: rows for orders 330616 (Sales Order, 29Ga. Black), 330617 (Board & Batten, 26Ga. Black), 330618 (Tuff Rib & Diamond Rib, 29Ga. Black), 330618 (Tuff Rib & Diamond Rib, 29Ga. Charcoal), 330618 (Tuff Rib & Diamond Rib, 29Ga. White White, partly cropped)
- Indicators: green checkboxes/Stock checkboxes; red dot on one Notes button, green dot on 330616 Notes button; orange divider lines between line-item groups
- Dialog/popup: Title "Select Supplier / Coil Number". Body: Supplier field pre-filled "Cascadia" (dropdown closed, no list shown); Coil Number dropdown "Undefined" with list open, "Undefined" highlighted blue, search box "Select Coil Number" with magnifier icon below. Buttons: Cancel (red), Assign (green, enabled)
- Verified: pass3


---

## Page 3 — Shipping

_Legend and Overall Notes are repeated at the top of this page; see [Board-wide notes](#board-wide-notes-legend-priorities-warehouseslocations-machines)._

### Sales in EBMS
Section header (517, 88), branching to three department columns: Trim / Rollforming / Shipping (517,88)-(590,142).
- Trim → "See Page 1" (364,165)-(404,216)
- Rollforming → "See Page 2" (448,165)-(508,216)
- Shipping (583, 165) — this page's main flow, continues below.

#### Screens (14)

##### Screen (272,70) — Warehouses list, 3 rows
- File: `p3_009_x272_y70.png`
- Illustrates: (290,75)-(294,78) "If we have multiply Warehouses then there needs to be a way to select the default Warehouse..."
- Header/tabs: Same Warehouses tab bar as Screen (294,46). Green "+ Create Warehouse" button.
- Controls: none beyond tab bar and Create button
- Table: Columns: Name | Address | Description | Default | Action. Row 1: "Warehouse #1" | "20 Clearview Dr. Tillsonburg" | "Wise Line's primary warehouse in the production plant" | ✔ | "…". Row 2: "Warehouse #2" | "52219 John Wise Line, Aylmer" | "Wise Line's secondary warehouse for large order packs" | (blank) | "…". Row 3: "Warehouse #3" | "590 Barth Side Road, Langton" | "Wise Line's overflow warehouse" | (blank) | "…". 3 rows, all visible.
- Indicators: Default column checkmark only on Warehouse #1.
- Dialog/popup: none
- Notes: Not a duplicate of Screen (294,70) — that screen has only 1 row (Warehouse #1); this one has all 3 warehouses, illustrating the multi-warehouse/default-warehouse selection concept.
- Verified: pass3

##### Screen (294,46) — Warehouses (Admin settings, empty)
- File: `p3_001_x294_y46.png`
- Illustrates: (301,41)-(305,44) "First you would have to create a Warehouse"
- Header/tabs: Tab bar: Users, Machines, "Warehouses" (active/white), Location Types, Loactions, Trucks, Priorities. Search box top right.
- Controls: Green "+ Create Warehouse" button, top right, enabled.
- Table: Columns: Name | Address | Description | Default | Action. No rows (empty state).
- Indicators: none
- Dialog/popup: none
- Notes: Empty table, no placeholder text shown.
- Verified: pass3

##### Screen (294,58) — Create Warehouse dialog
- File: `p3_004_x294_y58.png`
- Illustrates: (304,52)-(309,54) "Clicking this button would open this window where you would enter the Name, Address and Description of the Warehouse you want to create."
- Header/tabs: Behind dialog: same Warehouses tab bar as Screen (294,46).
- Controls: Modal titled "Create Warehouse" with red "X" close button. Fields: Name (placeholder "Warehouse Name"), Address (placeholder "123 Main St"), Description (textarea, placeholder "Enter Warehouse Description"). Green "Create" button at bottom, enabled.
- Table: none (table behind dialog is empty, obscured)
- Indicators: none
- Dialog/popup: Title "Create Warehouse", fields Name/Address/Description, button Create.
- Notes: none
- Verified: pass3

##### Screen (294,70) — Warehouses list, 1 row
- File: `p3_007_x294_y70.png`
- Illustrates: no adjacent annotation (nearest: (290,75) default-warehouse question further below)
- Header/tabs: Same Warehouses tab bar as Screen (294,46). Green "+ Create Warehouse" button.
- Table: Columns: Name | Address | Description | Default | Action. Row 1: "Warehouse #1" | "20 Clearview Dr. Tillsonburg" | "Wise Line's primary warehouse in the production plant" | ✔ (checkmark) | "…"
- Indicators: Default column shows a black checkmark for Warehouse #1.
- Dialog/popup: none
- Notes: none
- Verified: pass3

##### Screen (325,46) — Location Type (Admin settings, empty)
- File: `p3_002_x325_y46.png`
- Illustrates: (331,42)-(336,44) "Second you would have to create a Location Type"
- Header/tabs: Tab bar: Users, Machines, Warehouses, "Location Type" (active/white), Loactions, Trucks, Priorities. Department pill row: Trim (active/white), Standing Seam, Rollforming, Board & Batten, Accessories. Search box top right.
- Controls: Green "+ Create Location Type" button, top right, enabled.
- Table: Columns: Name | Warehouse | Description | Action. No rows (empty state).
- Indicators: none
- Dialog/popup: none
- Notes: none
- Verified: pass3

##### Screen (325,58) — Create Location Type dialog
- File: `p3_005_x325_y58.png`
- Illustrates: (336,51)-(340,54) "Clicking this button would open this window where you would enter the Name and Description of the Location Type you want to create. You would also select a Warehouse from the dropdown of existing Warehouses."
- Header/tabs: Behind dialog: Location Type tab bar with grey "Trim" pill shown atop the dialog itself.
- Controls: Modal titled "Create Location Type" (with grey "Trim" department label pill at top), red "X" close. Fields: Name (placeholder "Location Type Name"), Warehouse (dropdown, placeholder "Warehouse"), Description (textarea, placeholder "Enter Location Type Description"). Green "Create" button, enabled.
- Table: none (empty table behind)
- Indicators: none
- Dialog/popup: Title "Create Location Type", dept pill "Trim", fields Name/Warehouse (dropdown)/Description, button Create.
- Notes: none
- Verified: pass3

##### Screen (325,70) — Location Type list, 1 row
- File: `p3_008_x325_y70.png`
- Illustrates: no adjacent annotation
- Header/tabs: Same Location Type tab bar as Screen (325,46), Trim dept pill active.
- Table: Columns: Name | Warehouse | Description | Action. Row 1: "Small" | "Warehouse #1" | "Small Trim Carts, 18" wide" | "…"
- Indicators: none
- Dialog/popup: none
- Notes: none
- Verified: pass3

##### Screen (355,46) — Locations (Admin settings, empty)
- File: `p3_003_x355_y46.png`
- Illustrates: (362,42)-(366,44) "Third you would have to create a Location"
- Header/tabs: Tab bar: Users, Machines, Warehouses, Location Types, "Locations" (active/white), Trucks, Priorities. Department pill row: Trim (active/white), Standing Seam, Rollforming, Board & Batten, Accessories. Search box top right.
- Controls: Green "+ Create Location" button, top right, enabled.
- Table: Columns: Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action. No rows (empty state).
- Indicators: none
- Dialog/popup: none
- Notes: none
- Verified: pass3

##### Screen (355,58) — Create Location dialog
- File: `p3_006_x355_y58.png`
- Illustrates: (365,51)-(372,54) "Clicking this button would open this window where you would enter the Name, Max Weight and Description of the Location you want to create. You would also select a Warehouse from the dropdown of existing Warehouses, a Location Type from the dropdown of existing Location Types within that Warehouse and you have to decide if this is a Multi Order location."
- Header/tabs: Grey "Trim" department pill at top of modal.
- Controls: Modal titled "Create Location". Fields: Name (placeholder "Location Name"), Warehouse (dropdown, placeholder "Warehouse"), Location Type (dropdown, placeholder "Location Type"), Max Weight (numeric, placeholder "0", unit "lbs"), Multi Order toggle (currently "No", greyed/checked-off state) with adjacent "Number of Orders" field (placeholder "0"), Description (textarea, placeholder "Enter Location Description"). Green "Create" button, enabled.
- Table: none
- Indicators: Multi Order toggle shown in off/"No" state (grey checkmark icon).
- Dialog/popup: Title "Create Location", dept pill "Trim", fields as above, button Create.
- Notes: none
- Verified: pass3

##### Screen (355,76) — Locations list, 1 row (Multi Order off)
- File: `p3_010_x355_y76.png`
- Illustrates: (351,62)-(355,64) "All Location Names have to be unique within the entire app, can never be doubled up."
- Header/tabs: Same Locations tab bar as Screen (355,46), Trim dept pill active.
- Table: Columns: Name | Warehouse | Location Type | Max Weight | Description | Multi Order | Action. Row 1: "301" | "Warehouse #1" | "Small" | "1200 lbs" | "1200 lbs, 18" Wide Small Trim Cart" | (grey/off checkmark icon) 0 | "…"
- Indicators: Multi Order column shows a greyed-out checkmark icon with "0" — not a Multi Order location.
- Dialog/popup: none
- Notes: Description text says "1200 lbs" but Max Weight column also independently says "1200 lbs" (duplicate figure in description).
- Verified: pass3

##### Screen (370,92) — Location picker popup (Warehouse/Dept/Type/Location tabs)
- File: `p3_016_x370_y92.png`
- Illustrates: (374,89)-(377,91) "This is how locations would show up in production when Workers are selecting locations."
- Header/tabs: Top row of pill tabs: "Warehouse #1" (active/white), Warehouse #2, Warehouse #3. Second row: Trim (active/white), Rollforming, Accessories. Red "X" close button top right.
- Controls: Six columns of location-type buttons, each with a grey header: "1 of 1", "Wooden", "Small", "Medium", "Large", "Long".
- Table: none (grid of buttons)
- Table: n/a — list of location codes per column: 1 of 1 [101-106]; Wooden [201-212]; Small [301-318]; Medium [401-410]; Large [501-510]; Long [601-616].
- Indicators: none
- Dialog/popup: Location-selection popup, no title text beyond tabs; each location code is a clickable button.
- Notes: none
- Verified: pass3

##### Screen (374,66) — Create Location dialog, Multi Order = Yes
- File: `p3_013_x374_y66.png`
- Illustrates: (380,65)-(384,69) "If you want this to be a Multi Order Location than you would toggle "On" the Multi Order button. This would make the Number of Orders text box become available..."; (366,70)-(373,70) "Yes A Multi Order Location"
- Header/tabs: Grey "Trim" department pill atop modal, red "X" close.
- Controls: Same "Create Location" modal as Screen (355,58) but Multi Order toggle now shows green checkmark "Yes" (enabled), with adjacent "Number of Orders" field now active/editable showing placeholder "0". Green "Create" button.
- Table: none
- Indicators: Multi Order toggle green/checked = Yes.
- Dialog/popup: Title "Create Location", same fields, Multi Order toggled Yes.
- Notes: Same as Screen (355,58) except: Multi Order toggle is set to "Yes" (green) instead of "No".
- Verified: pass3

##### Screen (378,76) — Locations list, 1 row (Multi Order on, 12)
- File: `p3_015_x378_y76.png`
- Illustrates: (397,78)-(401,84) "A Multi Order Location would allow you to use the location multiple times... This example would be able to be used 12 times..." (nearest)
- Header/tabs: Same Locations tab bar as Screen (355,46), Trim active.
- Table: Row 1: "301" | "Warehouse #1" | "Small" | "3500 lbs" | "1200 lbs, 18" Wide Small Trim Cart" | Multi Order checkmark green/ON, count "12" | "…"
- Indicators: Multi Order column shows green (enabled) checkmark icon, count 12. Max Weight now 3500 lbs (changed from 1200 lbs in Screen (355,76)); Description text still says "1200 lbs" (stale relative to the new Max Weight).
- Dialog/popup: none
- Notes: Differs from Screen (355,76) in three ways: Max Weight 3500 lbs (was 1200 lbs), Multi Order green/on with count 12 (was grey/off with count 0).
- Verified: pass3

##### Screen (384,66) — Create Location dialog, Number of Orders = 12
- File: `p3_014_x384_y66.png`
- Illustrates: (397,78)-(401,84) "A Multi Order Location would allow you to use the location multiple times (for multiple orders) before becoming unavailable, within the Max Weight limit. This example would be able to be used 12 times (for 12 different orders)..."
- Header/tabs: Grey "Trim" department pill atop modal.
- Controls: Same modal as Screen (374,66), Multi Order = Yes (green), Number of Orders field now filled with "12". Green "Create" button.
- Table: none
- Indicators: Multi Order toggle green/Yes; Number of Orders = 12.
- Dialog/popup: Title "Create Location", Number of Orders = 12.
- Notes: Same as Screen (374,66) except: Number of Orders field now contains "12".
- Verified: pass3


### Shipping

#### Roles
- Shipping (583, 165)
- Shipping Manager (575, 172): "Shipping Managers should be able to see and edit everything from here down. Including what the Worker can see and do." (570, 171)
- Admin (548, 150): "Admin should be able to do everything in every Department (category)." (542, 150)
- "Salesmen need to push orders into the app" (552, 147) — feeding "All Unscheduled" (552, 150)
- "Each Department (category) needs be completely separate from the others. For example, everything that's done in the Trim department (category) should not affect anything in the Rollforming department (category). Each department (category) should be able to Release To Production without the other departments (categories) having to schedule their items. For example: A Trim Manager should be able to release the scheduled trims to production without the Rollforming Manager having to schedule their items first." (558, 147)

##### Screens (3)

###### Screen (218,42) — Priorities (Admin settings)
- File: `p3_000_x218_y42.png`
- Illustrates: no adjacent annotation (nearest is (207,42) Priorities dept-specific note and (212,45) hierarchy note, both further away)
- Header/tabs: Top tab bar: Users, Machines, Warehouses, Location Types, Loactions [sic], Trucks, "Priorities" (active/white). Second row of department pills: Trim (active/white), Standing Seam, Rollforming, Board & Batten, Accessories, Shipping. Search box "Search…" top right.
- Controls: none beyond tabs and search
- Table: Columns: Colour | Names | Hierarchy | Actions. Rows: (red) Now / 1 / …; (orange) ASAP / 2 / …; (yellow) By 8:00 / 3 / …; (yellow) By 9:00 / 4 / …; (yellow) By 10:00 / 5 / …; (yellow) By 11:00 / 6 / …; (yellow) By 12:00 / 7 / …; (yellow) By 1:00 / 8 / …; (yellow) By 2:00 / 9 / …; (yellow) By 3:00 / 10 / …; (yellow) By 4:00 / 11 / …; (yellow) By 5:00 / 12 / …. 12 rows total, all visible.
- Indicators: Colour column swatches — 1 red, 1 orange, 10 yellow. "Now" row separated by a bold black rule beneath it. Each row's Actions cell shows "…" (more menu).
- Dialog/popup: none
- Notes: "Loactions" tab label is a typo for "Locations". Confirms text annotation's priority hierarchy concept (#1 sorts to top) and department-specific priority lists.
- Verified: pass3

###### Screen (434,46) — Machines (Admin settings, collapsed)
- File: `p3_011_x434_y46.png`
- Illustrates: (410,33)-(476,41) "Machines, Rollforming" heading; (445,52)-(449,53) "Clicking this button would open this window where you would be able to create a list of coil suppliers."
- Header/tabs: Tab bar: Users, "Machines" (active/white), Warehouses, Location Types, Loactions, Trucks, Priorities. Search box top right.
- Controls: Three collapsible department panels: "Trim" (green badge "6 Machine(s)", chevron down), "Rollforming" (green badge "5 Machine(s)", grey "Coil Suppliers" button, chevron down), "Accessories" (no badge/count shown, chevron implied). All panels collapsed.
- Table: none (accordion, not table)
- Indicators: Green pill badges showing machine counts per department.
- Dialog/popup: none
- Notes: none
- Verified: pass3

###### Screen (434,55) — Coil Suppliers popup
- File: `p3_012_x434_y55.png`
- Illustrates: (445,52)-(449,53) "Clicking this button would open this window where you would be able to create a list of coil suppliers."
- Header/tabs: Same Machines tab bar and accordion (Trim/Rollforming/Accessories) as Screen (434,46), behind popup.
- Controls: Popup titled "Coil Suppliers" anchored near the Rollforming panel's "Coil Suppliers" button. List rows each with a red circular "X" delete icon: "- Taylor", "- Color Steel", "- Cascadia". Green "Add" button at bottom.
- Table: none (simple list)
- Indicators: Red delete/remove icons per supplier row.
- Dialog/popup: Title "Coil Suppliers", 3 items (Taylor, Color Steel, Cascadia) each removable, "Add" button.
- Notes: none
- Verified: pass3


#### Shipping Unscheduled tab
- Tab: Shipping Unscheduled (605, 182)
- Set the Ship Date (606, 197)
- Scheduling Entire Order (602, 199) — Or (606, 199) — Scheduling Partial Order (608, 199)
- "Once you have selected at least one order, then the Schedule button should become available. We need to be able to expand & collapse orders, view the map, check & deal with notes and set Priorities without losing the orders we've selected." (560, 202)
- Update Image placeholder (575, 205)
- "Select all the orders you want to Schedule." (562, 208)
- The Truck Notes Tab (562, 211)
- Viewing the Map (586, 211)
- "Clicking the Schedule button will open this window" (570, 212)
- Update Image placeholders (551, 217), (600, 218), (575, 220)
- "Click this to view the address on a map" (603, 222)
- "Click this to open a calender and select a Ship Date" (567, 228)
- Update Image placeholders (600, 228), (575, 237)
- "This shows the Total Weight for all the Delivery Orders you have selected and are scheduling. It also shows the Longest Length of everything on the orders you have selected and are scheduling." (586, 243)
- "Only once you have selected a Ship Date do the check boxes for the trucks become available." (562, 244)
- "This shows the Total Weight for all the Pickups you have selected and are scheduling. It also shows the Longest Length of everything on the orders you have selected and are scheduling." (587, 246)
- "These are NOT customer pickups, these are things that a delivery driver needs to pickup for a supplier." (586, 248)
- Update Image placeholder (575, 250)
- "Select the truck you want to assign these order to" (567, 258)
- "If the Assigned Weight is over the Weight Limit, then this box gets highlighted in orange. This does NOT give any other warnings or prevent the Manager from assigning these orders to this truck because later the Manager will just have to divide up the orders into multiple loads for this truck." (587, 259)
- "Selecting a truck will auto fill the Total Weight & Longest Length of the Delivery Orders and/or Pickups you had selected. Once you have selected a truck, then the Apply button becomes available." (562, 263)
- Update Image placeholder (574, 266)
- "Clicking Apply will make the selected orders disappear from the Unsheduled tab and appear in the Scheduled tab under the Date and Truck that you selected." (566, 273)
- Viewing Partial Order (613, 287)

##### Screens (3)

###### Screen (598,42) area — three distinct states (not duplicates)
- File: `p3_020_x543_y212.png`, `p3_021_x567_y214.png`, `p3_022_x592_y224.png`
- Illustrates: (562,208)-(565,209) "Select all the orders you want to Schedule."; (562,211)-(567,211) "The Truck Notes Tab"; (586,211)-(590,211) "Viewing the Map"; (603,222)-(606,223) "Click this to view the address on a map"
- p3_020 (`p3_020_x543_y212.png`): Shipping Unscheduled table, Schedule button green/enabled, Trucks Notes enabled, checkboxes checked on rows 330605, 330609, 330615, 330616, 330618, 330632 (6 of 11), no popup — identical state to Screen (567,201) file `p3_018_x567_y201.png`.
- p3_021 (`p3_021_x567_y214.png`): Trucks Notes/Schedule popup, "Select Ship Date..." empty, 4 truck panels (101 Wt 8,500/Len 22'0", 102 Wt 18,500/Len 32'0", 103 Wt 18,500/Len 32'0", 104 Wt 34,400/Len 28'0"), all fields 0/blank, Apply disabled (pale), Cancel enabled (red) — identical state to Screen (592,212) file `p3_019_x592_y212.png`.
- p3_022 (`p3_022_x592_y224.png`): Map popup titled "Order #: 330618  Customer Name: A.W.C.", red "X" close, embedded Google Maps place card for "567 George St" (Directions/Save/Nearby/Send to phone/Share, address "567 George St, Woodstock, ON N4S 4J6", edit/add-place links, Photos thumbnail) plus map view with red pin. Behind popup: Shipping Unscheduled table with the same 6 rows checked and Schedule enabled.
- Table: see per-file notes above.
- Indicators: p3_020 has the same red/green Order Notes dots as Screen (595,185).
- Dialog/popup: p3_021 = truck-notes/schedule dialog; p3_022 = map dialog; p3_020 = none.
- Notes: These three files are NOT duplicates of each other — each shows a different UI state (checked table / schedule popup / map popup).
- Verified: pass3

###### Screen (592,212) — Shipping Unscheduled tab, 6 orders selected, Schedule enabled
- File: `p3_019_x592_y212.png`
- Illustrates: (570,212)-(574,212) "Clicking the Schedule button will open this window" — this is the state just before the click.
- Header/tabs: "Shipping" pill; tabs Unscheduled (active) / Scheduled / Accessories / Loading; "Completed orders for the past 90 days" (top right); Search box.
- Controls: "Schedule" button (green, enabled, top left); "Trucks Notes" button (green, top right). No date strip on this tab.
- Table: Columns: [checkbox] | [expand] | Entry Date | Ship Date | Order # | Customer Name | Address | City | Map | Weight | Longest Length | Ship Via | Priority | Order Notes. 11 rows, all Entry Date Monday, May 06/2024: 330605 H F H Inc, 212 Victoria St., Belmont, 532.67 lbs, 13'6" (162"), Delivery, Ship Thu May 09 — checked, Notes (red dot); 330608 Jireh Tools, 1548 County Rd 34, Ruthven, 1,673.49 lbs, 9'9-1/2" (117-1/2"), Thu May 09 — unchecked; 330609 Arnold Contracting, 789 Walnut St., Vienna, 4,292.09 lbs, 21'3-3/4" (255-3/4"), Thu May 09 — checked; 330615 DAP Roofing Inc., 88 Raglan St., Aylmer, 924.78 lbs, 12'0" (144"), Thu May 09 — checked; 330616 Arnold Contracting, 432 Hill St., London, 1,534.26 lbs, 16'0" (192"), Thu May 09 — checked, Notes (green dot); 330617 Ontario Metal Products Ltd., 8376 Hwy 3, Dunnville, 489.17 lbs, 32'0" (384"), Fri May 10 — unchecked; 330618 A.W.C., 567 George St., Woodstock, 1,004.97 lbs, 13'6" (162"), Thu May 09 — checked, Notes (green dot); 330622 Ontario Metal Products Ltd., 8376 Hwy 3, Dunnville, 218.64 lbs, 18'7-1/2" (223-1/2"), Fri May 10 — unchecked; 330629 Ontario Metal Products Ltd., 8376 Hwy 3, Dunnville, 734.28 lbs, 14'2-1/2" (170-1/2"), Fri May 10 — unchecked; 330631 Jireh Tools, 1548 County Rd 34, Ruthven, 1,386.37 lbs, 25'9" (309"), Thu May 09 — unchecked; 330632 Upright Construction, 21 Butler Dr., St. Thomas, 512.14 lbs, 4'1" (49"), Thu May 09 — checked. Every row: Map = red pin icon, Ship Via = truck icon "Delivery", Priority = "Select Priority".
- Indicators: 6 checked rows (330605, 330609, 330615, 330616, 330618, 330632); Order Notes dots red on 330605, green on 330616 and 330618.
- Dialog/popup: none.
- Notes: The Schedule popup with truck panels is on `p3_021_x567_y214.png` (see the p3_020/021/022 group entry).
- Verified: pass3

###### Screen (595,185) — Shipping Unscheduled tab, Schedule button disabled
- File: `p3_017_x595_y185.png`
- Illustrates: (605,182)-(608,184) "Shipping Unscheduled"; (560,202)-(565,205) "Once you have selected at least one order, then the Schedule button should become available..."
- Header/tabs: Department pill "Shipping" top left. Tab bar: Unscheduled (active/white), Scheduled, Accessories, Loading. Top right: "Completed orders for the past 90 days" pill, Search box below it.
- Controls: "Schedule" button top left, disabled/greyed (pale green, italic text). "Trucks Notes" button top right, green, enabled.
- Table: Columns: [checkbox] | [expand arrow] | Entry Date | Ship Date | Order # | Customer Name | Address | City | Map | Weight | Longest Length | Ship Via | Priority | Order Notes. Rows (all unchecked): 330605 H F H Inc, 212 Victoria St., Belmont, 532.67 lbs, 13'6" (162"), Delivery, Select Priority, Notes(red dot); 330608 Jireh Tools, 1548 County Rd 34, Ruthven, 1,673.49 lbs, 9'9-1/2" (117-1/2"), Delivery, Select Priority, Notes; 330609 Arnold Contracting, 789 Walnut St., Vienna, 4,292.09 lbs, 21'3-3/4" (255-3/4"), Delivery, Select Priority, Notes; 330615 DAP Roofing Inc., 88 Raglan St., Aylmer, 924.78 lbs, 12'0" (144"), Delivery, Select Priority, Notes; 330616 Arnold Contracting, 432 Hill St., London, 1,534.26 lbs, 16'0" (192"), Delivery, Select Priority, Notes(green dot); 330617 Ontario Metal Products Ltd., 8376 Hwy 3, Dunnville, 489.17 lbs, 32'0" (384"), Delivery, Select Priority, Notes; 330618 A.W.C., 567 George St., Woodstock, 1,004.97 lbs, 13'6" (162"), Delivery, Select Priority, Notes(green dot); 330622 Ontario Metal Products Ltd., 8376 Hwy 3, Dunnville, 218.64 lbs, 18'7-1/2" (223-1/2"), Delivery, Select Priority, Notes; 330629 Ontario Metal Products Ltd., 8376 Hwy 3, Dunnville, 734.28 lbs, 14'2-1/2" (170-1/2"), Delivery, Select Priority, Notes; 330631 Jireh Tools, 1548 County Rd 34, Ruthven, 1,386.37 lbs, 25'9" (309"), Delivery, Select Priority, Notes; 330632 Upright Construction, 21 Butler Dr., St. Thomas, 512.14 lbs, 4'1" (49"), Delivery, Select Priority, Notes. Entry Date all "Monday, May 06/2024". Ship Date mostly "Thursday, May 09/2024" except 330617/330622/330629 = "Friday, May 10/2024". 11 rows visible, all shown.
- Indicators: Red map pin icon per row (Map column). Order Notes: red dot (330605, unread), green dot (330616, 330618, read/dealt-with), others plain "Notes" button (no note).
- Dialog/popup: none
- Notes: All row checkboxes unchecked; Schedule button correspondingly disabled.
- Verified: pass3


#### Shipping Scheduled tab
- Tab: Shipping Scheduled (605, 302)
- "Choose the day you want to work on." (616, 306)
- "If the weight in these boxes are over the Weight Limit of the Truck, then the boxes should be highlighted in orange." (617, 308)
- "Here you would have a tab for each truck." (594, 308)
- "This would show how many Delivery Orders have been scheduled for each truck for the selected day, and the total weight of those order." (616, 310)
- "This would show how many Pickups have been scheduled for each truck for the selected day, and the total weight of those pickups. These are NOT customer pickups, these are things that a delivery driver needs to pickup for a supplier." (617, 311)
- Update Image placeholder (606, 312)
- "This would show how many of the Delivery Orders that are scheduled for each truck that are NOT assigned to a Load yet, and the total weight of those order." (616, 313)
- "This would show how many of the Pickups that are scheduled for each truck that are NOT assigned to a Load yet, and the total weight of those order. These are NOT customer pickups, these are things that a delivery driver needs to pickup for a supplier." (616, 315)
- "When these are zero, then the boxes should be highlighted in green showing that everything is assigned to a Load." (617, 317)
- "Clicking on a this button would open up a drop down of all the orders that are scheduled for that truck for the selected day" (596, 319)
- "The Status for each order would be blank until the orders are released to loading." (616, 324)
- "We need a Select All check box, which would select all the order that have not been assigned to a load." (594, 325)
- Update Image placeholder (605, 330)

##### Screens (10)

###### Screen (586,378) — Shipping Scheduled, Truck 101 with Load 1 + Load 2 tabs
- File: `p3_033_x586_y378.png`
- Illustrates: (591,357)-(596,358) "Clicking the Add To Load button would cause a few things to happen:" / (592,359)-(596,365) description of Load tab/status/weight updates
- Header/tabs: Same day-tab bar, Thu. May 09/2024 active.
- Controls: Truck 101 card header now shows two pills: "Load 1  Weight: 2,991.71 lbs.  [Unreleased]  +" and "Load 2  +" (new, empty). Delivery Orders Total# 6 (8,800.91 lbs orange), Total Unassigned# 3 (5,809.20 lbs, plain box).
- Table: order rows (same 6 orders as Screen (598,359), collapsed under Delivery Orders summary, not fully shown in this crop — L-1 markers on 330605, 330615, 330616; checkboxes on 330609, 330618, 330632).
- Indicators: "Unreleased" black status pill on Load 1.
- Dialog/popup: none
- Notes: Confirms annotation: after Add To Load, a new "Load 2" tab appears, status "Unreleased" shown on Load 1.
- Verified: pass3

###### Screen (598,305) — Shipping Scheduled tab, Truck 101 with Load 1 orders (day view)
- File: `p3_026_x598_y305.png`
- Illustrates: (605,302)-(608,304) "Shipping Scheduled"; (594,308)-(597,309) "Here you would have a tab for each truck."
- Header/tabs: Shipping pill, tab bar Unscheduled/"Scheduled"(active)/Accessories/Loading. "All Scheduled Orders" pill, date field "Thursday May 09/2024" with calendar icon, day-tabs Mon May 06/2024, Tue May 07/2024, Wed May 08/2024, "Thu. May 09/2024" (active/white outline), Fri May 10/2024.
- Controls: Four Truck cards (101, 102, 103, 104), each with "Load 1" pill + green "+" button. Truck 101: Delivery Orders Total# 6 (Total Weight 8,800.91 lbs, orange highlight), Total Unassigned# 6 (Total Unassigned Weight 8,800.91 lbs, orange); Pickups Total#0/0 lbs, Total Unassigned# 0/0 lbs (green). Trucks 102-104: all zeros (green highlighted boxes for unassigned #/weight), weight limits 18,500/18,500/34,400 lbs respectively; Truck 101 weight limit 8,500 lbs.
- Table: n/a (truck cards)
- Indicators: Truck 101 boxes orange (over limit / has unassigned); trucks 102-104 boxes green (0, fully assigned/empty).
- Dialog/popup: none
- Notes: none
- Verified: pass3

###### Screen (598,320) — Truck 101 expanded showing order list under Load 1
- File: `p3_027_x598_y320.png`
- Illustrates: (596,319)-(602,320) "Clicking on a this button would open up a drop down of all the orders that are scheduled for that truck for the selected day"
- Header/tabs: Same as Screen (598,305).
- Controls: Truck 101 card expanded (blue outline) showing order table below the Load1/Delivery/Pickup summary; "Reschedule" button top right, disabled/pale.
- Table: Columns: [checkbox] | Order # | Customer Name | Address | City | Map | Weight | Longest Length | Ship Via | Priority | Status | Order Notes. Rows: 330605 H F H Inc, 212 Victoria St., Belmont, 532.67 lbs, 13'6" (162"), Delivery, Select Priority, (Status blank), Notes(red); 330609 Arnold Contracting, 789 Walnut St., Vienna, 4,292.09 lbs, 21'3-3/4" (255-3/4"), Delivery, Select Priority, blank, Notes; 330615 DAP Roofing Inc., 88 Raglan St., Aylmer, 924.78 lbs, 12'0" (144"), Delivery, Select Priority, blank, Notes; 330616 Arnold Contracting, 432 Hill St., London, 1,534.26 lbs, 16'0" (192"), Delivery, Select Priority, blank, Notes(green); 330618 A.W.C., 567 George St., Woodstock, 1,004.97 lbs, 13'6" (162"), Delivery, Select Priority, blank, Notes(green); 330632 Upright Construction, 21 Butler Dr., St. Thomas, 512.14 lbs, 4'1" (49"), Delivery, Select Priority, blank, Notes. 6 rows, all unchecked.
- Indicators: Status column blank for all rows (per annotation: blank until released to loading). Order Notes: red dot (330605), green dots (330616, 330618).
- Dialog/popup: none
- Notes: Weight totals in card header show 8,800.91 lbs orange highlight.
- Verified: pass3

###### Screen (598,330) — Trucks 102-104 collapsed (duplicate)
- File: `p3_028_x598_y330.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104.
- Dialog/popup: none
- Notes: Same as Screen (598,305) except: cropped to show only the empty Truck 102/103/104 cards (Truck 101 scrolled off).
- Verified: pass3

###### Screen (598,339) — Truck 101, orders being checked for Load 1
- File: `p3_029_x598_y339.png`
- Illustrates: (593,346)-(596,347) "Select all the orders you want to assign to Load 1."; (616,344)-(620,345) "As you select orders, the Total Weight Selected needs to keep updating."
- Header/tabs: Same day-tab bar as Screen (598,305), Thu. May 09/2024 active.
- Controls: Truck 101 card, single "Load 1" pill + green "+" (Load 2 not yet present). "Selected Orders: Total Weight: 2,991.71 lbs." now shown. "Reschedule" button now enabled/green (was disabled). Delivery Orders Total# 6 (8,800.91 lbs orange), Total Unassigned# 6 (8,800.91 lbs orange) — nothing committed to a load yet.
- Table: Rows with plain checkboxes (no "L-1" tags yet): 330605 (checked), 330609 (unchecked), 330615 (checked), 330616 (checked), 330618 (unchecked), 330632 (unchecked). 3 of 6 checked (330605, 330615, 330616) — these sum to 2,991.71 lbs, matching "Selected Orders" total.
- Indicators: Delivery Orders Total Weight and Total Unassigned Weight both orange (nothing assigned yet).
- Dialog/popup: none
- Notes: Not a duplicate of Screen (598,330) — this is the order-selection step before "Add To Load", distinct from the collapsed Truck 102-104 cards.
- Verified: pass3

###### Screen (598,349) — Shipping Scheduled, all 4 trucks collapsed
- File: `p3_030_x598_y349.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (truck 101 card scrolled off top; only 102, 103, 104 visible, all with Load 1 pill + green "+", all zero/green)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups).
- Dialog/popup: none
- Notes: Duplicate/near-identical to portions of Screen (598,305)/(598,320)/(598,339) — shows trucks 102-104 only, all empty.
- Verified: pass3

###### Screen (598,359) — Truck 101, Load 1 committed (L-1 tags), Load 2 added
- File: `p3_031_x598_y359.png`
- Illustrates: (591,357)-(596,358) "Clicking the Add To Load button would cause a few things to happen"; (592,359)-(596,365) load tab/status/weight update description
- Header/tabs: Same as Screen (598,305), Thu. May 09/2024 active.
- Controls: Truck 101 card header now shows two pills: "Load 1  Weight: 2,991.71 lbs.  [Unreleased]  +" and "Load 2  +" (empty). Delivery Orders Total# 6 (Total Weight 8,800.91 orange), Total Unassigned# 3 (Total Unassigned Weight 5,809.20 lbs, no highlight). "Reschedule" button disabled/pale.
- Table: Columns same as Screen (598,320). Rows: L-1 | 330605 H F H Inc …Notes(red); [unchecked] 330609 Arnold Contracting …Notes; L-1 | 330615 DAP Roofing Inc. …Notes; L-1 | 330616 Arnold Contracting …Notes(green); [unchecked] 330618 A.W.C. …Notes(green); [unchecked] 330632 Upright Construction …Notes.
- Indicators: "L-1" text replaces the checkbox for orders already committed to Load 1 (330605, 330615, 330616). The remaining unassigned orders (330609, 330618, 330632) show plain unchecked checkboxes, not checked.
- Dialog/popup: none
- Notes: After "Add To Load," the 3 previously-selected orders became "L-1" tagged and a new empty "Load 2" pill appeared; the other 3 orders reverted to unchecked (not pre-selected for Load 2).
- Verified: pass3

###### Screen (598,368) — Trucks 102-104 collapsed (repeat)
- File: `p3_032_x598_y368.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a
- Table: n/a
- Indicators: All green/zero, same as Screen (598,349).
- Dialog/popup: none
- Notes: Same as Screen (598,349) — duplicate crop of empty trucks 102/103/104.
- Verified: pass3

###### Screen (598,441) — Trucks 102-104 collapsed (duplicate)
- File: `p3_041_x598_y460.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104, each showing empty "Load 1 +" pill.
- Dialog/popup: none
- Notes: Not a header-only crop — same collapsed-trucks content as Screens (598,330)/(598,368)/(598,434b).
- Verified: pass3

###### Screen (598,591) — Shipping / Scheduled — full date strip, all trucks unstarted, Friday selected
- File: `p3_056_x598_y591.png`
- Illustrates: no adjacent annotation (full-page view showing date navigation)
- Header/tabs: "Shipping" button, "Completed orders for the past 90 days" button; tabs Unscheduled / **Scheduled** (active) / Accessories / Loading; Search box.
- Controls: Date strip: "All Scheduled Orders", calendar red "Friday May 10/2024" (selected/highlighted red), "Mon. May 06/2024", "Tue. May 07/2024", "Wed. May 08/2024", "Thu. May 09/2024" (white/normal, not highlighted), "Fri. May 10/2024" (white/normal, distinct from the red calendar chip). Four truck cards fully visible: Truck 101 (Weight Limit 8,500 lbs.), Truck 102 (18,500 lbs.), Truck 103 (18,500 lbs.), Truck 104 (34,400 lbs.) — each with "Load 1" (+) and Delivery Orders/Pickups fields, all values 0.
- Table: none (no orders loaded in this view)
- Indicators: Only "Friday May 10/2024" calendar chip shown with red badge/highlight; all other date pills are plain gray/white.
- Dialog/popup: none
- Notes: All four trucks shown with empty Load 1 panels.
- Verified: pass3


#### Load assignment
- "We need to be able to expand & collapse orders, view the map, check & deal with notes and set Priorities without losing the orders we've selected." (592, 338)
- "Once you have selected at least one order, then the Add To Load button & Reschedule button should become available." (591, 341)
- "As you select orders, the Total Weight Selected needs to keep updating." (616, 344)
- "Select all the orders you want to assign to Load 1." (593, 346)
- Update Image placeholder (605, 351)
- "Clicking the Add To Load button would cause a few things to happen:" (591, 357)
- "Clicking the Add To Load button would assign the selected orders to that load" (598, 357)
- "The selected orders would be assigned to that load. The total weight of the orders assigned to that load would be displayed in the load tab. A status of Unreleased would appear in the load tab. The load number (L-1 in this case) would replace the order check boxes. Another load tab would appear (Load 2 in this case) The Total # and Total Weight for Delivery Orders would update The Total Weight for Selected Orders would update" (592, 359)
- Update Image placeholders (606, 366), (594, 385), (615, 386)
- "Clicking on a Load tab would show the orders assigned to that Load" (605, 397)
- Update Image placeholder (606, 407)
- "Clicking Route will open a map showing a route for the orders on this Load" (601, 415)
- Update Image placeholder (605, 426)
- "The sequence of these orders determines which order to deliver 1st, 2nd, 3rd, etc. and shows that route on the map. We need to be able to drag these orders up & down to change the order that they will be delivered." (617, 441)
- Update Image placeholder (604, 456)
- "Clicking the Release To Loading button would make the Load show up in the Loading window and change the Load and order Status's to Not Started" (598, 468)
- Update Image placeholder (605, 480)

##### Screens (18)

###### Screen (567,201) — Shipping Unscheduled tab, 6 orders selected, no popup
- File: `p3_018_x567_y201.png`
- Illustrates: (562,208)-(565,209) "Select all the orders you want to Schedule."
- Header/tabs: Same as Screen (595,185): Shipping pill, Unscheduled (active)/Scheduled/Accessories/Loading, "Completed orders for the past 90 days" pill, Search box.
- Controls: "Schedule" button top left now green/enabled. "Trucks Notes" button top right, green, enabled. No popup/dialog visible.
- Table: Same 11-row table as Screen (595,185), same data; checkboxes now checked on rows 330605, 330609, 330615, 330616, 330618, 330632 (6 of 11 checked), rest unchecked.
- Indicators: Same red/green Order Notes dots as Screen (595,185) (red on 330605, green on 330616/330618).
- Dialog/popup: none
- Notes: Plain table state, no dialog open — despite the neighbouring file being a popup, this file itself shows no popup.
- Verified: pass3

###### Screen (567,229) — Schedule window, calendar open (default no date)
- File: `p3_023_x567_y229.png`
- Illustrates: (567,228)-(571,228) "Click this to open a calender and select a Ship Date"
- Header/tabs: Same Schedule window as Screen (567,201) behind calendar.
- Controls: "Select Ship Date..." field with calendar popup open: header "‹ May 2024 ›", days grid Su-Sa, dates 1-31, "9" highlighted green (today/current). "Cancel" (white/grey) and "Set Date" (dark green) buttons at bottom of calendar. Apply button still disabled below.
- Table: n/a (truck cards behind, all still 0)
- Indicators: Date "9" highlighted green in calendar.
- Dialog/popup: Calendar picker "May 2024" with Cancel / Set Date buttons.
- Notes: none
- Verified: pass3

###### Screen (567,244) — Schedule window, date set, trucks unchecked
- File: `p3_024_x567_y244.png`
- Illustrates: (562,244)-(566,245) "Only once you have selected a Ship Date do the check boxes for the trucks become available."
- Header/tabs: Same Schedule window.
- Controls: Ship date field now shows "Thursday, May 09/2024". Selected Delivery Orders: Total #: 6, Total Weight: 8,800.91 lbs., Longest Length: 21'3-3/4" (255-3/4"); Selected Pickups all 0. Truck checkboxes for 101/102/103/104 now green-outlined/available but still unchecked. Apply button still disabled (pale). Cancel enabled (red).
- Table: n/a (truck cards)
- Indicators: Truck checkboxes now enabled (green outline) vs greyed before.
- Dialog/popup: none (same schedule window)
- Notes: none
- Verified: pass3

###### Screen (567,259) — Schedule window, Truck 101 selected, weight orange
- File: `p3_025_x567_y259.png`
- Illustrates: (587,259)-(591,263) "If the Assigned Weight is over the Weight Limit, then this box gets highlighted in orange..."; (562,263)-(566,266) "Selecting a truck will auto fill the Total Weight & Longest Length..."
- Header/tabs: Same Schedule window, ship date "Thursday, May 09/2024".
- Controls: Truck 101 checkbox now checked (green check). Truck 101's "Assigned Delivery Orders" Total Weight field now shows "8,800.91 lbs." highlighted orange (over its 8,500 lbs limit), Longest Length "21'3-3/4" (255-3/4")". Apply button now enabled (green). Trucks 102/103/104 unchanged/unchecked.
- Table: n/a
- Indicators: Truck 101 Assigned Delivery Orders Total Weight box highlighted orange (over weight limit).
- Dialog/popup: none
- Notes: none
- Verified: pass3

###### Screen (586,630) — Shipping / Scheduled — Trucks 102/103/104 empty Load panels
- File: `p3_059_x586_y630.png`
- Illustrates: no adjacent annotation
- Same as Screen (598,529) — identical, all values 0.
- Verified: pass3

###### Screen (598,407) — Trucks 102-104 collapsed (duplicate)
- File: `p3_035_x598_y407.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Controls: none
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104, each showing empty "Load 1 +" pill.
- Dialog/popup: none
- Notes: NOT the Truck 101 Load1-4/Route screen — that content is at Screen (598,399), file `p3_034_x598_y399.png`. Same collapsed-trucks content as Screens (598,330)/(598,368).
- Verified: pass3

###### Screen (598,417) — Day-tab header strip only (no truck cards)
- File: `p3_036_x598_y417.png`
- Illustrates: no adjacent annotation
- Header/tabs: Shipping pill, Unscheduled/Scheduled(active)/Accessories/Loading, Search box, "All Scheduled Orders" pill, date "Thursday May 09/2024", day tabs Mon-Fri (Thu. May 09/2024 active outline). No truck cards visible in this crop.
- Controls: none
- Table: n/a
- Indicators: none
- Dialog/popup: none
- Notes: Header-only crop, identical to Screens (598,420)/(598,443)/(598,460)/(598,478)/(598,495)/(598,504) header strips (files `p3_037`... — see individual entries; this crop shows no other content).
- Verified: pass3

###### Screen (598,434) — Truck 101 Route map (long route, 154 Kms)
- File: `p3_037_x598_y420.png`
- Illustrates: (601,415)-(605,416) "Clicking Route will open a map showing a route for the orders on this Load"
- Header/tabs: Truck 101 card with Load 1 (2,991.71 lbs, Unreleased), Load 2 (5,297.06 lbs, Unreleased), Load 3 (512.14 lbs, Unreleased), Load 4 (empty). Distance 154 Kms., Driving Time 2 hr. 14 mins., Load Unload Time 2 hr. 8 mins., Total Time 4 hr. 22 mins.
- Controls: "Release To Loading" (green), "Route" (blue, active/selected), "Selected Orders: Total Weight: 0 lbs.", "Reschedule" (disabled).
- Table: Same 3-row order table as Screen (598,407): 330605 H F H Inc, 330615 DAP Roofing Inc., 330616 Arnold Contracting (in that order), above the embedded map.
- Indicators: none beyond table's red/green note dots.
- Dialog/popup: Embedded Google Maps route view below the table, showing a purple route line connecting "London" origin through "218 Victoria Street", a "1 hr 35 min / 97.5 km" waypoint label, to "20 Clearview Drive".
- Notes: none
- Verified: pass3

###### Screen (598,434b) — Trucks 102-104 collapsed (duplicate)
- File: `p3_038_x598_y434.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104.
- Dialog/popup: none
- Notes: Same collapsed-trucks content as Screens (598,330)/(598,368)/(598,460)/(598,478)/(598,495)/(598,504).
- Verified: pass3

###### Screen (598,443b) — Day-tab header strip only
- File: `p3_039_x598_y443.png`
- Illustrates: no adjacent annotation (header chrome only)
- Header/tabs: Day-tabs row only (Mon-Fri, Thu active), no truck cards.
- Controls: none
- Table: n/a
- Indicators: none
- Dialog/popup: none
- Notes: Header-only crop, same as Screen (598,417) file `p3_036_x598_y417.png`.
- Verified: pass3

###### Screen (598,443) — Truck 101 Route map (shorter leg, 123 Kms)
- File: `p3_040_x598_y446.png`
- Illustrates: (617,441)-(622,444) "The sequence of these orders determines which order to deliver 1st, 2nd, 3rd, etc. and shows that route on the map. We need to be able to drag these orders up & down to change the order..."
- Header/tabs: Same Truck 101 card, but Distance now "123 Kms.", Driving Time "1 hr. 46 mins.", Load Unload Time "2 hr. 8 mins.", Total Time "3 hr. 54 mins." Load 1/2/3/4 pills same as before.
- Controls: Same Release To Loading / Route / Selected Orders / Reschedule buttons.
- Table: Order rows reordered: 330615 DAP Roofing Inc. (Aylmer) now first, then 330605 H F H Inc (Belmont), then 330616 Arnold Contracting (London) — i.e., sequence changed vs Screen (598,434)'s order (330605, 330615, 330616).
- Indicators: none new
- Dialog/popup: Map shows purple route "London → 218 Victoria Street → (1 hr 3 min / 66.5 km) → 88 Raglan Street → 20 Clearview Drive", i.e. different sequence/route than previous screen.
- Notes: Demonstrates the drag-to-reorder route sequencing described in the annotation — same Load 1, orders resequenced, distance/time recalculated (154→123 Kms).
- Verified: pass3

###### Screen (598,529) — Shipping / Scheduled — Trucks 102/103/104 empty Load panels
- File: `p3_049_x598_y529.png`
- Illustrates: no adjacent annotation (side panel showing unassigned trucks)
- Header/tabs: none visible (cropped to truck cards only)
- Controls: Three stacked truck cards: Truck 102 (Weight Limit 18,500 lbs.), Truck 103 (Weight Limit 18,500 lbs.), Truck 104 (Weight Limit 34,400 lbs.). Each has "Load 1" label with green (+) button, and two sub-sections "Delivery Orders:" and "Pickups:", each with fields Total #: [0], Total Weight: [0 lbs.], Total Unassigned #: [0] (green), Total Unassigned Weight: [0 lbs.] (green).
- Table: none
- Indicators: Total Unassigned # and Total Unassigned Weight fields are green-filled; other numeric fields are white/bordered.
- Dialog/popup: none
- Notes: All values are 0 — empty/unassigned state.
- Verified: pass3

###### Screen (598,546) — Shipping / Scheduled — Trucks 102/103/104 empty Load panels
- File: `p3_051_x598_y546.png`
- Illustrates: "As soon as a Load is En Route, then the check boxes for the orders become unavailable." (592,543) — contextual only, not depicted in this crop
- Header/tabs: none (cropped)
- Same as Screen (598,529) except: no changes — identical truck cards, all values 0.
- Verified: pass3

###### Screen (598,563) — Shipping / Scheduled — Trucks 102/103/104 empty Load panels
- File: `p3_053_x598_y563.png`
- Illustrates: no adjacent annotation
- Same as Screen (598,529) — identical, all values 0.
- Verified: pass3

###### Screen (598,580) — Shipping / Scheduled — Trucks 102/103/104 empty Load panels
- File: `p3_055_x598_y580.png`
- Illustrates: no adjacent annotation
- Same as Screen (598,529) — identical, all values 0.
- Verified: pass3

###### Screen (609,378) — Shipping > Scheduled — Truck 101 Load view
- File: `p3_060_x609_y378.png`
- Illustrates: "Clicking on a Load tab would show the orders assigned to that Load" (605,397)
- Header/tabs: Shipping | "Completed orders for the past 90 days" (top right); tab strip Unscheduled/Scheduled(active)/Accessories/Loading; Search box
- Controls: date strip: All Scheduled Orders, Thursday May 09/2024 (active, calendar icon), Mon 05/06/2024, Tue 05/07/2024, Wed 05/08/2024, Thu 05/09/2024, Fri 05/10/2024; Load tabs Load 1 (Weight 2,991.71 lbs, black square "Unreleased", green + button), Load 2 (Weight 5,297.06 lbs, "Unreleased", +), Load 3 (Weight 512.14 lbs, "Unreleased", +), Load 4 (+ only); "Reschedule" button (greyed/disabled, light green)
- Table: Truck 101, Weight Limit 8,500 lbs. Delivery Orders: Total # 6, Total Weight 8,800.91 lbs, Total Unassigned # 0, Total Unassigned Weight 0 lbs. Pickups: Total # 0, Total Weight 0 lbs, Total Unassigned # 0, Total Unassigned Weight 0 lbs. Selected Orders: Total Weight 0 lbs.
  Columns: checkbox | (dropdown arrow) | Order # | Customer Name | Address | City | Map | Weight | Longest Length | Ship Via | Priority | Status | Order Notes
  Rows: L-1 330605 H F H Inc, 212 Victoria St., Belmont, [map pin], 532.67 lbs, 13'6" (162"), Delivery, Select Priority, —, Notes (red dot)
  L-1 330609 Arnold Contracting, 789 Walnut St., Vienna, [pin], 4,292.09 lbs, 21'3-3/4" (255-3/4"), Delivery, Select Priority, —, Notes
  L-1 330615 DAP Roofing Inc., 88 Raglan St., Aylmer, [pin], 924.78 lbs, 12'0" (144"), Delivery, Select Priority, —, Notes
  L-1 330616 Arnold Contracting, 432 Hill St., London, [pin], 1,534.26 lbs, 16'0" (192"), Delivery, Select Priority, —, Notes (green dot)
  L-1 330618 A.W.C., 567 George St., Woodstock, [pin], 1,004.97 lbs, 13'6" (162"), Delivery, Select Priority, —, Notes
  L-1 330632 Upright Construction, 21 Butler Dr., St. Thomas, [pin], 512.14 lbs, 4'1" (49"), Delivery, Select Priority, —, Notes (green dot)
- Indicators: Order Notes buttons colored red or green (some plain white); Unreleased status shown as black square icon
- Dialog/popup: none
- Notes: all rows tagged "L-1" (Load 1) with a dropdown arrow next to checkbox
- Verified: pass3

###### Screen (609,388) — Shipping > Scheduled — Trucks 102/103/104, empty loads
- File: `p3_061_x609_y388.png`
- Illustrates: no adjacent annotation
- Header/tabs: (continuation of same Scheduled screen, showing additional truck cards)
- Controls: each truck card has "Load 1" tab with green + button
- Table: Truck 102, Weight Limit 18,500 lbs — Delivery Orders: Total # 0, Total Weight 0 lbs, Total Unassigned # 0, Total Unassigned Weight 0 lbs; Pickups: same all-zero. Truck 103, Weight Limit 18,500 lbs — same. Truck 104, Weight Limit 34,400 lbs — same.
- Indicators: all Total/Unassigned value fields green, all zero
- Dialog/popup: none
- Notes: empty-state cards, no orders assigned to these trucks
- Verified: pass3

###### Screen (609,627) — Shipping > Scheduled — Trucks 102/103/104, empty loads
- File: `p3_063_x609_y627.png`
- Illustrates: no adjacent annotation
- Table: Same as Screen (609,388) — identical (Truck 102/103/104 all-zero empty load cards)
- Verified: pass3


#### Loading & delivery status progression
- "As soon as the first package of any of the orders on this Load are marked as Loaded, then the Load Status would change to Loading." (592, 489)
- "As soon as the first package is marked as loaded onto the truck, then the order Status would change to Loading." (592, 492)
- Update Image placeholder (605, 495)
- "Once ALL the packages for an order are marked as Loaded, then the order Status would change to Loaded. The Load Status would still show Loading because not ALL of the packages for ALL of the orders on this Load are loaded yet." (592, 507)
- Update Image placeholder (604, 513)
- "Once ALL the packages for ALL the order on this Load are marked as Loaded, then the Load Status would change to Loaded." (592, 523)
- Update Image placeholder (604, 528)
- "When the Driver checks off that he has left the warehouse, then the Load Status and all the order Status's would change to En Route." (592, 540)
- "As soon as a Load is En Route, then the check boxes for the orders become unavailable." (592, 543)
- Update Image placeholder (604, 546)
- "Once an order has been Delivered, then the order Status would change to Delivered. The Load Status would still show En Route because not ALL of the orders on this Load have been delivered yet." (592, 558)
- Update Image placeholder (604, 568)
- "Once ALL the order has been Delivered, then the Load Status would change to Delivered." (592, 574)
- Update Image placeholder (605, 580)

##### Screens (12)

###### Screen (586,621) — Shipping / Scheduled — Truck 101 order table, Load 3 order Not Started
- File: `p3_058_x586_y621.png`
- Illustrates: no adjacent annotation for this exact state
- Header/tabs: Same as Screen (598,591)/(598,606).
- Controls: Truck 101 header (red highlighted card). Load 1: 2,991.71 lbs., green "Completed". Load 2: 5,297.06 lbs., green "Completed". Load 3 (red text): 512.14 lbs., gray "Not Started" badge, red (+) icon. Load 4 label. Delivery Orders: Total # 6, Total Weight 8,800.91 lbs. (yellow highlight), Total Unassigned # 0, Total Unassigned Weight 0 lbs. Pickups all 0. "Selected Orders: Total Weight: [0 lbs.]" field, "Reschedule" button (disabled).
- Table: Columns: [checkbox], (load-tag column showing "L-1"), Order #, Customer Name, Address, City, Map, Weight, Longest Length, Ship Via, Priority, Status, Order Notes. Rows: L-1 330605 H F H Inc, 212 Victoria St., Belmont, 532.67 lbs, 13'6" (162"), Delivery, Select Priority, green "Delivered", Notes (red dot). L-1 330609 Arnold Contracting, 789 Walnut St., Vienna, 4,292.09 lbs, 21'3-3/4" (255-3/4"), Delivery, Select Priority, green "Delivered", Notes. L-1 330615 DAP Roofing Inc., 88 Raglan St., Aylmer, 924.78 lbs, 12'0" (144"), Delivery, Select Priority, green "Delivered", Notes. L-1 330616 Arnold Contracting, 432 Hill St., London, 1,534.26 lbs, 16'0" (192"), Delivery, Select Priority, green "Delivered", Notes (green dot). L-1 330618 A.W.C., 567 George St., Woodstock, 1,004.97 lbs, 13'6" (162"), Delivery, Select Priority, green "Delivered", Notes (green dot). L-1 330632 Upright Construction, 21 Butler Dr., St. Thomas, 512.14 lbs, 4'1" (49"), Delivery, Select Priority, gray "Not Started", Notes — this row highlighted red/pink background and red border.
- Indicators: Last row (330632) fully highlighted in red/pink with red border, gray "Not Started" status badge — contrasts with other rows' green "Delivered" badges.
- Dialog/popup: none
- Notes: Row-level "L-1" tag denotes Load number per order; red highlight flags the incomplete order within an otherwise completed load set.
- Verified: pass3

###### Screen (598,460) — Truck 101, Load 1 Status = Not Started
- File: `p3_042_x598_y470.png`
- Illustrates: (598,468)-(604,470) [text at (601,415) region] "Clicking the Release To Loading button would make the Load show up in the Loading window and change the Load and order Status's to Not Started"
- Header/tabs: Same Truck 101 card; Load 1 pill now shows grey "Not Started" status (was black "Unreleased"). Release To Loading and Reschedule buttons now greyed/disabled; Route button still enabled.
- Table: Same 3 orders (330615, 330605, 330616) — order sequence as in Screen (598,443) — each now has Status column = grey "Not Started" badge (previously blank).
- Indicators: Load 1 status pill grey "Not Started"; each order row Status badge grey "Not Started".
- Dialog/popup: none
- Notes: none
- Verified: pass3

###### Screen (598,470) area duplicate — Trucks 102-104 collapsed
- File: `p3_043_x598_y478.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104.
- Dialog/popup: none
- Notes: Not a header-only crop — same collapsed-trucks content as Screens (598,330)/(598,368)/(598,434b)/(598,441).
- Verified: pass3

###### Screen (598,478) — Truck 101, Load 1 Status = Loading (1 order loading)
- File: `p3_044_x598_y487.png`
- Illustrates: (592,489)-(597,491) "As soon as the first package of any of the orders on this Load are marked as Loaded, then the Load Status would change to Loading."; (592,492)-(597,494) "...then the order Status would change to Loading."
- Header/tabs: Same Truck 101 card; Load 1 pill status now light-blue "Loading".
- Table: Same 3 orders; 330616 Arnold Contracting Status now light-blue "Loading" badge; 330615 and 330605 remain grey "Not Started".
- Indicators: Load 1 pill = blue "Loading"; one order row = blue "Loading", two rows = grey "Not Started".
- Dialog/popup: none
- Notes: none
- Verified: pass3

###### Screen (598,487) area duplicate — Trucks 102-104 collapsed
- File: `p3_045_x598_y495.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104.
- Dialog/popup: none
- Notes: Not a header-only crop — same collapsed-trucks content as the other Trucks 102-104 duplicates.
- Verified: pass3

###### Screen (598,495) — Truck 101, Load 1 Status = Loading (order Loaded, another Loading)
- File: `p3_046_x598_y504.png`
- Illustrates: (592,507)-(597,510) "Once ALL the packages for an order are marked as Loaded, then the order Status would change to Loaded. The Load Status would still show Loading because not ALL of the packages for ALL of the orders on this Load are loaded yet."
- Header/tabs: Same Truck 101 card; Load 1 pill still light-blue "Loading".
- Table: Same 3 orders, order sequence now 330615 DAP Roofing (Status grey "Not Started"), 330605 H F H Inc (Status light-blue "Loading"), 330616 Arnold Contracting (Status red "Loaded").
- Indicators: One order row now red "Loaded" badge; one blue "Loading"; one grey "Not Started"; Load 1 pill remains blue "Loading".
- Dialog/popup: none
- Notes: "Loaded" status is shown in a red badge in this mock (visually red, not green, despite meaning complete) — worth flagging as it could be confused with an error/overdue state.
- Verified: pass3

###### Screen (598,504) area duplicate — Trucks 102-104 collapsed
- File: `p3_047_x598_y512.png`
- Illustrates: no adjacent annotation
- Header/tabs: n/a (crop shows only trucks 102, 103, 104 cards)
- Table: n/a
- Indicators: All boxes green (0 orders/pickups) for trucks 102/103/104.
- Dialog/popup: none
- Notes: Not a header-only crop — same collapsed-trucks content as the other Trucks 102-104 duplicates; final file in this batch.
- Verified: pass3

###### Screen (598,521) — Shipping / Scheduled — Truck 101, Load 1 Loaded
- File: `p3_048_x598_y521.png`
- Illustrates: "As soon as the first package of any of the orders on this Load are marked as Loaded, then the Load Status would change to Loading." (592,489) / "As soon as the first package is marked as loaded onto the truck, then the order Status would change to Loading." (592,492) — note: screenshot itself shows "Loaded"/red badge, not "Loading"; see Notes.
- Header/tabs: "Shipping" button (top left); "Completed orders for the past 90 days" button (top right); tab row: Unscheduled, **Scheduled** (active/white), Accessories, Loading; search box "Search..."
- Controls: Date strip — "All Scheduled Orders", calendar icon "Thursday May 09/2024" (outlined/selected), "Mon. May 06/2024", "Tue. May 07/2024", "Wed. May 08/2024", "Thu. May 09/2024" (white/bordered = active), "Fri. May 10/2024" (all gray pill buttons). Truck 101 panel: Weight Limit 8,500 lbs. Load 1 header: Weight 2,991.71 lbs., status badge red "Loaded" with green (+) icon. Load 2: Weight 5,297.06 lbs., black badge "Unreleased", (+) icon. Load 3: Weight 512.14 lbs., black badge "Unreleased", (+) icon. Load 4 (label only, cut off). Below: Distance 123 Kms., Driving Time 1 hr. 46 mins., Load Unload Time 2 hr. 8 mins., Total Time 3 hr. 54 mins. Buttons: "Release To Loading" (disabled/gray-green), "Route" (blue, active), "Selected Orders: Total Weight: [0 lbs.]" field, "Reschedule" (disabled/gray-green).
- Table: Columns: [checkbox], Order #, Customer Name, Address, City, Map, Weight, Longest Length, Ship Via, Priority, Status, Order Notes. Rows: 330615 | DAP Roofing Inc. | 88 Raglan St. | Aylmer | (pin) | 924.78 lbs | 12'0" (144") | Delivery | Select Priority | red "Loaded" | Notes. 330605 | H F H Inc | 212 Victoria St. | Belmont | (pin) | 532.67 lbs | 13'6" (162") | Delivery | Select Priority | red "Loaded" | Notes (red dot badge). 330616 | Arnold Contracting | 432 Hill St. | London | (pin) | 1,534.26 lbs | 16'0" (192") | Delivery | Select Priority | red "Loaded" | Notes (green dot badge).
- Indicators: Load 1 status badge red "Loaded"; row Status badges all red "Loaded"; Order Notes buttons have colored dot indicators (red on row 2, green on row 3, none on row 1).
- Dialog/popup: none
- Notes: Despite annotation text describing "Loading" as an interim state, this screenshot's badges read "Loaded" (red) — literal as shown.

###### Screen (598,538) — Shipping / Scheduled — Truck 101, Load 1 En Route
- File: `p3_050_x598_y538.png`
- Illustrates: "Once ALL the packages for an order are marked as Loaded, then the order Status would change to Loaded. The Load Status would still show Loading because not ALL of the packages for ALL of the orders on this Load are loaded yet." (592,507) / "When the Driver checks off that he has left the warehouse, then the Load Status and all the order Status's would change to En Route." (592,540)
- Header/tabs: Same as Screen (598,521) (Shipping / Unscheduled / Scheduled active / Accessories / Loading / Search)
- Controls: Same as Screen (598,521) layout. Load 1 badge now dark yellow/orange "En Route" (with green + icon). Load 2 "Unreleased" (black), Load 3 "Unreleased" (black), Load 4 label. Buttons "Release To Loading" (disabled), "Route" (active blue), "Selected Orders: Total Weight: [0 lbs.]", "Reschedule" (disabled).
- Table: Same columns as Screen (598,521). Rows: 330615 DAP Roofing Inc. ... Status dark yellow "En Route", Notes. 330605 H F H Inc ... Status "En Route", Notes (red dot). 330616 Arnold Contracting ... Status "En Route", Notes (green dot).
- Indicators: Load 1 badge and all row Status badges dark yellow/orange "En Route".
- Dialog/popup: none
- Notes: Same as Screen (598,521) except Load 1 and all order Status badges changed from red "Loaded" to yellow/orange "En Route".
- Verified: pass3

###### Screen (598,555) — Shipping / Scheduled — Truck 101, Load 1 Delivered (partial)
- File: `p3_052_x598_y555.png`
- Illustrates: no adjacent annotation text for this exact state; nearest is (592,543) re: checkboxes unavailable while En Route — not directly depicted
- Same as Screen (598,538) except: Load 1 status badge unchanged dark yellow "En Route"; Table row 1 (330615 DAP Roofing Inc.) Status now green "Delivered"; row 2 (330605 H F H Inc) Status remains yellow "En Route" (Notes red dot); row 3 (330616 Arnold Contracting) Status remains yellow "En Route" (Notes green dot).
- Indicators: Mixed status badges — one green "Delivered", two orange "En Route" — partial delivery progression within a Load still En Route.
- Verified: pass3

###### Screen (598,572) — Shipping / Scheduled — Truck 101, Load 1 Completed
- File: `p3_054_x598_y572.png`
- Illustrates: no adjacent annotation for this exact state (continuation of En Route → Delivered sequence)
- Same as Screen (598,538) except: Load 1 status badge now green "Completed"; all three table rows (330615, 330605, 330616) Status now green "Delivered".
- Indicators: Load badge green "Completed"; all row Status badges green "Delivered".
- Verified: pass3

###### Screen (598,606) — Shipping / Scheduled — Truck 101 with Loads 1&2 Completed, Load 3 Not Started
- File: `p3_057_x598_y606.png`
- Illustrates: no adjacent annotation for this exact state
- Header/tabs: Same as Screen (598,591); date strip same, with the calendar chip "Thursday May 09/2024" shown pink/salmon (not the bold red of Screen (598,591)'s Friday chip); "Thu. May 09/2024" pill also pink-tinted.
- Controls: Truck 101's "Truck 101 / Weight Limit: 8,500 lbs." label box filled solid bright red (white text). Load 1: Weight 2,991.71 lbs., green "Completed" badge. Load 2: Weight 5,297.06 lbs., green "Completed" badge. Load 3 box (pink/salmon background, red "Load 3" text): Weight 512.14 lbs., gray/white "Not Started" badge, red circular (+) icon. Load 4 label only. Delivery Orders: Total #: 6, Total Weight: 8,800.91 lbs. (highlighted yellow/orange), Total Unassigned #: 0, Total Unassigned Weight: 0 lbs. Pickups: Total #: 0, Total Weight: 0 lbs., Total Unassigned #: 0, Total Unassigned Weight: 0 lbs. Trucks 102/103/104 unchanged empty panels below.
- Table: none visible in this crop
- Indicators: Truck 101 label box solid red fill; Load 3 box pink-tinted with red "Load 3" text and red (+) icon; Total Weight field highlighted yellow/orange.
- Dialog/popup: none
- Notes: Red/pink highlight on Truck 101 and Load 3 flags an attention state (overdue load).
- Verified: pass3


#### Overdue orders (Shipping)
- Overdue Orders (606, 589)
- "Whenever there is an order that is overdue, the day tab that has that order should be highlighted in red. Also, the calendar should be highlighted in red." (593, 591)
- "It is Friday and there are orders that were scheduled for Thursday that are not delivered yet (overdue). The Thursday tab should then be highlighted in red" (617, 591)
- Update Image placeholder (605, 599)
- "When you click on the day that has overdue orders within it, then you would see the Truck and the Load that is overdue highlighted in red." (593, 606)
- Update Image placeholder (605, 611)
- Clicking the Truck tab (592, 620)
- Clicking the Load tab (614, 620)
- Update Image placeholder (616, 625)
- "Here you would see the orders that are overdue highlighted in red." (605, 628)
- Update Image placeholder (595, 628)

##### Screens (1)

###### Screen (609,621) — Shipping > Scheduled — Truck 101, Load 3 detail with Route highlighted, overdue (red)
- File: `p3_062_x609_y621.png`
- Illustrates: "Clicking Route will open a map showing a route for the orders on this Load" (601,415)
- Header/tabs: Shipping | Completed orders for the past 90 days; tabs Unscheduled/Scheduled(active)/Accessories/Loading; Search box
- Controls: date strip: All Scheduled Orders, Thursday May 09/2024 (highlighted red/active), Mon-Fri dates (Thu May 09/2024 also highlighted red); Load 1 (Weight 5,297.06 lbs, green "Completed", +), Load 2 (Weight 5,297.06 lbs, green "Completed", +), Load 3 (Weight 2,991.71 lbs, grey "Not Started", + — highlighted red box) with Distance: 78.8 Kms., Driving Time: 1 hr. 6 mins., Load Unload Time: 0 hr. 32 mins., Total Time: 1 hr. 38 mins.; Load 4 (+); buttons "Release To Loading" (disabled, light green), "Route" (active, blue highlighted), Selected Orders: Total Weight 0 lbs, "Reschedule" (disabled)
- Table: entire truck panel and header row outlined/highlighted red (overdue indication). Columns: checkbox | dropdown | Order # | Customer Name | Address | City | Map | Weight | Longest Length | Ship Via | Priority | Status | Order Notes. Row: 330632, Upright Construction, 21 Butler Dr., St. Thomas, [pin], 512.14 lbs, 4'1" (49"), Delivery, Select Priority, Not Started, Notes
- Indicators: entire Truck 101 card and Load 3 box shown in red highlight (overdue); Load 1 & 2 show green "Completed"
- Dialog/popup: none
- Notes: "Route" button appears actively selected/highlighted (blue)
- Verified: pass3


### Accessories (connected off the Shipping flow — see "See Shipping Department" cross-reference)

#### Accessories Scheduled tab
- "Open the dropdown on the order that you want to partially schedule." (1107, 205)
- "If you expand an order when at least 1 order has been check off to be scheduled, then the line item check boxes to split an order need to be unavailable." (1073, 221)
- "Select the line items you are wanting to schedule." (1107, 224)
- "Select the Production Date and click Set Date, this will make the order disappear out of the Unscheduled tab and appear in the Scheduled tab." (1047, 224)
- "As soon as you select at least 1 line item, then the Split Order button becomes available and the scheduling check boxes become unavailable." (1107, 226)
- Order Notes (1050, 230)
- "Clicking the Split Order button opens the calendar." (1113, 231)
- "These Order Notes would be imported from the Salesman (EBMS). There would be a red indicator showing that you haven't dealt with this note yet." (1051, 235)
- "Select the Production Date for the selected line items. This will schedule those line items and reset the Split Order function." (1106, 240)
- "Clicking this button opens the note." (1046, 243)
- "When part of an order has been scheduled, there needs be an indication in the Order # column showing that this order has been split, on both sub-orders." (1130, 249)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (1051, 250)
- "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be greyed out and completely uneditable in the Unscheduled tab. Once all the trims are Scheduled, the order will disappear in the Unscheduled tab within the Accessories department (category)." (1105, 253)
- Open question "?" (1181, 264)
- Accessories Scheduled (1091, 264)
- Viewing Partial Order (1099, 264)
- "If you are trying to create another package that combined with the packages already on the order will be over the Max Weight for the location, then the location name should highlight in red indicating that you need to select another location." (1190, 265)
- Adding a second location (1183, 270)
- Over riding the weight limit (1170, 270)
- "When viewing a partially scheduled order in the Scheduled tab, the accessories that are still unscheduled or scheduled to a different day should appear but be greyed out and completely uneditable. Also, the Status column should be blank for the unscheduled accessories." (1097, 272)
- Open questions "?" (1171, 275), (1189, 275)
- "If you try to "Create & Print" when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit. If you agree, it will override the weight limit and create the package and print the label." (1155, 276)
- "Choose the day you want to work on, this day tab should show your maximum capacity for the day and how much is already assigned to that day." (1078, 280)
- "Once an order has been scheduled, the Status should change to Not Started." (1103, 281)
- Open questions "?" (1169, 286), (1191, 288)
- Line Item Notes (1073, 289)
- Priorities (1107, 289)
- "If you override the weight limit on a Location, then that Location name needs to be highlighted in red." (1155, 291)
- "If orders have Priorities assigned to them then they are sorted primarily by Prep Date and secondarily by Priority. The Priorities are sorted by the hierarchy assigned to them." (1111, 291)
- "The order Status should remain Not Started until at least one Package has been created for that order. Then, the Status should change to In Progress and remain In Progress until all the accessories on that order have the Status of Packaged." (1077, 291)
- "As soon as an Accessories Location has been added to an order it should display it here." (1103, 291)
- "Only the Manager can set Priorities" (1135, 292)
- "The Manager and Workers should be able to add and view Line Item Notes at any point. These notes are just within the app, they do not come from or push back to EBMS." (1069, 296)
- "Clicking this button opens the Line Item Note." (1062, 303)
- "When you expand an order, you should be able to see the Status of each individual accessory." (1080, 304)
- "If part of a line item is packaged, then the status needs to show In Progress. Example: If 2 out of these 4 bags of screws are packaged, then is needs to show In Progress." (1079, 307)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (1068, 309)

##### Screens (21)

###### Screen (1032,232) — Accessories > Unscheduled, all rows unchecked (post schedule-reset state)
- File: `p3_066_x1032_y232.png`
- Illustrates: "Select the Production Date for the selected line items. This will schedule those line items and reset the Split Order function." (1106,240)
- Table: Same as Screen (1078,216) except: no expanded row; all row checkboxes unchecked (white); "Schedule" button greyed out/disabled. Columns: Entry Date | Ship Date | Order # | Priority | Customer Name | Ship Via | Order Notes. Rows: 330605 H F H Inc (Notes red); 330608 Jireh Tools; 330609 Arnold Contracting (Pick-up); 330615 DAP Roofing Inc.; 330616 Arnold Contracting (Pick-up, Notes green); 330617 Ontario Metal Products Ltd. (Friday 05/10); 330618 A.W.C. (Notes green); 330622 Ontario Metal Products Ltd. (Friday 05/10); 330629 Ontario Metal Products Ltd. (Friday 05/10); 330631 Jireh Tools; 330632 Upright Construction (Pick-up)
- Indicators: "Schedule" button disabled
- Dialog/popup: none
- Notes: reset state after a split-order scheduling action
- Verified: pass3

###### Screen (1032,244) — Accessories > Unscheduled, all rows unchecked (duplicate state)
- File: `p3_067_x1032_y244.png`
- Illustrates: no adjacent annotation
- Identical to Screen (1032,232) (`p3_066_x1032_y232.png`): same Accessories Unscheduled table, all row checkboxes unchecked (white), "Schedule" button greyed/disabled, columns Entry Date | Ship Date | Order # | Priority | Customer Name | Ship Via | Order Notes, same 11 rows (330605, 330608, 330609, 330615, 330616, 330617, 330618, 330622, 330629, 330631, 330632).
- Notes: previous entry for this file wrongly described an Order Note popup card (that content actually belongs to `p3_068_x1043_y248.png`, see next entry).
- Verified: pass3

###### Screen (1032,256) — Accessories > Unscheduled, all rows unchecked (duplicate state)
- File: `p3_069_x1032_y256.png`
- Illustrates: "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be greyed out and completely uneditable in the Unscheduled tab." (1105,253)
- Table: Same as Screen (1032,232) — identical (all checkboxes unchecked, Schedule button disabled)
- Verified: pass3

###### Screen (1049,291) — Accessories › Scheduled tab
- File: `p3_071_x1049_y291.png`
- Illustrates: "As soon as an Accessories Location has been added to an order it should display it here." (1103,291); "If orders have Priorities assigned to them then they are sorted primarily by Prep Date and secondarily by Priority..." (1111,291)
- Header/tabs: Accessories | Completed orders for the past 90 days; tabs Unscheduled/**Scheduled**(active)/Packaging; Search box
- Controls: date strip Wednesday May 08/2024 (active, calendar icon), Mon 05/06 (1000/5000), Tue 05/07 (1000/5000), Wed 05/08 (1000/5000, white/bordered active), Thu 05/09 (1000/5000), Fri 05/10 (1000/5000)
- Table: columns Ship Date | Prep Date | Order # | Customer Name | Priority | Status | Ship Via | Accessories Location | Order Notes. Rows (all "Not Started" gray status, Prep Date "Wed. 08/2024" field, Ship Date "Thursday, May 09/2024"): 330605 H F H Inc (Delivery, Notes red); 330608 Jireh Tools (Delivery); 330609 Arnold Contracting (Pick-up, small icon next to name, not expanded); 330615 DAP Roofing Inc. (Delivery); 330616 Arnold Contracting (Pick-up, Notes green); 330618 A.W.C. (Delivery); 330631 Jireh Tools (Delivery, Notes green) — this row is expanded; 330632 Upright Construction (Pick-up, cut off at bottom).
  Expanded sub-table for order 330631: columns Qty Ordered | Shipped | Product ID | Status | Description | Line Item Notes. Rows: 2, —, S158250, Not Started, "#10x1-1/2" Wood Binder Screw Dark Red", Notes(green); 1, —, S28250, Not Started, "#10x2" Wood Binder Screw Dark Red", Notes; 25, —, OSC, Not Started, "Outside Closures (Large Tab) 9"x36" Tuff Rib", Notes; 4, —, SL8250, Not Started, "Mulco Supra Expert Sealant Dark Red (Country Red 170)", Notes(red).
- Indicators: gray "Not Started" status badges throughout (header and line-item level); red/green dot Notes buttons on some rows.
- Dialog/popup: none
- Notes: previous entry for this file wrongly claimed it was identical to Screen (1049,305) and wrongly said order 330609 was the expanded row with items S158250/OSC/SL8250/1412 — the expanded row here is actually 330631 (Jireh Tools), with 4 different line items (S158250, S28250, OSC, SL8250). Also, previous entry wrongly described an Order Note popup card in a "green state" (that content actually belongs to `p3_070_x1043_y260.png`, see previous entry).
- Verified: pass3

###### Screen (1049,305) — Accessories › Scheduled tab
- File: `p3_072_x1049_y305.png`
- Illustrates: "As soon as an Accessories Location has been added to an order it should display it here." (1103,291); "If orders have Priorities assigned to them then they are sorted primarily by Prep Date and secondarily by Priority..." (1111,291)
- Header/tabs: Accessories (button, top-left); "Completed orders for the past 90 days" (top-right); sub-tabs Unscheduled / Scheduled (active) / Packaging; Search... field
- Controls: "All Scheduled Orders" button; date-strip: Wednesday May 08/2024 (calendar icon), Mon. May 06/2024 (1000/5000), Tue. May 07/2024 (1000/5000), Wed. May 08/2024 (1000/5000, selected/outlined), Thu. May 09/2024 (1000/5000), Fri. May 10/2024 (1000/5000)
- Table: columns — (expand), Ship Date, Prep Date, Order #, Customer Name, Priority, Status, Ship Via, Accessories Location, Order Notes. Rows: 330605 H F H Inc, Select Priority, Not Started, Delivery, (empty location), Notes(red); 330608 Jireh Tools, Not Started, Delivery, Notes; 330609 Arnold Contracting (icon), Not Started, Pick-up, Notes (not expanded); 330615 DAP Roofing Inc., Delivery; 330616 Arnold Contracting, Pick-up, Notes(green); 330618 A.W.C., Delivery; 330631 Jireh Tools, Not Started, Delivery, Notes(green) — this row expanded (bordered black), showing line items: Qty 2 S158250 "#10x1-1/2" Wood Binder Screw Dark Red" Not Started Notes(green); Qty 1 S28250 "#10x2" Wood Binder Screw Dark Red" Not Started Notes; Qty 25 OSC "Outside Closures (Large Tab) 9"x36" Tuff Rib" Not Started Notes; Qty 4 SL8250 "Mulco Supra Expert Sealant Dark Red (Country Red 170)" Not Started Notes(red); 330632 Upright Construction, Pick-up (cut off at bottom)
- Indicators: Status "Not Started" gray pill; Notes buttons red/green/plain; expanded row bordered in black
- Dialog/popup: none
- Notes: "Select Priority" is a dropdown placeholder on every row; Prep Date shown as editable date field "Wed. 08/2024"; the expanded order is 330631 (Jireh Tools), not 330609
- Verified: pass3

###### Screen (1049,317) — Accessories › Scheduled tab
- File: `p3_074_x1049_y317.png`
- Same as Screen (1049,305) — duplicate capture, no visible differences.
- Verified: pass3

###### Screen (1049,330) — Accessories › Scheduled tab
- File: `p3_076_x1049_y330.png`
- Same as Screen (1049,305) — duplicate capture (crops 072/074/076 identical).
- Verified: pass3

###### Screen (1053,216) — Accessories > Unscheduled, date-picker modal open
- File: `p3_064_x1053_y216.png`
- Illustrates: no adjacent annotation
- Header/tabs: Accessories | Completed orders for the past 90 days; tabs Unscheduled(active)/Scheduled/Packaging; Search box
- Controls: date strip Wednesday May 08/2024 (active), Mon 05/06 (1000/5000), Tue 05/07 (1000/5000), Wed 05/08 (1000/5000), Thu 05/09 (1000/5000), Fri 05/10 (1000/5000); "Schedule" button (green)
- Table: columns Entry Date | Ship Date | Order # | Priority | Customer Name | Ship Via | Order Notes. Rows (checkboxes mostly checked): 330605 H F H Inc (Notes red); 330608 Jireh Tools; 330609 Arnold Contracting (Pick-up); 330615 DAP Roofing Inc. (Pick-up); [row obscured by modal] ...330617 Delivery; ...3306xx Pick-up (Notes green); 330622 Delivery; 330629 Delivery; 330631 Thursday May 09/2024 Delivery; 330632 Thursday May 09/2024 Pick-up
- Indicators: red/green dots on some Notes buttons
- Dialog/popup: Title "May 2024" calendar with left/right chevrons, red "X" close button, days grid Su-Sa, dates 1-31, "8" highlighted green (selected); buttons "Cancel" and "Set Date" (green)
- Notes: modal triggered from the Schedule action / date field
- Verified: pass3

###### Screen (1059,307) — Line Item Note modal
- File: `p3_073_x1059_y307.png`
- Illustrates: no adjacent annotation
- Header/tabs: Modal titled "Line Item Note"
- Controls: text input "Leave your note here..." with send icon button (green)
- Indicators: Note card: avatar "AM", name "Accessories Manager", email accessoriesmanager@wiseline.ca, timestamp "Tue, May 07/2024 10:42", body "Special instructions, talk to manager before packaging"; below the note, a red circle X icon (left) and a green circle check icon (right)
- Dialog/popup: this whole image is the modal (purple border), title "Line Item Note"
- Verified: pass3

###### Screen (1059,320) — Line Item Note modal
- File: `p3_075_x1059_y320.png`
- Illustrates: no adjacent annotation
- Same as Screen (1059,307) except: the red X / green check icon row is replaced by a single full-width solid green bar beneath the note.
- Verified: pass3

###### Screen (1059,333) — Line Item Note modal (two notes)
- File: `p3_077_x1059_y333.png`
- Illustrates: no adjacent annotation
- Header/tabs: Modal titled "Line Item Note"
- Controls: text input "Leave your note here..." with send icon button (green)
- Indicators: Two note cards. Card 1: avatar "AM" "Accessories Manager", accessoriesmanager@wiseline.ca, "Tue, May 07/2024 10:42", "Special instructions, talk to manager before packaging", full-width green bar below. Card 2: avatar "AW" "Accessories Worker", accessoriesworker@gmail.caom [sic], "Tue, May 07/2024 2:31", "Not package due to low stock, waiting for supplier shipment.", red circle X icon (left) and green circle check icon (right)
- Notes: literal typo preserved: "accessoriesworker@gmail.caom"
- Verified: pass3

###### Screen (1078,216) — Accessories > Unscheduled, Order 330609 expanded (Split Order line items)
- File: `p3_065_x1078_y216.png`
- Illustrates: "Clicking the Split Order button opens the calendar." (1113,231); "As soon as you select at least 1 line item, then the Split Order button becomes available and the scheduling check boxes become unavailable." (1107,226)
- Header/tabs: Accessories | Completed orders for the past 90 days; tabs Unscheduled(active)/Scheduled/Packaging; Search
- Controls: date strip same as above; "Schedule" green button; "Split Order" button (green, enabled) next to expanded row
- Table: main columns Entry Date | Ship Date | Order # | Priorities | Customer Name | Ship Via | Order Notes. Expanded sub-table for Order 330609 (Arnold Contracting, Pick-up): columns Qty Ordered | Product ID | Description | Line Item Notes. Rows: 3, S158250, "#10x1-1/2" Wood Binder Screw Dark Red", Notes(green); 16, OSC, "Outside Closures (Large Tab) 9"x36" Tuff Rib", Notes; 12, SL8250, "Mulco Supra Expert Sealant Dark Red (Country Red 170)", Notes(green); 150, 1412, "1x4x12ft Rough Cut", Notes. Other visible rows: 330605 H F H Inc (Notes red); 330608 Jireh Tools; 330615 DAP Roofing Inc.; 330616 Arnold Contracting (Pick-up); 330617 Ontario Metal Products Ltd. (Friday May 10); 330618 A.W.C. (Notes green); 330622 Ontario Metal Products Ltd. (Friday May 10); 330629 Ontario Metal Products Ltd. (Friday May 10); 330631 Jireh Tools; 330632 Upright Construction (Pick-up)
- Indicators: unchecked small checkboxes (light green outline) next to each line item row; green/red Notes dots
- Dialog/popup: none
- Notes: line item checkboxes unchecked in this state; row for 330609 has expand arrow open
- Verified: pass3

###### Screen (1084,280) — Accessories Scheduled tab
- File: `p3_085_x1084_y280.png`
- Illustrates: no adjacent annotation
- Header/tabs: Accessories; Unscheduled / Scheduled (active) / Packaging; Completed orders for the past 90 days (top right); Search box
- Controls: date strip: All Scheduled Orders, calendar icon "Wednesday May 08/2024" (selected), Mon May 06/2024 (1000/5000), Tue May 07/2024 (1000/5000), Wed May 08/2024 (1000/5000, selected/outlined), Thu May 09/2024 (1000/5000), Fri May 10/2024 (1000/5000)
- Table: Ship Date | Prep Date | Order # | Customer Name | Priority | Status | Ship Via | Accessories Location | Order Notes — rows (8): Thursday May 09/2024 / Wed. May 08/2024 (editable field) / 330605 / H F H Inc / Select Priority / Not Started (gray) / Delivery / — / Notes (red dot); 330608 / Jireh Tools / Not Started / Delivery / — / Notes; 330609 (icon) / Arnold Contracting / Not Started / Pick-up / — / Notes; 330615 / DAP Roofing Inc. / Not Started / Delivery / — / Notes; 330616 / Arnold Contracting / Not Started / Pick-up / — / Notes (green dot); 330618 / A.W.C. / Not Started / Delivery / — / Notes; 330631 / Jireh Tools / Not Started / Delivery / — / Notes (green dot); 330632 / Upright Construction / Not Started / Pick-up / — / Notes
- Indicators: gray "Not Started" pill; red/green dots on Notes buttons; truck icon = Delivery, walking-person icon = Pick-up
- Notes: Accessories Location column empty for all rows.
- Verified: pass3

###### Screen (1084,291) — Accessories Scheduled tab with Status/Location populated
- File: `p3_089_x1084_y291.png`
- Illustrates: "As soon as an Accessories Location has been added to an order it should display it here." (1103,291)
- Header/tabs: Accessories, Scheduled tab active; date strip same as prior
- Table: Ship Date | Prep Date | Order # | Customer Name | Priority | Status | Ship Via | Accessories Location | Order Notes — rows: 330605 H F H Inc / Select Priority / In Progress (orange) / Delivery / B8 / Notes(red); 330608 Jireh Tools / Select Priority / Packaged (green) / Delivery / A15 / Notes; 330609 Arnold Contracting / Select Priority / In Progress (orange) / Pick-up / B6 / Notes; 330615 DAP Roofing Inc. / Select Priority / In Progress (orange) / Delivery / C3 / Notes; 330616 Arnold Contracting / Select Priority / Packaged (green) / Pick-up / B3, B4 / Notes(green); 330618 A.W.C. / Select Priority / Not Started (gray) / Delivery / — / Notes; 330631 Jireh Tools / Select Priority / Not Started / Delivery / — / Notes(green); 330632 Upright Construction / Select Priority / Packaged (green) / Pick-up / A7 / Notes
- Indicators: Status pill colors: orange=In Progress, green=Packaged, gray=Not Started; Accessories Location populated with bin codes, multiple locations comma-separated ("B3, B4")
- Verified: pass3

###### Screen (1084,301) — Accessories Scheduled tab, row expanded to line items
- File: `p3_090_x1084_y301.png`
- Illustrates: no adjacent annotation
- Header/tabs: same as (1084,291)
- Controls: expand caret on order 330615 row expanded (border highlighted)
- Table: Same order-level table as (1084,291), plus expanded sub-table under 330615: Qty Ordered | Shipped | Product ID | Status | Description | Line Item Notes — rows: 3/-/S18206/Packaged(green)/"#10x1" Wood Binder Screw Charcoal"/Notes(green); 4/-/S28250/In Progress(orange)/"#10x2" Wood Binder Screw Charcoal"/Notes; 2/-/ES/Not Started(gray)/Emseal 1"x1", 19.68' Roll/Notes(green); 1/-/SL8306/Packaged(green)/Mulco Supra Expert Sealant Charcoal (Granite Grey 590)/Notes
- Indicators: same status pill colors as above
- Notes: an icon appears next to order # 330609 in some rows (unexplained).
- Verified: pass3

###### Screen (1104,266) — Accessories › Scheduled tab (order row expanded, partially scheduled)
- File: `p3_082_x1104_y266.png`
- Illustrates: "Once an order has been scheduled, the Status should change to Not Started." (1103,281)
- Header/tabs: Accessories button; "Completed orders for the past 90 days"; sub-tabs Unscheduled/Scheduled(active)/Packaging; Search...
- Controls: "All Scheduled Orders" button; date strip: Wednesday May 08/2024 (calendar), Mon 05/06 (1000/5000), Tue 05/07 (1000/5000), Wed 05/08 (1000/5000, selected), Thu 05/09 (1000/5000), Fri 05/10 (1000/5000)
- Table: columns Ship Date, Prep Date, Order #, Customer Name, Priority, Status, Ship Via, Accessories Location, Order Notes. Rows: 330605 H F H Inc Not Started Delivery Notes(red); 330608 Jireh Tools Not Started Delivery Notes; 330609 Arnold Contracting (icon) Not Started Pick-up Notes, expanded — sub-table Qty Ordered/Shipped/Product ID/Status/Description/Line Item Notes: 3/(blank)/S158250/Not Started/"#10x1-1/2" Wood Binder Screw Dark Red"/Notes(green); 16/OSC row greyed/italic "Outside Closures (Large Tab) 9"x36" Tuff Rib" (no status); 12/SL8250 row greyed/italic "Mulco Supra Expert Sealant Dark Red (Country Red 170)" (no status); 150/1412/Not Started/"1x4x12ft Rough Cut"/Notes; then 330615 DAP Roofing Inc. Delivery; 330616 Arnold Contracting Pick-up Notes(green); 330618 A.W.C. Delivery; 330631 Jireh Tools Delivery Notes(green); 330632 Upright Construction Pick-up
- Indicators: greyed/italic rows for OSC and SL8250 (the line items not scheduled for this date)
- Dialog/popup: none
- Verified: pass3

###### Screen (1111,217) — Accessories › Unscheduled tab (order expanded, Split Order)
- File: `p3_078_x1111_y217.png`
- Illustrates: "Priorities" (1107,289); Split Order flow annotations (1107,226)
- Header/tabs: Accessories button top-left; "Completed orders for the past 90 days" top-right; sub-tabs Unscheduled (active) / Scheduled / Packaging; Search...
- Controls: date strip: calendar icon "Wednesday May 08/2024", Mon. May 06/2024 (1000/5000), Tue. May 07/2024 (1000/5000), Wed. May 08/2024 (1000/5000), Thu. May 09/2024 (1000/5000), Fri. May 10/2024 (1000/5000); "Schedule" button (light green, disabled/greyed)
- Table: columns — checkbox, expand, Entry Date, Ship Date, Order #, Priorities, Customer Name, Ship Via, Order Notes. Rows: 330605 Mon. May 06/2024 / Thu. May 09/2024, Select Priority, H F H Inc, Delivery, Notes(red); 330608 same dates, Jireh Tools, Delivery, Notes; 330609 Arnold Contracting, Pick-up, Notes, row expanded — expanded sub-table: "Split Order" button (green, left); columns Qty Ordered, Product ID, Description, Line Item Notes; rows: checked 3 S158250 "#10x1-1/2" Wood Binder Screw Dark Red" Notes(green); unchecked 16 OSC "Outside Closures (Large Tab) 9"x36" Tuff Rib" Notes; unchecked 12 SL8250 "Mulco Supra Expert Sealant Dark Red (Country Red 170)" Notes(green); checked 150 1412 "1x4x12ft Rough Cut" Notes; then rows: 330615 DAP Roofing Inc. Delivery; 330616 Arnold Contracting Pick-up Notes(green); 330617 Ontario Metal Products Ltd. Fri.May10 Delivery; 330618 A.W.C. Delivery Notes(green); 330622 Ontario Metal Products Ltd. Fri.May10 Delivery; 330629 Ontario Metal Products Ltd. Fri.May10 Delivery; 330631 Jireh Tools Delivery; 330632 Upright Construction Pick-up
- Indicators: green checkboxes (some checked); Notes buttons red/green/plain; expanded row bordered black
- Dialog/popup: none
- Notes: outer row checkboxes unchecked; only line-item checkboxes within the expanded order are checked
- Verified: pass3

###### Screen (1111,233) — Accessories › Unscheduled tab, Set Date popup
- File: `p3_079_x1111_y233.png`
- Illustrates: "Clicking the Split Order button opens the calendar." (1113,231)
- Header/tabs: Same as Screen (1111,217) except: date picker modal overlaid
- Controls: modal calendar: "May 2024" with left/right chevrons, red "X" close button (top-right); weekday headers Su Mo Tu We Th Fr Sa; date grid 1-31 with "8" highlighted green (selected); "Cancel" button (white) and "Set Date" button (green)
- Table: background table same as Screen (1111,217), partially obscured
- Dialog/popup: Title "May 2024" (calendar popup), buttons Cancel / Set Date
- Verified: pass3

###### Screen (1111,248) — Accessories › Unscheduled tab (after Split Order — scheduled line items greyed)
- File: `p3_080_x1111_y248.png`
- Illustrates: "When scheduling part of an order, the scheduled line items should not disappear. Rather, they should be greyed out and completely uneditable in the Unscheduled tab." (1105,253)
- Header/tabs: Same as Screen (1111,217)
- Controls: Same as Screen (1111,217) except: "Split Order" button shown grey/italic (disabled); left-side row checkboxes for ALL rows (330605 through 330632, including 330609) now shown green/checked, not just 330615 onward
- Table: Same as Screen (1111,217) except: in the expanded 330609 sub-table, row "3 S158250" greyed out/italic (no checkbox), rows "16 OSC" and "12 SL8250" show green (available/unchecked) checkboxes, row "150 1412" greyed out/italic (no checkbox); an icon now also appears next to order # 330609
- Indicators: greyed/italic text = scheduled/uneditable items
- Dialog/popup: none
- Verified: pass3

###### Screen (1116,291) — Accessories Scheduled tab with Priorities set
- File: `p3_088_x1116_y291.png`
- Illustrates: "If orders have Priorities assigned to them then they are sorted primarily by Prep Date and secondarily by Priority. The Priorities are sorted by the hierarchy assigned to them." (1111,291); "Only the Manager can set Priorities" (1135,292)
- Header/tabs: Accessories, Scheduled tab active; date strip same as (1084,280)
- Table: Ship Date | Prep Date | Order # | Customer Name | Priority | Status | Ship Via | Accessories Location | Order Notes — rows: 330638 Ontario Metal Products Ltd. / "NOW" (red badge) / Not Started / Delivery / — / Notes(red); 330639 Ontario Metal Products Ltd. / "ASAP" (orange badge) / Not Started / Delivery / — / Notes; 330641 Upright Construction / "ASAP" (orange) / Not Started / Pick-up / — / Notes; 330643 DAP Roofing Inc. / "By 10:00" (yellow) / Not Started / Pick-up / — / Notes; 330648 Arnold Contracting / "By 3:00" (yellow) / Not Started / Delivery / — / Notes; then 330605 H F H Inc / Select Priority / Not Started / Delivery / — / Notes(red); 330608 Jireh Tools / Select Priority / Not Started / Delivery / — / Notes; 330609 Arnold Contracting (icon) / Select Priority / Not Started / Pick-up / — / Notes; 330615 DAP Roofing Inc. / Select Priority / Not Started / Delivery / — / Notes; 330616 Arnold Contracting / Select Priority / Not Started / Pick-up / — / Notes(green); 330618 A.W.C. / Select Priority / Not Started / Delivery / — / Notes; 13 rows visible (last row 330632 partially cut off at bottom)
- Indicators: Priority badges color-coded: red=NOW, orange=ASAP, yellow=By time
- Notes: prioritised orders listed first among same Prep Date.
- Verified: pass3

###### Screen (1266,195) — Completed order history for the past 90 days (Accessories, Packaging)
- File: `p3_098_x1266_y195.png`
- Illustrates: "This tab needs to primarily sort by Prep Date, and then by Priority." (1240,195) and "This tab needs to primarily sort by Prep Date and then by Priority." (1285,195)
- Same as Screen (1260,183) except: Priority column now populated: 330638 = red "NOW" badge; 330639 = orange "ASAP" badge; 330641 = orange "ASAP" badge; 330643 = yellow "By 10:00" badge; 330648 = yellow "By 3:00" badge; 330617 (Thu) = yellow "By 10:00" badge. Rows also renumbered/reordered to put prioritized orders first (330638, 330639, 330641, 330643, 330648 appear above 330605 etc.)
- Verified: pass3


#### Overdue Orders (Accessories)
- Overdue Orders (1092, 313)
- "Whenever there is an order that is overdue, the day tab that has that order should be highlighted in red. Also, the calendar should be highlighted in red." (1079, 315)
- "It is Thursday and there are orders that were scheduled for Wednesday that are not completed yet (overdue). The Wednesday tab should then be highlighted in red." (1103, 315)
- "When you click on the day that has overdue orders within it, then you would see the orders that are overdue highlighted in red." (1079, 325)
- "If there are overdue orders for a day that is not displayed in the week tabs then you should still see the highlighted calendar." (1103, 334)
- "If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again." (1069, 336)
- "Clicking this button opens the calendar." (1081, 337)
- "The date that has the overdue order should be highlighted in red within the calendar." (1103, 339)

##### Screens (6)

###### Screen (1084,315) — Accessories Scheduled tab, Wednesday tab overdue (red)
- File: `p3_091_x1084_y315.png`
- Illustrates: "It is Thursday and there are orders that were scheduled for Wednesday that are not completed yet (overdue). The Wednesday tab should then be highlighted in red." (1103,315)
- Header/tabs: Accessories, Scheduled active; calendar chip reads "Thursday May 09/2024" highlighted solid red; day tabs: Mon May 06 (1000/5000), Tue May 07 (1000/5000), Wed May 08 (1000/5000) highlighted solid red, Thu May 09 (1000/5000), Fri May 10 (1000/5000)
- Table: Ship Date | Prep Date | Order # | Customer Name | Priority | Status | Ship Via | Accessories Location | Order Notes — rows (Friday May 10/2024 ship dates, Prep Thu 09/2024): 330710 Arnold Contracting / Select Priority / Not Started / Pick-up / — / Notes(green); 330708 Jireh Tools / Not Started / Delivery / — / Notes; 330685 H F H Inc / Not Started / Delivery / — / Notes; 330692 DAP Roofing Inc. / Not Started / Pick-up / — / Notes; 330683 Arnold Contracting / Not Started / Delivery / — / Notes(green); 330684 DAP Roofing Inc. / Not Started / Delivery / — / Notes; 330701 Arnold Contracting / Not Started / Pick-up / — / Notes(green); 330702 Upright Construction / Not Started / Delivery / — / Notes
- Indicators: Red highlighted calendar chip and Wed tab denote overdue day
- Verified: pass3

###### Screen (1084,325) — Accessories Scheduled tab, overdue orders highlighted red (row-level)
- File: `p3_092_x1084_y325.png`
- Illustrates: overdue highlighting context (1103,315)/(1103,334)
- Header/tabs: Accessories, Scheduled active; calendar chip "Wednesday May 08/2024" pink/light-red highlighted, "Wed. May 08/2024 (1000/5000)" tab pink highlighted
- Table: Same columns as prior; rows: 330605 H F H Inc/Packaged/Delivery/B8/Notes(red) [not highlighted]; 330608 Jireh Tools/Packaged/Delivery/A15/Notes [not highlighted]; 330609 Arnold Contracting/Packaged/Pick-up/B6/Notes [not highlighted]; 330615 DAP Roofing Inc./In Progress/Delivery/C3/Notes — row highlighted red/pink; 330616 Arnold Contracting/Packaged/Pick-up/B3,B4/Notes(green) [not highlighted]; 330618 A.W.C./Not Started/Delivery/—/Notes — row highlighted red/pink; 330631 Jireh Tools/Not Started/Delivery/—/Notes(green) — row highlighted red/pink; 330632 Upright Construction/Packaged/Pick-up/A7/Notes [not highlighted]
- Indicators: Only incomplete (In Progress / Not Started) rows from the overdue day are highlighted red; Packaged rows are not
- Verified: pass3

###### Screen (1084,335) — Calendar date picker popup with overdue date highlighted
- File: `p3_093_x1084_y335.png`
- Illustrates: "If there are overdue orders for a day that is not displayed in the week tabs then you should still see the highlighted calendar." (1103,334); "The date that has the overdue order should be highlighted in red within the calendar." (1103,339)
- Header/tabs: Accessories, Scheduled active; calendar chip "Thursday May 09/2024" solid red; date tabs Mon-Fri all gray behind popup
- Controls: Calendar popup title "May 2024" with ‹ › nav arrows; Su Mo Tu We Th Fr Sa header; day "3" highlighted solid red; day "9" highlighted solid green (selected); Cancel button, "Set Date" button (green)
- Table: obscured by popup — same 8 rows as (1084,315)
- Indicators: Red date "3" = overdue day; green date "9" = currently selected date
- Dialog/popup: Calendar date-picker modal, buttons Cancel / Set Date
- Verified: pass3

###### Screen (1271,243) — Same modal, popup dismissed, Location field visible
- File: `p3_107_x1271_y243.png`
- Illustrates: same as Screen (1291,243)
- Same as Screen (1291,243) except: confirmation popup closed; "Accessories Location" field now shows "D5"; Package Weight still red "1,562.5 lbs."; Select Location, and weight box active; Create & Print, See Packages, Order Complete still greyed.
- Verified: pass3

###### Screen (1278,348) — Accessories Scheduled/Overdue tab, overdue rows highlighted red
- File: `p3_132_x1278_y348.png`
- Illustrates: "Overdue Accessories to be packaged need to be highlighted in red." (1271,348); "Example: If it is Thursday, May 09/2024 and there are Accessories from Wednesday, May 08/2024 that are not packaged yet, then we need those Wednesday Orders to be highlighted as overdue." (1270,349)
- Header/tabs: Department pill "Accessories"; sub-tab "Packaging"; top-right "Completed order history for the past 90 days"; search box
- Table: Columns — Prep Date | Order # | Priority | Customer Name | Truck | Ship Via | Status | Order Notes. First three rows (Wednesday, May 08/2024: 330618 A.W.C. Truck 104 Delivery "In Progress" orange badge, Notes button green; 330631 Jireh Tools Truck 103 Delivery "In Progress" orange, Notes grey; 330632 Upright Construction Truck N/A Pick-up "Not Started" grey, Notes grey) are boxed in a thick red highlight rectangle indicating overdue. Remaining rows (Thursday, May 09/2024, all "Not Started" grey status, Notes grey): 330617 Ontario Metal Products Ltd. Truck 102 Delivery; 330622 Ontario Metal Products Ltd. Truck 102 Delivery; 330629 Ontario Metal Products Ltd. Truck 102 Delivery; 330635 Jireh Tools (no truck) Delivery; 330636 Arnold Contracting Truck N/A Pick-up; 330639 DAP Roofing Inc. Truck 101 Delivery; 330642 Arnold Contracting Truck N/A Pick-up; 330643 A.W.C. Truck 104 Delivery.
- Indicators: red rectangle border/fill around the overdue Wednesday rows; Status shows orange "In Progress" pill for two rows vs grey "Not Started" for others; Priority column is blank for all rows.
- Notes: this differs from the plain "Not Started" table seen earlier — shows In Progress status and overdue highlighting.
- Verified: pass3

###### Screen (1291,243) — Weight-limit override confirmation popup
- File: `p3_106_x1291_y243.png`
- Illustrates: "If you try to 'Create & Print' when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit..." (1155,276)
- Header/tabs: background top-right button reads "Completed order history for the past 90 days"; left sidebar has a small hanger/coat icon next to a highlighted row
- Controls: order detail modal with table (same 7 line items as prior), several rows now show reduced Left To Package (OSC 0/28, ISC 18/28), Accessories Location field showing "D5"
- Table: same columns as Screen (1211,226); OSC row: Auto Fill, 28 ordered, 0 left; ISC row: Auto Fill, 28 ordered, 18 left
- Indicators: Package Weight box shown in red "1,562.5 lbs." (over limit); Select Location button green/enabled
- Dialog/popup: "The package you are trying to create is over the weight limit, are you sure you want to continue?" with buttons "No" (red) and "Yes, Create & Print" (green)
- Notes: last Auto Fill row (1412, 125/125) shown greyed/disabled
- Verified: pass3


#### Accessories Packaging tab (Manager view)
- "Manager's View of Accessories Packaging tab" (1089, 344)
- "The Packaging tab will be the same for both the Manager and the Worker." (1076, 348)
- Open question "?" (1092, 349)
- "This would be the Manager's view in the Accessories Packaging tab. The Manger would have the same authority as a worker." (1076, 350)
- "If the line item that was in the deleted package had a Status of Packaged already, then after deleting, that Status would have to change back to Not Started again. If some of that line item is still packaged, then it would have to change back to In Progress." (1199, 368)

##### Screens (17)

###### Screen (1084,347) — Accessories Packaging tab (order list, manager view)
- File: `p3_094_x1084_y347.png`
- Illustrates: no adjacent annotation
- Header/tabs: Accessories; Unscheduled / Scheduled / Packaging (active); Completed order history for the past 90 days; Search box
- Table: Prep Date | Order # | Priority | Customer Name | Truck | Ship Via | Status | Order Notes — rows: Wed May 08/2024 / 330605 / — / H F H Inc / — / Delivery / Not Started / Notes(red); Wed 08 / 330608 / — / Jireh Tools / — / Delivery / Not Started / Notes; Wed 08 / 330609 / — / Arnold Contracting / N/A / Pick-up / Not Started / Notes; Wed 08 / 330615 / — / DAP Roofing Inc. / — / Delivery / Not Started / Notes; Wed 08 / 330616 / — / Arnold Contracting / N/A / Pick-up / Not Started / Notes(green); Wed 08 / 330618 / — / A.W.C. / — / Delivery / Not Started / Notes(green); Wed 08 / 330631 / — / Jireh Tools / — / Delivery / Not Started / Notes; Wed 08 / 330632 / — / Upright Construction / N/A / Pick-up / Not Started / Notes; (orange divider line) Thu May 09/2024 / 330617 / — / Ontario Metal Products Ltd. / — / Delivery / Not Started / Notes; Thu 09 / 330622 / — / Ontario Metal Products Ltd. / — / Delivery / Not Started / Notes; Thu 09 / 330629 / — / Ontario Metal Products Ltd. / — / Delivery / Not Started / Notes; 11 rows visible (truncated)
- Indicators: gray "Not Started" pill throughout; orange divider line between Wednesday and Thursday groups; red/green dots on Notes buttons
- Notes: Truck column shows "N/A" for Pick-up rows, blank for Delivery rows.
- Verified: pass3

###### Screen (1160,272) — Packaging item modal — over-weight confirmation
- File: `p3_084_x1160_y272.png`
- Same as Screen (1182,272) — byte-identical duplicate capture (same confirmation dialog: "With this package the location will be over the weight limit, are you sure you want to continue?", buttons No / Yes, Create & Print).
- Verified: pass3

###### Screen (1160,284) — Packaging item modal — Location assigned (single, red)
- File: `p3_086_x1160_y284.png`
- Illustrates: "If you override the weight limit on a Location, then that Location name needs to be highlighted in red." (1155,291)
- Header/tabs: Same as (1160,272) modal
- Controls: Same line-item Auto Fill buttons as (1160,272); Create & Print button disabled (greyed); Select Location, See Packages, Order Complete enabled; "Package Weight" field placeholder (empty)
- Table: Same as (1160,272) except last two rows: 3/0/-/Packaged/SL8262/Mulco Supra Expert Sealant Black (950); 125/125/-/Not Started/1412/1x4x12ft Rough Cut
- Indicators: Accessories Location field shows single red badge "B6"
- Notes: Customer Name A.W.C., Order # 330618, PO# Barn Lean-to, Salesman Henry Wall; Ship Date Thursday, May 09/2024; Ship Via Delivery; Priority (blank)
- Verified: pass3

###### Screen (1171,259) — Accessories › Packaging tab, order detail modal
- File: `p3_081_x1171_y259.png`
- Illustrates: "Over riding the weight limit" (1170,270); "Adding a second location" (1183,270); "If you override the weight limit on a Location, then that Location name needs to be highlighted in red." (1155,291)
- Header/tabs: Accessories button; "Completed order history for the past 90 days"; sub-tab "Packaging"; Search...
- Controls: modal close "X" (red, top-right); each line item has "Auto Fill" button (green; greyed for packaged rows) or "Delete" (red); bottom buttons: "Select Location" (green), "Create & Print" (green), weight field "3.00 lbs.", "See Packages" (green); "Order Complete" (green, full width)
- Table: columns — Qty Ordered, Left To Package, Packaging, Status, ID, Description, Line Item Notes. Rows: 2/0/-/Packaged/S158262/"#10x1-1/2" Wood Binder Screw Black"/Notes; 1/0/-/Packaged/S28262/"#10x2" Wood Binder Screw Black"/Notes; 28/0/-/Packaged/OSC/"Outside Closures (Large Tab) 9"x36" Tuff Rib"/Notes; 28/0/-/Packaged/ISC/"Inside Closures (Small Tab) 9"x36" Tuff Rib"/Notes; 2/0/-/Packaged/ES/"Emseal 1"x1", 19.68' Roll"/Notes; 3/3/3/Not Started/SL8262/"Mulco Supra Expert Sealant Black (950)"/Notes; 125/125/-/Not Started/1412/"1x4x12ft Rough Cut"/Notes
- Indicators: green square = Packaged status, gray square = Not Started status
- Dialog/popup: modal (blue border) with order info footer: Customer Name A.W.C., Order#: 330618, PO#: Barn Lean-to, Salesman: Henry Wall, Ship Date: Thursday, May 09/2024, Ship Via: Delivery, Priority: (blank), Accessories Location "B6" highlighted red
- Notes: Accessories Location "B6" in red badge = weight-limit override
- Verified: pass3

###### Screen (1182,272) — Accessories › Packaging tab, weight-limit override confirmation dialog
- File: `p3_083_x1182_y272.png`
- Illustrates: "If you try to "Create & Print" when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit. If you agree, it will override the weight limit and create the package and print the label." (1155,276)
- Header/tabs: Same background as Screen (1171,259)
- Controls: same underlying modal controls, partially obscured by confirmation dialog
- Table: same line items as Screen (1171,259), obscured
- Dialog/popup: Body (bold, no separate title): "With this package the location will be over the weight limit, are you sure you want to continue?"; buttons "No" (red) and "Yes, Create & Print" (green)
- Verified: pass3

###### Screen (1182,284) — Packaging item modal — two Locations assigned
- File: `p3_087_x1182_y284.png`
- Illustrates: "Once you select a second Location, then the first Location needs to be highlighted in orange indicating to not put any more packages on that location." (1201,289)
- Header/tabs: Same as prior modal screens
- Controls: Same as (1160,272) — Auto Fill buttons, red Delete, Select Location, Create & Print (enabled, green), "3.00 lbs." field, See Packages, Order Complete
- Table: Same as (1160,272)
- Indicators: Accessories Location shows two badges: "B6" (orange) and "B8" (white/outlined)
- Notes: Customer Name A.W.C., Order # 330618, Ship Date Thursday, May 09/2024, Ship Via Delivery
- Verified: pass3

###### Screen (1197,357) — Packaging item modal — statuses reverted after package deletion
- File: `p3_095_x1197_y357.png`
- Illustrates: "If the line item that was in the deleted package had a Status of Packaged already, then after deleting, that Status would have to change back to Not Started again. If some of that line item is still packaged, then it would have to change back to In Progress." (1199,368)
- Header/tabs: Same as (1160,272) modal, tabs Accessories/Packaging in background
- Controls: Auto Fill buttons enabled for 6 rows, one Auto Fill greyed/disabled (row 5); Select Location, See Packages, Order Complete enabled (green); Create & Print greyed/disabled; "Package Weight" field placeholder empty
- Table: Qty Ordered | Left To Package | Packaging | Status | ID | Description | Line Item Notes — rows: 2/2/-/Not Started/S158262/"#10x1-1/2" Wood Binder Screw Black"; 1/1/-/Not Started/S28262/"#10x2" Wood Binder Screw Black"; 28/28/-/Not Started/OSC/Outside Closures (Large Tab) 9"x36" Tuff Rib; 28/28/-/Not Started/ISC/Inside Closures (Small Tab) 9"x36" Tuff Rib; 2/0/-/Packaged/ES/Emseal 1"x1", 19.68' Roll; 3/3/-/Not Started/SL8262/Mulco Supra Expert Sealant Black (950); 125/125/-/Not Started/1412/1x4x12ft Rough Cut
- Indicators: gray dots = Not Started (majority), one green dot = Packaged (Emseal row)
- Notes: Customer Name A.W.C., Order # 330618, Ship Date Thursday May 09/2024, Ship Via Delivery, Accessories Location "B6" single badge.
- Verified: pass3

###### Screen (1211,226) — Line item detail modal for order 330618
- File: `p3_101_x1211_y226.png`
- Illustrates: "Line Item Notes" (1237,224); "The Manager and Workers should be able to add and view Line Item Notes at any point in packaging..." (1230,226)
- Header/tabs: background shows Accessories/Packaging tabs, "Completed orders for the past 90 days" button, search box
- Controls: Modal with rounded blue border, red "X" close button top-right
- Table: Columns — (Auto Fill button) | Qty Ordered | Left To Package | Packaging | Backorder | Status | ID | Description | Line Item Notes. Rows: 2/2 S158262 "#10x1-1/2" Wood Binder Screw Black" Not Started, Notes; 1/1 S28262 "#10x2" Wood Binder Screw Black" Not Started, Notes(red); 28/28 OSC "Outside Closures (Large Tab) 9"x36" Tuff Rib" Not Started, Notes; 28/28 ISC "Inside Closures (Small Tab) 9"x36" Tuff Rib" Not Started, Notes(green); 2/2 ES "Emseal 1"x1", 19.68' Roll" Not Started, Notes; 3/3 SL8262 "Mulco Supra Expert Sealant Black (950)" Not Started, Notes; 125/125 1412 "1x4x12ft Rough Cut" Not Started, Notes
- Indicators: order info footer — Customer Name: A.W.C.; Order #: 330618; PO#: Barn Lean-to; Salesman: Henry Wall; Ship Date: Thursday, May 09/2024; Ship Via: Delivery; Priority: (blank); Location: (blank)
- Dialog/popup: this whole screen is the order-detail modal; bottom buttons (all disabled/greyed): Select Location, Create & Print, Package Weight (input box), See Packages, Order Complete
- Notes: All Auto Fill buttons green/enabled; Status column all grey "Not Started" boxes
- Verified: pass3

###### Screen (1211,240) — Line item detail modal for order 330618
- File: `p3_103_x1211_y240.png`
- Illustrates: same as Screen (1211,226)
- Same as Screen (1211,226) except: none — identical state, cropped slightly differently.
- Verified: pass3

###### Screen (1211,253) — Line item detail modal for order 330618 (reset state)
- File: `p3_108_x1211_y253.png`
- Illustrates: same context as Screen (1211,226)
- Same as Screen (1211,226) except: none — identical baseline state (all Not Started, all fields blank).
- Verified: pass3

###### Screen (1211,266) — Line item detail modal for order 330618 (baseline)
- File: `p3_112_x1211_y266.png`
- Illustrates: no directly adjacent annotation to this exact frame
- Header/tabs: background shows Accessories/Packaging tabs, "Completed orders for the past 90 days" button, search box
- Controls: Modal with rounded blue border, red "X" close button top-right
- Table: same as Screen (1211,226): all 7 line items shown with green "Auto Fill" buttons, all rows "Not Started", Packaging column empty
- Indicators: order info footer — Customer Name: A.W.C.; Order #: 330618; PO#: Barn Lean-to; Salesman: Henry Wall; Ship Date: Thursday, May 09/2024; Ship Via: Delivery; Priority: (blank); Location: (blank)
- Dialog/popup: order-detail modal; bottom buttons all disabled/greyed: Select Location, Create & Print, Package Weight (input box), See Packages, Order Complete
- Notes: identical baseline state to Screen (1211,226)/(1211,253) — nothing packaged yet
- Verified: pass3

###### Screen (1220,242) — Line Item Note popup (unread/red state)
- File: `p3_105_x1220_y242.png`
- Illustrates: "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red..." (1230,246)
- Header/tabs: Modal titled "Line Item Note"
- Controls: Text input "Leave your note here..." with green send-arrow button
- Table: n/a
- Indicators: red X icon (left) and green checkmark icon (right) below the note
- Dialog/popup: Note card — avatar "AM", author "Accessories Manager", timestamp "Tue, May 07/2024 10:42", email "accessoriesmanager@wiseline.ca", body text "Special instructions, talk to manager before packaging"
- Notes: card outlined, red X button appears active/highlighted (unread state)
- Verified: pass3

###### Screen (1220,255) — Line Item Note popup (read/green state)
- File: `p3_109_x1220_y255.png`
- Illustrates: same as Screen (1220,242)
- Same as Screen (1220,242) except: the red X icon is gone entirely, replaced by a single full-width solid green checkmark bar, indicating the note has been marked as read/handled.
- Verified: pass3

###### Screen (1220,268) — Line Item Notes stacked (unread + read)
- File: `p3_113_x1220_y268.png`
- Illustrates: "If a second note is added that has not been 'Checked-off' yet then the note should be highlighted in red again." (1229,273)
- Header/tabs: Modal titled "Line Item Note"
- Controls: text input "Leave your note here..." with send button
- Dialog/popup: two stacked note cards — 1) "AM" Accessories Manager, "Tue, May 07/2024 10:42", "accessoriesmanager@wiseline.ca", "Special instructions, talk to manager before packaging", full-width green checkmark bar (read, no red X shown); 2) "AW" Accessories Worker, "Tue, May 07/2024 2:31", "accessoriesworker@gmail.caom" [sic], "Not package due to low stock, waiting for supplier shipment.", with separate red X and green check icons (unread/new note)
- Notes: email has a typo "gmail.caom" as shown
- Verified: pass3

###### Screen (1244,228) — Line item detail modal for order 330618
- File: `p3_102_x1244_y228.png`
- Illustrates: same as Screen (1211,226)
- Same as Screen (1211,226) except: modal repositioned slightly (no background table visible/cropped differently); identical content otherwise.
- Verified: pass3

###### Screen (1244,242) — Line item detail modal, Delete state on ES row
- File: `p3_104_x1244_y242.png`
- Illustrates: "Auto Fill and/or Manually Entering Amounts to Package" (1261,240); "Input the amount you are going to package." (1249,240)
- Same as Screen (1211,226) except: ES row (2/2, Emseal) now shows red "Delete" button instead of "Auto Fill", with Packaging column = 2 (fully entered); Select Location button now enabled (green); Package Weight box shows "1.4 lbs."; Create & Print, See Packages, Order Complete still greyed/disabled.
- Verified: pass3

###### Screen (1329,250) — Order detail, Delete state, empty Location field
- File: `p3_138_x1329_y250.png`
- Illustrates: no directly adjacent annotation found in this x-range
- Same as order-detail modal (Screen 1211,226 baseline) except: OSC row shows red "Delete" button with Packaging=28; Location field blank; Create & Print, See Packages, Order Complete all greyed; Package Weight shows "1.12 lbs."
- Verified: pass3


#### Roles: Accessories Worker
- Accessories Worker (1247, 182)
- Accessories Packaging (1252, 182)
- "Accessories Workers should be able to see everything from here down." (1242, 183)
- "The Worker window should just be a list of the scheduled orders. A Worker should not need to select days of the week, it needs to just be a list. This lists needs to always sort primarily by Prep Date and then have a distinct line between the different days. See example: ----->" (1249, 187)
- Priorities (1263, 193)
- "This tab needs to primarily sort by Prep Date and then by Priority." (1285, 195) / "This tab needs to primarily sort by Prep Date, and then by Priority." (1240, 195)
- "Workers can NOT change Priorities" (1264, 197)
- "Even though this line item has a Priority assigned to it, it gets pushed down as it has a later Prep Date than the orders on top of it." (1285, 202)
- "The "Truck" data comes from Dispatch. If the order is not assigned to a Truck yet, then the column for that order would just stay blank. Whether the order has a Truck assigned to it or not, it makes no difference with regards to if the order can be packaged, it is just visual info." (1239, 204)
- "If the order is a Pick-up, then the Truck column would just automatically be assigned "N/A"" (1239, 209)
- Line Item Notes (1237, 224)
- "Clicking an order line opens the order and only shows accessories, not line items in other Departments (categories)." (1254, 225)
- "The Manager and Workers should be able to add and view Line Item Notes at any point in packaging. These notes are just within the app, they do not come from or push back to EBMS." (1230, 226)
- "It should only display the accessories for the order you are working on." (1240, 229)
- Update Image placeholder (1220, 233)
- "Clicking this button opens the Line Item Note." (1224, 238)
- Auto Fill and/or Manually Entering Amounts to Package (1261, 240)
- "Input the amount you are going to package." (1249, 240)
- "In the note, you can click the checkmark indicating that you've read the note and dealt with it accordingly, changing the note color from red to green. If you click the X, it will leave the note color red reminding you to deal with it later." (1230, 246)
- Update Image placeholder (1219, 246)
- Open questions "?" (1275, 246), (1300, 248)
- "When you're working on a new order (nothing has been Packaged for this order yet), then once there is an amount in the Packaging column, then the Select Location button becomes available." (1239, 249)
- "This will show the combined weight of the accessories you are planning to package. We need to be able to set a Max Weight per package (ex. 15 lbs)." (1264, 249)
- "Clicking the Auto Fill button would automatically fill whatever is in the Left To Package column into the Packaging column." (1324, 251)
- "After clicking an Auto Fill button, then it changes to a delete button, which, if clicked would remove the number from the Packaging column." (1324, 253)
- "If the package you are planning to package is heavier than the Max Weight, this box will be highlighted in red." (1283, 253)
- "Clicking this button opens the list of locations." (1246, 254)
- "If you try to "Create & Print" when the potential package is over the weight limit, you will get a pop up asking if you want to continue with the over weight package. If you agree it will override the weight limit and create the package and print the label." (1292, 254)
- Over Weight Packages (1264, 254)
- Open question "?" (1337, 255)
- "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into. Example: If a Worker in the Accessories department (category) goes to select a location, the location window needs to default to Accessories locations. That being said the Worker should still be able to choose a different department (category) to select a location there too." (1238, 258)
- "When selecting a location, you need to be able to just click on an available location." (1263, 258)
- Update Image placeholder (1219, 258)
- Location availability and how that availability is reset (1268, 260)
- "The Worker does NOT have to use the Auto Fill function, he needs to also be able to just click on a line item within the Packaging column and then manually type in any number between 1 and the number in the Left To Package column." (1324, 265)
- "When you open the location window on an order that already has a location, it needs to be highlighted." (1291, 266)
- Open question "?" (1339, 267)
- Multiple Locations (1264, 268)
- "Click on the location you are wanting to select." (1250, 268)
- Update Image placeholders (1281, 269), (1219, 273)
- "If a second note is added that has not been "Checked-off" yet then the note should be highlighted in red again." (1229, 273)
- "Clicking on a second Location needs to add that Location to the order as well, now this order has 2 Locations." (1282, 275)
- "If you try to "Create & Print" when the potential package will cause the Location to be over the weight limit, you will get a pop up asking if you want to continue and go over the Location weight limit. If you disagree, then you will need to chose another Location to be able to Create & Print." (1201, 276)
- Update Image placeholder (1252, 276)
- Open question "?" (1336, 278)
- "Once a location has been selected, then the Create & Print button becomes available." (1240, 278)
- "As locations are assigned to orders they grey out and become unavailable." (1311, 281)
- Over Weight on a Location (1234, 282)
- Update Image placeholder (1282, 283)
- "Clicking the Create & Print button will print the label, reset the Packaging column and update the Left To Package column." (1250, 283)
- "For locations to become available again (reset) they need to be removed from an order manually." (1305, 283) — or (1306, 285) — "When the last Accessories package has been scanned onto the truck by shipping, then after 15 mins. the location becomes available again (reset)." (1305, 286)
- "When only part of a line item is Packaged, then that line item's Status needs to be In Progress. So if the Left To Package column is NOT zero but NOT equel to the Qty Ordered column, then it would show In Progress." (1324, 286)
- Open question "?" (1338, 288)
- "Once you select a second Location, then the first Location needs to be highlighted in orange indicating to not put any more packages on that location." (1201, 289)
- Removing Locations (1278, 290)
- "Each department (category) will need to be assigned a unique number code to identify and keep labels separate between departments (categories). Example: Trim - 01 Rollforming - 02 Accessories - 03" (1232, 293)
- "The labels should be identified by a code made up of 3 parts. The 1st part is the department (category) ID, the second part is the order number and then the last part is the number of packages wrapped for the order, which just keeps counting up as you create packages." (1238, 294)
- Open question "?" (1260, 295)
- "The Order Complete button should only become available once the 1st package has been created." (1265, 296)
- "See Shipping Department" (1315, 296) — cross-reference back to Shipping.
- Update Image placeholder (1281, 298)
- "Once the first package has been created, then the See Packages button becomes available." (1263, 298)
- "To remove a Location from an order you would click on the Location you want to remove, this would give you a pop-up ask to confirm this action." (1275, 304)
- Packaging multiple line items in the same package (1250, 304)
- Open question "?" (1252, 310)
- Update Image placeholder (1280, 312)
- "Enter the amount you want to package from multiple item lines and print your label." (1241, 318)
- "Once the Left To Package column is zero, then that line item's Status needs to automatically change to Packaged and the Auto Fill button needs to grey out." (1239, 320)
- Open question "?" (1252, 322)
- Update Image placeholder (1281, 324)
- "If a worker wants to remove all the Locations from an order, then the worker needs to be forced to select a new Location. An order with existing packages HAS to have a Location." (1291, 329)
- Deleting a Package (1237, 330)
- "Clicking the See Packages button opens a list of the packages already on the order." (1257, 331)
- Reprinting Labels (1252, 331)
- "If something was packaged wrong, then we need to be able to delete that package and repackage the items that were in it." (1228, 333)
- Open question "?" (1220, 337)
- "Here you can reprint a label for an existing package." (1263, 337)
- Update Image placeholder (1280, 337)
- Open question "?" (1252, 337)
- "Clicking the Delete button would give you this pop up" (1220, 343)
- Overdue Accessories To Be Packaged (1267, 345)
- Completing an Order (1251, 347)
- "Overdue Accessories to be packaged need to be highlighted in red." (1271, 348)
- "Example: If it is Thursday, May 09/2024 and there are Accessories from Wednesday, May 08/2024 that are not packaged yet, then we need those Wednesday Orders to be highlighted as overdue." (1270, 349)
- Open question "?" (1218, 349), (1286, 352), (1255, 353)
- "Once the Worker is satisfied with everything on the order then he would click the Order Complete button. He would get a pop-up to confirm this action. Once confirmed the order disappears from the Packaging tab and appears in the Completed Orders tab." (1263, 354)
- "Clicking Yes will delete the package and put the number of pcs. that were in the package back into the Left To Package column." (1217, 359)
- Open question "?" (1207, 361)
- "Clicking the Complete Order button would give you this pop up" (1254, 361)
- Open question "?" (1229, 363)
- "Deleting a package will make that package number invalid, if anyone tries to scan the bar code on the deleted label will need to get a messge that this package has been deleted." (1216, 364)
- Open question "?" (1254, 367)
- "Clicking Yes would make this order disappear out of the Wrapping tab and appear in the Completed Orders tab and create a manufaturing batch" (1258, 373)

##### Screens (24)

###### Screen (1244,205) — Completed order history for the past 90 days (Accessories, Packaging)
- File: `p3_099_x1244_y205.png`
- Illustrates: "The 'Truck' data comes from Dispatch. If the order is not assigned to a Truck yet, then the column for that order would just stay blank..." (1239,204)
- Same as Screen (1260,183) except: Truck column now populated with numbers for some rows: 330608=103, 330618=104, 330631=103, 330617(Thu)=102, 330622=102, 330629=102 (others blank or N/A for pick-ups)
- Verified: pass3

###### Screen (1244,215) — Completed order history for the past 90 days (Accessories, Packaging)
- File: `p3_100_x1244_y215.png`
- Illustrates: "If the order is a Pick-up, then the Truck column would just automatically be assigned 'N/A'" (1239,209)
- Same as Screen (1244,205) except: row 330618 is highlighted with a blue selection border/outline (selected row).
- Verified: pass3

###### Screen (1209,332) — See Packages modal, two packages listed
- File: `p3_129_x1209_y332.png`
- Illustrates: "Clicking the See Packages button opens a list of the packages already on the order." (1257,331)
- Header/tabs: modal title area shows Customer Name: A.W.C.; Order #: 330618; PO: Barn Lean-to; Location: B6
- Controls: red "X" close top-right
- Table: Columns — Packages | Qty / Description | (actions). Rows: "03 - 330618 - 01" | "2 - ES" | Delete (red) / Reprint; "03 - 330618 - 02" | "28 - OSC / 28 - ISC" | Delete (red) / Reprint
- Indicators: remaining rows in the packages list are empty/blank placeholder bars
- Dialog/popup: this is the "See Packages" list modal
- Notes: background shows order-detail modal with Auto Fill buttons for remaining line items.
- Verified: pass3

###### Screen (1209,345) — Delete-package confirmation popup
- File: `p3_131_x1209_y345.png`
- Illustrates: "Clicking the Delete button would give you this pop up" (1220,343); "Clicking Yes will delete the package and put the number of pcs. that were in the package back into the Left To Package column." (1217,359)
- Same as Screen (1209,332) except: confirmation popup overlaid: "Are you sure you want to delete this package?" with buttons "No" (red) and "Yes, Delete Package" (green).
- Verified: pass3

###### Screen (1222,357) — See Packages modal, package deleted state
- File: `p3_134_x1222_y357.png`
- Illustrates: "Deleting a package will make that package number invalid, if anyone tries to scan the bar code on the deleted label will need to get a messge that this package has been deleted." (1216,364)
- Same as Screen (1209,332) except: second row "03 - 330618 - 02" now greyed out with italic text "Deleted" replacing the qty/description and Reprint button removed; first row "03 - 330618 - 01" unchanged (Delete/Reprint buttons active).
- Verified: pass3

###### Screen (1238,284) — Printed package label #1 (ES)
- File: `p3_119_x1238_y284.png`
- Illustrates: relates to "Once the first package has been created, then the See Packages button becomes available." (1263,298)
- Header/tabs: none (standalone label graphic)
- Controls: none (static label)
- Table: n/a
- Indicators: n/a
- Dialog/popup: label card — "Customer: A.W.C.", "Sales Order #: 330618", "PO #: Barn Lean-to", "2 - ES", "Weight: 1.4 lbs.", barcode, code "03 - 330618 - 01"
- Notes: label format is code = department-orderNumber-packageSequence (03=Accessories, 330618=order, 01=first package); standalone label graphic, no header/controls.
- Verified: pass3

###### Screen (1238,306) — Printed package label #2 (OSC/ISC)
- File: `p3_122_x1238_y306.png`
- Illustrates: relates to package list in order detail (package 03-330618-... labels)
- Header/tabs: none (standalone label graphic)
- Controls: none (static label)
- Table: n/a
- Indicators: n/a
- Dialog/popup: label — "Customer: A.W.C.", "Sales Order #: 330618", "PO #: Barn Lean-to", "28 - OSC", "28 - ISC", "Weight: 2.52 lbs.", barcode, code "03 - 330618 - 02"
- Notes: not identical to Screen (1238,284) — that label is for package -01 (2-ES, 1.4 lbs.), this is package -02 (28-OSC/28-ISC, 2.52 lbs.).
- Verified: pass3

###### Screen (1244,291) — Order detail, ES fully Packaged, ready to reprint/close
- File: `p3_120_x1244_y291.png`
- Illustrates: no directly adjacent annotation found in this x-range (mislabeled as a location-picker popup in a prior transcription pass)
- Same as order-detail modal (Screen 1211,226 layout) except: ES row shows green "Packaged" status with 0 Left To Package, Auto Fill greyed for that row; other rows (S158262, S28262, OSC, ISC, SL8262, 1412) still Not Started (28/28 unpackaged for OSC/ISC, no Delete buttons); Accessories Location shows "B6"; Package Weight box empty (placeholder text, not a value); Create & Print greyed/disabled; Select Location, See Packages, Order Complete all green/enabled.
- Verified: pass3

###### Screen (1244,307) — Delete confirmations on two accessory rows, ES packaged
- File: `p3_124_x1244_y307.png`
- Illustrates: "If something was packaged wrong, then we need to be able to delete that package and repackage the items that were in it." (1228,333)
- Same as order-detail modal (Screen 1211,226 layout) except: OSC and ISC rows both show red "Delete" buttons with Packaging=28 each (fully packaged, both Not Started status oddly shown); ES row shows Packaged status (green dot); Create & Print, See Packages, Order Complete now green/enabled; Location field shows "B6"; Package Weight = "2.52 lbs."
- Verified: pass3

###### Screen (1244,307) — Same as above, duplicate coordinate, ID column shows OSC twice
- File: `p3_125_x1244_y307.png`
- Illustrates: same as Screen (1244,307) above
- Same as prior Screen (1244,307) except: table's second Delete row's ID column literally reads "OSC" again (instead of "ISC") in this capture — appears to be a labeling artifact in the source mockup; description still reads "Inside Closures (Small Tab) 9"x36" Tuff Rib".
- Verified: pass3

###### Screen (1244,319) — Order detail, three items Packaged
- File: `p3_127_x1244_y319.png`
- Illustrates: "Enter the amount you want to package from multiple item lines and print your label." (1241,318)
- Same as order-detail modal except: rows S158262 and S28262 still Not Started; OSC, ISC, ES rows show green "Packaged" status with 0 Left To Package; SL8262 and 1412 rows still Not Started; Location "B6"; Create & Print, See Packages, Order Complete enabled (green).
- Verified: pass3

###### Screen (1244,334) — See Packages modal (duplicate capture)
- File: `p3_130_x1244_y334.png`
- Illustrates: same as Screen (1209,332)
- Same as Screen (1209,332) except: nothing — identical.
- Verified: pass3

###### Screen (1244,350) — Order detail, all items Packaged, Location B6+D5
- File: `p3_133_x1244_y350.png`
- Illustrates: "Once the Worker is satisfied with everything on the order then he would click the Order Complete button. He would get a pop-up to confirm this action..." (1263,354)
- Same as order-detail modal except: all 7 line items show green "Packaged" status with 0 Left To Package; Auto Fill buttons greyed (used up) except two still active green; Location field shows two chips "B6" "D5"; Create & Print greyed; Select Location, See Packages, Order Complete all green/enabled.
- Verified: pass3

###### Screen (1244,362) — Order-complete confirmation popup
- File: `p3_135_x1244_y362.png`
- Illustrates: "Clicking the Complete Order button would give you this pop up" (1254,361)
- Same as order-detail modal (all items Packaged) except: confirmation popup overlaid: "Are you sure you are done with this order?" with buttons "No" (red) and "Yes" (green).
- Verified: pass3

###### Screen (1272,263) — Location picker modal, second highlighted location
- File: `p3_111_x1272_y263.png`
- Illustrates: "When you open the location window on an order that already has a location, it needs to be highlighted." (1291,266)
- Same as Screen (1244,256) except: B6 shown outlined green (previously selected/existing), same grid layout.
- Verified: pass3

###### Screen (1272,277) — Location picker, two locations selected (B6, B8)
- File: `p3_116_x1272_y277.png`
- Illustrates: "Clicking on a second Location needs to add that Location to the order as well, now this order has 2 Locations." (1282,275)
- Same as Screen (1244,256) except: both B6 and B8 are outlined in green (two locations selected/highlighted).
- Verified: pass3

###### Screen (1272,291) — Location picker, B6 & B8 selected (repeat)
- File: `p3_121_x1272_y291.png`
- Illustrates: same as Screen (1272,277)
- Same as Screen (1272,277) except: nothing — identical state.
- Verified: pass3

###### Screen (1272,306) — Location picker, remove-location confirmation popup
- File: `p3_123_x1272_y306.png`
- Illustrates: "To remove a Location from an order you would click on the Location you want to remove, this would give you a pop-up ask to confirm this action." (1275,304)
- Same as Screen (1272,277) except: B6 and B8 both still outlined green (selected), and a confirmation dialog is overlaid: "Are you sure you want to remove this location from this order?" with buttons "No" (red) and "Yes" (green).
- Verified: pass3

###### Screen (1272,319) — Location grid, only B6 selected
- File: `p3_126_x1272_y319.png`
- Illustrates: same as Screen (1272,277)
- Same as Screen (1272,277) except: only B6 is outlined green here; B8 shows the plain unselected style (not identical to (1272,277), which has both B6 and B8 green).
- Verified: pass3

###### Screen (1291,282) — Location field showing two chips (B6, B8)
- File: `p3_117_x1291_y282.png`
- Illustrates: same as Screen (1272,277)
- Header/tabs: cropped view of order-detail form fields only
- Controls: Ship Date: Thursday, May 09/2024; Ship Via: Delivery; Priority: (blank); Location: two chips "B6" "B8"; Package Weight box (greyed, "Package Weight" placeholder); See Packages (greyed); Order Complete (greyed)
- Table: n/a
- Notes: bottom edge shows a blue horizontal divider line
- Verified: pass3

###### Screen (1309,283) — Location picker grid, no selection highlighted
- File: `p3_118_x1309_y283.png`
- Illustrates: same as Screen (1272,277)
- Same as Screen (1272,277) except: neither B6 nor B8 is outlined green here — both show the plain black/white unselected style, i.e. no location is highlighted in this capture (not identical to (1272,277)).
- Verified: pass3

###### Screen (1329,261) — Numeric keypad entry popup for Packaging column
- File: `p3_139_x1329_y261.png`
- Illustrates: "The Worker does NOT have to use the Auto Fill function, he needs to also be able to just click on a line item within the Packaging column and then manually type in any number between 1 and the number in the Left To Package column." (1324,265)
- Same as Screen (1329,250) except: a numeric keypad popup is overlaid next to the ISC row's Packaging cell: input field "___ pcs." with green "Enter" button, keypad digits 1-9, 0, backspace arrow, and red "X" cancel button.
- Verified: pass3

###### Screen (1329,273) — Order detail, ISC partially packaged (10)
- File: `p3_140_x1329_y273.png`
- Illustrates: same context as Screen (1329,261), manual entry result
- Same as Screen (1329,250) except: ISC row Packaging column now shows "10" (manually entered); Package Weight updated to "1.62 lbs."
- Verified: pass3

###### Screen (1329,285) — Order detail, mixed statuses incl. In Progress
- File: `p3_141_x1329_y285.png`
- Illustrates: "When only part of a line item is Packaged, then that line item's Status needs to be In Progress. So if the Left To Package column is NOT zero but NOT equal to the Qty Ordered column, then it would show In Progress." (1324,286)
- Same as order-detail modal baseline except: OSC row Packaged (green, 0 left, Auto Fill greyed); ISC row Status shows orange "In Progress" badge with Left To Package = 18 (out of 28); other rows Not Started; Location field shows "B6"; Select Location, See Packages, Order Complete all green/enabled; Create & Print greyed.
- Verified: pass3


#### Completed Orders tab
- Completed Orders tab (1252, 374)
- "When you open the Completed Orders tab you should be able to view all the completed orders for the past 90 days. The completed orders should be displayed here and appear like this." (1264, 375)
- Open question "?" (1253, 379)
- "Clicking on an order opens it in this window" (1255, 388)
- "Within the Completed Orders tab we need to be able to see a list of the line items ordered and a list of the packages that were created for this order and what was put into each package." (1239, 390)
- Open question "?" (1254, 391)
- "Within the Completed Orders tab we need to be able to reprint package labels and change/add/remove locations if necessary." (1264, 393)

##### Screens (4)

###### Screen (1244,195) — Completed order history for the past 90 days (Accessories, Packaging)
- File: `p3_097_x1244_y195.png`
- Illustrates: no adjacent annotation (same as Screen (1260,183))
- Same as Screen (1260,183) except: nothing — identical table content and state.
- Verified: pass3

###### Screen (1244,377) — Completed Orders tab table
- File: `p3_136_x1244_y377.png`
- Illustrates: "When you open the Completed Orders tab you should be able to view all the completed orders for the past 90 days. The completed orders should be displayed here and appear like this." (1264,375)
- Header/tabs: Department pill "Accessories"; sub-tab "Packaging"; top-right "Completed order history for the past 90 days"; search box
- Table: Columns — Ship Date | Prep Date | Completed Date & Time | Order # | Customer Name | Accessory Location. Rows (14 visible): Thu May09/2024 | Wed May08/2024 | Wed May08/2024 9:16am | 330638 | Ontario Metal Products Ltd. | C5; Thu May09 | Wed May08 | Wed May08 9:28am | 330635 | Jireh Tools | A3; Thu May09 | Wed May08 | Wed May08 10:08am | 330639 | Upright Construction | B5; Thu May09 | Wed May08 | Wed May08 2:57pm | 330605 | H F H Inc | B10, E5; Thu May09 | Wed May08 | Wed May08 3:45pm | 330618 | A.W.C. | B6, D5 (row highlighted/selected with blue outline); Wed May08 | Tue May07 | Tue May07 10:21am | 330609 | Arnold Contracting | D2; Wed May08 | Tue May07 | Tue May07 1:42pm | 330615 | DAP Roofing Inc. | D3; Wed May08 | Tue May07 | Tue May07 4:22am | 330616 | Arnold Contracting | A1; Tue May07 | Mon May06 | Mon May06 10:18am | 330608 | A.W.C. | A7, A8; Tue May07 | Mon May06 | Mon May06 10:59am | 330631 | Jireh Tools | E2; Tue May07 | Mon May06 | Mon May06 11:37am | 330619 | A.W.C. | D1; Tue May07 | Mon May06 | Mon May06 2:24pm | 330636 | Jireh Tools | B15, B16; Mon May06 | Fri May03 | Fri May03 11:49am | 330632 | Jireh Tools | B1; Mon May06 | Fri May03 | Fri May03 12:56pm | 330638 | H F H Inc | A9; Mon May06 | Fri May03 | Fri May03 4:49pm | 330639 | Upright Construction | D3
- Notes: row 330618 (A.W.C.) selected/outlined in blue, matching detail modal shown in next screen.
- Verified: pass3

###### Screen (1244,389) — Completed Orders detail modal (order 330618)
- File: `p3_137_x1244_y389.png`
- Illustrates: "Clicking on an order opens it in this window" (1255,388); "Within the Completed Orders tab we need to be able to reprint package labels and change/add/remove locations if necessary." (1264,393)
- Header/tabs: same background list as Screen (1244,377), row 330618 highlighted blue
- Table: Left table — Qty Ordered | ID | Description | Line Item Notes: 2 S158262 "#10x1-1/2" Wood Binder Screw Black" Notes; 1 S28262 "#10x2" Wood Binder Screw Black" Notes; 28 OSC "Outside Closures (Large Tab) 9"x36" Tuff Rib" Notes; 28 ISC "Inside Closures (Small Tab) 9"x36" Tuff Rib" Notes; 2 ES "Emseal 1"x1", 19.68' Roll" Notes; 3 SL8262 "Mulco Supra Expert Sealant Black (950)" Notes; 125 1412 "1x4x12ft Rough Cut" Notes. Right table — Packages | Qty/Description | Reprint: 03-330618-01 "2 - ES" Reprint; 03-330618-02 "28-OSC / 28-ISC" Reprint; 03-330618-03 "2-S158262/1-S28262" Reprint; 03-330618-04 "3-SL8262" Reprint; 03-330618-05 "125-1412" Reprint
- Indicators: footer — Customer Name: A.W.C.; Order #: 330618; PO#: Barn Lean-to; Salesman: Henry Wall; Ship Date: Thursday, May 09/2024; Ship Via: Delivery; Priority: (blank); Accessories Location: chips "B6" "D5"
- Controls: single green button "Select Location" at bottom
- Dialog/popup: this whole screen is the completed-order detail modal
- Verified: pass3

###### Screen (1260,183) — Completed order history for the past 90 days (Accessories, Packaging)
- File: `p3_096_x1260_y183.png`
- Illustrates: "Within the Completed Orders tab we need to be able to see a list of the line items ordered and a list of the packages that were created for this order and what was put into each package." (1239,390); no directly adjacent annotation to this exact frame
- Header/tabs: Department pill "Accessories" (top-left); sub-tab "Packaging" below it (unselected/inactive style, grey); top-right button "Completed orders for the past 90 days" (grey pill); search box top-right ("Search...")
- Controls: none active beyond header buttons; search box empty
- Table: Columns — Prep Date | Order # | Priority | Customer Name | Truck | Ship Via | Status | Order Notes. Rows (12 visible, more below fold):
  1. Wednesday, May 08/2024 | 330605 | (blank) | H F H Inc | (blank) | Delivery | Not Started | Notes (red dot)
  2. Wednesday, May 08/2024 | 330608 | (blank) | Jireh Tools | (blank) | Delivery | Not Started | Notes
  3. Wednesday, May 08/2024 | 330609 (with icon) | (blank) | Arnold Contracting | N/A | Pick-up | Not Started | Notes
  4. Wednesday, May 08/2024 | 330615 | (blank) | DAP Roofing Inc. | (blank) | Delivery | Not Started | Notes
  5. Wednesday, May 08/2024 | 330616 | (blank) | Arnold Contracting | N/A | Pick-up | Not Started | Notes (green dot)
  6. Wednesday, May 08/2024 | 330618 | (blank) | A.W.C. | (blank) | Delivery | Not Started | Notes (green dot)
  7. Wednesday, May 08/2024 | 330631 | (blank) | Jireh Tools | (blank) | Delivery | Not Started | Notes
  8. Wednesday, May 08/2024 | 330632 | (blank) | Upright Construction | N/A | Pick-up | Not Started | Notes
  9. Thursday, May 09/2024 | 330617 | (blank) | Ontario Metal Products Ltd. | (blank) | Delivery | Not Started | Notes
  10. Thursday, May 09/2024 | 330622 | (blank) | Ontario Metal Products Ltd. | (blank) | Delivery | Not Started | Notes
  11. Thursday, May 09/2024 | 330629 | (blank) | Ontario Metal Products Ltd. | (blank) | Delivery | Not Started | Notes
- Indicators: orange horizontal divider line between the Wed May 08 group and Thu May 09 group; Notes buttons colored red or green per row (some plain white/grey = no note)
- Dialog/popup: none
- Notes: Status column shows grey "Not Started" pill for all rows; row 330609 has a small icon next to the order number (line-split indicator per annotation at 1130,249 re: split orders)
- Verified: pass3


### Unclear / open questions
- Many "?" markers on the board (purple/red circles) have no accompanying text — meaning unresolved at coordinates: (296,78), (1181,264), (1171,275), (1189,275), (1169,286), (1191,288), (1092,349), (1275,246), (1300,248), (1337,255), (1339,267), (1336,278), (1338,288), (1260,295), (1252,310), (1252,322), (1220,337), (1252,337), (1218,349), (1286,352), (1255,353), (1207,361), (1229,363), (1254,367), (1253,379), (1254,391).
- Numerous "Update Image" placeholders throughout indicate screenshots the prototype author intended to add but did not — actual UI appearance for those steps isn't documented in text.
- The Accessories sub-flow is spatially and logically connected to Shipping only via a "See Shipping Department" cross-reference (1315,296) and a routing arrow back up to "Accessories Packaging" — its exact relationship to the Shipping department flow (e.g., whether it's a separate department page mistakenly on this sheet, or genuinely part of Shipping) isn't stated explicitly.
- Two near-duplicate "For locations to become available again" notes at (1305,283) and (1305,286) joined by "or" (1306,285) — unclear if both conditions are alternatives or sequential.

#### Screens (1)

##### Screen (1043,260) — Order Note card, action taken (green state)
- File: `p3_070_x1043_y260.png`
- Illustrates: "Once an order has been scheduled, the Status should change to Not Started." (1103,281) — nearest, not a confident match
- Dialog/popup: Same card as Screen (1043,248): avatar "HW", "Henry Wall", "henrywall@wiseline.ca", "Tue. May 07/2024 10:42", body "Would like this order by 4:30 tomorrow" — except: red X icon absent, single full-width green bar shown in place of both action icons
- Notes: the "after" state of the note card once the green check was clicked.
- Verified: pass3



### Other screens on this page (4)

Screens whose annotated section did not match a heading above. Ordered by board position (x, then y).

#### Screen (1244,256) — Location picker modal (Warehouse #1 / Accessories)
- File: `p3_110_x1244_y256.png`
- Illustrates: "Department (category) specific. It needs to default to the locations for the department (category) the Workers is signed into..." (1238,258); "When selecting a location, you need to be able to just click on an available location." (1263,258)
- Header/tabs: Warehouse tabs "Warehouse #1" (active), "Warehouse #2", "Warehouse #3"; department sub-tabs "Trim", "Rollforming", "Accessories" (active/selected)
- Controls: red "X" close button top-right
- Table: Location groups as column headers: "1 of 1", "Rack", "Cart", "Lumber", "Long" — each with grid of location codes (A1-A6, B1-B18, C1-C4, D1-D10, E1-E10). Enabled (white/black) vs disabled (greyed) codes: A1,A3,A6 enabled / A2,A4,A5 disabled; B1-B3,B6,B8,B11-B13(err),B16,B17 pattern (see below); one location "B6" outlined in green (selected)
- Indicators: B6 has a green outline border indicating it is being selected/highlighted
- Dialog/popup: this is the "Select Location" modal itself, layered above the order-detail modal (visible faintly behind)
- Notes: background shows the order-detail modal (with Delete button on one row, Select Location green button)
- Verified: pass3


#### Screen (1244,270) — Location field showing B6, Create & Print enabled
- File: `p3_114_x1244_y270.png`
- Illustrates: "Click on the location you are wanting to select." (1250,268); "Once a location has been selected, then the Create & Print button becomes available." (1240,278)
- Same as order-detail modal (Screen 1211,226 layout) except: ES row shows red "Delete" button, Packaging=2; Location field now shows "B6"; Package Weight = "1.4 lbs."; Create & Print now green/enabled; Select Location green/enabled; See Packages and Order Complete still greyed.
- Verified: pass3


#### Screen (1272,331) — Location grid, forced-selection warning popup
- File: `p3_128_x1272_y331.png`
- Illustrates: "If a worker wants to remove all the Locations from an order, then the worker needs to be forced to select a new Location. An order with existing packages HAS to have a Location." (1291,329)
- Same as Screen (1272,277) except: B6 and B8 now shown with plain black outline (not green — deselected), and a popup is overlaid: "An order with existing packages needs to have at least 1 location, please select a location to continue." with single green "Ok" button.
- Verified: pass3


#### Screen (1309,270) — Location picker modal, all locations available, no selection
- File: `p3_115_x1309_y270.png`
- Illustrates: no directly adjacent annotation found in this x-range; likely a fresh open of the location picker for a different department/warehouse combo with no locations occupied
- Header/tabs: Warehouse tabs "Warehouse #1" (active), "Warehouse #2", "Warehouse #3"; department sub-tabs "Trim", "Rollforming", "Accessories" (active/selected)
- Controls: red "X" close button top-right; background order-detail modal not visible (this crop shows only the location grid)
- Table: Location groups as column headers: "1 of 1", "Rack", "Cart", "Lumber", "Long" — every code (A1-A6, B1-B18, C1-C4, D1-D10, E1-E10) shown enabled (white/black), none greyed out — differs from Screen (1244,256) where several codes are disabled
- Indicators: none of the location codes are outlined green — no location currently selected/highlighted
- Dialog/popup: this is the "Select Location" modal itself
- Notes: all locations available; no selection shown
- Verified: pass3


---
